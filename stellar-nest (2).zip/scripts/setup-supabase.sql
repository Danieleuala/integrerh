-- Integre RH - Script de Setup Automático para Supabase
-- Execute este script no SQL Editor do seu projeto Supabase

-- 1. Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Criar função para atualizar timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- 3. Tabela de funcionários
CREATE TABLE IF NOT EXISTS employees (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(50),
  position VARCHAR(255) NOT NULL,
  department VARCHAR(255) NOT NULL,
  manager_id UUID REFERENCES employees(id),
  join_date DATE NOT NULL,
  salary DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
  avatar TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Tabela de vagas
CREATE TABLE IF NOT EXISTS jobs (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  department VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  requirements TEXT[] DEFAULT '{}',
  benefits TEXT[] DEFAULT '{}',
  salary VARCHAR(100),
  type VARCHAR(20) DEFAULT 'full_time' CHECK (type IN ('full_time', 'part_time', 'contract')),
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('open', 'closed', 'draft')),
  created_date DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Tabela de candidaturas
CREATE TABLE IF NOT EXISTS job_applications (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
  candidate_name VARCHAR(255) NOT NULL,
  candidate_email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  location VARCHAR(255),
  resume_url TEXT,
  status VARCHAR(30) DEFAULT 'pending' CHECK (status IN ('pending', 'screening', 'phone_interview', 'technical_test', 'final_interview', 'approved', 'rejected')),
  applied_date DATE NOT NULL,
  current_stage INTEGER DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Tabela de treinamentos
CREATE TABLE IF NOT EXISTS trainings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(20) DEFAULT 'technical' CHECK (category IN ('technical', 'soft_skills', 'compliance', 'leadership')),
  duration VARCHAR(50) NOT NULL,
  format VARCHAR(20) DEFAULT 'online' CHECK (format IN ('online', 'presencial', 'hybrid')),
  instructor VARCHAR(255),
  start_date DATE NOT NULL,
  end_date DATE,
  status VARCHAR(20) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed', 'expired')),
  certificate TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. Tabela de avaliações
CREATE TABLE IF NOT EXISTS evaluations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  evaluator_id UUID REFERENCES employees(id),
  type VARCHAR(10) DEFAULT 'manager' CHECK (type IN ('360', 'self', 'manager')),
  period VARCHAR(50) NOT NULL,
  competencies JSONB NOT NULL DEFAULT '[]',
  overall_score DECIMAL(4,2) NOT NULL,
  feedback TEXT,
  date DATE NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'approved')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Tabela de documentos
CREATE TABLE IF NOT EXISTS documents (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(20) DEFAULT 'other' CHECK (type IN ('contract', 'id', 'certificate', 'other')),
  upload_date DATE DEFAULT CURRENT_DATE,
  size VARCHAR(20),
  url TEXT,
  storage_path TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. Criar triggers para updated_at
CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_job_applications_updated_at BEFORE UPDATE ON job_applications FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_trainings_updated_at BEFORE UPDATE ON trainings FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_evaluations_updated_at BEFORE UPDATE ON evaluations FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- 10. Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_employees_email ON employees(email);
CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_job_applications_job_id ON job_applications(job_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_employee_id ON evaluations(employee_id);

-- 11. Inserir dados iniciais
INSERT INTO employees (name, email, phone, position, department, join_date, salary, status, avatar) VALUES
('Ana Silva', 'ana.silva@integrerh.com', '(11) 99999-0001', 'Gerente de RH', 'Recursos Humanos', '2023-01-15', 8500.00, 'active', 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face'),
('Carlos Mendes', 'carlos.mendes@integrerh.com', '(11) 99999-0002', 'Gerente de TI', 'Tecnologia', '2022-03-10', 9200.00, 'active', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'),
('Maria Santos', 'maria.santos@integrerh.com', '(11) 99999-0003', 'Analista de Vendas', 'Vendas', '2023-06-20', 4500.00, 'active', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face')
ON CONFLICT (email) DO NOTHING;

INSERT INTO jobs (title, department, description, requirements, benefits, salary, type, status, created_date) VALUES
('Desenvolvedor Full Stack', 'Tecnologia', 'Responsável pelo desenvolvimento de aplicações web utilizando React, Node.js e PostgreSQL.', 
 ARRAY['React', 'Node.js', 'PostgreSQL', '3+ anos de experiência'], 
 ARRAY['Vale refeição', 'Plano de saúde', 'Home office flexível'], 
 'R$ 6.000 - R$ 8.000', 'full_time', 'open', '2024-01-15'),
('Analista de Marketing', 'Marketing', 'Desenvolver e executar estratégias de marketing digital para aumentar o engajamento.', 
 ARRAY['Marketing Digital', 'Google Analytics', 'Redes Sociais'], 
 ARRAY['Vale refeição', 'Plano de saúde'], 
 'R$ 4.000 - R$ 5.500', 'full_time', 'open', '2024-01-10');

-- 12. Habilitar Row Level Security
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainings ENABLE ROW LEVEL SECURITY;
ALTER TABLE evaluations ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- 13. Criar políticas básicas de segurança
CREATE POLICY "Enable read access for authenticated users" ON employees FOR SELECT TO authenticated USING (true);
CREATE POLICY "Enable read access for open jobs" ON jobs FOR SELECT USING (status = 'open');

-- ✅ Setup completo! Sua plataforma Integre RH está pronta para produção!
