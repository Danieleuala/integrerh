#!/bin/bash

# Integre RH - Deploy Script
# Usage: ./scripts/deploy.sh [environment] [target]
# Example: ./scripts/deploy.sh production vps

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
ENVIRONMENT=${1:-production}
TARGET=${2:-vps}
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo -e "${BLUE}🚀 Integre RH Deploy Script${NC}"
echo -e "${BLUE}Environment: ${ENVIRONMENT}${NC}"
echo -e "${BLUE}Target: ${TARGET}${NC}"
echo -e "${BLUE}Timestamp: ${TIMESTAMP}${NC}"
echo ""

# Function to print status
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Validate environment
if [[ ! "$ENVIRONMENT" =~ ^(development|staging|production)$ ]]; then
    print_error "Invalid environment. Use: development, staging, or production"
    exit 1
fi

# Check required tools
if ! command_exists npm; then
    print_error "npm is required but not installed."
    exit 1
fi

if ! command_exists node; then
    print_error "Node.js is required but not installed."
    exit 1
fi

# Load environment variables
if [ -f ".env.${ENVIRONMENT}" ]; then
    print_status "Loading environment variables from .env.${ENVIRONMENT}"
    export $(cat .env.${ENVIRONMENT} | grep -v '#' | awk '/=/ {print $1}')
else
    print_warning "No .env.${ENVIRONMENT} file found. Using default values."
fi

# Build process
build_application() {
    print_status "Installing dependencies..."
    npm ci --production=false

    print_status "Running type check..."
    npm run typecheck

    print_status "Running tests..."
    npm test

    print_status "Building client application..."
    npm run build:client

    print_status "Building server application..."
    npm run build:server

    print_status "Build completed successfully!"
}

# Deploy to VPS
deploy_to_vps() {
    print_status "Deploying to VPS..."

    if [ -z "$VPS_HOST" ] || [ -z "$VPS_USER" ]; then
        print_error "VPS_HOST and VPS_USER environment variables are required"
        exit 1
    fi

    # Create deployment directory
    local DEPLOY_DIR="/var/www/integre-rh"
    local BACKUP_DIR="/var/www/integre-rh-backup-${TIMESTAMP}"

    print_status "Creating deployment archive..."
    tar -czf "integre-rh-${TIMESTAMP}.tar.gz" \
        dist/ \
        public/ \
        package.json \
        package-lock.json \
        .env.${ENVIRONMENT} \
        nginx/ \
        docker-compose.yml

    print_status "Uploading to VPS..."
    scp "integre-rh-${TIMESTAMP}.tar.gz" "${VPS_USER}@${VPS_HOST}:/tmp/"

    print_status "Deploying on VPS..."
    ssh "${VPS_USER}@${VPS_HOST}" << EOF
        set -e
        
        # Backup current deployment
        if [ -d "${DEPLOY_DIR}" ]; then
            sudo mv "${DEPLOY_DIR}" "${BACKUP_DIR}"
        fi
        
        # Create new deployment directory
        sudo mkdir -p "${DEPLOY_DIR}"
        cd "${DEPLOY_DIR}"
        
        # Extract new version
        sudo tar -xzf "/tmp/integre-rh-${TIMESTAMP}.tar.gz" -C .
        
        # Install production dependencies
        sudo npm ci --production
        
        # Set proper permissions
        sudo chown -R www-data:www-data "${DEPLOY_DIR}"
        sudo chmod -R 755 "${DEPLOY_DIR}"
        
        # Copy environment file
        sudo cp ".env.${ENVIRONMENT}" .env
        
        # Restart services
        sudo systemctl restart integre-rh
        sudo systemctl restart nginx
        
        # Clean up
        rm "/tmp/integre-rh-${TIMESTAMP}.tar.gz"
        
        echo "✅ Deployment completed successfully!"
EOF

    # Clean up local archive
    rm "integre-rh-${TIMESTAMP}.tar.gz"
    print_status "VPS deployment completed!"
}

# Deploy with Docker
deploy_with_docker() {
    print_status "Deploying with Docker..."

    if ! command_exists docker; then
        print_error "Docker is required but not installed."
        exit 1
    fi

    # Build Docker image
    print_status "Building Docker image..."
    docker build -t "integre-rh:${TIMESTAMP}" .
    docker tag "integre-rh:${TIMESTAMP}" "integre-rh:latest"

    # Stop existing containers
    print_status "Stopping existing containers..."
    docker-compose down || true

    # Start new containers
    print_status "Starting new containers..."
    docker-compose up -d

    # Wait for health check
    print_status "Waiting for application to be ready..."
    for i in {1..30}; do
        if curl -f http://localhost:3001/api/health >/dev/null 2>&1; then
            print_status "Application is ready!"
            break
        fi
        if [ $i -eq 30 ]; then
            print_error "Application failed to start within 30 seconds"
            exit 1
        fi
        sleep 1
    done

    print_status "Docker deployment completed!"
}

# Deploy to Netlify
deploy_to_netlify() {
    print_status "Deploying to Netlify..."

    if ! command_exists netlify; then
        print_error "Netlify CLI is required. Install with: npm install -g netlify-cli"
        exit 1
    fi

    # Build for static hosting
    npm run build:client

    # Deploy
    if [ "$ENVIRONMENT" = "production" ]; then
        netlify deploy --prod --dir=dist/client
    else
        netlify deploy --dir=dist/client
    fi

    print_status "Netlify deployment completed!"
}

# Deploy to Vercel
deploy_to_vercel() {
    print_status "Deploying to Vercel..."

    if ! command_exists vercel; then
        print_error "Vercel CLI is required. Install with: npm install -g vercel"
        exit 1
    fi

    # Deploy
    if [ "$ENVIRONMENT" = "production" ]; then
        vercel --prod
    else
        vercel
    fi

    print_status "Vercel deployment completed!"
}

# Database migration
migrate_database() {
    print_status "Running database migrations..."

    if [ -z "$DB_HOST" ] || [ -z "$DB_USER" ] || [ -z "$DB_PASSWORD" ]; then
        print_warning "Database credentials not found. Skipping migration."
        return
    fi

    # Run migration script
    if [ -f "scripts/migrate-database.ts" ]; then
        npx tsx scripts/migrate-database.ts
        print_status "Database migration completed!"
    else
        print_warning "No migration script found."
    fi
}

# SSL Certificate setup
setup_ssl() {
    print_status "Setting up SSL certificate..."

    if [ -z "$DOMAIN" ]; then
        print_warning "DOMAIN not specified. Skipping SSL setup."
        return
    fi

    if command_exists certbot; then
        sudo certbot --nginx -d "$DOMAIN" -d "www.$DOMAIN" --non-interactive --agree-tos --email "$SSL_EMAIL"
        print_status "SSL certificate configured!"
    else
        print_warning "Certbot not found. Install certbot for automatic SSL setup."
    fi
}

# Health check
health_check() {
    print_status "Running health check..."

    local URL="${FRONTEND_URL:-http://localhost:3001}"
    
    for i in {1..10}; do
        if curl -f "${URL}/api/health" >/dev/null 2>&1; then
            print_status "Health check passed!"
            return 0
        fi
        sleep 2
    done

    print_error "Health check failed!"
    return 1
}

# Main deployment logic
main() {
    case $TARGET in
        "build-only")
            build_application
            ;;
        "vps")
            build_application
            deploy_to_vps
            migrate_database
            health_check
            ;;
        "docker")
            build_application
            deploy_with_docker
            migrate_database
            health_check
            ;;
        "netlify")
            build_application
            deploy_to_netlify
            ;;
        "vercel")
            build_application
            deploy_to_vercel
            ;;
        *)
            print_error "Invalid target. Use: vps, docker, netlify, vercel, or build-only"
            exit 1
            ;;
    esac

    echo ""
    print_status "🎉 Deployment completed successfully!"
    echo -e "${BLUE}Environment: ${ENVIRONMENT}${NC}"
    echo -e "${BLUE}Target: ${TARGET}${NC}"
    echo -e "${BLUE}Timestamp: ${TIMESTAMP}${NC}"
    
    if [ "$TARGET" != "build-only" ]; then
        echo ""
        echo -e "${GREEN}🔗 Application URLs:${NC}"
        echo -e "${BLUE}Frontend: ${FRONTEND_URL:-http://localhost:3001}${NC}"
        echo -e "${BLUE}API: ${FRONTEND_URL:-http://localhost:3001}/api${NC}"
        echo -e "${BLUE}Health: ${FRONTEND_URL:-http://localhost:3001}/api/health${NC}"
    fi
}

# Run main function
main "$@"
