// Test login functionality
const testLogin = async () => {
  try {
    const response = await fetch('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: 'admin@integrerh.com',
        password: 'admin123',
        role: 'admin'
      }),
    });

    const data = await response.json();
    console.log('Status:', response.status);
    console.log('Response:', data);

    if (response.ok) {
      console.log('✅ Login funcionando!');
      console.log('Token:', data.token ? 'Presente' : 'Ausente');
      console.log('User:', data.user ? data.user.name : 'Ausente');
    } else {
      console.log('❌ Login falhou:', data.error);
    }
  } catch (error) {
    console.log('❌ Erro na requisição:', error.message);
  }
};

testLogin();
