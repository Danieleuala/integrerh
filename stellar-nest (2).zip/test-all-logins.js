const axios = require('axios');

const API_URL = 'https://api.integrerh.com.br/api';

// Credenciais de teste disponíveis
const testUsers = [
  { email: 'admin@integrerh.com', password: 'admin123', role: 'admin', name: 'Administrator' },
  { email: 'rh@integrerh.com', password: 'rh123', role: 'hr', name: 'RH Manager' },
  { email: 'gestor@integrerh.com', password: 'gestor123', role: 'manager', name: 'Team Manager' },
  { email: 'funcionario@integrerh.com', password: 'func123', role: 'employee', name: 'Employee' },
  { email: 'candidato@integrerh.com', password: 'cand123', role: 'candidate', name: 'Candidate' }
];

async function testLogin(user) {
  try {
    console.log(`\n🔐 Testando login: ${user.email}`);
    
    const response = await axios.post(`${API_URL}/auth/login`, {
      email: user.email,
      password: user.password
    });

    if (response.status === 200 && response.data.token) {
      console.log(`✅ SUCESSO - ${user.name}`);
      console.log(`   📧 Email: ${user.email}`);
      console.log(`   🔑 Senha: ${user.password}`);
      console.log(`   👤 Role: ${user.role}`);
      console.log(`   🎫 Token: ${response.data.token.substring(0, 20)}...`);
      return { success: true, user, token: response.data.token };
    }
  } catch (error) {
    console.log(`❌ FALHA - ${user.email}`);
    console.log(`   Erro: ${error.response?.data?.error || error.message}`);
    return { success: false, user, error: error.message };
  }
}

async function testAllLogins() {
  console.log('🚀 INICIANDO TESTE DE TODOS OS LOGINS...\n');
  console.log(`📡 API URL: ${API_URL}`);
  
  const results = [];
  
  for (const user of testUsers) {
    const result = await testLogin(user);
    results.push(result);
    await new Promise(resolve => setTimeout(resolve, 500)); // Delay entre testes
  }
  
  console.log('\n' + '='.repeat(60));
  console.log('📊 RESUMO DOS TESTES:');
  console.log('='.repeat(60));
  
  const successful = results.filter(r => r.success);
  const failed = results.filter(r => !r.success);
  
  console.log(`\n✅ SUCESSOS: ${successful.length}/${results.length}`);
  successful.forEach(r => {
    console.log(`   • ${r.user.email} (${r.user.role})`);
  });
  
  if (failed.length > 0) {
    console.log(`\n❌ FALHAS: ${failed.length}/${results.length}`);
    failed.forEach(r => {
      console.log(`   • ${r.user.email} - ${r.error}`);
    });
  }
  
  console.log('\n' + '='.repeat(60));
  console.log('🎯 CREDENCIAIS FUNCIONANDO:');
  console.log('='.repeat(60));
  
  successful.forEach((r, index) => {
    console.log(`\n${index + 1}. ${r.user.name.toUpperCase()}`);
    console.log(`   📧 Email: ${r.user.email}`);
    console.log(`   🔑 Senha: ${r.user.password}`);
    console.log(`   👤 Perfil: ${r.user.role}`);
  });
  
  return results;
}

// Executar teste
testAllLogins().catch(console.error);
