// Teste local do app-production.js
const express = require('express');

// Simular o servidor de produção
const app = express();
app.use(express.json());

// Demo credentials (copiado do app-production.js)
const demoUsers = {
  'admin@integrerh.com': { password: 'admin123', role: 'admin', name: 'Administrator' },
  'rh@integrerh.com': { password: 'rh123', role: 'hr', name: 'RH Manager' },
  'gestor@integrerh.com': { password: 'gestor123', role: 'manager', name: 'Team Manager' },
  'funcionario@integrerh.com': { password: 'func123', role: 'employee', name: 'Employee' },
  'candidato@integrerh.com': { password: 'cand123', role: 'candidate', name: 'Candidate' }
};

// Endpoint de login (versão corrigida)
app.post('/api/auth/login', (req, res) => {
  console.log('🔐 Login attempt:', req.body.email);

  const { email, password, role } = req.body;
  const user = demoUsers[email];

  if (user && user.password === password && (!role || user.role === role)) {
    console.log('✅ Login successful for:', email);
    const token = 'demo-token-' + Date.now() + '-' + email;
    console.log('🎫 Generated token:', token);
    
    res.json({
      message: 'Login realizado com sucesso',
      token: token,
      user: {
        id: Date.now(),
        name: user.name,
        email: email,
        role: user.role,
        department: 'Demo Department',
        permissions: ['*']
      }
    });
  } else {
    console.log('❌ Login failed for:', email);
    res.status(401).json({ error: 'Credenciais inválidas' });
  }
});

// Endpoint de verify (versão corrigida)
app.get('/api/auth/verify', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  console.log('🔍 Verify attempt with token:', token);

  if (token && token.startsWith('demo-token-')) {
    // Extrair email do token
    const tokenParts = token.split('-');
    let userEmail = 'demo@integrerh.com';
    
    if (tokenParts.length > 3) {
      userEmail = tokenParts.slice(3).join('-');
    }
    
    console.log('📧 Extracted email from token:', userEmail);
    
    const user = demoUsers[userEmail];
    
    if (user) {
      console.log('✅ Token verification successful for:', userEmail);
      res.json({
        user: {
          id: Date.now(),
          name: user.name,
          email: userEmail,
          role: user.role,
          department: 'Demo Department',
          permissions: ['*']
        }
      });
    } else {
      console.log('⚠️ User not found, using fallback');
      res.json({
        user: {
          id: Date.now(),
          name: 'Demo User',
          email: userEmail,
          role: 'admin',
          permissions: ['*']
        }
      });
    }
  } else {
    console.log('❌ Invalid token');
    res.status(401).json({ error: 'Token inválido' });
  }
});

// Teste automatizado
async function testFlow() {
  console.log('\n🧪 INICIANDO TESTE AUTOMATIZADO...\n');
  
  const testUsers = [
    { email: 'rh@integrerh.com', password: 'rh123', role: 'hr' },
    { email: 'gestor@integrerh.com', password: 'gestor123', role: 'manager' }
  ];
  
  for (const testUser of testUsers) {
    console.log(`\n--- Testando ${testUser.email} ---`);
    
    // Simular login
    const loginData = {
      email: testUser.email,
      password: testUser.password,
      role: testUser.role
    };
    
    // Simular requisição
    const user = demoUsers[testUser.email];
    if (user && user.password === testUser.password) {
      const token = 'demo-token-' + Date.now() + '-' + testUser.email;
      console.log('✅ Login OK, token:', token);
      
      // Simular verify
      const tokenParts = token.split('-');
      const extractedEmail = tokenParts.slice(3).join('-');
      console.log('📧 Email extraído do token:', extractedEmail);
      
      if (extractedEmail === testUser.email) {
        console.log('✅ Verify OK - Email correto!');
      } else {
        console.log('❌ Verify FAIL - Email incorreto!');
      }
    } else {
      console.log('❌ Login FAIL');
    }
  }
  
  console.log('\n🏁 TESTE FINALIZADO\n');
}

// Executar teste
testFlow();
