-- Integre RH Database Schema for Supabase
-- Run this script in your Supabase SQL Editor to create all necessary tables

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable Row Level Security
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Employees table
CREATE TABLE employees (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(50),
  position VARCHAR(255) NOT NULL,
  department VARCHAR(255) NOT NULL,
  manager_id UUID REFERENCES employees(id),
  join_date DATE NOT NULL,
  salary DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave')),
  avatar TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Jobs table
CREATE TABLE jobs (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  department VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  requirements TEXT[] DEFAULT '{}',
  benefits TEXT[] DEFAULT '{}',
  salary VARCHAR(100),
  type VARCHAR(20) DEFAULT 'full_time' CHECK (type IN ('full_time', 'part_time', 'contract')),
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('open', 'closed', 'draft')),
  created_date DATE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Job Applications table
CREATE TABLE job_applications (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
  candidate_name VARCHAR(255) NOT NULL,
  candidate_email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  location VARCHAR(255),
  resume_url TEXT,
  status VARCHAR(30) DEFAULT 'pending' CHECK (status IN ('pending', 'screening', 'phone_interview', 'technical_test', 'final_interview', 'approved', 'rejected')),
  applied_date DATE NOT NULL,
  current_stage INTEGER DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Application Stage History table
CREATE TABLE application_stage_history (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  application_id UUID REFERENCES job_applications(id) ON DELETE CASCADE,
  stage VARCHAR(100) NOT NULL,
  date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  notes TEXT,
  evaluator VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Trainings table
CREATE TABLE trainings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(20) DEFAULT 'technical' CHECK (category IN ('technical', 'soft_skills', 'compliance', 'leadership')),
  duration VARCHAR(50) NOT NULL,
  format VARCHAR(20) DEFAULT 'online' CHECK (format IN ('online', 'presencial', 'hybrid')),
  instructor VARCHAR(255),
  start_date DATE NOT NULL,
  end_date DATE,
  status VARCHAR(20) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed', 'expired')),
  certificate TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Training Participants junction table
CREATE TABLE training_participants (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  training_id UUID REFERENCES trainings(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  enrolled_date DATE DEFAULT CURRENT_DATE,
  completion_date DATE,
  progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(training_id, employee_id)
);

-- Training Materials table
CREATE TABLE training_materials (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  training_id UUID REFERENCES trainings(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(20) DEFAULT 'pdf' CHECK (type IN ('video', 'pdf', 'quiz', 'presentation')),
  url TEXT,
  storage_path TEXT,
  duration VARCHAR(50),
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Evaluations table
CREATE TABLE evaluations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  evaluator_id UUID REFERENCES employees(id),
  type VARCHAR(10) DEFAULT 'manager' CHECK (type IN ('360', 'self', 'manager')),
  period VARCHAR(50) NOT NULL,
  competencies JSONB NOT NULL DEFAULT '[]',
  overall_score DECIMAL(4,2) NOT NULL,
  feedback TEXT,
  date DATE NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'approved')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Documents table
CREATE TABLE documents (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  employee_id UUID REFERENCES employees(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(20) DEFAULT 'other' CHECK (type IN ('contract', 'id', 'certificate', 'other')),
  upload_date DATE DEFAULT CURRENT_DATE,
  size VARCHAR(20),
  url TEXT,
  storage_path TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Announcements table
CREATE TABLE announcements (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  author VARCHAR(255) NOT NULL,
  date DATE DEFAULT CURRENT_DATE,
  priority VARCHAR(10) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  departments TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Feedbacks table
CREATE TABLE feedbacks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  from_id UUID REFERENCES employees(id),
  to_id UUID REFERENCES employees(id),
  message TEXT NOT NULL,
  type VARCHAR(15) DEFAULT 'positive' CHECK (type IN ('positive', 'constructive', 'goal')),
  competency VARCHAR(255),
  date DATE DEFAULT CURRENT_DATE,
  is_private BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User profiles table for authentication
CREATE TABLE user_profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  employee_id UUID REFERENCES employees(id),
  role VARCHAR(20) DEFAULT 'employee' CHECK (role IN ('rh_admin', 'manager', 'employee', 'candidate')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create triggers for updated_at
CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_job_applications_updated_at BEFORE UPDATE ON job_applications FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_trainings_updated_at BEFORE UPDATE ON trainings FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_training_participants_updated_at BEFORE UPDATE ON training_participants FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_training_materials_updated_at BEFORE UPDATE ON training_materials FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_evaluations_updated_at BEFORE UPDATE ON evaluations FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_announcements_updated_at BEFORE UPDATE ON announcements FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_feedbacks_updated_at BEFORE UPDATE ON feedbacks FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_employees_email ON employees(email);
CREATE INDEX idx_employees_department ON employees(department);
CREATE INDEX idx_employees_status ON employees(status);
CREATE INDEX idx_jobs_status ON jobs(status);
CREATE INDEX idx_jobs_department ON jobs(department);
CREATE INDEX idx_job_applications_job_id ON job_applications(job_id);
CREATE INDEX idx_job_applications_status ON job_applications(status);
CREATE INDEX idx_training_participants_training_id ON training_participants(training_id);
CREATE INDEX idx_training_participants_employee_id ON training_participants(employee_id);
CREATE INDEX idx_evaluations_employee_id ON evaluations(employee_id);
CREATE INDEX idx_evaluations_evaluator_id ON evaluations(evaluator_id);
CREATE INDEX idx_documents_employee_id ON documents(employee_id);
CREATE INDEX idx_feedbacks_from_id ON feedbacks(from_id);
CREATE INDEX idx_feedbacks_to_id ON feedbacks(to_id);

-- Enable Row Level Security (RLS)
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainings ENABLE ROW LEVEL SECURITY;
ALTER TABLE evaluations ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedbacks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Basic RLS policies (adjust based on your security requirements)
-- Users can view their own profile
CREATE POLICY "Users can view own profile" ON user_profiles FOR SELECT USING (auth.uid() = id);

-- HR Admins can view all data
CREATE POLICY "HR Admins can view all employees" ON employees FOR ALL USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'rh_admin')
);

CREATE POLICY "HR Admins can view all jobs" ON jobs FOR ALL USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'rh_admin')
);

-- Employees can view their own data
CREATE POLICY "Employees can view own data" ON employees FOR SELECT USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND employee_id = employees.id)
);

-- Managers can view their team's data
CREATE POLICY "Managers can view team data" ON employees FOR SELECT USING (
  EXISTS (SELECT 1 FROM user_profiles up 
          JOIN employees e ON up.employee_id = e.id 
          WHERE up.id = auth.uid() AND up.role = 'manager' AND employees.manager_id = e.id)
);

-- Public job viewing for candidates
CREATE POLICY "Anyone can view open jobs" ON jobs FOR SELECT USING (status = 'open');

-- Insert sample data
INSERT INTO employees (name, email, phone, position, department, join_date, salary, status, avatar) VALUES
('Ana Silva', 'ana.silva@integrerh.com', '(11) 99999-0001', 'Gerente de RH', 'Recursos Humanos', '2023-01-15', 8500.00, 'active', 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face'),
('Carlos Mendes', 'carlos.mendes@integrerh.com', '(11) 99999-0002', 'Gerente de TI', 'Tecnologia', '2022-03-10', 9200.00, 'active', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'),
('Maria Santos', 'maria.santos@integrerh.com', '(11) 99999-0003', 'Analista de Vendas', 'Vendas', '2023-06-20', 4500.00, 'active', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face'),
('Roberto Lima', 'roberto.lima@integrerh.com', '(11) 99999-0004', 'Desenvolvedor Sênior', 'Tecnologia', '2022-08-15', 7800.00, 'active', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face'),
('Julia Costa', 'julia.costa@integrerh.com', '(11) 99999-0005', 'Designer UX', 'Produto', '2023-02-01', 6200.00, 'on_leave', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face');

-- Update manager relationships
UPDATE employees SET manager_id = (SELECT id FROM employees WHERE email = 'ana.silva@integrerh.com') 
WHERE email IN ('carlos.mendes@integrerh.com', 'maria.santos@integrerh.com');

UPDATE employees SET manager_id = (SELECT id FROM employees WHERE email = 'carlos.mendes@integrerh.com') 
WHERE email IN ('roberto.lima@integrerh.com', 'julia.costa@integrerh.com');

-- Insert sample jobs
INSERT INTO jobs (title, department, description, requirements, benefits, salary, type, status, created_date) VALUES
('Desenvolvedor Full Stack', 'Tecnologia', 'Responsável pelo desenvolvimento de aplica��ões web utilizando React, Node.js e PostgreSQL.', 
 ARRAY['React', 'Node.js', 'PostgreSQL', '3+ anos de experiência'], 
 ARRAY['Vale refeição', 'Plano de saúde', 'Home office flexível'], 
 'R$ 6.000 - R$ 8.000', 'full_time', 'open', '2024-01-15'),
('Analista de Marketing', 'Marketing', 'Desenvolver e executar estratégias de marketing digital para aumentar o engajamento.', 
 ARRAY['Marketing Digital', 'Google Analytics', 'Redes Sociais'], 
 ARRAY['Vale refeição', 'Plano de saúde'], 
 'R$ 4.000 - R$ 5.500', 'full_time', 'open', '2024-01-10');

-- Insert sample trainings
INSERT INTO trainings (title, description, category, duration, format, instructor, start_date, end_date, status) VALUES
('Liderança e Gestão de Equipes', 'Curso completo sobre técnicas de liderança e gestão de pessoas.', 'leadership', '20 horas', 'online', 'Dra. Fernanda Alves', '2024-02-01', '2024-02-15', 'in_progress'),
('Segurança da Informação', 'Treinamento obrigatório sobre políticas de segurança.', 'compliance', '8 horas', 'online', null, '2024-01-20', '2024-01-25', 'completed');

-- Insert sample announcements
INSERT INTO announcements (title, content, author, date, priority, departments) VALUES
('Nova Política de Home Office', 'A partir de fevereiro, todos os colaboradores poderão trabalhar até 3 dias por semana em home office. Consulte o manual para mais detalhes.', 'Ana Silva', '2024-01-20', 'high', ARRAY['Todos']),
('Treinamento Obrigatório de Segurança', 'Todos os colaboradores devem completar o treinamento de segurança da informação até o final do mês.', 'Ana Silva', '2024-01-18', 'medium', ARRAY['Todos']);
