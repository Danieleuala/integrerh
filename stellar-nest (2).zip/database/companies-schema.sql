-- Tabela de Empresas/Clientes
CREATE TABLE companies (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  trade_name VARCHAR(255),
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(50),
  cnpj VARCHAR(18) UNIQUE,
  address TEXT,
  city VARCHAR(100),
  state VARCHAR(50),
  zip_code VARCHAR(10),
  website VARCHAR(255),
  logo_url TEXT,
  description TEXT,
  industry VARCHAR(100),
  size VARCHAR(20) DEFAULT 'small' CHECK (size IN ('small', 'medium', 'large', 'enterprise')),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'trial', 'suspended')),
  plan VARCHAR(20) DEFAULT 'basic' CHECK (plan IN ('basic', 'professional', 'enterprise')),
  max_employees INTEGER DEFAULT 50,
  max_jobs INTEGER DEFAULT 10,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de usuários das empresas (substitui parte da user_profiles)
CREATE TABLE company_users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  auth_user_id UUID REFERENCES auth.users(id),
  employee_id UUID REFERENCES employees(id),
  email VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(20) DEFAULT 'employee' CHECK (role IN ('admin', 'hr', 'manager', 'employee', 'candidate')),
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'pending')),
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(company_id, email)
);

-- Adicionar company_id às tabelas existentes
ALTER TABLE employees ADD COLUMN company_id UUID REFERENCES companies(id);
ALTER TABLE jobs ADD COLUMN company_id UUID REFERENCES companies(id);
ALTER TABLE trainings ADD COLUMN company_id UUID REFERENCES companies(id);
ALTER TABLE evaluations ADD COLUMN company_id UUID REFERENCES companies(id);
ALTER TABLE documents ADD COLUMN company_id UUID REFERENCES companies(id);
ALTER TABLE announcements ADD COLUMN company_id UUID REFERENCES companies(id);
ALTER TABLE feedbacks ADD COLUMN company_id UUID REFERENCES companies(id);

-- Criar índices
CREATE INDEX idx_companies_status ON companies(status);
CREATE INDEX idx_companies_email ON companies(email);
CREATE INDEX idx_company_users_company_id ON company_users(company_id);
CREATE INDEX idx_company_users_email ON company_users(email);
CREATE INDEX idx_employees_company_id ON employees(company_id);
CREATE INDEX idx_jobs_company_id ON jobs(company_id);

-- Trigger para updated_at
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_company_users_updated_at BEFORE UPDATE ON company_users FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Habilitar RLS
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE company_users ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para empresas
CREATE POLICY "Admins can view all companies" ON companies FOR ALL USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'admin')
);

CREATE POLICY "Company users can view own company" ON companies FOR SELECT USING (
  EXISTS (SELECT 1 FROM company_users WHERE auth_user_id = auth.uid() AND company_id = companies.id)
);

CREATE POLICY "Company users can view own user data" ON company_users FOR ALL USING (
  auth_user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Modificar políticas existentes para incluir company_id
DROP POLICY IF EXISTS "HR Admins can view all employees" ON employees;
CREATE POLICY "Users can view company employees" ON employees FOR ALL USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'admin') OR
  EXISTS (SELECT 1 FROM company_users WHERE auth_user_id = auth.uid() AND company_id = employees.company_id AND role IN ('admin', 'hr'))
);

DROP POLICY IF EXISTS "HR Admins can view all jobs" ON jobs;
CREATE POLICY "Users can view company jobs" ON jobs FOR ALL USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'admin') OR
  EXISTS (SELECT 1 FROM company_users WHERE auth_user_id = auth.uid() AND company_id = jobs.company_id AND role IN ('admin', 'hr', 'manager'))
);

-- Inserir empresa de demonstração
INSERT INTO companies (name, trade_name, email, phone, cnpj, address, city, state, zip_code, website, description, industry, size, status, plan, max_employees, max_jobs) VALUES
('Integre RH Demonstração', 'Integre RH Demo', 'demo@integrerh.com', '(11) 99999-9999', '12.345.678/0001-90', 'Av. Paulista, 1000', 'São Paulo', 'SP', '01310-100', 'https://integrerh.com', 'Empresa de demonstração do sistema Integre RH', 'Tecnologia', 'medium', 'active', 'professional', 100, 20);

-- Atualizar dados existentes para vincular à empresa demo
UPDATE employees SET company_id = (SELECT id FROM companies WHERE email = 'demo@integrerh.com');
UPDATE jobs SET company_id = (SELECT id FROM companies WHERE email = 'demo@integrerh.com');
UPDATE trainings SET company_id = (SELECT id FROM companies WHERE email = 'demo@integrerh.com');
