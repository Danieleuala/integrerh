-- Integre RH - Complete Database Schema for Supabase
-- Execute this script in your Supabase SQL editor to create all tables

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create employees table
CREATE TABLE IF NOT EXISTS employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    rg VARCHAR(15) NOT NULL,
    position VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    manager_id UUID REFERENCES employees(id),
    join_date DATE NOT NULL,
    termination_date DATE,
    termination_reason TEXT,
    ctps VARCHAR(20),
    salary DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'on_leave', 'terminated')),
    avatar TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    requirements TEXT[] DEFAULT '{}',
    benefits TEXT[] DEFAULT '{}',
    salary VARCHAR(100),
    type VARCHAR(20) DEFAULT 'full_time' CHECK (type IN ('full_time', 'part_time', 'contract')),
    status VARCHAR(20) DEFAULT 'open' CHECK (status IN ('open', 'closed', 'draft')),
    created_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create job applications table
CREATE TABLE IF NOT EXISTS job_applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    candidate_name VARCHAR(255) NOT NULL,
    candidate_email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    location TEXT,
    resume_url TEXT,
    status VARCHAR(30) DEFAULT 'pending' CHECK (status IN ('pending', 'screening', 'phone_interview', 'technical_test', 'final_interview', 'approved', 'rejected')),
    applied_date DATE DEFAULT CURRENT_DATE,
    current_stage INTEGER DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create application stage history table
CREATE TABLE IF NOT EXISTS application_stage_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    application_id UUID NOT NULL REFERENCES job_applications(id) ON DELETE CASCADE,
    stage VARCHAR(100) NOT NULL,
    date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    notes TEXT,
    evaluator VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create trainings table
CREATE TABLE IF NOT EXISTS trainings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(20) DEFAULT 'technical' CHECK (category IN ('technical', 'soft_skills', 'compliance', 'leadership')),
    duration VARCHAR(50) NOT NULL,
    format VARCHAR(20) DEFAULT 'online' CHECK (format IN ('online', 'presencial', 'hybrid')),
    instructor VARCHAR(255),
    start_date DATE NOT NULL,
    end_date DATE,
    status VARCHAR(20) DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed', 'expired')),
    certificate TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create training participants table
CREATE TABLE IF NOT EXISTS training_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    training_id UUID NOT NULL REFERENCES trainings(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    enrolled_date DATE DEFAULT CURRENT_DATE,
    completion_date DATE,
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(training_id, employee_id)
);

-- Create training materials table
CREATE TABLE IF NOT EXISTS training_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    training_id UUID NOT NULL REFERENCES trainings(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(20) DEFAULT 'video' CHECK (type IN ('video', 'pdf', 'quiz', 'presentation')),
    url TEXT,
    storage_path TEXT,
    duration VARCHAR(20),
    order_index INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create evaluations table
CREATE TABLE IF NOT EXISTS evaluations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    evaluator_id UUID NOT NULL REFERENCES employees(id),
    type VARCHAR(10) DEFAULT 'manager' CHECK (type IN ('360', 'self', 'manager')),
    period VARCHAR(50) NOT NULL,
    competencies JSONB NOT NULL DEFAULT '[]',
    overall_score DECIMAL(3,1) NOT NULL CHECK (overall_score >= 0 AND overall_score <= 10),
    feedback TEXT,
    date DATE DEFAULT CURRENT_DATE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'approved')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(20) DEFAULT 'other' CHECK (type IN ('contract', 'id', 'certificate', 'other')),
    upload_date DATE DEFAULT CURRENT_DATE,
    size VARCHAR(20),
    url TEXT,
    storage_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create feedbacks table
CREATE TABLE IF NOT EXISTS feedbacks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    from_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    to_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    type VARCHAR(20) DEFAULT 'positive' CHECK (type IN ('positive', 'constructive', 'goal')),
    competency VARCHAR(255),
    date DATE DEFAULT CURRENT_DATE,
    is_private BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create announcements table
CREATE TABLE IF NOT EXISTS announcements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author VARCHAR(255) NOT NULL,
    date DATE DEFAULT CURRENT_DATE,
    priority VARCHAR(10) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
    departments TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create employee history table
CREATE TABLE IF NOT EXISTS employee_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    date DATE DEFAULT CURRENT_DATE,
    type VARCHAR(20) NOT NULL CHECK (type IN ('hire', 'promotion', 'transfer', 'termination', 'status_change', 'salary_change')),
    description TEXT NOT NULL,
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create notifications table (for real-time updates)
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id VARCHAR(50) NOT NULL, -- Can be employee ID or 'all'
    type VARCHAR(20) DEFAULT 'info' CHECK (type IN ('info', 'success', 'warning', 'error')),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    related_module VARCHAR(50),
    related_id UUID,
    action_url TEXT,
    read BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create activity log table
CREATE TABLE IF NOT EXISTS activity_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    related_data JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department);
CREATE INDEX IF NOT EXISTS idx_employees_status ON employees(status);
CREATE INDEX IF NOT EXISTS idx_employees_manager ON employees(manager_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_department ON jobs(department);
CREATE INDEX IF NOT EXISTS idx_job_applications_job ON job_applications(job_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_status ON job_applications(status);
CREATE INDEX IF NOT EXISTS idx_training_participants_employee ON training_participants(employee_id);
CREATE INDEX IF NOT EXISTS idx_training_participants_training ON training_participants(training_id);
CREATE INDEX IF NOT EXISTS idx_training_materials_training ON training_materials(training_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_employee ON evaluations(employee_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_evaluator ON evaluations(evaluator_id);
CREATE INDEX IF NOT EXISTS idx_documents_employee ON documents(employee_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_to_employee ON feedbacks(to_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_from_employee ON feedbacks(from_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_user ON activity_log(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_module ON activity_log(module);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add updated_at triggers to all tables
CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_job_applications_updated_at BEFORE UPDATE ON job_applications FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_trainings_updated_at BEFORE UPDATE ON trainings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_training_participants_updated_at BEFORE UPDATE ON training_participants FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_training_materials_updated_at BEFORE UPDATE ON training_materials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_evaluations_updated_at BEFORE UPDATE ON evaluations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_feedbacks_updated_at BEFORE UPDATE ON feedbacks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_announcements_updated_at BEFORE UPDATE ON announcements FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert some initial demo data
INSERT INTO employees (id, name, email, phone, cpf, rg, position, department, address, join_date, salary, status) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'Ana Silva', 'ana.silva@integrerh.com', '(11) 99999-0001', '123.456.789-01', '12.345.678-9', 'Gerente de RH', 'Recursos Humanos', 'Rua das Flores, 123 - São Paulo, SP', '2023-01-15', 8500.00, 'active'),
('550e8400-e29b-41d4-a716-446655440002', 'Carlos Mendes', 'carlos.mendes@integrerh.com', '(11) 99999-0002', '987.654.321-01', '98.765.432-1', 'Gerente de TI', 'Tecnologia', 'Av. Paulista, 456 - São Paulo, SP', '2022-03-10', 9200.00, 'active'),
('550e8400-e29b-41d4-a716-446655440003', 'Maria Santos', 'maria.santos@integrerh.com', '(11) 99999-0003', '456.789.123-01', '45.678.912-3', 'Analista de Vendas', 'Vendas', 'Rua Augusta, 789 - São Paulo, SP', '2023-06-20', 4500.00, 'active');

-- Update manager relationships
UPDATE employees SET manager_id = '550e8400-e29b-41d4-a716-446655440001' WHERE id = '550e8400-e29b-41d4-a716-446655440002';
UPDATE employees SET manager_id = '550e8400-e29b-41d4-a716-446655440002' WHERE id = '550e8400-e29b-41d4-a716-446655440003';

-- Insert sample job
INSERT INTO jobs (id, title, department, description, requirements, benefits, salary, type, status) VALUES
('550e8400-e29b-41d4-a716-446655440101', 'Desenvolvedor Full Stack', 'Tecnologia', 'Responsável pelo desenvolvimento de aplicações web utilizando React, Node.js e PostgreSQL.', 
ARRAY['React', 'Node.js', 'PostgreSQL', '3+ anos de experiência'], 
ARRAY['Vale refeição', 'Plano de saúde', 'Home office flexível'], 
'R$ 6.000 - R$ 8.000', 'full_time', 'open');

-- Insert sample training
INSERT INTO trainings (id, title, description, category, duration, format, instructor, start_date, status) VALUES
('550e8400-e29b-41d4-a716-446655440201', 'Segurança da Informação', 'Treinamento obrigatório sobre políticas de segurança.', 'compliance', '8 horas', 'online', 'Prof. João Santos', '2024-01-20', 'completed');

-- Enroll employees in training
INSERT INTO training_participants (training_id, employee_id, progress) VALUES
('550e8400-e29b-41d4-a716-446655440201', '550e8400-e29b-41d4-a716-446655440001', 100),
('550e8400-e29b-41d4-a716-446655440201', '550e8400-e29b-41d4-a716-446655440002', 100),
('550e8400-e29b-41d4-a716-446655440201', '550e8400-e29b-41d4-a716-446655440003', 100);

-- Insert training materials
INSERT INTO training_materials (training_id, name, type, url, duration, order_index) VALUES
('550e8400-e29b-41d4-a716-446655440201', 'Fundamentos de Segurança', 'video', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', '25 min', 1),
('550e8400-e29b-41d4-a716-446655440201', 'Políticas de Senha', 'pdf', 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', '10 min', 2),
('550e8400-e29b-41d4-a716-446655440201', 'Teste de Conhecimento', 'quiz', NULL, '15 min', 3);

-- Insert sample evaluation
INSERT INTO evaluations (employee_id, evaluator_id, type, period, competencies, overall_score, feedback, status) VALUES
('550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440002', 'manager', '2024 - Q1', 
'[
  {"name": "Comunicação", "score": 8, "maxScore": 10},
  {"name": "Trabalho em Equipe", "score": 9, "maxScore": 10},
  {"name": "Proatividade", "score": 7, "maxScore": 10},
  {"name": "Conhecimento Técnico", "score": 8, "maxScore": 10}
]'::jsonb, 
8.0, 'Maria tem demonstrado excelente desempenho na área de vendas. Recomendo investir em treinamentos técnicos.', 'completed');

-- Insert sample feedback
INSERT INTO feedbacks (from_id, to_id, message, type, competency, is_private) VALUES
('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', 'Excelente trabalho na apresentação do projeto! Muito bem estruturada e clara.', 'positive', 'Comunicação', false),
('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', 'Sugiro melhorar a organização do tempo nas reuniões para ser mais eficiente.', 'constructive', 'Gestão de Tempo', true);

-- Insert sample announcement
INSERT INTO announcements (title, content, author, priority, departments) VALUES
('Nova Política de Home Office', 'A partir de fevereiro, todos os colaboradores poderão trabalhar até 3 dias por semana em home office. Consulte o manual para mais detalhes.', 'Ana Silva', 'high', ARRAY['Todos']),
('Treinamento Obrigatório de Segurança', 'Todos os colaboradores devem completar o treinamento de segurança da informação até o final do mês.', 'Ana Silva', 'medium', ARRAY['Todos']);

-- Create storage buckets (execute in Supabase Storage)
-- hr-documents: for employee documents
-- training-videos: for training video content
-- profile-avatars: for employee profile pictures

-- Enable Row Level Security (RLS)
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainings ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE evaluations ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedbacks ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

-- Create basic RLS policies (you may want to customize these based on your authentication system)
-- For now, allow all operations for authenticated users

-- Employees policies
CREATE POLICY "Allow all operations for authenticated users" ON employees FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON jobs FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON job_applications FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON trainings FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON training_participants FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON training_materials FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON evaluations FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON documents FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON feedbacks FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON announcements FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON notifications FOR ALL USING (true);
CREATE POLICY "Allow all operations for authenticated users" ON activity_log FOR ALL USING (true);

-- Enable real-time subscriptions
ALTER PUBLICATION supabase_realtime ADD TABLE employees;
ALTER PUBLICATION supabase_realtime ADD TABLE jobs;
ALTER PUBLICATION supabase_realtime ADD TABLE job_applications;
ALTER PUBLICATION supabase_realtime ADD TABLE trainings;
ALTER PUBLICATION supabase_realtime ADD TABLE training_participants;
ALTER PUBLICATION supabase_realtime ADD TABLE evaluations;
ALTER PUBLICATION supabase_realtime ADD TABLE feedbacks;
ALTER PUBLICATION supabase_realtime ADD TABLE announcements;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
