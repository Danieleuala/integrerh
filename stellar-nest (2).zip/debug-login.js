// Debug script to test login functionality
const testCredentials = [
  { email: 'admin@integrerh.com', password: 'admin123', role: 'admin' },
  { email: 'rh@integrerh.com', password: 'rh123', role: 'hr' },
  { email: 'gestor@integrerh.com', password: 'gestor123', role: 'manager' },
  { email: 'funcionario@integrerh.com', password: 'func123', role: 'employee' },
  { email: 'candidato@integrerh.com', password: 'cand123', role: 'candidate' }
];

// URLs to test
const urls = [
  'http://localhost:3001/api',  // Local dev server
  'http://localhost:8080/api',  // Local production server
  'https://api.integrerh.com.br/api' // Production
];

async function testLogin(baseUrl, credentials) {
  try {
    console.log(`\n🧪 Testing ${baseUrl}/auth/login`);
    console.log(`📧 Email: ${credentials.email}`);
    
    const response = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ SUCCESS: ${data.message}`);
      console.log(`👤 User: ${data.user?.name} (${data.user?.role})`);
      console.log(`🔑 Token: ${data.token ? 'Generated' : 'Missing'}`);
    } else {
      console.log(`❌ FAILED: ${data.error || 'Unknown error'}`);
      console.log(`📊 Status: ${response.status}`);
    }
    
    return { success: response.ok, data };
  } catch (error) {
    console.log(`💥 ERROR: ${error.message}`);
    return { success: false, error: error.message };
  }
}

async function testHealth(baseUrl) {
  try {
    console.log(`\n❤️ Testing ${baseUrl}/health`);
    const response = await fetch(`${baseUrl}/health`);
    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ Health OK: ${data.status}`);
    } else {
      console.log(`❌ Health FAILED`);
    }
  } catch (error) {
    console.log(`💥 Health ERROR: ${error.message}`);
  }
}

async function runTests() {
  console.log('🔍 INTEGRE RH LOGIN DEBUG TEST');
  console.log('================================');
  
  for (const url of urls) {
    console.log(`\n🌐 Testing: ${url}`);
    console.log('─'.repeat(50));
    
    // Test health endpoint
    await testHealth(url);
    
    // Test first credential
    await testLogin(url, testCredentials[0]);
  }
  
  console.log('\n📋 SUMMARY:');
  console.log('Check above results to identify which endpoint is working.');
  console.log('Expected behavior: Production should return success for demo credentials.');
}

// Run tests if this script is executed directly
if (typeof window === 'undefined') {
  runTests().catch(console.error);
}

module.exports = { testLogin, testHealth, testCredentials };
