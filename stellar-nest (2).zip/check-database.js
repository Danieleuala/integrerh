// Check SQLite database for users
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const bcrypt = require('bcryptjs');

async function checkDatabase() {
  try {
    console.log('🔍 Verificando banco de dados SQLite...');
    
    // Open database
    const db = await open({
      filename: './integrerh.db',
      driver: sqlite3.Database
    });

    // Check if users table exists
    const tables = await db.all(`
      SELECT name FROM sqlite_master 
      WHERE type='table' AND name='users'
    `);
    
    console.log(`📊 Tabelas encontradas: ${tables.length > 0 ? 'users existe' : 'users NÃO existe'}`);

    if (tables.length > 0) {
      // Get all users
      const users = await db.all('SELECT id, name, email, role, is_active FROM users');
      
      console.log(`\n👥 Usuários no banco: ${users.length}`);
      console.log('─'.repeat(50));
      
      for (const user of users) {
        console.log(`📧 ${user.email}`);
        console.log(`👤 Nome: ${user.name}`);
        console.log(`🎭 Role: ${user.role}`);
        console.log(`✅ Ativo: ${user.is_active ? 'Sim' : 'Não'}`);
        console.log('');
      }

      // Test password verification
      console.log('🔑 Testando senhas...');
      const adminUser = await db.get('SELECT * FROM users WHERE email = ?', ['admin@integrerh.com']);
      
      if (adminUser) {
        const isValid = await bcrypt.compare('admin123', adminUser.password);
        console.log(`🔐 Senha admin válida: ${isValid ? 'SIM' : 'NÃO'}`);
        
        if (!isValid) {
          console.log('⚠️  PROBLEMA: Senha hasheada não confere!');
          console.log(`Hash stored: ${adminUser.password.substring(0, 20)}...`);
        }
      } else {
        console.log('❌ Usuário admin não encontrado!');
      }
    }

    await db.close();
    
  } catch (error) {
    console.error('💥 Erro ao verificar banco:', error.message);
  }
}

checkDatabase();
