import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { getUserById } from "../database/queries/users";

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
    name: string;
    companyId?: string;
  };
}

export const authenticateToken = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1]; // Bearer TOKEN

    if (!token) {
      res.status(401).json({ error: "Token de acesso requerido" });
      return;
    }

    const secret = process.env.JWT_SECRET;
    if (!secret) {
      res.status(500).json({ error: "Configuração de segurança inválida" });
      return;
    }

    const decoded = jwt.verify(token, secret) as any;

    // Buscar usuário no banco de dados para validar se ainda existe e está ativo
    const user = await getUserById(decoded.userId);

    if (!user || user.status !== "active") {
      res.status(401).json({ error: "Usuário inválido ou inativo" });
      return;
    }

    req.user = {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      companyId: user.company_id,
    };

    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      res.status(403).json({ error: "Token inválido" });
    } else if (error instanceof jwt.TokenExpiredError) {
      res.status(403).json({ error: "Token expirado" });
    } else {
      console.error("Erro na autenticação:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  }
};

export const requireRole = (allowedRoles: string[]) => {
  return (
    req: AuthenticatedRequest,
    res: Response,
    next: NextFunction,
  ): void => {
    if (!req.user) {
      res.status(401).json({ error: "Usuário não autenticado" });
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({
        error: "Acesso negado. Permissões insuficientes.",
        requiredRoles: allowedRoles,
        userRole: req.user.role,
      });
      return;
    }

    next();
  };
};

export const generateToken = (
  userId: string,
  email: string,
  role: string,
): string => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET não configurado");
  }

  return jwt.sign(
    {
      userId,
      email,
      role,
      iat: Math.floor(Date.now() / 1000),
    },
    secret,
    {
      expiresIn: process.env.JWT_EXPIRES_IN || "7d",
      issuer: "integre-rh",
      audience: "integre-rh-users",
    },
  );
};

export const hashPassword = async (password: string): Promise<string> => {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
};

export const comparePassword = async (
  password: string,
  hash: string,
): Promise<boolean> => {
  return await bcrypt.compare(password, hash);
};

export const generateResetToken = (): string => {
  return jwt.sign(
    {
      type: "password_reset",
      timestamp: Date.now(),
    },
    process.env.JWT_SECRET!,
    { expiresIn: "1h" },
  );
};

export const verifyResetToken = (token: string): any => {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

    if (decoded.type !== "password_reset") {
      throw new Error("Token inválido");
    }

    return decoded;
  } catch (error) {
    throw new Error("Token de reset inválido ou expirado");
  }
};
