import { getDatabase } from "../connection";
import { RowDataPacket, ResultSetHeader } from "mysql2/promise";

export interface User extends RowDataPacket {
  id: string;
  company_id?: string;
  name: string;
  email: string;
  password: string;
  role: "rh_admin" | "manager" | "employee" | "candidate";
  phone?: string;
  avatar?: string;
  status: "active" | "inactive" | "pending";
  last_login?: Date;
  email_verified: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface CreateUserData {
  name: string;
  email: string;
  password: string;
  role: "rh_admin" | "manager" | "employee" | "candidate";
  phone?: string;
  companyName?: string;
}

export interface PasswordReset extends RowDataPacket {
  id: string;
  user_id: string;
  token: string;
  used: boolean;
  expires_at: Date;
  created_at: Date;
}

export const createUser = async (userData: CreateUserData): Promise<string> => {
  const db = getDatabase();

  try {
    await db.execute("START TRANSACTION");

    let companyId: string | null = null;

    // If creating an admin and company name is provided, create company first
    if (userData.role === "rh_admin" && userData.companyName) {
      const [companyResult] = await db.execute<ResultSetHeader>(
        "INSERT INTO companies (name, status) VALUES (?, ?)",
        [userData.companyName, "active"],
      );

      // Get the company ID
      const [companyRows] = await db.execute<RowDataPacket[]>(
        "SELECT id FROM companies WHERE name = ? ORDER BY created_at DESC LIMIT 1",
        [userData.companyName],
      );

      if (companyRows.length > 0) {
        companyId = companyRows[0].id;
      }
    }

    // Create user
    const [result] = await db.execute<ResultSetHeader>(
      `INSERT INTO users (company_id, name, email, password, role, phone, status, email_verified) 
       VALUES (?, ?, ?, ?, ?, ?, 'active', false)`,
      [
        companyId,
        userData.name,
        userData.email,
        userData.password,
        userData.role,
        userData.phone || null,
      ],
    );

    // Get the user ID
    const [userRows] = await db.execute<RowDataPacket[]>(
      "SELECT id FROM users WHERE email = ?",
      [userData.email],
    );

    const userId = userRows[0].id;

    await db.execute("COMMIT");
    return userId;
  } catch (error) {
    await db.execute("ROLLBACK");
    throw error;
  }
};

export const getUserByEmail = async (email: string): Promise<User | null> => {
  const db = getDatabase();

  const [rows] = await db.execute<User[]>(
    "SELECT * FROM users WHERE email = ? LIMIT 1",
    [email],
  );

  return rows.length > 0 ? rows[0] : null;
};

export const getUserById = async (id: string): Promise<User | null> => {
  const db = getDatabase();

  const [rows] = await db.execute<User[]>(
    "SELECT * FROM users WHERE id = ? LIMIT 1",
    [id],
  );

  return rows.length > 0 ? rows[0] : null;
};

export const updateUserPassword = async (
  userId: string,
  hashedPassword: string,
): Promise<boolean> => {
  const db = getDatabase();

  const [result] = await db.execute<ResultSetHeader>(
    "UPDATE users SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [hashedPassword, userId],
  );

  return result.affectedRows > 0;
};

export const updateUserLastLogin = async (userId: string): Promise<boolean> => {
  const db = getDatabase();

  const [result] = await db.execute<ResultSetHeader>(
    "UPDATE users SET last_login = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [userId],
  );

  return result.affectedRows > 0;
};

export const updateUserProfile = async (
  userId: string,
  updates: Partial<User>,
): Promise<boolean> => {
  const db = getDatabase();

  const allowedFields = ["name", "phone", "avatar"];
  const fields: string[] = [];
  const values: any[] = [];

  Object.keys(updates).forEach((key) => {
    if (
      allowedFields.includes(key) &&
      updates[key as keyof User] !== undefined
    ) {
      fields.push(`${key} = ?`);
      values.push(updates[key as keyof User]);
    }
  });

  if (fields.length === 0) {
    return false;
  }

  fields.push("updated_at = CURRENT_TIMESTAMP");
  values.push(userId);

  const [result] = await db.execute<ResultSetHeader>(
    `UPDATE users SET ${fields.join(", ")} WHERE id = ?`,
    values,
  );

  return result.affectedRows > 0;
};

export const updateUserStatus = async (
  userId: string,
  status: "active" | "inactive" | "pending",
): Promise<boolean> => {
  const db = getDatabase();

  const [result] = await db.execute<ResultSetHeader>(
    "UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [status, userId],
  );

  return result.affectedRows > 0;
};

export const getUsersByCompany = async (companyId: string): Promise<User[]> => {
  const db = getDatabase();

  const [rows] = await db.execute<User[]>(
    "SELECT * FROM users WHERE company_id = ? ORDER BY name ASC",
    [companyId],
  );

  return rows;
};

export const getUsersByRole = async (
  role: string,
  companyId?: string,
): Promise<User[]> => {
  const db = getDatabase();

  let query = "SELECT * FROM users WHERE role = ?";
  const params: any[] = [role];

  if (companyId) {
    query += " AND company_id = ?";
    params.push(companyId);
  }

  query += " ORDER BY name ASC";

  const [rows] = await db.execute<User[]>(query, params);

  return rows;
};

export const createPasswordReset = async (
  userId: string,
  token: string,
): Promise<boolean> => {
  const db = getDatabase();

  // Delete any existing reset tokens for this user
  await db.execute("DELETE FROM password_resets WHERE user_id = ?", [userId]);

  // Create new reset token
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

  const [result] = await db.execute<ResultSetHeader>(
    "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
    [userId, token, expiresAt],
  );

  return result.affectedRows > 0;
};

export const getPasswordReset = async (
  token: string,
): Promise<PasswordReset | null> => {
  const db = getDatabase();

  const [rows] = await db.execute<PasswordReset[]>(
    "SELECT * FROM password_resets WHERE token = ? AND used = false AND expires_at > NOW() LIMIT 1",
    [token],
  );

  return rows.length > 0 ? rows[0] : null;
};

export const deletePasswordReset = async (token: string): Promise<boolean> => {
  const db = getDatabase();

  const [result] = await db.execute<ResultSetHeader>(
    "DELETE FROM password_resets WHERE token = ?",
    [token],
  );

  return result.affectedRows > 0;
};

export const markPasswordResetAsUsed = async (
  token: string,
): Promise<boolean> => {
  const db = getDatabase();

  const [result] = await db.execute<ResultSetHeader>(
    "UPDATE password_resets SET used = true WHERE token = ?",
    [token],
  );

  return result.affectedRows > 0;
};

export const verifyUserEmail = async (userId: string): Promise<boolean> => {
  const db = getDatabase();

  const [result] = await db.execute<ResultSetHeader>(
    "UPDATE users SET email_verified = true, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
    [userId],
  );

  return result.affectedRows > 0;
};

export const deleteUser = async (userId: string): Promise<boolean> => {
  const db = getDatabase();

  try {
    await db.execute("START TRANSACTION");

    // Delete related records first
    await db.execute("DELETE FROM password_resets WHERE user_id = ?", [userId]);
    await db.execute("DELETE FROM activity_log WHERE user_id = ?", [userId]);
    await db.execute("DELETE FROM notifications WHERE user_id = ?", [userId]);

    // Delete user
    const [result] = await db.execute<ResultSetHeader>(
      "DELETE FROM users WHERE id = ?",
      [userId],
    );

    await db.execute("COMMIT");
    return result.affectedRows > 0;
  } catch (error) {
    await db.execute("ROLLBACK");
    throw error;
  }
};

export const getUserStats = async (companyId?: string): Promise<any> => {
  const db = getDatabase();

  let query = `
    SELECT 
      COUNT(*) as total,
      COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
      COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive,
      COUNT(CASE WHEN role = 'rh_admin' THEN 1 END) as admins,
      COUNT(CASE WHEN role = 'manager' THEN 1 END) as managers,
      COUNT(CASE WHEN role = 'employee' THEN 1 END) as employees,
      COUNT(CASE WHEN role = 'candidate' THEN 1 END) as candidates,
      COUNT(CASE WHEN last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 END) as active_last_30_days
    FROM users
  `;

  const params: any[] = [];

  if (companyId) {
    query += " WHERE company_id = ?";
    params.push(companyId);
  }

  const [rows] = await db.execute<RowDataPacket[]>(query, params);

  return rows[0];
};
