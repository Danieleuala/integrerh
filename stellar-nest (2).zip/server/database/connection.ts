import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

export interface DatabaseConfig {
  host: string;
  port: number;
  user: string;
  password: string;
  database: string;
  ssl?: boolean;
  connectionLimit: number;
  acquireTimeout: number;
  timeout: number;
}

const config: DatabaseConfig = {
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT || "3306"),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "integre_rh",
  ssl: process.env.DB_SSL === "true",
  connectionLimit: 10,
  acquireTimeout: 60000,
  timeout: 60000,
};

let pool: mysql.Pool;

export const initializeDatabase = async (): Promise<mysql.Pool> => {
  try {
    // Create connection pool
    pool = mysql.createPool({
      ...config,
      waitForConnections: true,
      queueLimit: 0,
    });

    // Test connection
    const connection = await pool.getConnection();
    console.log("✅ Database connection established");

    // Run initial setup if needed
    await runInitialSetup(connection);

    connection.release();
    return pool;
  } catch (error) {
    console.error("❌ Database connection failed:", error);
    throw error;
  }
};

const runInitialSetup = async (
  connection: mysql.PoolConnection,
): Promise<void> => {
  try {
    // Check if tables exist, create if not
    const [tables] = await connection.execute(
      `
      SELECT TABLE_NAME 
      FROM information_schema.TABLES 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users'
    `,
      [config.database],
    );

    if ((tables as any[]).length === 0) {
      console.log("📦 Creating database tables...");
      await createTables(connection);
      console.log("✅ Database tables created successfully");
    } else {
      console.log("✅ Database tables already exist");
    }
  } catch (error) {
    console.error("❌ Error in initial setup:", error);
    throw error;
  }
};

const createTables = async (
  connection: mysql.PoolConnection,
): Promise<void> => {
  // Companies table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS companies (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      name VARCHAR(255) NOT NULL,
      cnpj VARCHAR(18) UNIQUE,
      email VARCHAR(255),
      phone VARCHAR(20),
      address TEXT,
      logo_url TEXT,
      plan_type ENUM('free', 'basic', 'premium', 'enterprise') DEFAULT 'free',
      status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
      settings JSON,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
  `);

  // Users table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      company_id VARCHAR(36),
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password VARCHAR(255) NOT NULL,
      role ENUM('rh_admin', 'manager', 'employee', 'candidate') NOT NULL,
      phone VARCHAR(20),
      avatar TEXT,
      status ENUM('active', 'inactive', 'pending') DEFAULT 'active',
      last_login TIMESTAMP NULL,
      email_verified BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL,
      INDEX idx_email (email),
      INDEX idx_company_role (company_id, role)
    )
  `);

  // Employees table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS employees (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      user_id VARCHAR(36),
      company_id VARCHAR(36) NOT NULL,
      employee_code VARCHAR(50) UNIQUE,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      phone VARCHAR(20),
      cpf VARCHAR(14) UNIQUE,
      rg VARCHAR(15),
      position VARCHAR(255) NOT NULL,
      department VARCHAR(255) NOT NULL,
      address TEXT,
      manager_id VARCHAR(36),
      join_date DATE NOT NULL,
      termination_date DATE NULL,
      termination_reason TEXT NULL,
      ctps VARCHAR(20),
      salary DECIMAL(10,2),
      status ENUM('active', 'inactive', 'on_leave', 'terminated') DEFAULT 'active',
      avatar TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL,
      INDEX idx_company_status (company_id, status),
      INDEX idx_department (department),
      INDEX idx_manager (manager_id)
    )
  `);

  // Jobs table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS jobs (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      company_id VARCHAR(36) NOT NULL,
      title VARCHAR(255) NOT NULL,
      department VARCHAR(255) NOT NULL,
      description TEXT NOT NULL,
      requirements JSON,
      benefits JSON,
      salary_range VARCHAR(100),
      type ENUM('full_time', 'part_time', 'contract', 'internship') DEFAULT 'full_time',
      location VARCHAR(255),
      remote_option BOOLEAN DEFAULT FALSE,
      status ENUM('draft', 'open', 'closed', 'archived') DEFAULT 'draft',
      posted_date DATE,
      closing_date DATE,
      created_by VARCHAR(36),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
      INDEX idx_company_status (company_id, status),
      INDEX idx_department (department),
      FULLTEXT idx_title_desc (title, description)
    )
  `);

  // Job applications table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS job_applications (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      job_id VARCHAR(36) NOT NULL,
      candidate_name VARCHAR(255) NOT NULL,
      candidate_email VARCHAR(255) NOT NULL,
      candidate_phone VARCHAR(20),
      candidate_location VARCHAR(255),
      resume_url TEXT,
      cover_letter TEXT,
      status ENUM('pending', 'screening', 'phone_interview', 'technical_test', 'final_interview', 'approved', 'rejected') DEFAULT 'pending',
      current_stage INTEGER DEFAULT 0,
      applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      notes TEXT,
      score INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
      INDEX idx_job_status (job_id, status),
      INDEX idx_candidate_email (candidate_email),
      INDEX idx_applied_date (applied_date)
    )
  `);

  // Trainings table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS trainings (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      company_id VARCHAR(36) NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      category ENUM('technical', 'soft_skills', 'compliance', 'leadership', 'safety') DEFAULT 'technical',
      duration INTEGER, -- in minutes
      format ENUM('online', 'presential', 'hybrid') DEFAULT 'online',
      instructor VARCHAR(255),
      max_participants INTEGER,
      start_date DATE,
      end_date DATE,
      status ENUM('draft', 'scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'draft',
      certificate_template TEXT,
      created_by VARCHAR(36),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
      INDEX idx_company_status (company_id, status),
      INDEX idx_category (category),
      INDEX idx_dates (start_date, end_date)
    )
  `);

  // Training participants table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS training_participants (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      training_id VARCHAR(36) NOT NULL,
      employee_id VARCHAR(36) NOT NULL,
      enrolled_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      completion_date TIMESTAMP NULL,
      progress INTEGER DEFAULT 0,
      score INTEGER DEFAULT 0,
      certificate_url TEXT,
      status ENUM('enrolled', 'in_progress', 'completed', 'dropped') DEFAULT 'enrolled',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE CASCADE,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      UNIQUE KEY unique_training_employee (training_id, employee_id),
      INDEX idx_training_status (training_id, status),
      INDEX idx_employee_status (employee_id, status)
    )
  `);

  // Training materials table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS training_materials (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      training_id VARCHAR(36) NOT NULL,
      name VARCHAR(255) NOT NULL,
      type ENUM('video', 'pdf', 'quiz', 'presentation', 'document', 'link') DEFAULT 'document',
      file_url TEXT,
      file_size INTEGER,
      duration INTEGER, -- in minutes for videos
      order_index INTEGER DEFAULT 0,
      is_required BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (training_id) REFERENCES trainings(id) ON DELETE CASCADE,
      INDEX idx_training_order (training_id, order_index)
    )
  `);

  // Documents table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS documents (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      employee_id VARCHAR(36) NOT NULL,
      name VARCHAR(255) NOT NULL,
      type ENUM('contract', 'id', 'certificate', 'resume', 'medical', 'other') DEFAULT 'other',
      category VARCHAR(100),
      file_url TEXT NOT NULL,
      file_size INTEGER,
      mime_type VARCHAR(100),
      upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      expiry_date DATE NULL,
      is_confidential BOOLEAN DEFAULT FALSE,
      uploaded_by VARCHAR(36),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
      INDEX idx_employee_type (employee_id, type),
      INDEX idx_category (category),
      INDEX idx_expiry (expiry_date)
    )
  `);

  // Evaluations table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS evaluations (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      employee_id VARCHAR(36) NOT NULL,
      evaluator_id VARCHAR(36) NOT NULL,
      type ENUM('self', 'manager', '360', 'performance') DEFAULT 'performance',
      period VARCHAR(50) NOT NULL,
      competencies JSON,
      overall_score DECIMAL(3,2),
      feedback TEXT,
      goals JSON,
      status ENUM('draft', 'submitted', 'reviewed', 'approved', 'rejected') DEFAULT 'draft',
      evaluation_date DATE,
      due_date DATE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      FOREIGN KEY (evaluator_id) REFERENCES employees(id) ON DELETE CASCADE,
      INDEX idx_employee_period (employee_id, period),
      INDEX idx_evaluator (evaluator_id),
      INDEX idx_status_due (status, due_date)
    )
  `);

  // Feedback table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS feedback (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      from_employee_id VARCHAR(36) NOT NULL,
      to_employee_id VARCHAR(36) NOT NULL,
      type ENUM('positive', 'constructive', 'goal', 'general') DEFAULT 'general',
      subject VARCHAR(255),
      message TEXT NOT NULL,
      competency VARCHAR(255),
      is_private BOOLEAN DEFAULT FALSE,
      is_anonymous BOOLEAN DEFAULT FALSE,
      status ENUM('draft', 'sent', 'read', 'acknowledged') DEFAULT 'sent',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (from_employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      FOREIGN KEY (to_employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      INDEX idx_to_employee (to_employee_id),
      INDEX idx_from_employee (from_employee_id),
      INDEX idx_type_date (type, created_at)
    )
  `);

  // Password resets table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS password_resets (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      user_id VARCHAR(36) NOT NULL,
      token VARCHAR(500) NOT NULL,
      used BOOLEAN DEFAULT FALSE,
      expires_at TIMESTAMP NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_token (token),
      INDEX idx_expires (expires_at)
    )
  `);

  // Activity log table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS activity_log (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      user_id VARCHAR(36),
      action VARCHAR(100) NOT NULL,
      module VARCHAR(50) NOT NULL,
      description TEXT,
      ip_address VARCHAR(45),
      user_agent TEXT,
      metadata JSON,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
      INDEX idx_user_action (user_id, action),
      INDEX idx_module_date (module, created_at),
      INDEX idx_date (created_at)
    )
  `);

  // Notifications table
  await connection.execute(`
    CREATE TABLE IF NOT EXISTS notifications (
      id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
      user_id VARCHAR(36) NOT NULL,
      type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
      title VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      action_url TEXT,
      is_read BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_user_read (user_id, is_read),
      INDEX idx_date (created_at)
    )
  `);

  console.log("✅ All database tables created successfully");
};

export const getDatabase = (): mysql.Pool => {
  if (!pool) {
    throw new Error(
      "Database not initialized. Call initializeDatabase() first.",
    );
  }
  return pool;
};

export const closeDatabase = async (): Promise<void> => {
  if (pool) {
    await pool.end();
    console.log("🔒 Database connection closed");
  }
};

// Health check function
export const checkDatabaseHealth = async (): Promise<boolean> => {
  try {
    const db = getDatabase();
    await db.execute("SELECT 1");
    return true;
  } catch (error) {
    console.error("Database health check failed:", error);
    return false;
  }
};
