import sqlite3 from 'sqlite3';
import { Database, open } from 'sqlite';
import bcrypt from 'bcryptjs';
import path from 'path';

let db: Database<sqlite3.Database, sqlite3.Statement>;

export const initializeSQLiteDatabase = async () => {
  try {
    console.log('🔗 Inicializando banco SQLite...');
    
    // Open SQLite database
    db = await open({
      filename: path.join(process.cwd(), 'integrerh.db'),
      driver: sqlite3.Database
    });

    // Enable foreign keys
    await db.exec('PRAGMA foreign_keys = ON');

    // Create users table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('admin', 'hr', 'manager', 'employee', 'candidate', 'rh_admin')),
        department TEXT,
        phone TEXT,
        avatar TEXT,
        permissions TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        email_verified BOOLEAN DEFAULT FALSE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create password reset tokens table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        user_id TEXT NOT NULL,
        token TEXT NOT NULL,
        expires_at DATETIME NOT NULL,
        used BOOLEAN DEFAULT FALSE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // Create sessions table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS user_sessions (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        user_id TEXT NOT NULL,
        token_hash TEXT NOT NULL,
        ip_address TEXT,
        user_agent TEXT,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // Create jobs table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        department TEXT NOT NULL,
        location TEXT,
        salary_min REAL,
        salary_max REAL,
        employment_type TEXT DEFAULT 'full_time' CHECK (employment_type IN ('full_time', 'part_time', 'contract')),
        status TEXT DEFAULT 'open' CHECK (status IN ('open', 'closed', 'draft')),
        requirements TEXT,
        benefits TEXT,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create job applications table
    await db.exec(`
      CREATE TABLE IF NOT EXISTS job_applications (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        job_id TEXT NOT NULL,
        candidate_name TEXT NOT NULL,
        candidate_email TEXT NOT NULL,
        candidate_phone TEXT,
        resume_url TEXT,
        cover_letter TEXT,
        status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'interviewed', 'approved', 'rejected')),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
      )
    `);

    // Insert default admin user if not exists
    const adminUser = await db.get(
      'SELECT id FROM users WHERE email = ? AND role = ?',
      ['admin@integrerh.com', 'admin']
    );

    if (!adminUser) {
      const hashedPassword = await bcrypt.hash('admin123', 12);
      await db.run(`
        INSERT INTO users (name, email, password, role, department, permissions, email_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        'Administrador',
        'admin@integrerh.com',
        hashedPassword,
        'admin',
        'Administração',
        JSON.stringify(['*']),
        true
      ]);
      console.log('✅ Usuário admin padrão criado');
    }

    // Insert demo users
    const demoUsers = [
      { name: 'RH Manager', email: 'rh@integrerh.com', password: 'rh123', role: 'hr', department: 'Recursos Humanos' },
      { name: 'Gestor Equipe', email: 'gestor@integrerh.com', password: 'gestor123', role: 'manager', department: 'Tecnologia' },
      { name: 'Funcionário Demo', email: 'funcionario@integrerh.com', password: 'func123', role: 'employee', department: 'Tecnologia' },
      { name: 'Candidato Demo', email: 'candidato@integrerh.com', password: 'cand123', role: 'candidate', department: null }
    ];

    for (const user of demoUsers) {
      const existingUser = await db.get('SELECT id FROM users WHERE email = ?', [user.email]);
      
      if (!existingUser) {
        const hashedPassword = await bcrypt.hash(user.password, 12);
        const permissions = getUserPermissions(user.role);
        
        await db.run(`
          INSERT INTO users (name, email, password, role, department, permissions, email_verified)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          user.name,
          user.email,
          hashedPassword,
          user.role,
          user.department,
          JSON.stringify(permissions),
          true
        ]);
      }
    }

    // Insert demo jobs
    const mockJobs = [
      {
        title: 'Desenvolvedor Frontend React',
        description: 'Desenvolvedor especializado em React.js para projetos inovadores',
        department: 'Tecnologia',
        location: 'São Paulo, SP',
        salary_min: 8000,
        salary_max: 12000,
        employment_type: 'full_time',
        status: 'open',
        requirements: JSON.stringify(['React.js', 'TypeScript', 'CSS', 'Git']),
        benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'Home office'])
      },
      {
        title: 'Analista de RH',
        description: 'Analista para gestão de pessoas e processos de RH',
        department: 'Recursos Humanos',
        location: 'São Paulo, SP',
        salary_min: 6000,
        salary_max: 9000,
        employment_type: 'full_time',
        status: 'open',
        requirements: JSON.stringify(['Graduação em RH', 'Experiência em DP', 'Excel avançado']),
        benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'VR'])
      }
    ];

    for (const job of mockJobs) {
      const existingJob = await db.get(
        'SELECT id FROM jobs WHERE title = ? AND department = ?',
        [job.title, job.department]
      );
      
      if (!existingJob) {
        await db.run(`
          INSERT INTO jobs (title, description, department, location, salary_min, salary_max, 
                          employment_type, status, requirements, benefits)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          job.title,
          job.description,
          job.department,
          job.location,
          job.salary_min,
          job.salary_max,
          job.employment_type,
          job.status,
          job.requirements,
          job.benefits
        ]);
      }
    }

    console.log('✅ Banco SQLite inicializado com sucesso');
    return db;
  } catch (error) {
    console.error('❌ Erro ao inicializar SQLite:', error);
    throw error;
  }
};

const getUserPermissions = (role: string): string[] => {
  const permissions: Record<string, string[]> = {
    admin: ['*'],
    rh_admin: ['*'],
    hr: ['users.read', 'users.write', 'jobs.read', 'jobs.write', 'evaluations.read', 'evaluations.write', 'trainings.read', 'trainings.write'],
    manager: ['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write', 'trainings.read'],
    employee: ['profile.read', 'profile.write', 'evaluations.read', 'trainings.read'],
    candidate: ['jobs.read', 'applications.read', 'applications.write']
  };
  return permissions[role] || [];
};

export { db };
