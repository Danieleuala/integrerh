import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import morgan from 'morgan';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { body, validationResult } from 'express-validator';
import mysql from 'mysql2/promise';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Database connection pool
let db: mysql.Pool;

const createDbConnection = () => {
  db = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306'),
    user: process.env.DB_USER || 'integrerh_user',
    password: process.env.DB_PASSWORD || 'IntegrerhUser2024!',
    database: process.env.DB_NAME || 'integrerh_production',
    waitForConnections: true,
    connectionLimit: 20,
    queueLimit: 0,
    timeout: 60000,
    reconnect: true,
    multipleStatements: true
  });
};

// Initialize database with tables and data
const initializeDatabase = async () => {
  try {
    createDbConnection();
    
    console.log('🔗 Conectando ao MySQL...');
    const connection = await db.getConnection();
    console.log('✅ MySQL conectado com sucesso');
    
    // Create tables
    console.log('📋 Criando tabelas...');
    
    // Users table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'hr', 'manager', 'employee', 'candidate') NOT NULL,
        department VARCHAR(100),
        phone VARCHAR(20),
        avatar TEXT,
        permissions JSON,
        is_active BOOLEAN DEFAULT TRUE,
        email_verified BOOLEAN DEFAULT FALSE,
        last_login TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_email (email),
        INDEX idx_role (role),
        INDEX idx_active (is_active)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Password reset tokens table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        user_id VARCHAR(36) NOT NULL,
        token VARCHAR(255) NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        used BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_token (token),
        INDEX idx_expires (expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // User sessions table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS user_sessions (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        user_id VARCHAR(36) NOT NULL,
        token_hash VARCHAR(255) NOT NULL,
        ip_address VARCHAR(45),
        user_agent TEXT,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_token_hash (token_hash),
        INDEX idx_user_expires (user_id, expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Jobs table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS jobs (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        department VARCHAR(100) NOT NULL,
        location VARCHAR(255),
        salary_min DECIMAL(10,2),
        salary_max DECIMAL(10,2),
        employment_type ENUM('full_time', 'part_time', 'contract', 'internship') DEFAULT 'full_time',
        status ENUM('open', 'closed', 'draft', 'paused') DEFAULT 'open',
        requirements JSON,
        benefits JSON,
        skills JSON,
        experience_level ENUM('entry', 'mid', 'senior', 'lead') DEFAULT 'mid',
        remote_type ENUM('office', 'remote', 'hybrid') DEFAULT 'office',
        created_by VARCHAR(36),
        updated_by VARCHAR(36),
        published_at TIMESTAMP NULL,
        closed_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON SET NULL,
        FOREIGN KEY (updated_by) REFERENCES users(id) ON SET NULL,
        INDEX idx_status (status),
        INDEX idx_department (department),
        INDEX idx_employment_type (employment_type),
        INDEX idx_created_at (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Job applications table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS job_applications (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        job_id VARCHAR(36) NOT NULL,
        candidate_name VARCHAR(255) NOT NULL,
        candidate_email VARCHAR(255) NOT NULL,
        candidate_phone VARCHAR(20),
        candidate_city VARCHAR(100),
        resume_url TEXT,
        cover_letter TEXT,
        portfolio_url TEXT,
        linkedin_url TEXT,
        status ENUM('pending', 'reviewing', 'interview_scheduled', 'interviewed', 'test_sent', 'approved', 'rejected', 'withdrawn') DEFAULT 'pending',
        score INT DEFAULT 0,
        notes TEXT,
        reviewed_by VARCHAR(36),
        reviewed_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
        FOREIGN KEY (reviewed_by) REFERENCES users(id) ON SET NULL,
        INDEX idx_job_status (job_id, status),
        INDEX idx_candidate_email (candidate_email),
        INDEX idx_created_at (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Employee documents table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS employee_documents (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        employee_id VARCHAR(36) NOT NULL,
        document_type ENUM('contract', 'id', 'resume', 'diploma', 'certificate', 'other') NOT NULL,
        title VARCHAR(255) NOT NULL,
        file_url TEXT NOT NULL,
        file_size INT,
        file_type VARCHAR(100),
        is_required BOOLEAN DEFAULT FALSE,
        is_verified BOOLEAN DEFAULT FALSE,
        verified_by VARCHAR(36),
        verified_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (verified_by) REFERENCES users(id) ON SET NULL,
        INDEX idx_employee_type (employee_id, document_type)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    // Create default admin user
    console.log('👤 Criando usuários padrão...');
    
    const [adminExists] = await connection.execute(
      'SELECT id FROM users WHERE email = ?',
      ['admin@integrerh.com']
    );

    if ((adminExists as any[]).length === 0) {
      const hashedPassword = await bcrypt.hash('admin123', 12);
      await connection.execute(`
        INSERT INTO users (name, email, password, role, department, permissions, email_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        'Administrador Sistema',
        'admin@integrerh.com',
        hashedPassword,
        'admin',
        'Administração',
        JSON.stringify(['*']),
        true
      ]);
      console.log('✅ Usuário admin criado');
    }

    // Create demo users
    const demoUsers = [
      { 
        name: 'Gerente RH', 
        email: 'rh@integrerh.com', 
        password: 'rh123', 
        role: 'hr', 
        department: 'Recursos Humanos' 
      },
      { 
        name: 'Gestor Tecnologia', 
        email: 'gestor@integrerh.com', 
        password: 'gestor123', 
        role: 'manager', 
        department: 'Tecnologia' 
      },
      { 
        name: 'Funcionário Demo', 
        email: 'funcionario@integrerh.com', 
        password: 'func123', 
        role: 'employee', 
        department: 'Tecnologia' 
      },
      { 
        name: 'Candidato Demo', 
        email: 'candidato@integrerh.com', 
        password: 'cand123', 
        role: 'candidate', 
        department: null 
      }
    ];

    for (const user of demoUsers) {
      const [userExists] = await connection.execute(
        'SELECT id FROM users WHERE email = ?',
        [user.email]
      );

      if ((userExists as any[]).length === 0) {
        const hashedPassword = await bcrypt.hash(user.password, 12);
        const permissions = getUserPermissions(user.role);
        
        await connection.execute(`
          INSERT INTO users (name, email, password, role, department, permissions, email_verified)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          user.name,
          user.email,
          hashedPassword,
          user.role,
          user.department,
          JSON.stringify(permissions),
          true
        ]);
        console.log(`✅ Usuário ${user.name} criado`);
      }
    }

    // Create demo jobs
    console.log('💼 Criando vagas de demonstração...');
    const demoJobs = [
      {
        title: 'Desenvolvedor Full Stack',
        description: 'Desenvolvedor para trabalhar com React, Node.js e MySQL em projetos inovadores',
        department: 'Tecnologia',
        location: 'São Paulo, SP',
        salary_min: 8000,
        salary_max: 15000,
        employment_type: 'full_time',
        status: 'open',
        requirements: JSON.stringify(['React.js', 'Node.js', 'MySQL', 'TypeScript', 'Git']),
        benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'Home office', 'Auxílio educação']),
        skills: JSON.stringify(['JavaScript', 'React', 'Node.js', 'MySQL']),
        experience_level: 'mid',
        remote_type: 'hybrid'
      },
      {
        title: 'Analista de RH Sênior',
        description: 'Analista sênior para gestão de pessoas, processos de RH e desenvolvimento organizacional',
        department: 'Recursos Humanos',
        location: 'São Paulo, SP',
        salary_min: 7000,
        salary_max: 12000,
        employment_type: 'full_time',
        status: 'open',
        requirements: JSON.stringify(['Graduação em RH/Psicologia', 'Experiência em DP', 'Excel avançado', 'Gestão de pessoas']),
        benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'VR', 'Auxílio educação']),
        skills: JSON.stringify(['Gestão de Pessoas', 'Departamento Pessoal', 'Recrutamento']),
        experience_level: 'senior',
        remote_type: 'office'
      },
      {
        title: 'Designer UX/UI',
        description: 'Designer para criação de interfaces e experiências digitais incríveis',
        department: 'Design',
        location: 'São Paulo, SP',
        salary_min: 6000,
        salary_max: 12000,
        employment_type: 'full_time',
        status: 'open',
        requirements: JSON.stringify(['Figma', 'Adobe Creative Suite', 'Prototipagem', 'UX Research']),
        benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'Curso de idiomas', 'MacBook']),
        skills: JSON.stringify(['Figma', 'Adobe XD', 'Prototipagem', 'Design Systems']),
        experience_level: 'mid',
        remote_type: 'hybrid'
      }
    ];

    for (const job of demoJobs) {
      const [jobExists] = await connection.execute(
        'SELECT id FROM jobs WHERE title = ? AND department = ?',
        [job.title, job.department]
      );

      if ((jobExists as any[]).length === 0) {
        await connection.execute(`
          INSERT INTO jobs (title, description, department, location, salary_min, salary_max, 
                           employment_type, status, requirements, benefits, skills, experience_level, remote_type, published_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        `, [
          job.title,
          job.description,
          job.department,
          job.location,
          job.salary_min,
          job.salary_max,
          job.employment_type,
          job.status,
          job.requirements,
          job.benefits,
          job.skills,
          job.experience_level,
          job.remote_type
        ]);
        console.log(`✅ Vaga ${job.title} criada`);
      }
    }

    connection.release();
    console.log('✅ Banco de dados MySQL inicializado com sucesso');
    
    // Log summary
    const [userCount] = await db.execute('SELECT COUNT(*) as count FROM users');
    const [jobCount] = await db.execute('SELECT COUNT(*) as count FROM jobs');
    
    console.log('\n📊 Resumo do sistema:');
    console.log(`   👥 Usuários: ${(userCount as any[])[0].count}`);
    console.log(`   💼 Vagas: ${(jobCount as any[])[0].count}`);
    console.log(`   🏢 Empresa: Integre RH`);
    console.log(`   🌐 Domínio: integrerh.com.br`);

  } catch (error) {
    console.error('❌ Erro ao inicializar MySQL:', error);
    throw error;
  }
};

// Helper function to get user permissions based on role
const getUserPermissions = (role: string): string[] => {
  const permissions: Record<string, string[]> = {
    admin: ['*'],
    hr: ['users.read', 'users.write', 'jobs.read', 'jobs.write', 'evaluations.read', 'evaluations.write', 'trainings.read', 'trainings.write', 'reports.read'],
    manager: ['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write', 'trainings.read', 'reports.read'],
    employee: ['profile.read', 'profile.write', 'evaluations.read', 'trainings.read', 'documents.read'],
    candidate: ['jobs.read', 'applications.read', 'applications.write', 'profile.read', 'profile.write']
  };
  return permissions[role] || [];
};

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      connectSrc: ["'self'", "https://api.integrerh.com.br"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
}));

app.use(compression());
app.use(morgan('combined'));

app.use(cors({
  origin: [
    'https://integrerh.com.br',
    'https://www.integrerh.com.br',
    'https://api.integrerh.com.br',
    'http://localhost:8080',
    'http://localhost:3000'
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
  message: { error: 'Muitas tentativas. Tente novamente em 15 minutos.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  skipSuccessfulRequests: true,
  message: { error: 'Muitas tentativas de login. Tente novamente em 15 minutos.' }
});

app.use('/api/', limiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

// Auth middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    
    // Check if session exists and is valid
    const [session] = await db.execute(
      'SELECT * FROM user_sessions WHERE token_hash = ? AND expires_at > NOW()',
      [crypto.createHash('sha256').update(token).digest('hex')]
    );

    if ((session as any[]).length === 0) {
      return res.status(401).json({ error: 'Sessão inválida ou expirada' });
    }

    // Get user details
    const [user] = await db.execute(
      'SELECT id, name, email, role, department, permissions, is_active FROM users WHERE id = ? AND is_active = TRUE',
      [decoded.userId]
    );

    if ((user as any[]).length === 0) {
      return res.status(401).json({ error: 'Usuário não encontrado ou inativo' });
    }

    req.user = (user as any[])[0];
    req.token = token;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    return res.status(403).json({ error: 'Token inválido' });
  }
};

// Validation middleware
const handleValidationErrors = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Dados inválidos',
      details: errors.array()
    });
  }
  next();
};

// Auth routes
app.post('/api/auth/register', [
  body('name').isLength({ min: 2 }).withMessage('Nome deve ter pelo menos 2 caracteres'),
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 6 }).withMessage('Senha deve ter pelo menos 6 caracteres'),
  body('role').isIn(['admin', 'hr', 'manager', 'employee', 'candidate']).withMessage('Tipo de usuário inválido'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { name, email, password, role, department, phone } = req.body;

    // Check if user already exists
    const [existingUser] = await db.execute(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if ((existingUser as any[]).length > 0) {
      return res.status(400).json({ error: 'Email já está em uso' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);
    const permissions = getUserPermissions(role);

    // Create user
    const [result] = await db.execute(`
      INSERT INTO users (name, email, password, role, department, phone, permissions)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [name, email, hashedPassword, role, department || null, phone || null, JSON.stringify(permissions)]);

    res.status(201).json({
      message: 'Usuário criado com sucesso',
      userId: (result as any).insertId
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/login', [
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 1 }).withMessage('Senha é obrigatória'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Get user
    let query = 'SELECT * FROM users WHERE email = ? AND is_active = TRUE';
    let params: any[] = [email];

    if (role) {
      query += ' AND role = ?';
      params.push(role);
    }

    const [users] = await db.execute(query, params);
    const user = (users as any[])[0];

    if (!user) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Update last login
    await db.execute(
      'UPDATE users SET last_login = NOW() WHERE id = ?',
      [user.id]
    );

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET!,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    // Create session
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    await db.execute(`
      INSERT INTO user_sessions (user_id, token_hash, ip_address, user_agent, expires_at)
      VALUES (?, ?, ?, ?, ?)
    `, [user.id, tokenHash, req.ip, req.get('User-Agent') || '', expiresAt]);

    // Return user data (without password)
    const userData = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      avatar: user.avatar,
      permissions: JSON.parse(user.permissions || '[]')
    };

    res.json({
      message: 'Login realizado com sucesso',
      token,
      user: userData
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.get('/api/auth/verify', authenticateToken, (req: any, res) => {
  res.json({
    message: 'Token válido',
    user: req.user
  });
});

app.post('/api/auth/logout', authenticateToken, async (req: any, res) => {
  try {
    const tokenHash = crypto.createHash('sha256').update(req.token).digest('hex');
    
    // Delete session
    await db.execute(
      'DELETE FROM user_sessions WHERE token_hash = ?',
      [tokenHash]
    );

    res.json({ message: 'Logout realizado com sucesso' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Jobs API
app.get('/api/jobs', async (req, res) => {
  try {
    const [jobs] = await db.execute(`
      SELECT j.*, u.name as created_by_name 
      FROM jobs j
      LEFT JOIN users u ON j.created_by = u.id
      WHERE j.status = 'open' 
      ORDER BY j.created_at DESC
    `);
    res.json(jobs);
  } catch (error) {
    console.error('Get jobs error:', error);
    res.status(500).json({ error: 'Erro ao buscar vagas' });
  }
});

app.get('/api/jobs/:id', async (req, res) => {
  try {
    const [jobs] = await db.execute(
      'SELECT * FROM jobs WHERE id = ?',
      [req.params.id]
    );
    
    if ((jobs as any[]).length === 0) {
      return res.status(404).json({ error: 'Vaga não encontrada' });
    }
    
    res.json((jobs as any[])[0]);
  } catch (error) {
    console.error('Get job error:', error);
    return res.status(500).json({ error: 'Erro ao buscar vaga' });
  }
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await db.execute('SELECT 1');
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'MySQL connected',
      version: '1.0.0',
      environment: process.env.NODE_ENV || 'development'
    });
  } catch (error) {
    res.status(500).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      database: 'MySQL disconnected',
      error: 'Database connection failed'
    });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint não encontrado' });
});

// Error handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (db) {
    await db.end();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully');
  if (db) {
    await db.end();
  }
  process.exit(0);
});

// Start server
const startServer = async () => {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`🚀 Servidor Integre RH rodando na porta ${PORT}`);
      console.log(`🌐 API URL: ${process.env.API_URL || `http://localhost:${PORT}`}`);
      console.log(`📱 Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:8080'}`);
      console.log('');
      console.log('🔐 Sistema de autenticação JWT ativo');
      console.log('🗄️  Banco MySQL configurado');
      console.log('🛡️  Segurança e rate limiting ativos');
      console.log('');
      console.log('👤 Credenciais de acesso:');
      console.log('   🔑 Admin: admin@integrerh.com / admin123');
      console.log('   👥 RH: rh@integrerh.com / rh123');
      console.log('   👔 Gestor: gestor@integrerh.com / gestor123');
      console.log('   👨‍💼 Funcionário: funcionario@integrerh.com / func123');
      console.log('   🎯 Candidato: candidato@integrerh.com / cand123');
    });
  } catch (error) {
    console.error('❌ Falha ao iniciar servidor:', error);
    process.exit(1);
  }
};

startServer();

export default app;
