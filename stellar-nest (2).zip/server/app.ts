import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import morgan from 'morgan';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { body, validationResult } from 'express-validator';
import mysql from 'mysql2/promise';
import crypto from 'crypto';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Database connection
let db: mysql.Pool;

const createDbConnection = () => {
  db = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306'),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'admin123',
    database: process.env.DB_NAME || 'integrerh_prod',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    acquireTimeout: 60000,
    timeout: 60000,
    reconnect: true
  });
};

// Initialize database
const initializeDatabase = async () => {
  try {
    createDbConnection();
    
    // Test connection
    const connection = await db.getConnection();
    console.log('✅ Database connected successfully');
    
    // Create database if not exists
    await connection.execute(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'integrerh_prod'}`);
    await connection.execute(`USE ${process.env.DB_NAME || 'integrerh_prod'}`);
    
    // Create users table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'hr', 'manager', 'employee', 'candidate', 'rh_admin') NOT NULL,
        department VARCHAR(100),
        phone VARCHAR(20),
        avatar TEXT,
        permissions JSON,
        is_active BOOLEAN DEFAULT TRUE,
        email_verified BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    // Create password reset tokens table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        user_id VARCHAR(36) NOT NULL,
        token VARCHAR(255) NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        used BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // Create sessions table for tracking active sessions
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS user_sessions (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        user_id VARCHAR(36) NOT NULL,
        token_hash VARCHAR(255) NOT NULL,
        ip_address VARCHAR(45),
        user_agent TEXT,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);

    // Insert default admin user if not exists
    const [adminUser] = await connection.execute(
      'SELECT id FROM users WHERE email = ? AND role = ?',
      ['admin@integrerh.com', 'admin']
    );

    if ((adminUser as any[]).length === 0) {
      const hashedPassword = await bcrypt.hash('admin123', 12);
      await connection.execute(`
        INSERT INTO users (name, email, password, role, department, permissions, email_verified)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        'Administrador',
        'admin@integrerh.com',
        hashedPassword,
        'admin',
        'Administração',
        JSON.stringify(['*']), // All permissions
        true
      ]);
      console.log('✅ Default admin user created');
    }

    // Insert demo users
    const demoUsers = [
      { name: 'RH Manager', email: 'rh@integrerh.com', password: 'rh123', role: 'hr', department: 'Recursos Humanos' },
      { name: 'Gestor Equipe', email: 'gestor@integrerh.com', password: 'gestor123', role: 'manager', department: 'Tecnologia' },
      { name: 'Funcionário Demo', email: 'funcionario@integrerh.com', password: 'func123', role: 'employee', department: 'Tecnologia' },
      { name: 'Candidato Demo', email: 'candidato@integrerh.com', password: 'cand123', role: 'candidate', department: null }
    ];

    for (const user of demoUsers) {
      const [existingUser] = await connection.execute(
        'SELECT id FROM users WHERE email = ?',
        [user.email]
      );

      if ((existingUser as any[]).length === 0) {
        const hashedPassword = await bcrypt.hash(user.password, 12);
        const permissions = getUserPermissions(user.role);
        
        await connection.execute(`
          INSERT INTO users (name, email, password, role, department, permissions, email_verified)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          user.name,
          user.email,
          hashedPassword,
          user.role,
          user.department,
          JSON.stringify(permissions),
          true
        ]);
      }
    }

    connection.release();
    console.log('✅ Database initialized successfully');
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    process.exit(1);
  }
};

// Helper function to get user permissions based on role
const getUserPermissions = (role: string): string[] => {
  const permissions: Record<string, string[]> = {
    admin: ['*'],
    hr: ['users.read', 'users.write', 'jobs.read', 'jobs.write', 'evaluations.read', 'evaluations.write', 'trainings.read', 'trainings.write'],
    manager: ['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write', 'trainings.read'],
    employee: ['profile.read', 'profile.write', 'evaluations.read', 'trainings.read'],
    candidate: ['jobs.read', 'applications.read', 'applications.write']
  };
  return permissions[role] || [];
};

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
}));

app.use(compression());
app.use(morgan('combined'));

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:8081',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
  message: {
    error: 'Muitas tentativas. Tente novamente em 15 minutos.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  skipSuccessfulRequests: true,
  message: {
    error: 'Muitas tentativas de login. Tente novamente em 15 minutos.'
  }
});

app.use('/api/', limiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

// Auth middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    
    // Check if session exists and is valid
    const [session] = await db.execute(
      'SELECT * FROM user_sessions WHERE token_hash = ? AND expires_at > NOW()',
      [crypto.createHash('sha256').update(token).digest('hex')]
    );

    if ((session as any[]).length === 0) {
      return res.status(401).json({ error: 'Sessão inválida ou expirada' });
    }

    // Get user details
    const [user] = await db.execute(
      'SELECT id, name, email, role, department, permissions, is_active FROM users WHERE id = ? AND is_active = TRUE',
      [decoded.userId]
    );

    if ((user as any[]).length === 0) {
      return res.status(401).json({ error: 'Usuário não encontrado ou inativo' });
    }

    req.user = (user as any[])[0];
    req.token = token;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    return res.status(403).json({ error: 'Token inválido' });
  }
};

// Validation middleware
const handleValidationErrors = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Dados inválidos',
      details: errors.array()
    });
  }
  next();
};

// Auth routes
app.post('/api/auth/register', [
  body('name').isLength({ min: 2 }).withMessage('Nome deve ter pelo menos 2 caracteres'),
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 6 }).withMessage('Senha deve ter pelo menos 6 caracteres'),
  body('role').isIn(['admin', 'hr', 'manager', 'employee', 'candidate', 'rh_admin']).withMessage('Tipo de usuário inválido'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { name, email, password, role, department, phone } = req.body;

    // Check if user already exists
    const [existingUser] = await db.execute(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if ((existingUser as any[]).length > 0) {
      return res.status(400).json({ error: 'Email já está em uso' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);
    const permissions = getUserPermissions(role);

    // Create user
    const [result] = await db.execute(`
      INSERT INTO users (name, email, password, role, department, phone, permissions)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [name, email, hashedPassword, role, department || null, phone || null, JSON.stringify(permissions)]);

    res.status(201).json({
      message: 'Usuário criado com sucesso',
      userId: (result as any).insertId
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/login', [
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 1 }).withMessage('Senha é obrigatória'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Get user
    let query = 'SELECT * FROM users WHERE email = ? AND is_active = TRUE';
    let params: any[] = [email];

    if (role) {
      query += ' AND role = ?';
      params.push(role);
    }

    const [users] = await db.execute(query, params);
    const user = (users as any[])[0];

    if (!user) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET!,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    // Create session
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    await db.execute(`
      INSERT INTO user_sessions (user_id, token_hash, ip_address, user_agent, expires_at)
      VALUES (?, ?, ?, ?, ?)
    `, [user.id, tokenHash, req.ip, req.get('User-Agent') || '', expiresAt]);

    // Return user data (without password)
    const userData = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      avatar: user.avatar,
      permissions: JSON.parse(user.permissions || '[]')
    };

    res.json({
      message: 'Login realizado com sucesso',
      token,
      user: userData
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/forgot-password', [
  body('email').isEmail().withMessage('Email inválido'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { email } = req.body;

    // Check if user exists
    const [users] = await db.execute(
      'SELECT id, name FROM users WHERE email = ? AND is_active = TRUE',
      [email]
    );

    // Always return success for security (don't reveal if email exists)
    if ((users as any[]).length === 0) {
      return res.json({ message: 'Se o email existir, você receberá instruções de recuperação' });
    }

    const user = (users as any[])[0];

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    // Save reset token
    await db.execute(`
      INSERT INTO password_reset_tokens (user_id, token, expires_at)
      VALUES (?, ?, ?)
    `, [user.id, resetToken, expiresAt]);

    // TODO: Send email with reset link
    console.log(`Password reset token for ${email}: ${resetToken}`);

    res.json({ message: 'Se o email existir, você receberá instruções de recuperação' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/reset-password', [
  body('token').isLength({ min: 1 }).withMessage('Token é obrigatório'),
  body('newPassword').isLength({ min: 6 }).withMessage('Nova senha deve ter pelo menos 6 caracteres'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    // Find valid reset token
    const [tokens] = await db.execute(`
      SELECT user_id FROM password_reset_tokens 
      WHERE token = ? AND expires_at > NOW() AND used = FALSE
    `, [token]);

    if ((tokens as any[]).length === 0) {
      return res.status(400).json({ error: 'Token inválido ou expirado' });
    }

    const userId = (tokens as any[])[0].user_id;

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 12);

    // Update password
    await db.execute(
      'UPDATE users SET password = ? WHERE id = ?',
      [hashedPassword, userId]
    );

    // Mark token as used
    await db.execute(
      'UPDATE password_reset_tokens SET used = TRUE WHERE token = ?',
      [token]
    );

    // Invalidate all sessions for this user
    await db.execute(
      'DELETE FROM user_sessions WHERE user_id = ?',
      [userId]
    );

    res.json({ message: 'Senha redefinida com sucesso' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.get('/api/auth/verify', authenticateToken, (req: any, res) => {
  res.json({
    message: 'Token válido',
    user: req.user
  });
});

app.post('/api/auth/logout', authenticateToken, async (req: any, res) => {
  try {
    const tokenHash = crypto.createHash('sha256').update(req.token).digest('hex');
    
    // Delete session
    await db.execute(
      'DELETE FROM user_sessions WHERE token_hash = ?',
      [tokenHash]
    );

    res.json({ message: 'Logout realizado com sucesso' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await db.execute('SELECT 1');
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'connected'
    });
  } catch (error) {
    res.status(500).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      database: 'disconnected',
      error: 'Database connection failed'
    });
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint não encontrado' });
});

// Error handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

// Start server
const startServer = async () => {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📱 Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:8081'}`);
    console.log(`🔗 API Health: http://localhost:${PORT}/api/health`);
  });
};

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (db) {
    await db.end();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully');
  if (db) {
    await db.end();
  }
  process.exit(0);
});

startServer().catch(console.error);

export default app;
