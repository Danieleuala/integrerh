import nodemailer from "nodemailer";
import SMTPTransport from "nodemailer/lib/smtp-transport";

interface EmailOptions {
  to: string | string[];
  subject: string;
  text?: string;
  html?: string;
  attachments?: Array<{
    filename: string;
    path?: string;
    content?: Buffer;
    contentType?: string;
  }>;
}

interface EmailConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
}

class EmailService {
  private transporter: nodemailer.Transporter<SMTPTransport.SentMessageInfo>;
  private isConfigured: boolean = false;

  constructor() {
    this.initializeTransporter();
  }

  private initializeTransporter(): void {
    try {
      const config: EmailConfig = {
        host: process.env.SMTP_HOST || "smtp.gmail.com",
        port: parseInt(process.env.SMTP_PORT || "587"),
        secure: process.env.SMTP_SECURE === "true",
        auth: {
          user: process.env.SMTP_USER || "",
          pass: process.env.SMTP_PASS || "",
        },
      };

      if (!config.auth.user || !config.auth.pass) {
        console.warn(
          "⚠️  Email service not configured - SMTP credentials missing",
        );
        return;
      }

      this.transporter = nodemailer.createTransporter(config);
      this.isConfigured = true;

      // Verify connection
      this.verifyConnection();
    } catch (error) {
      console.error("❌ Failed to initialize email service:", error);
    }
  }

  private async verifyConnection(): Promise<void> {
    try {
      await this.transporter.verify();
      console.log("✅ Email service connected successfully");
    } catch (error) {
      console.error("❌ Email service connection failed:", error);
      this.isConfigured = false;
    }
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.isConfigured) {
      console.error("❌ Email service not configured");
      return false;
    }

    try {
      const mailOptions = {
        from: {
          name: process.env.SMTP_FROM_NAME || "Integre RH",
          address: process.env.SMTP_FROM_EMAIL || process.env.SMTP_USER || "",
        },
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
        attachments: options.attachments,
      };

      const result = await this.transporter.sendMail(mailOptions);
      console.log("✅ Email sent successfully:", result.messageId);
      return true;
    } catch (error) {
      console.error("❌ Failed to send email:", error);
      return false;
    }
  }

  // Template methods for common emails
  async sendWelcomeEmail(
    to: string,
    name: string,
    role: string,
  ): Promise<boolean> {
    const subject = "Bem-vindo ao Integre RH!";
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #7c3aed; margin: 0;">Integre RH</h1>
          <p style="color: #666; margin: 5px 0;">Sistema de Gestão de Recursos Humanos</p>
        </div>
        
        <div style="background: linear-gradient(135deg, #7c3aed 0%, #3b82f6 100%); padding: 30px; border-radius: 12px; color: white; text-align: center; margin-bottom: 30px;">
          <h2 style="margin: 0 0 15px 0;">Bem-vindo, ${name}!</h2>
          <p style="margin: 0; opacity: 0.9;">Sua conta foi criada com sucesso como ${this.getRoleLabel(role)}</p>
        </div>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
          <h3 style="color: #334155; margin: 0 0 15px 0;">Próximos passos:</h3>
          <ul style="color: #64748b; line-height: 1.6; margin: 0; padding-left: 20px;">
            <li>Complete seu perfil na plataforma</li>
            <li>Familiarize-se com as funcionalidades</li>
            <li>Entre em contato conosco se precisar de ajuda</li>
          </ul>
        </div>
        
        <div style="text-align: center; margin-bottom: 30px;">
          <a href="${process.env.FRONTEND_URL || "http://localhost:5173"}/dashboard" 
             style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">
            Acessar Plataforma
          </a>
        </div>
        
        <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center;">
          <p style="color: #94a3b8; font-size: 14px; margin: 0;">
            Se você não criou esta conta, ignore este email.
          </p>
          <p style="color: #94a3b8; font-size: 12px; margin: 10px 0 0 0;">
            © 2024 Integre RH. Todos os direitos reservados.
          </p>
        </div>
      </div>
    `;

    return await this.sendEmail({ to, subject, html });
  }

  async sendPasswordResetEmail(
    to: string,
    name: string,
    resetUrl: string,
  ): Promise<boolean> {
    const subject = "Integre RH - Recuperação de Senha";
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #7c3aed; margin: 0;">Integre RH</h1>
          <p style="color: #666; margin: 5px 0;">Sistema de Gestão de Recursos Humanos</p>
        </div>
        
        <h2 style="color: #334155; text-align: center; margin-bottom: 30px;">Recuperação de Senha</h2>
        
        <p style="color: #64748b; line-height: 1.6;">Olá, ${name}</p>
        <p style="color: #64748b; line-height: 1.6;">
          Você solicitou a recuperação de senha para sua conta no Integre RH.
        </p>
        
        <div style="background: #fef3c7; border: 1px solid #f59e0b; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="color: #92400e; margin: 0; font-size: 14px;">
            <strong>Importante:</strong> Este link expira em 1 hora por motivos de segurança.
          </p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" 
             style="background-color: #7c3aed; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">
            Redefinir Senha
          </a>
        </div>
        
        <p style="color: #64748b; line-height: 1.6; font-size: 14px;">
          Se você não solicitou esta recuperação, pode ignorar este email com segurança. 
          Sua senha permanecerá inalterada.
        </p>
        
        <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center; margin-top: 30px;">
          <p style="color: #94a3b8; font-size: 12px; margin: 0;">
            © 2024 Integre RH. Todos os direitos reservados.
          </p>
        </div>
      </div>
    `;

    return await this.sendEmail({ to, subject, html });
  }

  async sendNewApplicationNotification(
    to: string,
    jobTitle: string,
    candidateName: string,
  ): Promise<boolean> {
    const subject = `Nova candidatura: ${jobTitle}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #7c3aed; margin: 0;">Integre RH</h1>
          <p style="color: #666; margin: 5px 0;">Sistema de Gestão de Recursos Humanos</p>
        </div>
        
        <div style="background: #dbeafe; border: 1px solid #3b82f6; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <h2 style="color: #1e40af; margin: 0 0 10px 0;">Nova Candidatura Recebida!</h2>
          <p style="color: #1e40af; margin: 0;">
            <strong>${candidateName}</strong> se candidatou para a vaga de <strong>${jobTitle}</strong>
          </p>
        </div>
        
        <p style="color: #64748b; line-height: 1.6;">
          Uma nova candidatura foi recebida e aguarda sua análise no sistema.
        </p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${process.env.FRONTEND_URL || "http://localhost:5173"}/jobs" 
             style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">
            Ver Candidaturas
          </a>
        </div>
        
        <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 0;">
            © 2024 Integre RH. Todos os direitos reservados.
          </p>
        </div>
      </div>
    `;

    return await this.sendEmail({ to, subject, html });
  }

  async sendTrainingInvitation(
    to: string,
    employeeName: string,
    trainingTitle: string,
    startDate: string,
  ): Promise<boolean> {
    const subject = `Convite para Treinamento: ${trainingTitle}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #7c3aed; margin: 0;">Integre RH</h1>
          <p style="color: #666; margin: 5px 0;">Sistema de Gestão de Recursos Humanos</p>
        </div>
        
        <h2 style="color: #334155; text-align: center; margin-bottom: 30px;">Convite para Treinamento</h2>
        
        <p style="color: #64748b; line-height: 1.6;">Olá, ${employeeName}</p>
        <p style="color: #64748b; line-height: 1.6;">
          Você foi inscrito no treinamento <strong>${trainingTitle}</strong>.
        </p>
        
        <div style="background: #f0fdf4; border: 1px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #15803d; margin: 0 0 10px 0;">Detalhes do Treinamento:</h3>
          <p style="color: #15803d; margin: 5px 0;"><strong>Título:</strong> ${trainingTitle}</p>
          <p style="color: #15803d; margin: 5px 0;"><strong>Data de Início:</strong> ${startDate}</p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${process.env.FRONTEND_URL || "http://localhost:5173"}/trainings" 
             style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold;">
            Acessar Treinamentos
          </a>
        </div>
        
        <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; text-align: center;">
          <p style="color: #94a3b8; font-size: 12px; margin: 0;">
            © 2024 Integre RH. Todos os direitos reservados.
          </p>
        </div>
      </div>
    `;

    return await this.sendEmail({ to, subject, html });
  }

  private getRoleLabel(role: string): string {
    const roleLabels: { [key: string]: string } = {
      rh_admin: "Administrador RH",
      manager: "Gestor",
      employee: "Colaborador",
      candidate: "Candidato",
    };
    return roleLabels[role] || role;
  }

  isConfigured(): boolean {
    return this.isConfigured;
  }
}

// Create singleton instance
const emailService = new EmailService();

// Export convenience function
export const sendEmail = (options: EmailOptions): Promise<boolean> => {
  return emailService.sendEmail(options);
};

export const sendWelcomeEmail = (
  to: string,
  name: string,
  role: string,
): Promise<boolean> => {
  return emailService.sendWelcomeEmail(to, name, role);
};

export const sendPasswordResetEmail = (
  to: string,
  name: string,
  resetUrl: string,
): Promise<boolean> => {
  return emailService.sendPasswordResetEmail(to, name, resetUrl);
};

export const sendNewApplicationNotification = (
  to: string,
  jobTitle: string,
  candidateName: string,
): Promise<boolean> => {
  return emailService.sendNewApplicationNotification(
    to,
    jobTitle,
    candidateName,
  );
};

export const sendTrainingInvitation = (
  to: string,
  employeeName: string,
  trainingTitle: string,
  startDate: string,
): Promise<boolean> => {
  return emailService.sendTrainingInvitation(
    to,
    employeeName,
    trainingTitle,
    startDate,
  );
};

export const isEmailServiceConfigured = (): boolean => {
  return emailService.isConfigured();
};

export default emailService;
