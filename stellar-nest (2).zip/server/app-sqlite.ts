import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import morgan from 'morgan';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { body, validationResult } from 'express-validator';
import crypto from 'crypto';
import { initializeSQLiteDatabase, db } from './database-sqlite';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Helper function to get user permissions based on role
const getUserPermissions = (role: string): string[] => {
  const permissions: Record<string, string[]> = {
    admin: ['*'],
    rh_admin: ['*'],
    hr: ['users.read', 'users.write', 'jobs.read', 'jobs.write', 'evaluations.read', 'evaluations.write', 'trainings.read', 'trainings.write'],
    manager: ['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write', 'trainings.read'],
    employee: ['profile.read', 'profile.write', 'evaluations.read', 'trainings.read'],
    candidate: ['jobs.read', 'applications.read', 'applications.write']
  };
  return permissions[role] || [];
};

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
}));

app.use(compression());
app.use(morgan('combined'));

app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:8080',
    'http://localhost:8080',
    'http://localhost:8081',
    'https://integrerh.com.br',
    'https://www.integrerh.com.br',
    'https://api.integrerh.com.br'
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static('dist/spa'));
}

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: {
    error: 'Muitas tentativas. Tente novamente em 15 minutos.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  skipSuccessfulRequests: true,
  message: {
    error: 'Muitas tentativas de login. Tente novamente em 15 minutos.'
  }
});

app.use('/api/', limiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

// Auth middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acesso requerido' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret') as any;
    
    // Check if session exists and is valid
    const session = await db.get(
      'SELECT * FROM user_sessions WHERE token_hash = ? AND expires_at > datetime("now")',
      [crypto.createHash('sha256').update(token).digest('hex')]
    );

    if (!session) {
      return res.status(401).json({ error: 'Sessão inválida ou expirada' });
    }

    // Get user details
    const user = await db.get(
      'SELECT id, name, email, role, department, permissions, is_active FROM users WHERE id = ? AND is_active = 1',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({ error: 'Usuário não encontrado ou inativo' });
    }

    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    return res.status(403).json({ error: 'Token inválido' });
  }
};

// Validation middleware
const handleValidationErrors = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Dados inválidos',
      details: errors.array()
    });
  }
  next();
};

// Auth routes
app.post('/api/auth/register', [
  body('name').isLength({ min: 2 }).withMessage('Nome deve ter pelo menos 2 caracteres'),
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 6 }).withMessage('Senha deve ter pelo menos 6 caracteres'),
  body('role').isIn(['admin', 'hr', 'manager', 'employee', 'candidate', 'rh_admin']).withMessage('Tipo de usuário inválido'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { name, email, password, role, department, phone } = req.body;

    // Check if user already exists
    const existingUser = await db.get('SELECT id FROM users WHERE email = ?', [email]);

    if (existingUser) {
      return res.status(400).json({ error: 'Email já está em uso' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);
    const permissions = getUserPermissions(role);

    // Create user
    const result = await db.run(`
      INSERT INTO users (name, email, password, role, department, phone, permissions)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [name, email, hashedPassword, role, department || null, phone || null, JSON.stringify(permissions)]);

    res.status(201).json({
      message: 'Usuário criado com sucesso',
      userId: result.lastID
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/login', [
  body('email').isEmail().withMessage('Email inválido'),
  body('password').isLength({ min: 1 }).withMessage('Senha é obrigatória'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Get user
    let query = 'SELECT * FROM users WHERE email = ? AND is_active = 1';
    let params: any[] = [email];

    if (role) {
      query += ' AND role = ?';
      params.push(role);
    }

    const user = await db.get(query, params);

    if (!user) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '7d' }
    );

    // Create session
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    await db.run(`
      INSERT INTO user_sessions (user_id, token_hash, ip_address, user_agent, expires_at)
      VALUES (?, ?, ?, ?, ?)
    `, [user.id, tokenHash, req.ip, req.get('User-Agent') || '', expiresAt.toISOString()]);

    // Return user data (without password)
    const userData = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      avatar: user.avatar,
      permissions: JSON.parse(user.permissions || '[]')
    };

    res.json({
      message: 'Login realizado com sucesso',
      token,
      user: userData
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.post('/api/auth/forgot-password', [
  body('email').isEmail().withMessage('Email inválido'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { email } = req.body;

    // Check if user exists
    const user = await db.get('SELECT id, name FROM users WHERE email = ? AND is_active = 1', [email]);

    // Always return success for security
    if (!user) {
      return res.json({ message: 'Se o email existir, você receberá instruções de recuperação' });
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    // Save reset token
    await db.run(`
      INSERT INTO password_reset_tokens (user_id, token, expires_at)
      VALUES (?, ?, ?)
    `, [user.id, resetToken, expiresAt.toISOString()]);

    console.log(`Password reset token for ${email}: ${resetToken}`);

    res.json({ message: 'Se o email existir, você receberá instruções de recuperação' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

app.get('/api/auth/verify', authenticateToken, (req: any, res) => {
  res.json({
    message: 'Token válido',
    user: req.user
  });
});

app.post('/api/auth/logout', authenticateToken, async (req: any, res) => {
  try {
    const tokenHash = crypto.createHash('sha256').update(req.token).digest('hex');
    
    // Delete session
    await db.run('DELETE FROM user_sessions WHERE token_hash = ?', [tokenHash]);

    res.json({ message: 'Logout realizado com sucesso' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Jobs API
app.get('/api/jobs', async (req, res) => {
  try {
    const jobs = await db.all('SELECT * FROM jobs WHERE status = "open" ORDER BY created_at DESC');
    res.json(jobs);
  } catch (error) {
    console.error('Get jobs error:', error);
    res.status(500).json({ error: 'Erro ao buscar vagas' });
  }
});

app.get('/api/jobs/:id', async (req, res) => {
  try {
    const job = await db.get('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
    if (!job) {
      return res.status(404).json({ error: 'Vaga não encontrada' });
    }
    res.json(job);
  } catch (error) {
    console.error('Get job error:', error);
    res.status(500).json({ error: 'Erro ao buscar vaga' });
  }
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await db.get('SELECT 1');
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'connected (SQLite)'
    });
  } catch (error) {
    res.status(500).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      database: 'disconnected',
      error: 'Database connection failed'
    });
  }
});

// Debug endpoint to check users
app.get('/api/debug/users', async (req, res) => {
  try {
    const users = await db.all('SELECT id, name, email, role, is_active FROM users');
    res.json({
      count: users.length,
      users: users
    });
  } catch (error) {
    res.status(500).json({ error: 'Database error', details: error.message });
  }
});

// Debug endpoint to add/update user
app.post('/api/debug/add-user', async (req, res) => {
  try {
    const { email, password, name, role } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const permissions = getUserPermissions(role || 'admin');

    // Check if user exists
    const existingUser = await db.get('SELECT id FROM users WHERE email = ?', [email]);

    if (existingUser) {
      await db.run('UPDATE users SET password = ?, name = ?, role = ? WHERE email = ?',
        [hashedPassword, name || 'User', role || 'admin', email]);
      res.json({ message: 'User updated', email, action: 'updated' });
    } else {
      await db.run(`
        INSERT INTO users (name, email, password, role, department, permissions, email_verified, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        name || 'User',
        email,
        hashedPassword,
        role || 'admin',
        'Administração',
        JSON.stringify(permissions),
        true,
        true
      ]);
      res.json({ message: 'User created', email, action: 'created' });
    }

  } catch (error) {
    res.status(500).json({ error: 'Database error', details: error.message });
  }
});

// API 404 handler for unmatched API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({ error: 'API endpoint não encontrado' });
});

// SPA fallback for production - serve index.html for all non-API routes
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile('index.html', { root: 'dist/spa' });
  });
} else {
  // 404 handler for development
  app.use((req, res) => {
    res.status(404).json({ error: 'Endpoint não encontrado' });
  });
}

// Error handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

// Start server
const startServer = async () => {
  try {
    await initializeSQLiteDatabase();
    
    app.listen(PORT, () => {
      console.log(`🚀 Servidor rodando na porta ${PORT}`);
      console.log(`📱 Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:8081'}`);
      console.log(`🔗 API Health: http://localhost:${PORT}/api/health`);
      console.log('');
      console.log('👤 Usuários de demonstração:');
      console.log('   Admin: admin@integrerh.com / admin123');
      console.log('   RH: rh@integrerh.com / rh123');
      console.log('   Gestor: gestor@integrerh.com / gestor123');
      console.log('   Funcionário: funcionario@integrerh.com / func123');
      console.log('   Candidato: candidato@integrerh.com / cand123');
    });
  } catch (error) {
    console.error('❌ Falha ao iniciar servidor:', error);
    process.exit(1);
  }
};

startServer();

export default app;
