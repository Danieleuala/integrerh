import express, { Request, Response } from "express";
import { body, validationResult, query } from "express-validator";
import { AuthenticatedRequest, requireRole } from "../middleware/auth";
import {
  createEmployee,
  getEmployeeById,
  getEmployeesByCompany,
  updateEmployee,
  deleteEmployee,
  getEmployeeStats,
} from "../database/queries/employees";
import { logActivity } from "../database/queries/activity";
import { uploadFile } from "../middleware/upload";

const router = express.Router();

// Validation rules
const createEmployeeValidation = [
  body("name")
    .isLength({ min: 2 })
    .withMessage("Nome deve ter pelo menos 2 caracteres"),
  body("email").isEmail().withMessage("Email inválido"),
  body("phone")
    .optional()
    .isMobilePhone("pt-BR")
    .withMessage("Telefone inválido"),
  body("cpf")
    .matches(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)
    .withMessage("CPF inválido"),
  body("rg").isLength({ min: 5 }).withMessage("RG inválido"),
  body("position").isLength({ min: 2 }).withMessage("Cargo é obrigatório"),
  body("department")
    .isLength({ min: 2 })
    .withMessage("Departamento é obrigatório"),
  body("address")
    .isLength({ min: 10 })
    .withMessage("Endereço completo é obrigatório"),
  body("joinDate").isISO8601().withMessage("Data de admissão inválida"),
  body("salary")
    .optional()
    .isNumeric()
    .withMessage("Salário deve ser numérico"),
];

const updateEmployeeValidation = [
  body("name")
    .optional()
    .isLength({ min: 2 })
    .withMessage("Nome deve ter pelo menos 2 caracteres"),
  body("email").optional().isEmail().withMessage("Email inválido"),
  body("phone")
    .optional()
    .isMobilePhone("pt-BR")
    .withMessage("Telefone inválido"),
  body("position")
    .optional()
    .isLength({ min: 2 })
    .withMessage("Cargo é obrigatório"),
  body("department")
    .optional()
    .isLength({ min: 2 })
    .withMessage("Departamento é obrigatório"),
  body("salary")
    .optional()
    .isNumeric()
    .withMessage("Salário deve ser numérico"),
];

// Get all employees (with filters)
router.get(
  "/",
  requireRole(["rh_admin", "manager"]),
  [
    query("page")
      .optional()
      .isInt({ min: 1 })
      .withMessage("Página deve ser um número positivo"),
    query("limit")
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage("Limite deve ser entre 1 e 100"),
    query("department").optional().isString(),
    query("status")
      .optional()
      .isIn(["active", "inactive", "on_leave", "terminated"]),
    query("search").optional().isString(),
  ],
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Parâmetros inválidos",
          details: errors.array(),
        });
      }

      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const department = req.query.department as string;
      const status = req.query.status as string;
      const search = req.query.search as string;

      const filters = {
        department,
        status,
        search,
        page,
        limit,
      };

      const result = await getEmployeesByCompany(req.user!.companyId!, filters);

      res.json({
        employees: result.employees,
        pagination: {
          page,
          limit,
          total: result.total,
          totalPages: Math.ceil(result.total / limit),
        },
      });
    } catch (error) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Get employee by ID
router.get(
  "/:id",
  requireRole(["rh_admin", "manager", "employee"]),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const employee = await getEmployeeById(id);

      if (!employee) {
        return res.status(404).json({ error: "Funcionário não encontrado" });
      }

      // Check access permissions
      if (req.user!.role === "employee" && employee.user_id !== req.user!.id) {
        return res.status(403).json({ error: "Acesso negado" });
      }

      if (req.user!.companyId && employee.company_id !== req.user!.companyId) {
        return res
          .status(403)
          .json({ error: "Funcionário não pertence à sua empresa" });
      }

      res.json(employee);
    } catch (error) {
      console.error("Error fetching employee:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Create new employee
router.post(
  "/",
  requireRole(["rh_admin", "manager"]),
  createEmployeeValidation,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Dados inválidos",
          details: errors.array(),
        });
      }

      const employeeData = {
        ...req.body,
        company_id: req.user!.companyId!,
        created_by: req.user!.id,
      };

      const employeeId = await createEmployee(employeeData);

      // Log activity
      await logActivity(
        req.user!.id,
        "employee_create",
        "employees",
        `Funcionário ${req.body.name} criado`,
      );

      res.status(201).json({
        message: "Funcionário criado com sucesso",
        employeeId,
      });
    } catch (error) {
      console.error("Error creating employee:", error);

      if (error instanceof Error && error.message.includes("Duplicate entry")) {
        return res.status(409).json({
          error: "CPF ou email já cadastrado",
        });
      }

      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Update employee
router.put(
  "/:id",
  requireRole(["rh_admin", "manager"]),
  updateEmployeeValidation,
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Dados inválidos",
          details: errors.array(),
        });
      }

      const { id } = req.params;

      // Check if employee exists and belongs to company
      const employee = await getEmployeeById(id);
      if (!employee) {
        return res.status(404).json({ error: "Funcionário não encontrado" });
      }

      if (employee.company_id !== req.user!.companyId) {
        return res
          .status(403)
          .json({ error: "Funcionário não pertence à sua empresa" });
      }

      const success = await updateEmployee(id, req.body);

      if (!success) {
        return res
          .status(400)
          .json({ error: "Falha ao atualizar funcionário" });
      }

      // Log activity
      await logActivity(
        req.user!.id,
        "employee_update",
        "employees",
        `Funcionário ${employee.name} atualizado`,
      );

      res.json({ message: "Funcionário atualizado com sucesso" });
    } catch (error) {
      console.error("Error updating employee:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Delete employee
router.delete(
  "/:id",
  requireRole(["rh_admin"]),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;

      // Check if employee exists and belongs to company
      const employee = await getEmployeeById(id);
      if (!employee) {
        return res.status(404).json({ error: "Funcionário não encontrado" });
      }

      if (employee.company_id !== req.user!.companyId) {
        return res
          .status(403)
          .json({ error: "Funcionário não pertence à sua empresa" });
      }

      const success = await deleteEmployee(id);

      if (!success) {
        return res.status(400).json({ error: "Falha ao excluir funcionário" });
      }

      // Log activity
      await logActivity(
        req.user!.id,
        "employee_delete",
        "employees",
        `Funcionário ${employee.name} excluído`,
      );

      res.json({ message: "Funcionário excluído com sucesso" });
    } catch (error) {
      console.error("Error deleting employee:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Update employee status
router.patch(
  "/:id/status",
  requireRole(["rh_admin", "manager"]),
  [
    body("status")
      .isIn(["active", "inactive", "on_leave", "terminated"])
      .withMessage("Status inválido"),
    body("reason").optional().isString().withMessage("Motivo deve ser texto"),
  ],
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Dados inválidos",
          details: errors.array(),
        });
      }

      const { id } = req.params;
      const { status, reason } = req.body;

      // Check if employee exists and belongs to company
      const employee = await getEmployeeById(id);
      if (!employee) {
        return res.status(404).json({ error: "Funcionário não encontrado" });
      }

      if (employee.company_id !== req.user!.companyId) {
        return res
          .status(403)
          .json({ error: "Funcionário não pertence à sua empresa" });
      }

      const updateData: any = { status };

      if (status === "terminated" && reason) {
        updateData.termination_reason = reason;
        updateData.termination_date = new Date().toISOString().split("T")[0];
      }

      const success = await updateEmployee(id, updateData);

      if (!success) {
        return res.status(400).json({ error: "Falha ao atualizar status" });
      }

      // Log activity
      await logActivity(
        req.user!.id,
        "employee_status_change",
        "employees",
        `Status de ${employee.name} alterado para ${status}${reason ? ` - ${reason}` : ""}`,
      );

      res.json({ message: "Status atualizado com sucesso" });
    } catch (error) {
      console.error("Error updating employee status:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Upload employee avatar
router.post(
  "/:id/avatar",
  requireRole(["rh_admin", "manager", "employee"]),
  uploadFile.single("avatar"),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;

      if (!req.file) {
        return res
          .status(400)
          .json({ error: "Arquivo de imagem é obrigatório" });
      }

      // Check if employee exists and access permissions
      const employee = await getEmployeeById(id);
      if (!employee) {
        return res.status(404).json({ error: "Funcionário não encontrado" });
      }

      // Employees can only update their own avatar
      if (req.user!.role === "employee" && employee.user_id !== req.user!.id) {
        return res.status(403).json({ error: "Acesso negado" });
      }

      if (req.user!.companyId && employee.company_id !== req.user!.companyId) {
        return res
          .status(403)
          .json({ error: "Funcionário não pertence à sua empresa" });
      }

      const avatarUrl = `/uploads/avatars/${req.file.filename}`;

      const success = await updateEmployee(id, { avatar: avatarUrl });

      if (!success) {
        return res.status(400).json({ error: "Falha ao atualizar avatar" });
      }

      // Log activity
      await logActivity(
        req.user!.id,
        "employee_avatar_update",
        "employees",
        `Avatar de ${employee.name} atualizado`,
      );

      res.json({
        message: "Avatar atualizado com sucesso",
        avatarUrl,
      });
    } catch (error) {
      console.error("Error uploading avatar:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Get employee statistics
router.get(
  "/stats/overview",
  requireRole(["rh_admin", "manager"]),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const stats = await getEmployeeStats(req.user!.companyId!);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching employee stats:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

// Get departments list
router.get(
  "/departments/list",
  requireRole(["rh_admin", "manager"]),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { departments } = await getEmployeesByCompany(
        req.user!.companyId!,
        {
          departments_only: true,
        },
      );

      res.json({ departments });
    } catch (error) {
      console.error("Error fetching departments:", error);
      res.status(500).json({ error: "Erro interno do servidor" });
    }
  },
);

export default router;
