import { Request, Response } from 'express';

// Email integration with Resend
interface EmailRequest {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  template?: string;
  templateData?: any;
}

export async function sendEmail(req: Request, res: Response) {
  try {
    const { to, subject, html, text, template, templateData }: EmailRequest = req.body;

    if (!process.env.RESEND_API_KEY) {
      return res.status(500).json({ 
        error: 'Email service not configured. Please set RESEND_API_KEY environment variable.' 
      });
    }

    let emailContent = html;
    
    // Handle templates
    if (template && templateData) {
      emailContent = generateEmailTemplate(template, templateData);
    }

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: `${process.env.FROM_NAME || 'Integre RH'} <${process.env.FROM_EMAIL || 'noreply@integrerh.com.br'}>`,
        to: Array.isArray(to) ? to : [to],
        subject,
        html: emailContent,
        ...(text && { text })
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return res.status(400).json({ error: errorData.message || 'Failed to send email' });
    }

    const data = await response.json();
    
    res.json({ 
      success: true, 
      messageId: data.id,
      message: 'Email sent successfully' 
    });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function sendPasswordResetEmail(req: Request, res: Response) {
  try {
    const { email, userName, resetToken } = req.body;

    if (!email || !userName || !resetToken) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const resetLink = `${process.env.APP_URL || 'http://localhost:5173'}/reset-password?token=${resetToken}`;
    
    const emailContent = generateEmailTemplate('password-reset', {
      userName,
      resetLink
    });

    const emailReq: EmailRequest = {
      to: email,
      subject: 'Redefinição de Senha - Integre RH',
      html: emailContent
    };

    return sendEmail({ body: emailReq } as Request, res);
  } catch (error) {
    console.error('Error sending password reset email:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function sendWelcomeEmail(req: Request, res: Response) {
  try {
    const { email, userName, userRole } = req.body;

    if (!email || !userName || !userRole) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const loginLink = `${process.env.APP_URL || 'http://localhost:5173'}/login`;
    
    const emailContent = generateEmailTemplate('welcome', {
      userName,
      userRole,
      loginLink
    });

    const emailReq: EmailRequest = {
      to: email,
      subject: 'Bem-vindo ao Integre RH!',
      html: emailContent
    };

    return sendEmail({ body: emailReq } as Request, res);
  } catch (error) {
    console.error('Error sending welcome email:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// WhatsApp integration with Meta Business API
interface WhatsAppMessage {
  to: string;
  type: 'text' | 'template' | 'interactive';
  text?: {
    body: string;
    preview_url?: boolean;
  };
  template?: {
    name: string;
    language: {
      code: string;
    };
    components?: any[];
  };
  interactive?: {
    type: 'button' | 'list';
    body: {
      text: string;
    };
    action: any;
  };
}

export async function sendWhatsAppMessage(req: Request, res: Response) {
  try {
    const { to, message, type = 'text' }: { to: string; message: string; type?: string } = req.body;

    if (!to || !message) {
      return res.status(400).json({ error: 'Missing required fields: to, message' });
    }

    if (!process.env.WHATSAPP_ACCESS_TOKEN || !process.env.WHATSAPP_PHONE_NUMBER_ID) {
      return res.status(500).json({ 
        error: 'WhatsApp service not configured. Please set WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID environment variables.' 
      });
    }

    const whatsappMessage: WhatsAppMessage = {
      to,
      type: 'text',
      text: {
        body: message,
        preview_url: true
      }
    };

    const response = await fetch(`https://graph.facebook.com/v18.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        ...whatsappMessage
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return res.status(400).json({ error: errorData.error?.message || 'Failed to send WhatsApp message' });
    }

    const data = await response.json();
    
    res.json({ 
      success: true, 
      messageId: data.messages?.[0]?.id,
      message: 'WhatsApp message sent successfully' 
    });
  } catch (error) {
    console.error('Error sending WhatsApp message:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function sendWhatsAppTemplate(req: Request, res: Response) {
  try {
    const { 
      to, 
      templateName, 
      languageCode = 'pt_BR', 
      components 
    }: { 
      to: string; 
      templateName: string; 
      languageCode?: string; 
      components?: any[] 
    } = req.body;

    if (!to || !templateName) {
      return res.status(400).json({ error: 'Missing required fields: to, templateName' });
    }

    if (!process.env.WHATSAPP_ACCESS_TOKEN || !process.env.WHATSAPP_PHONE_NUMBER_ID) {
      return res.status(500).json({ 
        error: 'WhatsApp service not configured.' 
      });
    }

    const whatsappMessage: WhatsAppMessage = {
      to,
      type: 'template',
      template: {
        name: templateName,
        language: {
          code: languageCode
        },
        ...(components && { components })
      }
    };

    const response = await fetch(`https://graph.facebook.com/v18.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        ...whatsappMessage
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return res.status(400).json({ error: errorData.error?.message || 'Failed to send WhatsApp template' });
    }

    const data = await response.json();
    
    res.json({ 
      success: true, 
      messageId: data.messages?.[0]?.id,
      message: 'WhatsApp template sent successfully' 
    });
  } catch (error) {
    console.error('Error sending WhatsApp template:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// WhatsApp webhook handler
export async function whatsappWebhook(req: Request, res: Response) {
  try {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    // Webhook verification
    if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
      console.log('WhatsApp webhook verified');
      return res.status(200).send(challenge);
    }

    // Handle incoming messages
    if (req.body.object === 'whatsapp_business_account') {
      const entry = req.body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;

      if (value?.messages?.[0]) {
        const message = value.messages[0];
        const contact = value.contacts?.[0];
        
        console.log('Received WhatsApp message:', {
          from: message.from,
          message: message.text?.body || message.caption || '',
          messageId: message.id,
          timestamp: message.timestamp,
          type: message.type
        });

        // Here you can process the incoming message
        // For example, add to a queue for processing, save to database, etc.
      }

      res.status(200).send('OK');
    } else {
      res.status(404).send('Not Found');
    }
  } catch (error) {
    console.error('WhatsApp webhook error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// HR-specific integration functions
export async function sendJobNotification(req: Request, res: Response) {
  try {
    const { 
      candidateEmail, 
      candidatePhone, 
      candidateName, 
      jobTitle, 
      companyName,
      method = 'email' 
    } = req.body;

    if (!candidateName || !jobTitle) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const results: any = {};

    // Send email notification
    if (method === 'email' || method === 'both') {
      if (candidateEmail) {
        const emailContent = generateEmailTemplate('job-notification', {
          candidateName,
          jobTitle,
          companyName: companyName || 'Integre RH',
          statusUrl: `${process.env.APP_URL || 'http://localhost:5173'}/candidate-portal`
        });

        const emailReq: EmailRequest = {
          to: candidateEmail,
          subject: `Nova Oportunidade: ${jobTitle}`,
          html: emailContent
        };

        try {
          await sendEmail({ body: emailReq } as Request, { json: () => {} } as Response);
          results.email = 'sent';
        } catch (error) {
          results.email = 'failed';
        }
      }
    }

    // Send WhatsApp notification
    if (method === 'whatsapp' || method === 'both') {
      if (candidatePhone) {
        const message = `🎯 Olá ${candidateName}! Sua candidatura para ${jobTitle} na ${companyName || 'nossa empresa'} foi recebida com sucesso. Acompanhe o status através do nosso portal.`;

        try {
          await sendWhatsAppMessage({ 
            body: { 
              to: candidatePhone, 
              message 
            } 
          } as Request, { json: () => {} } as Response);
          results.whatsapp = 'sent';
        } catch (error) {
          results.whatsapp = 'failed';
        }
      }
    }

    res.json({ 
      success: true, 
      results,
      message: 'Notifications processed' 
    });
  } catch (error) {
    console.error('Error sending job notification:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function sendStatusUpdate(req: Request, res: Response) {
  try {
    const { 
      candidateEmail, 
      candidatePhone, 
      candidateName, 
      jobTitle, 
      newStatus,
      notes,
      method = 'email' 
    } = req.body;

    if (!candidateName || !jobTitle || !newStatus) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const statusMessages: Record<string, string> = {
      'screening': 'Sua candidatura passou para a triagem de currículo',
      'phone_interview': 'Parabéns! Você foi selecionado(a) para entrevista por telefone',
      'technical_test': 'Próxima etapa: teste técnico',
      'final_interview': 'Última etapa: entrevista final',
      'approved': 'Parabéns! Você foi aprovado(a)! 🎉',
      'rejected': 'Infelizmente não seguiremos com sua candidatura desta vez'
    };

    const statusText = statusMessages[newStatus] || 'Status da candidatura atualizado';
    const results: any = {};

    // Send email notification
    if (method === 'email' || method === 'both') {
      if (candidateEmail) {
        const emailContent = generateEmailTemplate('status-update', {
          candidateName,
          jobTitle,
          statusText,
          notes
        });

        const emailReq: EmailRequest = {
          to: candidateEmail,
          subject: `Atualização da Candidatura - ${jobTitle}`,
          html: emailContent
        };

        try {
          await sendEmail({ body: emailReq } as Request, { json: () => {} } as Response);
          results.email = 'sent';
        } catch (error) {
          results.email = 'failed';
        }
      }
    }

    // Send WhatsApp notification
    if (method === 'whatsapp' || method === 'both') {
      if (candidatePhone) {
        const message = `📊 ${candidateName}, ${statusText} para a vaga ${jobTitle}. ${notes ? `Observações: ${notes}` : ''}`;

        try {
          await sendWhatsAppMessage({ 
            body: { 
              to: candidatePhone, 
              message 
            } 
          } as Request, { json: () => {} } as Response);
          results.whatsapp = 'sent';
        } catch (error) {
          results.whatsapp = 'failed';
        }
      }
    }

    res.json({ 
      success: true, 
      results,
      message: 'Status update notifications processed' 
    });
  } catch (error) {
    console.error('Error sending status update:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function sendTrainingNotification(req: Request, res: Response) {
  try {
    const { 
      employeeEmail, 
      employeePhone, 
      employeeName, 
      trainingTitle, 
      startDate,
      method = 'email' 
    } = req.body;

    if (!employeeName || !trainingTitle || !startDate) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const results: any = {};

    // Send email notification
    if (method === 'email' || method === 'both') {
      if (employeeEmail) {
        const emailContent = generateEmailTemplate('training-notification', {
          employeeName,
          trainingTitle,
          startDate,
          accessLink: `${process.env.APP_URL || 'http://localhost:5173'}/trainings`
        });

        const emailReq: EmailRequest = {
          to: employeeEmail,
          subject: `Novo Treinamento: ${trainingTitle}`,
          html: emailContent
        };

        try {
          await sendEmail({ body: emailReq } as Request, { json: () => {} } as Response);
          results.email = 'sent';
        } catch (error) {
          results.email = 'failed';
        }
      }
    }

    // Send WhatsApp notification
    if (method === 'whatsapp' || method === 'both') {
      if (employeePhone) {
        const message = `📚 ${employeeName}, você foi inscrito(a) no treinamento "${trainingTitle}" que inicia em ${startDate}. Acesse a plataforma para mais detalhes.`;

        try {
          await sendWhatsAppMessage({ 
            body: { 
              to: employeePhone, 
              message 
            } 
          } as Request, { json: () => {} } as Response);
          results.whatsapp = 'sent';
        } catch (error) {
          results.whatsapp = 'failed';
        }
      }
    }

    res.json({ 
      success: true, 
      results,
      message: 'Training notifications processed' 
    });
  } catch (error) {
    console.error('Error sending training notification:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Email template generator
function generateEmailTemplate(template: string, data: any): string {
  const baseTemplate = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>{{title}}</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
        <h1 style="color: #2563eb; margin: 0;">Integre RH</h1>
      </div>
      
      <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        {{content}}
      </div>
      
      <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
        <p>© 2024 Integre RH. Todos os direitos reservados.</p>
      </div>
    </body>
    </html>
  `;

  const templates: Record<string, { title: string; content: string }> = {
    'password-reset': {
      title: 'Redefinição de Senha',
      content: `
        <h2 style="color: #333; margin-bottom: 20px;">Redefinição de Senha</h2>
        <p>Olá, ${data.userName}!</p>
        <p>Recebemos uma solicitação para redefinir sua senha no Integre RH.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.resetLink}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
            Redefinir Senha
          </a>
        </div>
        <p style="color: #666; font-size: 14px;">Este link expira em 1 hora por motivos de segurança.</p>
      `
    },
    'welcome': {
      title: 'Bem-vindo ao Integre RH',
      content: `
        <h2 style="color: #333; margin-bottom: 20px;">Bem-vindo(a)!</h2>
        <p>Olá, ${data.userName}!</p>
        <p>Seja bem-vindo(a) ao <strong>Integre RH</strong>!</p>
        <p>Sua conta foi criada com o perfil de <strong>${data.userRole}</strong>.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.loginLink}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
            Acessar Plataforma
          </a>
        </div>
      `
    },
    'job-notification': {
      title: 'Nova Oportunidade',
      content: `
        <h2 style="color: #333; margin-bottom: 20px;">🎯 Nova Oportunidade!</h2>
        <p>Olá, ${data.candidateName}!</p>
        <p>Sua candidatura para a vaga de <strong>${data.jobTitle}</strong> na <strong>${data.companyName}</strong> foi recebida com sucesso.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.statusUrl}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
            Acompanhar Status
          </a>
        </div>
      `
    },
    'status-update': {
      title: 'Atualização da Candidatura',
      content: `
        <h2 style="color: #333; margin-bottom: 20px;">Atualização da Candidatura</h2>
        <p>Olá, ${data.candidateName}!</p>
        <p>${data.statusText} para a vaga <strong>${data.jobTitle}</strong>.</p>
        ${data.notes ? `<p><strong>Observações:</strong> ${data.notes}</p>` : ''}
      `
    },
    'training-notification': {
      title: 'Novo Treinamento',
      content: `
        <h2 style="color: #333; margin-bottom: 20px;">Novo Treinamento Disponível</h2>
        <p>Olá, ${data.employeeName}!</p>
        <p>Você foi inscrito(a) no treinamento <strong>${data.trainingTitle}</strong>.</p>
        <p><strong>Início:</strong> ${data.startDate}</p>
        ${data.accessLink ? `<div style="text-align: center; margin: 30px 0;">
          <a href="${data.accessLink}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
            Acessar Treinamento
          </a>
        </div>` : ''}
      `
    }
  };

  const templateData = templates[template];
  if (!templateData) {
    throw new Error(`Template ${template} not found`);
  }

  return baseTemplate
    .replace('{{title}}', templateData.title)
    .replace('{{content}}', templateData.content);
}

// Integration health check
export async function integrationsHealthCheck(req: Request, res: Response) {
  try {
    const health = {
      email: {
        configured: Boolean(process.env.RESEND_API_KEY),
        status: 'unknown'
      },
      whatsapp: {
        configured: Boolean(process.env.WHATSAPP_ACCESS_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID),
        status: 'unknown'
      }
    };

    // Test email service
    if (health.email.configured) {
      try {
        const response = await fetch('https://api.resend.com/domains', {
          headers: {
            'Authorization': `Bearer ${process.env.RESEND_API_KEY}`
          }
        });
        health.email.status = response.ok ? 'healthy' : 'error';
      } catch (error) {
        health.email.status = 'error';
      }
    } else {
      health.email.status = 'not_configured';
    }

    // Test WhatsApp service
    if (health.whatsapp.configured) {
      try {
        const response = await fetch(`https://graph.facebook.com/v18.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}`, {
          headers: {
            'Authorization': `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`
          }
        });
        health.whatsapp.status = response.ok ? 'healthy' : 'error';
      } catch (error) {
        health.whatsapp.status = 'error';
      }
    } else {
      health.whatsapp.status = 'not_configured';
    }

    res.json({ data: health });
  } catch (error) {
    console.error('Integrations health check failed:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}
