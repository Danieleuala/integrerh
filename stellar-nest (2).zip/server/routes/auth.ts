import express, { Request, Response } from "express";
import { body, validationResult } from "express-validator";
import rateLimit from "express-rate-limit";
import {
  generateToken,
  hashPassword,
  comparePassword,
  generateResetToken,
  verifyResetToken,
} from "../middleware/auth";
import {
  createUser,
  getUserByEmail,
  updateUserPassword,
  updateUserLastLogin,
  createPasswordReset,
  getPasswordReset,
  deletePasswordReset,
} from "../database/queries/users";
import { sendEmail } from "../services/emailService";
import { logActivity } from "../database/queries/activity";

const router = express.Router();

// Rate limiting
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  message: {
    error: "Muitas tentativas de login. Tente novamente em 15 minutos.",
  },
});

const resetLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // 3 reset attempts per hour
  message: {
    error: "Muitas solicitações de reset. Tente novamente em 1 hora.",
  },
});

// Validation rules
const registerValidation = [
  body("name")
    .isLength({ min: 2 })
    .withMessage("Nome deve ter pelo menos 2 caracteres"),
  body("email").isEmail().withMessage("Email inválido"),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Senha deve ter pelo menos 6 caracteres"),
  body("role")
    .isIn(["rh_admin", "manager", "employee", "candidate"])
    .withMessage("Tipo de usuário inválido"),
  body("companyName")
    .optional()
    .isLength({ min: 2 })
    .withMessage("Nome da empresa deve ter pelo menos 2 caracteres"),
];

const loginValidation = [
  body("email").isEmail().withMessage("Email inválido"),
  body("password").notEmpty().withMessage("Senha é obrigatória"),
];

const resetPasswordValidation = [
  body("email").isEmail().withMessage("Email inválido"),
];

const changePasswordValidation = [
  body("token").notEmpty().withMessage("Token é obrigatório"),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Nova senha deve ter pelo menos 6 caracteres"),
];

// Register endpoint
router.post(
  "/register",
  registerValidation,
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Dados inválidos",
          details: errors.array(),
        });
      }

      const { name, email, password, role, companyName, phone } = req.body;

      // Check if user already exists
      const existingUser = await getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({
          error: "Email já cadastrado no sistema",
        });
      }

      // Hash password
      const hashedPassword = await hashPassword(password);

      // Create user
      const userId = await createUser({
        name,
        email,
        password: hashedPassword,
        role,
        phone: phone || null,
        companyName: companyName || null,
      });

      // Generate token
      const token = generateToken(userId, email, role);

      // Log activity
      await logActivity(
        userId,
        "user_register",
        "auth",
        "Usuário registrado no sistema",
      );

      res.status(201).json({
        message: "Usuário criado com sucesso",
        user: {
          id: userId,
          name,
          email,
          role,
        },
        token,
      });
    } catch (error) {
      console.error("Erro no registro:", error);
      res.status(500).json({
        error: "Erro interno do servidor",
      });
    }
  },
);

// Login endpoint
router.post(
  "/login",
  authLimiter,
  loginValidation,
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Dados inválidos",
          details: errors.array(),
        });
      }

      const { email, password } = req.body;

      // Get user
      const user = await getUserByEmail(email);
      if (!user) {
        return res.status(401).json({
          error: "Email ou senha incorretos",
        });
      }

      // Check if user is active
      if (user.status !== "active") {
        return res.status(401).json({
          error: "Conta inativa. Entre em contato com o administrador.",
        });
      }

      // Verify password
      const isValidPassword = await comparePassword(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({
          error: "Email ou senha incorretos",
        });
      }

      // Update last login
      await updateUserLastLogin(user.id);

      // Generate token
      const token = generateToken(user.id, user.email, user.role);

      // Log activity
      await logActivity(
        user.id,
        "user_login",
        "auth",
        "Login realizado com sucesso",
      );

      res.json({
        message: "Login realizado com sucesso",
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          companyId: user.company_id,
          avatar: user.avatar,
        },
        token,
      });
    } catch (error) {
      console.error("Erro no login:", error);
      res.status(500).json({
        error: "Erro interno do servidor",
      });
    }
  },
);

// Forgot password endpoint
router.post(
  "/forgot-password",
  resetLimiter,
  resetPasswordValidation,
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Email inválido",
          details: errors.array(),
        });
      }

      const { email } = req.body;

      // Check if user exists
      const user = await getUserByEmail(email);
      if (!user) {
        // Don't reveal if email exists or not for security
        return res.json({
          message:
            "Se o email estiver cadastrado, você receberá as instruções de recuperação.",
        });
      }

      // Generate reset token
      const resetToken = generateResetToken();

      // Save reset token in database
      await createPasswordReset(user.id, resetToken);

      // Send reset email
      const resetUrl = `${process.env.FRONTEND_URL || "http://localhost:5173"}/reset-password?token=${resetToken}`;

      await sendEmail({
        to: email,
        subject: "Integre RH - Recuperação de Senha",
        html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #7c3aed;">Recuperação de Senha - Integre RH</h2>
          <p>Olá, ${user.name}</p>
          <p>Você solicitou a recuperação de senha para sua conta no Integre RH.</p>
          <p>Clique no botão abaixo para redefinir sua senha:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background-color: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;">
              Redefinir Senha
            </a>
          </div>
          <p style="color: #666; font-size: 14px;">
            Este link expira em 1 hora por motivos de segurança.
          </p>
          <p style="color: #666; font-size: 14px;">
            Se você não solicitou esta recuperação, ignore este email.
          </p>
          <hr style="margin: 30px 0; border: 1px solid #eee;">
          <p style="color: #999; font-size: 12px; text-align: center;">
            Integre RH - Sistema de Gestão de Recursos Humanos
          </p>
        </div>
      `,
      });

      // Log activity
      await logActivity(
        user.id,
        "password_reset_request",
        "auth",
        "Solicitação de recuperação de senha",
      );

      res.json({
        message:
          "Se o email estiver cadastrado, você receberá as instruções de recuperação.",
      });
    } catch (error) {
      console.error("Erro no reset de senha:", error);
      res.status(500).json({
        error: "Erro interno do servidor",
      });
    }
  },
);

// Reset password endpoint
router.post(
  "/reset-password",
  changePasswordValidation,
  async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: "Dados inválidos",
          details: errors.array(),
        });
      }

      const { token, password } = req.body;

      // Verify reset token
      const decoded = verifyResetToken(token);

      // Get reset record from database
      const resetRecord = await getPasswordReset(token);
      if (!resetRecord || resetRecord.used) {
        return res.status(400).json({
          error: "Token inválido ou já utilizado",
        });
      }

      // Check if token is expired (1 hour)
      const tokenAge = Date.now() - new Date(resetRecord.created_at).getTime();
      if (tokenAge > 60 * 60 * 1000) {
        // 1 hour
        return res.status(400).json({
          error: "Token expirado. Solicite uma nova recuperação.",
        });
      }

      // Hash new password
      const hashedPassword = await hashPassword(password);

      // Update user password
      await updateUserPassword(resetRecord.user_id, hashedPassword);

      // Mark token as used
      await deletePasswordReset(token);

      // Log activity
      await logActivity(
        resetRecord.user_id,
        "password_reset_complete",
        "auth",
        "Senha redefinida com sucesso",
      );

      res.json({
        message: "Senha redefinida com sucesso",
      });
    } catch (error) {
      console.error("Erro ao redefinir senha:", error);
      if (error instanceof Error && error.message.includes("Token")) {
        return res.status(400).json({
          error: error.message,
        });
      }
      res.status(500).json({
        error: "Erro interno do servidor",
      });
    }
  },
);

// Validate token endpoint
router.get("/validate", async (req: Request, res: Response) => {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).json({ error: "Token não fornecido" });
    }

    // Here you would normally verify the token and get user info
    // For now, just return a simple validation
    res.json({
      valid: true,
      message: "Token válido",
    });
  } catch (error) {
    res.status(401).json({
      valid: false,
      error: "Token inválido",
    });
  }
});

// Logout endpoint (optional - mainly for logging)
router.post("/logout", async (req: Request, res: Response) => {
  try {
    // In a JWT system, logout is mainly handled client-side
    // But we can log the activity if user ID is provided
    const { userId } = req.body;

    if (userId) {
      await logActivity(userId, "user_logout", "auth", "Logout realizado");
    }

    res.json({
      message: "Logout realizado com sucesso",
    });
  } catch (error) {
    console.error("Erro no logout:", error);
    res.status(500).json({
      error: "Erro interno do servidor",
    });
  }
});

export default router;
