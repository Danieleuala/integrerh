import { Request, Response } from 'express';
import { createClient } from '@supabase/supabase-js';

// Supabase configuration for server-side operations
const supabaseUrl = process.env.SUPABASE_URL || 'https://dummy-project.supabase.co';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR1bW15LXByb2plY3QiLCJyb2xlIjoic2VydmljZV9yb2xlIiwiaWF0IjoxNjQ2MDY3MjYwLCJleHAiOjE5NjE2NDMyNjB9.dummy-service-key-for-development';

// Create Supabase client with service role key for admin operations
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Employee Management APIs
export async function getEmployees(req: Request, res: Response) {
  try {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .order('name');

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function createEmployee(req: Request, res: Response) {
  try {
    const {
      name,
      email,
      phone,
      position,
      department,
      manager_id,
      join_date,
      salary,
      status,
      avatar
    } = req.body;

    const { data, error } = await supabase
      .from('employees')
      .insert({
        name,
        email,
        phone,
        position,
        department,
        manager_id,
        join_date,
        salary,
        status: status || 'active',
        avatar
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating employee:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function updateEmployee(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const updates = req.body;

    const { data, error } = await supabase
      .from('employees')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error updating employee:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function deleteEmployee(req: Request, res: Response) {
  try {
    const { id } = req.params;

    const { error } = await supabase
      .from('employees')
      .delete()
      .eq('id', id);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    console.error('Error deleting employee:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Job Management APIs
export async function getJobs(req: Request, res: Response) {
  try {
    const { data: jobs, error: jobsError } = await supabase
      .from('jobs')
      .select('*')
      .order('created_date', { ascending: false });

    if (jobsError) {
      return res.status(400).json({ error: jobsError.message });
    }

    // Fetch applications for each job
    const { data: applications, error: applicationsError } = await supabase
      .from('job_applications')
      .select('*');

    if (applicationsError) {
      console.error('Error fetching applications:', applicationsError);
    }

    // Combine jobs with their applications
    const jobsWithApplications = jobs.map(job => ({
      ...job,
      applications: applications?.filter(app => app.job_id === job.id) || []
    }));

    res.json({ data: jobsWithApplications });
  } catch (error) {
    console.error('Error fetching jobs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function createJob(req: Request, res: Response) {
  try {
    const {
      title,
      department,
      description,
      requirements,
      benefits,
      salary,
      type,
      status,
      created_date
    } = req.body;

    const { data, error } = await supabase
      .from('jobs')
      .insert({
        title,
        department,
        description,
        requirements,
        benefits,
        salary,
        type,
        status: status || 'draft',
        created_date: created_date || new Date().toISOString().split('T')[0]
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating job:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function updateJob(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const updates = req.body;

    const { data, error } = await supabase
      .from('jobs')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error updating job:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Job Application APIs
export async function createJobApplication(req: Request, res: Response) {
  try {
    const {
      job_id,
      candidate_name,
      candidate_email,
      phone,
      location,
      resume_url,
      applied_date,
      notes
    } = req.body;

    const { data, error } = await supabase
      .from('job_applications')
      .insert({
        job_id,
        candidate_name,
        candidate_email,
        phone,
        location,
        resume_url,
        status: 'pending',
        applied_date: applied_date || new Date().toISOString().split('T')[0],
        current_stage: 0,
        notes
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    // Create initial stage history entry
    await supabase
      .from('application_stage_history')
      .insert({
        application_id: data.id,
        stage: 'Aplicação Recebida',
        notes: 'Candidato aplicou para a vaga'
      });

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating job application:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function updateApplicationStatus(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const { status, current_stage, notes, evaluator } = req.body;

    // Update application
    const { data, error } = await supabase
      .from('job_applications')
      .update({
        status,
        current_stage,
        notes
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    // Add stage history entry
    const stageNames = [
      'Aplicação Recebida',
      'Triagem de Currículo',
      'Entrevista por Telefone',
      'Teste Técnico',
      'Entrevista Final',
      'Aprovado',
      'Rejeitado'
    ];

    const stageName = stageNames[current_stage] || status;

    await supabase
      .from('application_stage_history')
      .insert({
        application_id: id,
        stage: stageName,
        notes,
        evaluator
      });

    res.json({ data });
  } catch (error) {
    console.error('Error updating application status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Training Management APIs
export async function getTrainings(req: Request, res: Response) {
  try {
    const { data, error } = await supabase
      .from('trainings')
      .select(`
        *,
        training_participants (
          employee_id,
          progress,
          completion_date
        ),
        training_materials (
          id,
          name,
          type,
          url,
          duration,
          order_index
        )
      `)
      .order('start_date', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching trainings:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function createTraining(req: Request, res: Response) {
  try {
    const {
      title,
      description,
      category,
      duration,
      format,
      instructor,
      start_date,
      end_date,
      status
    } = req.body;

    const { data, error } = await supabase
      .from('trainings')
      .insert({
        title,
        description,
        category,
        duration,
        format,
        instructor,
        start_date,
        end_date,
        status: status || 'not_started'
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating training:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function enrollEmployeeInTraining(req: Request, res: Response) {
  try {
    const { training_id } = req.params;
    const { employee_id } = req.body;

    const { data, error } = await supabase
      .from('training_participants')
      .insert({
        training_id,
        employee_id,
        progress: 0
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error enrolling employee in training:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Evaluation Management APIs
export async function getEvaluations(req: Request, res: Response) {
  try {
    const { employee_id } = req.query;

    let query = supabase.from('evaluations').select('*');

    if (employee_id) {
      query = query.eq('employee_id', employee_id);
    }

    const { data, error } = await query.order('date', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching evaluations:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function createEvaluation(req: Request, res: Response) {
  try {
    const {
      employee_id,
      evaluator_id,
      type,
      period,
      competencies,
      overall_score,
      feedback,
      date,
      status
    } = req.body;

    const { data, error } = await supabase
      .from('evaluations')
      .insert({
        employee_id,
        evaluator_id,
        type,
        period,
        competencies,
        overall_score,
        feedback,
        date: date || new Date().toISOString().split('T')[0],
        status: status || 'pending'
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating evaluation:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Document Management APIs
export async function uploadDocument(req: Request, res: Response) {
  try {
    const { employee_id } = req.params;
    const { name, type, size } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    // Upload file to Supabase Storage
    const fileName = `${Date.now()}-${file.originalname}`;
    const filePath = `employees/${employee_id}/${fileName}`;

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('hr-documents')
      .upload(filePath, file.buffer, {
        contentType: file.mimetype
      });

    if (uploadError) {
      return res.status(400).json({ error: uploadError.message });
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from('hr-documents')
      .getPublicUrl(filePath);

    // Save document record
    const { data, error } = await supabase
      .from('documents')
      .insert({
        employee_id,
        name: name || file.originalname,
        type: type || 'other',
        size: size || `${Math.round(file.size / 1024)} KB`,
        url: urlData.publicUrl,
        storage_path: filePath
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error uploading document:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function deleteDocument(req: Request, res: Response) {
  try {
    const { employee_id, document_id } = req.params;

    // Get document info
    const { data: document, error: fetchError } = await supabase
      .from('documents')
      .select('storage_path')
      .eq('id', document_id)
      .eq('employee_id', employee_id)
      .single();

    if (fetchError) {
      return res.status(400).json({ error: fetchError.message });
    }

    // Delete from storage
    if (document.storage_path) {
      const { error: storageError } = await supabase.storage
        .from('hr-documents')
        .remove([document.storage_path]);

      if (storageError) {
        console.error('Error deleting from storage:', storageError);
      }
    }

    // Delete document record
    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', document_id)
      .eq('employee_id', employee_id);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'Document deleted successfully' });
  } catch (error) {
    console.error('Error deleting document:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Feedback APIs
export async function getFeedbacks(req: Request, res: Response) {
  try {
    const { employee_id } = req.query;

    let query = supabase.from('feedbacks').select('*');

    if (employee_id) {
      query = query.or(`from_id.eq.${employee_id},to_id.eq.${employee_id}`);
    }

    const { data, error } = await query.order('date', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching feedbacks:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function createFeedback(req: Request, res: Response) {
  try {
    const {
      from_id,
      to_id,
      message,
      type,
      competency,
      date,
      is_private
    } = req.body;

    const { data, error } = await supabase
      .from('feedbacks')
      .insert({
        from_id,
        to_id,
        message,
        type,
        competency,
        date: date || new Date().toISOString().split('T')[0],
        is_private: is_private || false
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating feedback:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Announcements APIs
export async function getAnnouncements(req: Request, res: Response) {
  try {
    const { data, error } = await supabase
      .from('announcements')
      .select('*')
      .order('date', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ data });
  } catch (error) {
    console.error('Error fetching announcements:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

export async function createAnnouncement(req: Request, res: Response) {
  try {
    const {
      title,
      content,
      author,
      date,
      priority,
      departments
    } = req.body;

    const { data, error } = await supabase
      .from('announcements')
      .insert({
        title,
        content,
        author,
        date: date || new Date().toISOString().split('T')[0],
        priority: priority || 'medium',
        departments
      })
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.status(201).json({ data });
  } catch (error) {
    console.error('Error creating announcement:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Analytics and Reports APIs
export async function getAnalytics(req: Request, res: Response) {
  try {
    // Fetch various analytics data
    const [
      { count: totalEmployees },
      { count: activeEmployees },
      { count: totalJobs },
      { count: openJobs },
      { count: totalTrainings },
      { count: activeTrainings },
      { count: totalEvaluations },
      { count: pendingEvaluations }
    ] = await Promise.all([
      supabase.from('employees').select('*', { count: 'exact', head: true }),
      supabase.from('employees').select('*', { count: 'exact', head: true }).eq('status', 'active'),
      supabase.from('jobs').select('*', { count: 'exact', head: true }),
      supabase.from('jobs').select('*', { count: 'exact', head: true }).eq('status', 'open'),
      supabase.from('trainings').select('*', { count: 'exact', head: true }),
      supabase.from('trainings').select('*', { count: 'exact', head: true }).eq('status', 'in_progress'),
      supabase.from('evaluations').select('*', { count: 'exact', head: true }),
      supabase.from('evaluations').select('*', { count: 'exact', head: true }).eq('status', 'pending')
    ]);

    const analytics = {
      employees: {
        total: totalEmployees || 0,
        active: activeEmployees || 0,
        inactive: (totalEmployees || 0) - (activeEmployees || 0)
      },
      jobs: {
        total: totalJobs || 0,
        open: openJobs || 0,
        closed: (totalJobs || 0) - (openJobs || 0)
      },
      trainings: {
        total: totalTrainings || 0,
        active: activeTrainings || 0,
        completed: (totalTrainings || 0) - (activeTrainings || 0)
      },
      evaluations: {
        total: totalEvaluations || 0,
        pending: pendingEvaluations || 0,
        completed: (totalEvaluations || 0) - (pendingEvaluations || 0)
      }
    };

    res.json({ data: analytics });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// Health check API
export async function healthCheck(req: Request, res: Response) {
  try {
    // Test database connection
    const { data, error } = await supabase
      .from('employees')
      .select('id')
      .limit(1);

    if (error) {
      return res.status(500).json({
        status: 'error',
        database: 'unhealthy',
        error: error.message
      });
    }

    res.json({
      status: 'healthy',
      database: 'connected',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Health check failed:', error);
    res.status(500).json({
      status: 'error',
      database: 'error',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}
