import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Mock data (simplified versions for migration)
const mockEmployees = [
  {
    name: 'João Silva',
    email: 'joao.silva@integrerh.com',
    password: 'senha123',
    role: 'employee',
    department: 'Tecnologia',
    phone: '(11) 99999-0001'
  },
  {
    name: 'Maria Santos',
    email: 'maria.santos@integrerh.com',
    password: 'senha123',
    role: 'manager',
    department: 'Recursos Humanos',
    phone: '(11) 99999-0002'
  },
  {
    name: 'Carlos Oliveira',
    email: 'carlos.oliveira@integrerh.com',
    password: 'senha123',
    role: 'employee',
    department: 'Financeiro',
    phone: '(11) 99999-0003'
  },
  {
    name: 'Ana Costa',
    email: 'ana.costa@integrerh.com',
    password: 'senha123',
    role: 'hr',
    department: 'Recursos Humanos',
    phone: '(11) 99999-0004'
  },
  {
    name: 'Pedro Almeida',
    email: 'pedro.almeida@integrerh.com',
    password: 'senha123',
    role: 'employee',
    department: 'Marketing',
    phone: '(11) 99999-0005'
  }
];

const mockJobs = [
  {
    title: 'Desenvolvedor Frontend React',
    description: 'Desenvolvedor especializado em React.js para projetos inovadores',
    department: 'Tecnologia',
    location: 'São Paulo, SP',
    salary_min: 8000,
    salary_max: 12000,
    employment_type: 'full_time',
    status: 'open',
    requirements: JSON.stringify(['React.js', 'TypeScript', 'CSS', 'Git']),
    benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'Home office'])
  },
  {
    title: 'Analista de RH',
    description: 'Analista para gestão de pessoas e processos de RH',
    department: 'Recursos Humanos',
    location: 'São Paulo, SP',
    salary_min: 6000,
    salary_max: 9000,
    employment_type: 'full_time',
    status: 'open',
    requirements: JSON.stringify(['Graduação em RH', 'Experiência em DP', 'Excel avançado']),
    benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'VR'])
  },
  {
    title: 'Designer UX/UI',
    description: 'Designer para criação de interfaces e experiências digitais',
    department: 'Design',
    location: 'São Paulo, SP',
    salary_min: 7000,
    salary_max: 11000,
    employment_type: 'full_time',
    status: 'open',
    requirements: JSON.stringify(['Figma', 'Adobe Creative', 'Prototipagem', 'UX Research']),
    benefits: JSON.stringify(['Vale alimentação', 'Plano de saúde', 'Curso de idiomas'])
  },
  {
    title: 'Estagiário de Marketing',
    description: 'Estágio em marketing digital e campanhas online',
    department: 'Marketing',
    location: 'São Paulo, SP',
    salary_min: 1200,
    salary_max: 1800,
    employment_type: 'part_time',
    status: 'open',
    requirements: JSON.stringify(['Cursando Marketing', 'Redes sociais', 'Canva']),
    benefits: JSON.stringify(['Vale transporte', 'Auxílio educação'])
  }
];

async function migrateData() {
  let connection: mysql.Connection | null = null;
  
  try {
    console.log('🔗 Conectando ao banco de dados...');
    
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306'),
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || 'admin123',
      database: process.env.DB_NAME || 'integrerh_prod'
    });

    console.log('✅ Conectado ao banco de dados');

    // Create jobs table if not exists
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS jobs (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        department VARCHAR(100) NOT NULL,
        location VARCHAR(100),
        salary_min DECIMAL(10,2),
        salary_max DECIMAL(10,2),
        employment_type ENUM('full_time', 'part_time', 'contract') DEFAULT 'full_time',
        status ENUM('open', 'closed', 'draft') DEFAULT 'open',
        requirements JSON,
        benefits JSON,
        created_by VARCHAR(36),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    // Create job applications table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS job_applications (
        id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
        job_id VARCHAR(36) NOT NULL,
        candidate_name VARCHAR(255) NOT NULL,
        candidate_email VARCHAR(255) NOT NULL,
        candidate_phone VARCHAR(20),
        resume_url TEXT,
        cover_letter TEXT,
        status ENUM('pending', 'reviewing', 'interviewed', 'approved', 'rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
      )
    `);

    // Migrate employees (as users)
    console.log('👥 Migrando funcionários...');
    
    for (const employee of mockEmployees) {
      // Check if user already exists
      const [existing] = await connection.execute(
        'SELECT id FROM users WHERE email = ?',
        [employee.email]
      );

      if ((existing as any[]).length === 0) {
        const hashedPassword = await bcrypt.hash(employee.password, 12);
        const permissions = getUserPermissions(employee.role);
        
        await connection.execute(`
          INSERT INTO users (name, email, password, role, department, phone, permissions, email_verified)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          employee.name,
          employee.email,
          hashedPassword,
          employee.role,
          employee.department,
          employee.phone,
          JSON.stringify(permissions),
          true
        ]);
        
        console.log(`   ✓ ${employee.name} (${employee.role})`);
      } else {
        console.log(`   ⚠️  ${employee.name} já existe`);
      }
    }

    // Migrate jobs
    console.log('💼 Migrando vagas...');
    
    for (const job of mockJobs) {
      // Check if job already exists
      const [existing] = await connection.execute(
        'SELECT id FROM jobs WHERE title = ? AND department = ?',
        [job.title, job.department]
      );

      if ((existing as any[]).length === 0) {
        await connection.execute(`
          INSERT INTO jobs (title, description, department, location, salary_min, salary_max, 
                          employment_type, status, requirements, benefits)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          job.title,
          job.description,
          job.department,
          job.location,
          job.salary_min,
          job.salary_max,
          job.employment_type,
          job.status,
          job.requirements,
          job.benefits
        ]);
        
        console.log(`   ✓ ${job.title} (${job.department})`);
      } else {
        console.log(`   ⚠️  ${job.title} já existe`);
      }
    }

    console.log('✅ Migração concluída com sucesso!');
    
    // Show summary
    const [userCount] = await connection.execute('SELECT COUNT(*) as count FROM users');
    const [jobCount] = await connection.execute('SELECT COUNT(*) as count FROM jobs');
    
    console.log('\n📊 Resumo:');
    console.log(`   👥 Usuários: ${(userCount as any[])[0].count}`);
    console.log(`   💼 Vagas: ${(jobCount as any[])[0].count}`);
    
  } catch (error) {
    console.error('❌ Erro na migração:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

function getUserPermissions(role: string): string[] {
  const permissions: Record<string, string[]> = {
    admin: ['*'],
    rh_admin: ['*'],
    hr: ['users.read', 'users.write', 'jobs.read', 'jobs.write', 'evaluations.read', 'evaluations.write', 'trainings.read', 'trainings.write'],
    manager: ['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write', 'trainings.read'],
    employee: ['profile.read', 'profile.write', 'evaluations.read', 'trainings.read'],
    candidate: ['jobs.read', 'applications.read', 'applications.write']
  };
  return permissions[role] || [];
}

// Run migration if called directly
if (require.main === module) {
  migrateData().catch(console.error);
}

export { migrateData };
