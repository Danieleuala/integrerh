import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getJobs,
  createJob,
  updateJob,
  createJobApplication,
  updateApplicationStatus,
  getTrainings,
  createTraining,
  enrollEmployeeInTraining,
  getEvaluations,
  createEvaluation,
  uploadDocument,
  deleteDocument,
  getFeedbacks,
  createFeedback,
  getAnnouncements,
  createAnnouncement,
  getAnalytics,
  healthCheck
} from "./routes/hr";
import {
  sendEmail,
  sendPasswordResetEmail,
  sendWelcomeEmail,
  sendWhatsAppMessage,
  sendWhatsAppTemplate,
  whatsappWebhook,
  sendJobNotification,
  sendStatusUpdate,
  sendTrainingNotification,
  integrationsHealthCheck
} from "./routes/integrations";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Health checks
  app.get("/api/health", healthCheck);
  app.get("/api/integrations/health", integrationsHealthCheck);

  // Employee management
  app.get("/api/employees", getEmployees);
  app.post("/api/employees", createEmployee);
  app.put("/api/employees/:id", updateEmployee);
  app.delete("/api/employees/:id", deleteEmployee);

  // Job management
  app.get("/api/jobs", getJobs);
  app.post("/api/jobs", createJob);
  app.put("/api/jobs/:id", updateJob);
  app.post("/api/jobs/:id/applications", createJobApplication);
  app.put("/api/applications/:id/status", updateApplicationStatus);

  // Training management
  app.get("/api/trainings", getTrainings);
  app.post("/api/trainings", createTraining);
  app.post("/api/trainings/:training_id/enroll", enrollEmployeeInTraining);

  // Evaluation management
  app.get("/api/evaluations", getEvaluations);
  app.post("/api/evaluations", createEvaluation);

  // Document management
  app.post("/api/employees/:employee_id/documents", uploadDocument);
  app.delete("/api/employees/:employee_id/documents/:document_id", deleteDocument);

  // Feedback management
  app.get("/api/feedbacks", getFeedbacks);
  app.post("/api/feedbacks", createFeedback);

  // Announcement management
  app.get("/api/announcements", getAnnouncements);
  app.post("/api/announcements", createAnnouncement);

  // Analytics
  app.get("/api/analytics", getAnalytics);

  // Email integration
  app.post("/api/email/send", sendEmail);
  app.post("/api/email/password-reset", sendPasswordResetEmail);
  app.post("/api/email/welcome", sendWelcomeEmail);

  // WhatsApp integration
  app.post("/api/whatsapp/send", sendWhatsAppMessage);
  app.post("/api/whatsapp/template", sendWhatsAppTemplate);
  app.get("/api/webhooks/whatsapp", whatsappWebhook);
  app.post("/api/webhooks/whatsapp", whatsappWebhook);

  // HR-specific integrations
  app.post("/api/notifications/job", sendJobNotification);
  app.post("/api/notifications/status", sendStatusUpdate);
  app.post("/api/notifications/training", sendTrainingNotification);

  return app;
}
