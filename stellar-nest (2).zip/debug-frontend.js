// Simular o que o frontend está fazendo
const API_BASE_URL = 'http://localhost:3001/api';

async function testLogin() {
  console.log('🚀 Testando login do gestor...');
  console.log('📡 API URL:', API_BASE_URL);
  
  const loginData = {
    email: 'gestor@integrerh.com',
    password: 'gestor123',
    role: 'manager'
  };
  
  console.log('📝 Dados de login:', loginData);
  
  try {
    // Primeiro, testar se a API está respondendo
    console.log('\n1️⃣ Testando health check...');
    const healthResponse = await fetch(`${API_BASE_URL}/health`);
    console.log('Health status:', healthResponse.status);
    
    if (healthResponse.ok) {
      const healthData = await healthResponse.json();
      console.log('✅ Health check OK:', healthData);
    } else {
      console.log('�� Health check failed');
      return;
    }
    
    // Agora testar o login
    console.log('\n2️⃣ Testando login...');
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(loginData)
    });
    
    console.log('Login response status:', response.status);
    console.log('Login response headers:', Object.fromEntries(response.headers.entries()));
    
    const responseText = await response.text();
    console.log('Login response text:', responseText);
    
    try {
      const responseData = JSON.parse(responseText);
      console.log('Login response data:', responseData);
      
      if (response.ok) {
        console.log('✅ Login successful!');
        console.log('User:', responseData.user);
        console.log('Token:', responseData.token.substring(0, 20) + '...');
      } else {
        console.log('❌ Login failed:', responseData.error);
      }
    } catch (e) {
      console.log('❌ Response is not JSON:', responseText);
    }
    
  } catch (error) {
    console.error('❌ Network error:', error.message);
  }
}

testLogin();
