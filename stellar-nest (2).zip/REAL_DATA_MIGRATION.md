# Guia de Migração para Dados Reais - Integre RH

Este guia explica como migrar da versão com dados mock para armazenamento real usando Supabase.

## 1. Configuração do Supabase

### 1.1. Criar Projeto no Supabase

1. Acesse [https://supabase.com](https://supabase.com)
2. Crie uma nova conta ou faça login
3. Clique em "New Project"
4. Escolha uma organização e configure o projeto:
   - Nome: `integre-rh-production`
   - Região: escolha a mais próxima dos usuários
   - Plano: Free ou Pro conforme necessário

### 1.2. Executar Schema do Banco

1. No painel do Supabase, vá em "SQL Editor"
2. Copie e execute o conteúdo do arquivo `database/complete-schema.sql`
3. Verifique se todas as tabelas foram criadas corretamente

### 1.3. Configurar Storage Buckets

1. Vá em "Storage" no painel do Supabase
2. Crie os seguintes buckets:
   - `hr-documents` (público)
   - `training-videos` (público)
   - `profile-avatars` (público)

3. Configure as políticas de acesso:
   ```sql
   -- Permitir upload e leitura para usuários autenticados
   CREATE POLICY "Allow upload for authenticated users" ON storage.objects
   FOR INSERT WITH CHECK (auth.role() = 'authenticated');
   
   CREATE POLICY "Allow read access for everyone" ON storage.objects
   FOR SELECT USING (true);
   ```

## 2. Configuração das Variáveis de Ambiente

### 2.1. Desenvolvimento

Atualize o arquivo `.env`:

```bash
# Database Configuration
VITE_USE_REAL_DATABASE=true
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua_chave_anonima_aqui

# Storage buckets
VITE_SUPABASE_STORAGE_BUCKET_DOCUMENTS=hr-documents
VITE_SUPABASE_STORAGE_BUCKET_VIDEOS=training-videos
VITE_SUPABASE_STORAGE_BUCKET_AVATARS=profile-avatars
```

### 2.2. Produção

Use o arquivo `.env.production` como base e configure todas as variáveis necessárias.

## 3. Migração de Dados

### 3.1. Migração Automática

A aplicação possui um helper para migrar dados mock para o Supabase:

```typescript
import { DataAdapter } from '@/lib/dataAdapter';

// Execute uma vez para migrar os dados existentes
const migration = await DataAdapter.migrateMockDataToReal();
console.log(migration.message);
```

### 3.2. Migração Manual

Se preferir, você pode migrar os dados manualmente:

1. **Funcionários**: Vá em Funcionários > Adicionar e insira os dados
2. **Vagas**: Vá em Vagas > Nova Vaga e configure as posições
3. **Treinamentos**: Crie os treinamentos e faça upload dos materiais
4. **Documentos**: Upload via interface de cada funcionário

## 4. Funcionalidades com Dados Reais

### 4.1. Upload de Documentos

- Suporte completo a PDF, DOC, DOCX, JPG, PNG
- Armazenamento seguro no Supabase Storage
- URLs públicas com controle de acesso
- Validação de tamanho e tipo de arquivo

### 4.2. Upload de Vídeos de Treinamento

- Suporte a MP4, AVI, MOV, WMV, FLV, WEBM, MKV
- Armazenamento otimizado para vídeos grandes
- Progresso de upload em tempo real
- Detecção automática de duração

### 4.3. Dados em Tempo Real

- Atualizações automáticas via WebSockets
- Notificações instantâneas
- Sincronização entre usuários
- Cache inteligente para performance

## 5. Verificação da Configuração

### 5.1. Teste de Conexão

```typescript
import { DataAdapter } from '@/lib/dataAdapter';

// Verificar status da conexão
const health = await DataAdapter.healthCheck();
console.log('Database status:', health);
```

### 5.2. Teste de Funcionalidades

1. **Criar Funcionário**: Teste o cadastro completo
2. **Upload de Documento**: Teste com diferentes tipos
3. **Criar Treinamento**: Adicione materiais e vídeos
4. **Aplicação de Vaga**: Teste o fluxo público
5. **Dashboard**: Verifique se os dados são carregados

## 6. Configurações de Produção

### 6.1. Performance

- Configure CDN para assets estáticos
- Otimize tamanhos de imagem e vídeo
- Configure cache headers apropriados

### 6.2. Segurança

- Configure Row Level Security (RLS) no Supabase
- Implemente autenticação real
- Configure CORS adequadamente
- Use HTTPS em produção

### 6.3. Backup

- Configure backups automáticos no Supabase
- Implemente estratégia de recuperação
- Monitore uso de storage

## 7. Monitoramento

### 7.1. Métricas do Supabase

- Monitore uso de API
- Acompanhe storage utilizado
- Verifique performance das queries

### 7.2. Logs da Aplicação

- Configure logging estruturado
- Monitore erros de upload
- Acompanhe tempo de resposta

## 8. Troubleshooting

### 8.1. Problemas Comuns

**Erro de conexão com Supabase:**
- Verifique URL e chave anônima
- Confirme se o projeto está ativo
- Verifique conectividade de rede

**Upload de arquivos falha:**
- Verifique políticas de storage
- Confirme configuração dos buckets
- Verifique tamanho máximo de arquivo

**Dados não aparecem:**
- Confirme migração de dados
- Verifique políticas RLS
- Teste queries no SQL Editor

### 8.2. Logs de Debug

Para ativar logs detalhados:

```bash
VITE_ENABLE_DEBUG_LOGS=true
```

## 9. Próximos Passos

Após a migração completa:

1. Configure autenticação real (auth.supabase.io)
2. Implemente notificações por email
3. Configure integração WhatsApp Business
4. Adicione analytics e métricas
5. Configure ambiente de staging

## Suporte

Para problemas técnicos ou dúvidas sobre a migração:

1. Consulte a documentação do Supabase
2. Verifique os logs da aplicação
3. Use o SQL Editor para debug de queries
4. Configure alertas para monitoramento contínuo

---

**Importante**: Sempre teste a migração em um ambiente de desenvolvimento antes de aplicar em produção.
