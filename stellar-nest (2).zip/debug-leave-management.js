// Debug script para testar LeaveManagement
console.log('🔍 TESTANDO LEAVE MANAGEMENT - DEBUG');
console.log('=====================================');

// Simular employee sem history
const employeeWithoutHistory = {
  id: "test-1",
  name: "Teste Employee",
  email: "teste@integrerh.com.br",
  phone: "(11) 99999-9999",
  cpf: "123.456.789-00",
  rg: "12.345.678-9",
  position: "Testador",
  department: "TI",
  address: "Rua Teste, 123",
  joinDate: "2024-01-01",
  salary: 5000,
  status: "active",
  documents: [],
  evaluations: [],
  trainings: [],
  // history: undefined // Sem history - vai causar o erro
};

// Simular employee com history vazio
const employeeWithEmptyHistory = {
  ...employeeWithoutHistory,
  id: "test-2",
  history: []
};

// Simular employee com history null
const employeeWithNullHistory = {
  ...employeeWithoutHistory,
  id: "test-3",
  history: null
};

// Função para testar se history é iterável
function testHistoryIterable(employee, testName) {
  console.log(`\n🧪 Teste: ${testName}`);
  console.log(`👤 Employee ID: ${employee.id}`);
  console.log(`📋 History type: ${typeof employee.history}`);
  console.log(`🔍 Is Array: ${Array.isArray(employee.history)}`);
  
  try {
    // Simular o código original que estava falhando
    const employeeHistory = Array.isArray(employee.history) ? employee.history : [];
    const newHistoryEntry = {
      id: `h_${Date.now()}`,
      date: new Date().toISOString(),
      type: 'status_change',
      description: 'Teste de afastamento',
      details: {
        oldValue: employee.status,
        newValue: 'on_leave',
        reason: 'Teste',
        authorizedBy: 'Sistema'
      }
    };
    
    const updatedHistory = [...employeeHistory, newHistoryEntry];
    console.log(`✅ SUCESSO: History atualizado com ${updatedHistory.length} entrada(s)`);
    
    return true;
  } catch (error) {
    console.log(`❌ ERRO: ${error.message}`);
    return false;
  }
}

// Executar testes
console.log('\n🚀 EXECUTANDO TESTES...\n');

const test1 = testHistoryIterable(employeeWithoutHistory, 'Employee sem history property');
const test2 = testHistoryIterable(employeeWithEmptyHistory, 'Employee com history vazio');
const test3 = testHistoryIterable(employeeWithNullHistory, 'Employee com history null');

console.log('\n📊 RESULTADOS:');
console.log('==============');
console.log(`Teste 1 (sem history): ${test1 ? '✅ PASS' : '❌ FAIL'}`);
console.log(`Teste 2 (history vazio): ${test2 ? '✅ PASS' : '❌ FAIL'}`);
console.log(`Teste 3 (history null): ${test3 ? '✅ PASS' : '❌ FAIL'}`);

const allPassed = test1 && test2 && test3;
console.log(`\n🎯 RESULTADO FINAL: ${allPassed ? '✅ TODOS OS TESTES PASSARAM' : '❌ ALGUNS TESTES FALHARAM'}`);

if (allPassed) {
  console.log('\n🎉 O erro "employee.history is not iterable" foi CORRIGIDO!');
  console.log('💡 A função agora verifica se history é um array antes de tentar iterá-lo.');
} else {
  console.log('\n⚠️ Ainda há problemas com o tratamento de history.');
}

console.log('\n🔧 CORREÇÕES IMPLEMENTADAS:');
console.log('- ✅ Verificação Array.isArray(employee.history) antes de usar spread operator');
console.log('- ✅ Inicialização de history como array vazio quando necessário');
console.log('- ✅ Correção em handleCreateLeave e handleReturnFromLeave');
console.log('- ✅ Correção nos métodos getEmployee e getEmployees');
console.log('- ✅ Correção no addEmployee para garantir history inicializado');

console.log('\n📋 ARQUIVOS MODIFICADOS:');
console.log('- client/components/LeaveManagement.tsx');
console.log('- client/lib/mockData.ts');
console.log('- client/lib/database.ts');
