#!/bin/bash

echo "🚀 Iniciando sistema completo Integre RH..."

# Verificar se as dependências estão instaladas
if [ ! -d "node_modules" ]; then
    echo "📦 Instalando dependências..."
    npm install
fi

# Criar diretório de uploads se não existir
mkdir -p uploads

# Verificar se MySQL está disponível (opcional)
echo "🔗 Verificando conexão com banco de dados..."

# Configurar variáveis de ambiente
export NODE_ENV=development
export PORT=3001
export FRONTEND_URL=http://localhost:8081

# Iniciar servidor backend
echo "🖥️  Iniciando servidor backend na porta 3001..."
npm run start:dev &
BACKEND_PID=$!

# Aguardar alguns segundos para o backend inicializar
sleep 5

# Iniciar cliente frontend
echo "🌐 Iniciando cliente frontend na porta 8081..."
npm run dev:client &
FRONTEND_PID=$!

echo "✅ Sistema iniciado com sucesso!"
echo ""
echo "📊 Backend API: http://localhost:3001"
echo "🌐 Frontend: http://localhost:8081"
echo "🔍 Health Check: http://localhost:3001/api/health"
echo ""
echo "👤 Usuários de demonstração:"
echo "   Admin: admin@integrerh.com / admin123"
echo "   RH: rh@integrerh.com / rh123"
echo "   Gestor: gestor@integrerh.com / gestor123"
echo "   Funcionário: funcionario@integrerh.com / func123"
echo "   Candidato: candidato@integrerh.com / cand123"
echo ""
echo "🛑 Para parar o sistema, pressione Ctrl+C"

# Função para cleanup quando o script for interrompido
cleanup() {
    echo ""
    echo "🛑 Parando sistema..."
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    exit 0
}

# Capturar sinais de interrupção
trap cleanup SIGINT SIGTERM

# Aguardar até que um dos processos termine
wait $BACKEND_PID $FRONTEND_PID
