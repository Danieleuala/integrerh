# Gestão de Afastamentos - Sistema IntegrEH

## 📋 Visão Geral

A funcionalidade de **Gestão de Afastamentos** foi implementada para separar claramente os afastamentos temporários dos desligamentos definitivos, permitindo que colaboradores possam retornar à empresa após períodos de afastamento.

## 🎯 Objetivo

- **Separar afastamentos de desligamentos**: Afastamentos são temporários e reversíveis, desligamentos são definitivos
- **Gestão completa de licenças**: Diferentes tipos de afastamento com controle de datas e motivos
- **Rastreabilidade**: Histórico completo de afastamentos e retornos
- **Facilidade de uso**: Interface intuitiva para RH gerenciar afastamentos

## ⚡ Funcionalidades Implementadas

### 1. Tipos de Afastamento Suportados

- **Licença Médica**: Para tratamentos de saúde
- **Licença Maternidade**: 120 dias de licença maternidade
- **Licença Paternidade**: Licença paternidade
- **Férias**: Períodos de férias prolongadas
- **Licença Pessoal**: Motivos pessoais diversos
- **Licença Estudo**: Para cursos e capacitações
- **Outro**: Outros tipos específicos

### 2. Status do Colaborador

- **Ativo**: Trabalhando normalmente
- **Em Afastamento** (`on_leave`): Temporariamente afastado
- **Inativo**: Status inativo (sem especificar motivo)
- **Desligado** (`terminated`): Desligamento definitivo

### 3. Gestão de Afastamentos

#### Configurar Afastamento
- Seleção do tipo de afastamento
- Data de início obrigatória
- Data prevista de retorno (opcional)
- Motivo detalhado obrigatório
- Observações adicionais (opcional)
- Autorização automática pelo usuário logado

#### Registrar Retorno
- Confirmação de retorno com data atual
- Reativação automática do colaborador
- Registro no histórico do colaborador
- Atualização do status para "Ativo"

### 4. Histórico e Rastreabilidade

Cada afastamento é registrado com:
- ID único do afastamento
- Datas de início e retorno
- Tipo e motivo do afastamento
- Status (ativo/retornado/estendido)
- Quem autorizou o afastamento
- Observações e documentos relacionados

## 🔧 Componentes Implementados

### `LeaveManagement.tsx`
Componente principal para gestão de afastamentos com:
- Interface para criar novos afastamentos
- Visualização do status atual
- Histórico de afastamentos
- Controle de retorno

### Integração com `Employees.tsx`
- Novo botão "Gerenciar Afastamento" no menu de ações
- Separação clara entre "Afastamento" e "Desligamento Definitivo"
- Visualização integrada na tela de detalhes do colaborador
- Estatísticas atualizadas incluindo colaboradores afastados

## 📊 Interface do Usuário

### Ações Disponíveis no Menu do Colaborador

1. **Gerenciar Afastamento** (azul) - Para afastamentos temporários
2. **Desligar Definitivamente** (vermelho) - Para desligamentos permanentes

### Diálogos Implementados

#### 1. Diálogo de Configuração de Afastamento
- Formulário completo com validações
- Seleção de tipo via dropdown
- Campos de data com calendário
- Área de texto para motivos e observações

#### 2. Diálogo de Confirmação de Retorno
- Resumo do afastamento atual
- Confirmação com detalhes do período
- Reativação automática do colaborador

#### 3. Diálogo de Desligamento Definitivo
- Avisos claros sobre a permanência da ação
- Orientação para usar afastamentos temporários
- Confirmação dupla para evitar erros

## 🔄 Fluxo de Trabalho

### Processo de Afastamento

1. **RH acessa o colaborador** → Menu de ações → "Gerenciar Afastamento"
2. **Configurar afastamento** → Preencher formulário → Confirmar
3. **Status alterado** → Colaborador fica "Em Afastamento"
4. **Registro criado** → Histórico atualizado automaticamente

### Processo de Retorno

1. **RH acessa afastamento ativo** → "Registrar Retorno"
2. **Confirmar retorno** → Data atual registrada automaticamente
3. **Status reativado** → Colaborador volta para "Ativo"
4. **Histórico atualizado** → Registro de retorno criado

## 💾 Armazenamento de Dados

### LocalStorage (Temporário)
Os registros de afastamento são salvos em `localStorage` com a chave `employeeLeaves`:

```typescript
interface LeaveRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  leaveType: 'medical' | 'maternity' | 'paternity' | 'vacation' | 'personal' | 'study' | 'other';
  startDate: string;
  expectedReturnDate?: string;
  actualReturnDate?: string;
  reason: string;
  status: 'active' | 'returned' | 'extended';
  authorizedBy: string;
  documents: string[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
}
```

### Histórico do Colaborador
Cada mudança é registrada no campo `history` do colaborador:

```typescript
{
  id: `h_${Date.now()}`,
  date: new Date().toISOString(),
  type: 'status_change',
  description: `Colaborador em afastamento - ${tipoAfastamento}`,
  details: {
    oldValue: 'active',
    newValue: 'on_leave',
    reason: motivo,
    leaveType: tipo,
    expectedReturn: dataRetorno,
    authorizedBy: usuario
  }
}
```

## 🎨 Indicadores Visuais

### Badges de Status
- **Ativo**: Verde - `bg-green-100 text-green-700`
- **Em Afastamento**: Laranja - `border-orange-200 text-orange-700`
- **Inativo**: Cinza - `bg-gray-100 text-gray-700`
- **Desligado**: Vermelho - `bg-red-100 text-red-700`

### Cards de Estatísticas
- Contador de colaboradores afastados
- Taxa de atividade calculada automaticamente
- Indicadores coloridos por categoria

## ⚠️ Validações e Regras

### Validações de Formulário
- Tipo de afastamento é obrigatório
- Data de início é obrigatória
- Motivo é obrigatório (mínimo de caracteres)
- Data de retorno deve ser posterior à data de início

### Regras de Negócio
- Apenas um afastamento ativo por colaborador
- Colaboradores inativos/desligados não podem ter novos afastamentos
- Retorno só é possível para afastamentos ativos
- Histórico preservado mesmo após retorno

## 🔮 Futuras Melhorias

### Integração com Banco de Dados
- Migrar de localStorage para tabelas SQL
- Relacionamento adequado entre Employee e LeaveRecord
- Backup automático dos dados

### Funcionalidades Adicionais
- Notificações automáticas de retorno previsto
- Integração com sistema de documentos médicos
- Relatórios específicos de afastamentos
- Aprovação em múltiplos níveis
- Extensão de afastamentos

### Interface Melhorada
- Calendário visual para visualizar afastamentos
- Dashboard específico para gestão de licenças
- Filtros avançados por tipo de afastamento
- Exportação de relatórios de afastamentos

## 🧪 Como Testar

1. **Acesse a página de Colaboradores**
2. **Selecione um colaborador ativo**
3. **Clique em "Gerenciar Afastamento"**
4. **Configure um afastamento teste**
5. **Verifique o status alterado**
6. **Teste o retorno do afastamento**
7. **Confirme o histórico atualizado**

## 📝 Notas Técnicas

- Componente totalmente responsivo
- Compatível com sistema de permissões existente
- Integração completa com `IntegratedDataStore`
- Preserva padrões de UI/UX do sistema
- Código TypeScript com tipagem completa
- Componentes reutilizáveis e modulares

---

**Implementado em**: Agosto 2024  
**Versão**: 1.0  
**Status**: Funcional e Testado  
**Compatibilidade**: Sistema IntegrEH v2.0+
