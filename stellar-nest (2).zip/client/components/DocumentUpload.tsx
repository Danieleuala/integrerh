import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Upload, FileText, CheckCircle, AlertCircle, X } from 'lucide-react';
import { DataAdapter } from '@/lib/dataAdapter';
import { fileUploadService, formatFileSize, validateFile, FILE_TYPES, MAX_FILE_SIZES } from '@/lib/fileUploadService';

interface DocumentUploadProps {
  employeeId: string;
  onDocumentAdded: () => void;
}

export function DocumentUpload({ employeeId, onDocumentAdded }: DocumentUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [detectedType, setDetectedType] = useState<'contract' | 'id' | 'certificate' | 'other' | null>(null);
  const [manualType, setManualType] = useState<'contract' | 'id' | 'certificate' | 'other'>('other');
  const [useManualType, setUseManualType] = useState(false);

  const detectDocumentType = (fileName: string): 'contract' | 'id' | 'certificate' | 'other' => {
    const name = fileName.toLowerCase();

    // Palavras-chave para contratos
    const contractKeywords = ['contrato', 'contract', 'acordo', 'termo', 'admissao', 'admissão', 'ctps'];
    if (contractKeywords.some(keyword => name.includes(keyword))) {
      return 'contract';
    }

    // Palavras-chave para documentos pessoais
    const idKeywords = ['rg', 'cpf', 'identidade', 'carteira', 'cnh', 'passaporte', 'titulo', 'reservista'];
    if (idKeywords.some(keyword => name.includes(keyword))) {
      return 'id';
    }

    // Palavras-chave para certificados
    const certificateKeywords = ['certificado', 'diploma', 'curso', 'capacitacao', 'capacitação', 'treinamento'];
    if (certificateKeywords.some(keyword => name.includes(keyword))) {
      return 'certificate';
    }

    return 'other';
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    setError(null);

    if (file) {
      // Validate file
      const allowedTypes = FILE_TYPES.DOCUMENTS;
      const maxSize = MAX_FILE_SIZES.DOCUMENT;

      const validation = validateFile(file, allowedTypes, maxSize);
      if (!validation.valid) {
        setError(validation.error || 'Arquivo inválido');
        return;
      }

      setSelectedFile(file);
      const detected = detectDocumentType(file.name);
      setDetectedType(detected);
      setManualType(detected);
      setUseManualType(false);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    setUploading(true);
    setUploadProgress(0);
    setError(null);

    try {
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      // Upload file to Supabase storage
      const documentType = useManualType ? manualType : detectedType || 'other';
      const uploadResult = await fileUploadService.uploadEmployeeDocument(
        selectedFile,
        employeeId,
        documentType
      );

      clearInterval(progressInterval);

      if (!uploadResult.success) {
        throw new Error(uploadResult.error || 'Erro ao fazer upload do arquivo');
      }

      // Create document object
      const newDocument = {
        name: selectedFile.name,
        type: documentType,
        uploadDate: new Date().toISOString().split('T')[0],
        size: formatFileSize(selectedFile.size),
        url: uploadResult.url,
        storage_path: uploadResult.path
      };

      // Add document to database
      const success = await DataAdapter.addDocument(employeeId, newDocument);

      if (!success) {
        throw new Error('Erro ao salvar documento no banco de dados');
      }

      setUploadProgress(100);
      setUploading(false);
      setSuccess(true);

      // Call the callback after successful upload
      setTimeout(() => {
        onDocumentAdded();
        setSelectedFile(null);
        setDetectedType(null);
        setSuccess(false);
        setUploadProgress(0);
      }, 1500);
    } catch (error) {
      setUploading(false);
      setUploadProgress(0);
      setError(error instanceof Error ? error.message : 'Erro desconhecido');
      console.error('Error uploading document:', error);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setDetectedType(null);
    setError(null);
    setUploadProgress(0);
  };

  if (success) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800">
          Documento enviado com sucesso!
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            {error}
          </AlertDescription>
        </Alert>
      )}

      <Card className="border-dashed border-2 border-gray-300 hover:border-purple-400 transition-colors">
        <CardContent className="p-6">
          <div className="text-center">
            <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Enviar Documento
            </h3>
            <p className="text-gray-600 mb-4">
              Selecione um arquivo para fazer upload (PDF, DOC, DOCX, JPG, PNG)
            </p>
            <p className="text-sm text-gray-500 mb-4">
              Tamanho máximo: {formatFileSize(MAX_FILE_SIZES.DOCUMENT)}
            </p>

            <div className="space-y-4">
              <div>
                <Label htmlFor="file-upload">Arquivo</Label>
                <Input
                  id="file-upload"
                  type="file"
                  accept={FILE_TYPES.DOCUMENTS.join(',')}
                  onChange={handleFileSelect}
                  className="cursor-pointer"
                  disabled={uploading}
                />
              </div>
              
              {selectedFile && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-5 h-5 text-gray-500" />
                      <div>
                        <p className="font-medium text-sm">{selectedFile.name}</p>
                        <p className="text-xs text-gray-500">
                          {formatFileSize(selectedFile.size)}
                        </p>
                      </div>
                    </div>
                    {!uploading && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearFile}
                        className="h-8 w-8 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  {uploading && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Enviando...</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <Progress value={uploadProgress} className="w-full" />
                    </div>
                  )}

                  {detectedType && (
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-blue-800">Tipo detectado automaticamente:</span>
                        <Badge className="bg-blue-100 text-blue-700">
                          {detectedType === 'contract' && '📄 Contrato'}
                          {detectedType === 'id' && '🆔 Documento Pessoal'}
                          {detectedType === 'certificate' && '🏆 Certificado'}
                          {detectedType === 'other' && '📎 Outros'}
                        </Badge>
                      </div>

                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="manual-type"
                          checked={useManualType}
                          onChange={(e) => setUseManualType(e.target.checked)}
                          className="rounded"
                        />
                        <Label htmlFor="manual-type" className="text-sm text-blue-700">
                          Alterar tipo manualmente
                        </Label>
                      </div>

                      {useManualType && (
                        <div className="mt-3">
                          <Label className="text-sm font-medium text-gray-700">Tipo do documento:</Label>
                          <Select value={manualType} onValueChange={(value: any) => setManualType(value)}>
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="contract">📄 Contrato</SelectItem>
                              <SelectItem value="id">🆔 Documento Pessoal</SelectItem>
                              <SelectItem value="certificate">🏆 Certificado</SelectItem>
                              <SelectItem value="other">📎 Outros</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
              
              <div className="flex justify-end space-x-3">
                {selectedFile && !uploading && (
                  <Button
                    variant="outline"
                    onClick={clearFile}
                  >
                    Cancelar
                  </Button>
                )}
                <Button
                  onClick={handleUpload}
                  disabled={!selectedFile || uploading}
                  className="bg-gradient-to-r from-purple-600 to-blue-600"
                >
                  {uploading ? `Enviando... ${uploadProgress}%` : 'Enviar Documento'}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
