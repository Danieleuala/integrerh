import { useAuth, getRoleDisplayName } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Heart, Search, Bell, User, LogOut, Settings, 
  Users, Briefcase, Award, BookOpen, MessageSquare, 
  BarChart3, FileText, Megaphone, Home, ChevronDown
} from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ReactNode } from 'react';

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navigationItems = [
    {
      title: 'Dashboard',
      href: '/dashboard',
      icon: Home,
      roles: ['rh_admin', 'manager', 'employee', 'candidate']
    },
    {
      title: 'Colaboradores',
      href: '/employees',
      icon: Users,
      roles: ['rh_admin', 'manager']
    },
    {
      title: 'Vagas',
      href: '/jobs',
      icon: Briefcase,
      roles: ['rh_admin', 'manager', 'candidate']
    },
    {
      title: 'Avaliações',
      href: '/evaluations',
      icon: Award,
      roles: ['rh_admin', 'manager', 'employee']
    },
    {
      title: 'Treinamentos',
      href: '/trainings',
      icon: BookOpen,
      roles: ['rh_admin', 'manager', 'employee']
    },
    {
      title: 'Feedback',
      href: '/feedback',
      icon: MessageSquare,
      roles: ['rh_admin', 'manager', 'employee']
    },
    {
      title: 'Relatórios',
      href: '/reports',
      icon: BarChart3,
      roles: ['rh_admin', 'manager']
    },
    {
      title: 'Comunicações',
      href: '/communications',
      icon: Megaphone,
      roles: ['rh_admin', 'manager', 'employee']
    }
  ];

  const availableItems = navigationItems.filter(item => 
    item.roles.includes(user.role as any)
  );

  const isActive = (href: string) => {
    return location.pathname === href || 
           (href !== '/dashboard' && location.pathname.startsWith(href));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/dashboard" className="flex items-center">
              <div className="w-10 h-10 bg-integre-gradient rounded-xl flex items-center justify-center shadow-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4 hidden sm:block">
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                  Integre RH
                </span>
                <p className="text-xs text-gray-500 -mt-1">Conectando gestão e performance</p>
              </div>
            </Link>

            {/* Navigation */}
            <nav className="hidden lg:flex space-x-1">
              {availableItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} to={item.href}>
                    <Button
                      variant={isActive(item.href) ? "default" : "ghost"}
                      size="sm"
                      className={`
                        ${isActive(item.href) 
                          ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-md" 
                          : "text-gray-700 hover:text-purple-600 hover:bg-purple-50"
                        } transition-all duration-200
                      `}
                    >
                      <Icon className="w-4 h-4 mr-2" />
                      {item.title}
                    </Button>
                  </Link>
                );
              })}
            </nav>

            {/* Right side */}
            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input 
                  placeholder="Buscar..." 
                  className="pl-10 w-64 bg-purple-50/50 border-purple-200 focus:border-purple-400"
                />
              </div>

              {/* Notifications */}
              <Button variant="ghost" size="sm" className="hover:bg-purple-50 relative">
                <Bell className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2 hover:bg-purple-50">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback className="bg-purple-100 text-purple-600">
                        {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden lg:block text-left">
                      <p className="text-sm font-medium text-gray-700">{user.name}</p>
                      <p className="text-xs text-gray-500">{getRoleDisplayName(user.role)}</p>
                    </div>
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                      <Badge variant="secondary" className="mt-1 bg-purple-100 text-purple-700 text-xs">
                        {getRoleDisplayName(user.role)}
                      </Badge>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="cursor-pointer">
                      <User className="w-4 h-4 mr-2" />
                      Meu Perfil
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/settings" className="cursor-pointer">
                      <Settings className="w-4 h-4 mr-2" />
                      Configurações
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair da Plataforma
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Mobile Navigation */}
          <div className="lg:hidden border-t border-purple-100 py-2">
            <div className="flex space-x-1 overflow-x-auto">
              {availableItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.href} to={item.href}>
                    <Button
                      variant={isActive(item.href) ? "default" : "ghost"}
                      size="sm"
                      className={`
                        ${isActive(item.href) 
                          ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white" 
                          : "text-gray-700"
                        } whitespace-nowrap
                      `}
                    >
                      <Icon className="w-4 h-4 mr-1" />
                      {item.title}
                    </Button>
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}
