import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Eye, Download, FileText, FileImage, File, ExternalLink,
  AlertCircle, Loader2, X, ZoomIn, ZoomOut, RotateCw
} from 'lucide-react';

interface DocumentViewerProps {
  document: {
    id: string;
    name: string;
    type: string;
    size: number;
    url?: string;
    extension?: string;
    uploadDate: string;
  };
  className?: string;
}

export function DocumentViewer({ document, className = '' }: DocumentViewerProps) {
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageZoom, setImageZoom] = useState(100);
  const [imageRotation, setImageRotation] = useState(0);

  // Get file extension from name or type
  const getFileExtension = () => {
    if (document.extension) return document.extension.toLowerCase();
    const extensionMatch = document.name.match(/\.([^.]+)$/);
    return extensionMatch ? extensionMatch[1].toLowerCase() : 'unknown';
  };

  const extension = getFileExtension();

  // Determine file type category
  const getFileCategory = () => {
    const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
    const pdfExtensions = ['pdf'];
    const documentExtensions = ['doc', 'docx', 'txt', 'rtf', 'odt'];
    const spreadsheetExtensions = ['xls', 'xlsx', 'csv', 'ods'];
    const presentationExtensions = ['ppt', 'pptx', 'odp'];

    if (imageExtensions.includes(extension)) return 'image';
    if (pdfExtensions.includes(extension)) return 'pdf';
    if (documentExtensions.includes(extension)) return 'document';
    if (spreadsheetExtensions.includes(extension)) return 'spreadsheet';
    if (presentationExtensions.includes(extension)) return 'presentation';
    return 'other';
  };

  const fileCategory = getFileCategory();

  // Get file icon based on category
  const getFileIcon = () => {
    switch (fileCategory) {
      case 'image': return FileImage;
      case 'pdf': return FileText;
      default: return File;
    }
  };

  const FileIcon = getFileIcon();

  // Generate mock URL for demo purposes (in real app, this would be the actual file URL)
  const getFileUrl = () => {
    if (document.url) return document.url;
    
    // Generate demo URLs based on file type
    if (fileCategory === 'image') {
      return `https://picsum.photos/800/600?random=${document.id}`;
    } else if (fileCategory === 'pdf') {
      return `https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf`;
    }
    return `#demo-file-${document.id}`;
  };

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Handle file download
  const handleDownload = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const url = getFileUrl();
      
      // Create a temporary link and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = document.name;
      link.target = '_blank';
      
      // For demo purposes, we'll just open in new tab
      // In real implementation, this would trigger actual download
      window.open(url, '_blank');
      
      // Add a small delay to simulate download process
      await new Promise(resolve => setTimeout(resolve, 1000));
      
    } catch (err) {
      setError('Erro ao baixar o arquivo. Tente novamente.');
      console.error('Download error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Render file preview based on type
  const renderPreview = () => {
    const fileUrl = getFileUrl();

    if (fileCategory === 'image') {
      return (
        <div className="relative">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-lg font-medium">Visualização da Imagem</h4>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setImageZoom(Math.max(50, imageZoom - 25))}
                disabled={imageZoom <= 50}
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              <span className="text-sm text-gray-600">{imageZoom}%</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setImageZoom(Math.min(200, imageZoom + 25))}
                disabled={imageZoom >= 200}
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setImageRotation((imageRotation + 90) % 360)}
              >
                <RotateCw className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="flex justify-center bg-gray-50 rounded-lg p-4 overflow-auto max-h-96">
            <img
              src={fileUrl}
              alt={document.name}
              style={{
                transform: `scale(${imageZoom / 100}) rotate(${imageRotation}deg)`,
                transition: 'transform 0.3s ease',
                maxWidth: '100%',
                height: 'auto'
              }}
              onError={() => setError('Erro ao carregar a imagem')}
            />
          </div>
        </div>
      );
    }

    if (fileCategory === 'pdf') {
      return (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-lg font-medium">Visualização do PDF</h4>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(fileUrl, '_blank')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Abrir em Nova Aba
            </Button>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <iframe
              src={fileUrl}
              className="w-full h-96 border-0 rounded"
              title={`Preview of ${document.name}`}
              onError={() => setError('Erro ao carregar o PDF')}
            />
          </div>
        </div>
      );
    }

    // For other file types, show file info and download option
    return (
      <div className="text-center py-8">
        <FileIcon className="w-16 h-16 mx-auto text-gray-400 mb-4" />
        <h4 className="text-lg font-medium text-gray-900 mb-2">
          Visualização não disponível
        </h4>
        <p className="text-gray-600 mb-4">
          Este tipo de arquivo ({extension.toUpperCase()}) não pode ser visualizado diretamente.
          Use o botão de download para acessar o arquivo.
        </p>
        <Button onClick={handleDownload} disabled={isLoading}>
          {isLoading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Download className="w-4 h-4 mr-2" />
          )}
          Baixar Arquivo
        </Button>
      </div>
    );
  };

  return (
    <div className={className}>
      {/* File Info Card */}
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <div className="p-2 bg-gray-100 rounded-lg">
              <FileIcon className="w-6 h-6 text-gray-600" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-gray-900 truncate">{document.name}</h4>
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="outline" className="text-xs">
                  {extension.toUpperCase()}
                </Badge>
                <span className="text-sm text-gray-500">
                  {formatFileSize(document.size)}
                </span>
                <span className="text-sm text-gray-500">
                  {format(new Date(document.uploadDate), 'dd/MM/yyyy', { locale: { name: 'pt-BR' } })}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {/* Visualizar Button */}
              <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Eye className="w-4 h-4 mr-1" />
                    Visualizar
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
                  <DialogHeader>
                    <DialogTitle className="flex items-center space-x-2">
                      <FileIcon className="w-5 h-5" />
                      <span>{document.name}</span>
                    </DialogTitle>
                    <DialogDescription>
                      {fileCategory === 'image' && 'Visualização de imagem com controles de zoom e rotação'}
                      {fileCategory === 'pdf' && 'Visualização de documento PDF'}
                      {fileCategory === 'document' && 'Arquivo de documento'}
                      {fileCategory === 'other' && `Arquivo ${extension.toUpperCase()}`}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="overflow-auto max-h-[calc(90vh-120px)]">
                    {error ? (
                      <Alert variant="destructive">
                        <AlertCircle className="w-4 h-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    ) : (
                      renderPreview()
                    )}
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <div className="text-sm text-gray-600">
                      Tamanho: {formatFileSize(document.size)} • 
                      Tipo: {extension.toUpperCase()} • 
                      Enviado em {format(new Date(document.uploadDate), 'dd/MM/yyyy')}
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        onClick={handleDownload}
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Download className="w-4 h-4 mr-2" />
                        )}
                        Baixar Arquivo
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setIsViewDialogOpen(false)}
                      >
                        <X className="w-4 h-4 mr-2" />
                        Fechar
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              {/* Baixar Arquivo Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                disabled={isLoading}
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                ) : (
                  <Download className="w-4 h-4 mr-1" />
                )}
                Baixar arquivo
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive" className="mt-2">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}
