import { useState, useEffect, useMemo } from 'react';
import { EnhancedDataStore, Test, TestQuestion, TestResult, Candidate } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { 
  TestTube, Clock, Play, CheckCircle, XCircle, Award,
  Target, BarChart3, TrendingUp, AlertCircle, Star,
  ArrowRight, ArrowLeft, Send, Trophy, Brain, Timer
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface CandidateTestAreaProps {
  candidateId?: string;
  jobId?: string;
  onClose: () => void;
}

interface TestSession {
  testId: string;
  startTime: Date;
  currentQuestionIndex: number;
  answers: Record<string, string | number>;
  timeRemaining: number;
}

export default function CandidateTestArea({ candidateId, jobId, onClose }: CandidateTestAreaProps) {
  const { toast } = useToast();
  
  // State management
  const [availableTests, setAvailableTests] = useState<Test[]>([]);
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);
  const [testSession, setTestSession] = useState<TestSession | null>(null);
  const [isTestActive, setIsTestActive] = useState(false);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState<string | number>('');
  const [showResults, setShowResults] = useState(false);
  const [currentResult, setCurrentResult] = useState<TestResult | null>(null);

  // Load available tests
  useEffect(() => {
    try {
      const tests = EnhancedDataStore.getTests().filter(test => test.isActive);
      setAvailableTests(tests);

      if (candidateId) {
        const candidate = EnhancedDataStore.getCandidates().find(c => c.id === candidateId);
        if (candidate) {
          setTestResults(candidate.testResults);
        }
      }
    } catch (error) {
      console.error('Error loading tests:', error);
      toast({
        title: "Erro ao carregar provas",
        description: "Não foi possível carregar as provas disponíveis. Tente novamente.",
        variant: "destructive",
      });
    }
  }, [candidateId, toast]);

  // Timer effect
  useEffect(() => {
    if (isTestActive && testSession && testSession.timeRemaining > 0) {
      const timer = setInterval(() => {
        setTestSession(prev => {
          if (!prev || prev.timeRemaining <= 1) {
            setIsTestActive(false);
            finishTest();
            return null;
          }
          return { ...prev, timeRemaining: prev.timeRemaining - 1 };
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isTestActive, testSession]);

  const startTest = (test: Test) => {
    setSelectedTest(test);
    setTestSession({
      testId: test.id,
      startTime: new Date(),
      currentQuestionIndex: 0,
      answers: {},
      timeRemaining: test.timeLimit * 60 // Convert minutes to seconds
    });
    setIsTestActive(true);
    setCurrentAnswer('');
    
    toast({
      title: "Prova iniciada",
      description: `Você tem ${test.timeLimit} minutos para completar a prova`,
    });
  };

  const saveAnswer = () => {
    if (!testSession || !selectedTest) return;

    const currentQuestion = selectedTest.questions[testSession.currentQuestionIndex];
    setTestSession(prev => ({
      ...prev!,
      answers: {
        ...prev!.answers,
        [currentQuestion.id]: currentAnswer
      }
    }));
  };

  const nextQuestion = () => {
    if (!testSession || !selectedTest) return;

    saveAnswer();
    
    if (testSession.currentQuestionIndex < selectedTest.questions.length - 1) {
      setTestSession(prev => ({
        ...prev!,
        currentQuestionIndex: prev!.currentQuestionIndex + 1
      }));
      setCurrentAnswer('');
    } else {
      finishTest();
    }
  };

  const previousQuestion = () => {
    if (!testSession) return;

    saveAnswer();
    
    if (testSession.currentQuestionIndex > 0) {
      setTestSession(prev => ({
        ...prev!,
        currentQuestionIndex: prev!.currentQuestionIndex - 1
      }));
      
      // Load previous answer
      const currentQuestion = selectedTest!.questions[testSession.currentQuestionIndex - 1];
      setCurrentAnswer(testSession.answers[currentQuestion.id] || '');
    }
  };

  const finishTest = () => {
    if (!testSession || !selectedTest || !candidateId) return;

    // Calculate score
    let correctAnswers = 0;
    let totalWeight = 0;

    selectedTest.questions.forEach(question => {
      totalWeight += question.weight;
      const userAnswer = testSession.answers[question.id];
      
      if (question.type === 'multiple_choice' && userAnswer === question.correctAnswer) {
        correctAnswers += question.weight;
      }
      // For essay questions, we'd need manual evaluation
    });

    const percentage = totalWeight > 0 ? (correctAnswers / totalWeight) * 100 : 0;
    const passed = percentage >= selectedTest.passingScore;

    const result: TestResult = {
      testId: selectedTest.id,
      testName: selectedTest.name,
      candidateId: candidateId,
      startedAt: testSession.startTime.toISOString(),
      completedAt: new Date().toISOString(),
      answers: testSession.answers,
      percentage: percentage,
      passed: passed,
      timeSpent: (selectedTest.timeLimit * 60) - testSession.timeRemaining
    };

    // Update candidate's test results
    const candidates = EnhancedDataStore.getCandidates();
    const candidateIndex = candidates.findIndex(c => c.id === candidateId);
    
    if (candidateIndex !== -1) {
      candidates[candidateIndex].testResults.push(result);
      // Update the data store (this would need to be implemented in your data store)
    }

    setCurrentResult(result);
    setTestResults(prev => [...prev, result]);
    setIsTestActive(false);
    setTestSession(null);
    setShowResults(true);

    toast({
      title: passed ? "Parabéns!" : "Prova concluída",
      description: passed 
        ? `Você foi aprovado com ${percentage.toFixed(1)}%!`
        : `Você obteve ${percentage.toFixed(1)}%. Nota mínima: ${selectedTest.passingScore}%`,
      variant: passed ? "default" : "destructive"
    });
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getTestStats = () => {
    if (testResults.length === 0) return null;

    const totalTests = testResults.length;
    const passedTests = testResults.filter(r => r.passed).length;
    const averageScore = testResults.reduce((acc, r) => acc + r.percentage, 0) / totalTests;
    const bestScore = Math.max(...testResults.map(r => r.percentage));

    return {
      totalTests,
      passedTests,
      averageScore,
      bestScore,
      passRate: (passedTests / totalTests) * 100
    };
  };

  const stats = getTestStats();

  // Test taking interface
  if (isTestActive && testSession && selectedTest) {
    const currentQuestion = selectedTest.questions[testSession.currentQuestionIndex];
    const progress = ((testSession.currentQuestionIndex + 1) / selectedTest.questions.length) * 100;

    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header with timer and progress */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{selectedTest.name}</h2>
                <p className="text-gray-600">
                  Questão {testSession.currentQuestionIndex + 1} de {selectedTest.questions.length}
                </p>
              </div>
              <div className="text-right">
                <div className={`text-2xl font-bold ${
                  testSession.timeRemaining < 300 ? 'text-red-600' : 'text-blue-600'
                }`}>
                  <Timer className="w-6 h-6 inline mr-2" />
                  {formatTime(testSession.timeRemaining)}
                </div>
                <p className="text-sm text-gray-600">Tempo restante</p>
              </div>
            </div>
            
            <Progress value={progress} className="h-3" />
            <p className="text-sm text-gray-600 mt-2">{progress.toFixed(0)}% concluído</p>
          </CardContent>
        </Card>

        {/* Question */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">
                Questão {testSession.currentQuestionIndex + 1}
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Badge variant="outline">{currentQuestion.type === 'multiple_choice' ? 'Múltipla Escolha' : 'Dissertativa'}</Badge>
                <Badge>{currentQuestion.weight} ponto(s)</Badge>
                {currentQuestion.category && (
                  <Badge variant="secondary">{currentQuestion.category}</Badge>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-lg leading-relaxed">{currentQuestion.text}</p>
            </div>

            {currentQuestion.type === 'multiple_choice' ? (
              <div className="space-y-3">
                {currentQuestion.options?.map((option, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <input
                      type="radio"
                      id={`option-${index}`}
                      name="answer"
                      value={index}
                      checked={currentAnswer === index}
                      onChange={(e) => setCurrentAnswer(parseInt(e.target.value))}
                      className="w-4 h-4 text-purple-600"
                    />
                    <label 
                      htmlFor={`option-${index}`} 
                      className="flex-1 p-3 border rounded-lg cursor-pointer hover:bg-gray-50"
                    >
                      <span className="font-medium mr-2">{String.fromCharCode(65 + index)})</span>
                      {option}
                    </label>
                  </div>
                ))}
              </div>
            ) : (
              <div>
                <Label htmlFor="essay-answer">Sua resposta:</Label>
                <Textarea
                  id="essay-answer"
                  value={currentAnswer as string}
                  onChange={(e) => setCurrentAnswer(e.target.value)}
                  placeholder="Digite sua resposta detalhada aqui..."
                  rows={8}
                  className="mt-2"
                />
              </div>
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={previousQuestion}
                disabled={testSession.currentQuestionIndex === 0}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Anterior
              </Button>
              
              <div className="text-center">
                <p className="text-sm text-gray-600">
                  {Object.keys(testSession.answers).length} de {selectedTest.questions.length} respondidas
                </p>
              </div>

              {testSession.currentQuestionIndex === selectedTest.questions.length - 1 ? (
                <Button onClick={finishTest} className="bg-green-600 hover:bg-green-700">
                  <Send className="w-4 h-4 mr-2" />
                  Finalizar Prova
                </Button>
              ) : (
                <Button onClick={nextQuestion}>
                  Próxima
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <Brain className="w-7 h-7 mr-3 text-purple-600" />
            Área de Testes para Candidatos
          </h2>
          <p className="text-gray-600 mt-1">
            Realize provas e acompanhe seu desempenho no processo seletivo
          </p>
        </div>
      </div>

      {/* Statistics */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.totalTests}</div>
              <div className="text-sm text-gray-600">Provas Realizadas</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.passedTests}</div>
              <div className="text-sm text-gray-600">Aprovações</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.averageScore.toFixed(1)}%</div>
              <div className="text-sm text-gray-600">Média Geral</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.bestScore.toFixed(1)}%</div>
              <div className="text-sm text-gray-600">Melhor Resultado</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Available Tests */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TestTube className="w-5 h-5 text-purple-600" />
            <span>Provas Disponíveis</span>
          </CardTitle>
          <CardDescription>
            Selecione uma prova para iniciar o teste
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableTests.map((test) => {
              const alreadyTaken = testResults.find(r => r.testId === test.id);
              
              return (
                <Card key={test.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-2">{test.name}</h3>
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                          {test.description}
                        </p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {test.timeLimit} min
                          </div>
                          <div className="flex items-center">
                            <Target className="w-4 h-4 mr-1" />
                            {test.passingScore}% para aprovar
                          </div>
                          <div className="flex items-center">
                            <FileText className="w-4 h-4 mr-1" />
                            {test.questions.length} questões
                          </div>
                        </div>
                      </div>
                      <div className="ml-4">
                        <Badge className={test.type === 'multiple_choice' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}>
                          {test.type === 'multiple_choice' ? 'Múltipla Escolha' : 'Dissertativa'}
                        </Badge>
                      </div>
                    </div>

                    {alreadyTaken && (
                      <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Último resultado:</span>
                          <div className="flex items-center space-x-2">
                            <span className={`font-bold ${alreadyTaken.passed ? 'text-green-600' : 'text-red-600'}`}>
                              {alreadyTaken.percentage.toFixed(1)}%
                            </span>
                            {alreadyTaken.passed && <Award className="w-4 h-4 text-green-600" />}
                          </div>
                        </div>
                      </div>
                    )}

                    <Button 
                      onClick={() => startTest(test)}
                      className="w-full"
                      variant={alreadyTaken?.passed ? "outline" : "default"}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      {alreadyTaken ? 'Refazer Prova' : 'Iniciar Prova'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {availableTests.length === 0 && (
            <div className="text-center py-12">
              <TestTube className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma prova disponível
              </h3>
              <p className="text-gray-600">
                Não há provas ativas no momento. Aguarde novas oportunidades.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Test History */}
      {testResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-purple-600" />
              <span>Histórico de Provas</span>
            </CardTitle>
            <CardDescription>
              Acompanhe seus resultados anteriores
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {testResults.map((result, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium">{result.testName}</h4>
                      <p className="text-sm text-gray-600">
                        Realizada em {format(new Date(result.completedAt), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                      </p>
                      <p className="text-sm text-gray-600">
                        Tempo gasto: {Math.floor(result.timeSpent / 60)}:{(result.timeSpent % 60).toString().padStart(2, '0')}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${result.passed ? 'text-green-600' : 'text-red-600'}`}>
                        {result.percentage.toFixed(1)}%
                      </div>
                      <div className="flex items-center space-x-2">
                        {result.passed ? (
                          <>
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            <span className="text-sm text-green-600">Aprovado</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4 text-red-600" />
                            <span className="text-sm text-red-600">Reprovado</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Results Dialog */}
      <Dialog open={showResults} onOpenChange={setShowResults}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {currentResult?.passed ? (
                <Trophy className="w-6 h-6 text-green-600" />
              ) : (
                <AlertCircle className="w-6 h-6 text-red-600" />
              )}
              <span>Resultado da Prova</span>
            </DialogTitle>
          </DialogHeader>
          
          {currentResult && (
            <div className="space-y-6">
              <div className="text-center">
                <div className={`text-4xl font-bold mb-2 ${
                  currentResult.passed ? 'text-green-600' : 'text-red-600'
                }`}>
                  {currentResult.percentage.toFixed(1)}%
                </div>
                <p className="text-gray-600">
                  {currentResult.passed ? 'Parabéns! Você foi aprovado!' : 'Não foi desta vez, mas continue tentando!'}
                </p>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Prova:</span>
                  <span className="font-medium">{currentResult.testName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Nota mínima:</span>
                  <span className="font-medium">{selectedTest?.passingScore}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tempo gasto:</span>
                  <span className="font-medium">
                    {Math.floor(currentResult.timeSpent / 60)}:{(currentResult.timeSpent % 60).toString().padStart(2, '0')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <Badge className={currentResult.passed ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                    {currentResult.passed ? 'Aprovado' : 'Reprovado'}
                  </Badge>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button variant="outline" onClick={() => setShowResults(false)}>
                  Fechar
                </Button>
                {!currentResult.passed && selectedTest && (
                  <Button onClick={() => {
                    setShowResults(false);
                    startTest(selectedTest);
                  }}>
                    Tentar Novamente
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
