import { useState, useMemo } from 'react';
import { EnhancedDataStore, Test, TestQuestion, TestResult } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  TestTube, Plus, Search, Eye, Edit, MoreHorizontal,
  Clock, Users, BarChart3, Target, CheckCircle, XCircle,
  FileText, Copy, Link, Trash2, Settings, Award,
  PlusCircle, MinusCircle, AlignLeft, List, Star, Brain
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import CandidateTestArea from './CandidateTestArea';

interface TestManagerProps {
  onClose: () => void;
}

export default function TestManager({ onClose }: TestManagerProps) {
  const { toast } = useToast();
  
  // State management
  const [tests, setTests] = useState<Test[]>(() => {
    const savedTests = localStorage.getItem('enhancedTests');
    if (savedTests) {
      return JSON.parse(savedTests);
    }
    return EnhancedDataStore.getTests();
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);
  
  // Dialog states
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [isCandidateTestAreaOpen, setIsCandidateTestAreaOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  
  // Form states
  const [testForm, setTestForm] = useState<Partial<Test>>({
    name: '',
    description: '',
    type: 'multiple_choice',
    timeLimit: 60,
    passingScore: 70,
    questions: [],
    isActive: true
  });
  const [currentQuestion, setCurrentQuestion] = useState<Partial<TestQuestion>>({
    text: '',
    type: 'multiple_choice',
    options: ['', '', '', ''],
    correctAnswer: 0,
    weight: 1,
    category: ''
  });

  const filteredTests = useMemo(() => {
    return tests.filter(test => {
      const matchesSearch = test.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           test.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = typeFilter === 'all' || test.type === typeFilter;
      
      return matchesSearch && matchesType;
    });
  }, [tests, searchTerm, typeFilter]);

  const handleCreateTest = () => {
    if (!testForm.name || !testForm.description || !testForm.questions?.length) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios e adicione pelo menos uma questão",
        variant: "destructive"
      });
      return;
    }

    if (isEditMode && selectedTest) {
      // Update existing test
      const updatedTests = tests.map(test =>
        test.id === selectedTest.id
          ? { ...testForm as Test, id: selectedTest.id, createdDate: selectedTest.createdDate }
          : test
      );
      setTests(updatedTests);
      // In a real app, this would update the data store
      localStorage.setItem('enhancedTests', JSON.stringify(updatedTests));

      toast({
        title: "Sucesso",
        description: "Prova atualizada com sucesso!",
      });
    } else {
      // Create new test
      const newTest = EnhancedDataStore.addTest({
        ...testForm as Omit<Test, 'id' | 'createdDate'>,
        createdBy: 'current_user'
      });
      setTests(EnhancedDataStore.getTests());

      toast({
        title: "Sucesso",
        description: "Prova criada com sucesso!",
      });
    }

    setIsCreateDialogOpen(false);
    setIsEditMode(false);
    setSelectedTest(null);
    setTestForm({
      name: '',
      description: '',
      type: 'multiple_choice',
      timeLimit: 60,
      passingScore: 70,
      questions: [],
      isActive: true
    });
  };

  const handleEditTest = (test: Test) => {
    setSelectedTest(test);
    setTestForm(test);
    setIsEditMode(true);
    setIsCreateDialogOpen(true);
  };

  const addQuestion = () => {
    if (!currentQuestion.text) {
      toast({
        title: "Erro",
        description: "Digite o texto da questão",
        variant: "destructive"
      });
      return;
    }

    const newQuestion: TestQuestion = {
      ...currentQuestion as TestQuestion,
      id: `question_${Date.now()}`
    };

    setTestForm(prev => ({
      ...prev,
      questions: [...(prev.questions || []), newQuestion]
    }));

    setCurrentQuestion({
      text: '',
      type: 'multiple_choice',
      options: ['', '', '', ''],
      correctAnswer: 0,
      weight: 1,
      category: ''
    });

    toast({
      title: "Questão adicionada",
      description: "A questão foi adicionada à prova",
    });
  };

  const removeQuestion = (questionId: string) => {
    setTestForm(prev => ({
      ...prev,
      questions: prev.questions?.filter(q => q.id !== questionId) || []
    }));
  };

  const updateQuestionOption = (index: number, value: string) => {
    const updatedOptions = [...(currentQuestion.options || [])];
    updatedOptions[index] = value;
    setCurrentQuestion(prev => ({
      ...prev,
      options: updatedOptions
    }));
  };

  const addQuestionOption = () => {
    setCurrentQuestion(prev => ({
      ...prev,
      options: [...(prev.options || []), '']
    }));
  };

  const removeQuestionOption = (index: number) => {
    const updatedOptions = (currentQuestion.options || []).filter((_, i) => i !== index);
    setCurrentQuestion(prev => ({
      ...prev,
      options: updatedOptions,
      correctAnswer: prev.correctAnswer && prev.correctAnswer >= index ? Math.max(0, prev.correctAnswer - 1) : prev.correctAnswer
    }));
  };

  const getTypeBadge = (type: Test['type']) => {
    switch (type) {
      case 'multiple_choice':
        return <Badge className="bg-blue-100 text-blue-700">Múltipla Escolha</Badge>;
      case 'essay':
        return <Badge className="bg-green-100 text-green-700">Dissertativa</Badge>;
      case 'mixed':
        return <Badge className="bg-purple-100 text-purple-700">Mista</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getQuestionTypeBadge = (type: TestQuestion['type']) => {
    switch (type) {
      case 'multiple_choice':
        return <Badge variant="outline" className="text-xs">Múltipla Escolha</Badge>;
      case 'essay':
        return <Badge variant="outline" className="text-xs">Dissertativa</Badge>;
      default:
        return <Badge variant="secondary" className="text-xs">Desconhecido</Badge>;
    }
  };

  const generateTestLink = (test: Test) => {
    return `${window.location.origin}/candidate-test/${test.id}`;
  };

  const copyTestLink = (test: Test) => {
    const link = generateTestLink(test);
    navigator.clipboard.writeText(link);
    toast({
      title: "Link copiado!",
      description: "O link da prova foi copiado para a área de transferência.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <TestTube className="w-7 h-7 mr-3 text-purple-600" />
            Gerenciamento de Provas
          </h2>
          <p className="text-gray-600 mt-1">
            Crie e gerencie provas para o processo seletivo
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={() => setIsCandidateTestAreaOpen(true)}
          >
            <Brain className="w-4 h-4 mr-2" />
            Área do Candidato
          </Button>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Criar Prova
          </Button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{tests.length}</div>
            <div className="text-sm text-gray-600">Total de Provas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">
              {tests.filter(t => t.isActive).length}
            </div>
            <div className="text-sm text-gray-600">Ativas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">
              {tests.reduce((acc, test) => acc + test.questions.length, 0)}
            </div>
            <div className="text-sm text-gray-600">Total de Questões</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">
              {Math.round(tests.reduce((acc, test) => acc + test.passingScore, 0) / tests.length) || 0}%
            </div>
            <div className="text-sm text-gray-600">Nota Média de Corte</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar provas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Tipos</SelectItem>
                  <SelectItem value="multiple_choice">Múltipla Escolha</SelectItem>
                  <SelectItem value="essay">Dissertativa</SelectItem>
                  <SelectItem value="mixed">Mista</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredTests.length} de {tests.length} prova(s)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tests List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Provas</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Questões</TableHead>
                <TableHead>Tempo Limite</TableHead>
                <TableHead>Nota de Corte</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Criado em</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTests.map((test) => (
                <TableRow key={test.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{test.name}</div>
                      <div className="text-sm text-gray-600">{test.description}</div>
                    </div>
                  </TableCell>
                  <TableCell>{getTypeBadge(test.type)}</TableCell>
                  <TableCell>{test.questions.length}</TableCell>
                  <TableCell>{test.timeLimit} min</TableCell>
                  <TableCell>{test.passingScore}%</TableCell>
                  <TableCell>
                    <Badge className={test.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                      {test.isActive ? 'Ativa' : 'Inativa'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {format(new Date(test.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setSelectedTest(test);
                          setIsViewDialogOpen(true);
                        }}>
                          <Eye className="w-4 h-4 mr-2" />
                          Visualizar
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setSelectedTest(test);
                          setIsPreviewDialogOpen(true);
                        }}>
                          <FileText className="w-4 h-4 mr-2" />
                          Preview
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => copyTestLink(test)}>
                          <Link className="w-4 h-4 mr-2" />
                          Copiar Link
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleEditTest(test)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredTests.length === 0 && (
            <div className="text-center py-12">
              <TestTube className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma prova encontrada
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || typeFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Crie sua primeira prova para começar'
                }
              </p>
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeira Prova
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Test Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditMode ? 'Editar Prova' : 'Criar Nova Prova'}</DialogTitle>
            <DialogDescription>
              {isEditMode ? 'Atualize a configuração da prova e questões' : 'Configure a prova e adicione as questões'}
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="basic" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="basic">Configurações Básicas</TabsTrigger>
              <TabsTrigger value="questions">Questões ({testForm.questions?.length || 0})</TabsTrigger>
            </TabsList>

            {/* Basic Configuration Tab */}
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="test-name">Nome da Prova *</Label>
                  <Input
                    id="test-name"
                    value={testForm.name || ''}
                    onChange={(e) => setTestForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Ex: Prova de Desenvolvimento React"
                  />
                </div>
                <div>
                  <Label htmlFor="test-type">Tipo da Prova</Label>
                  <Select
                    value={testForm.type || 'multiple_choice'}
                    onValueChange={(value) => setTestForm(prev => ({ 
                      ...prev, 
                      type: value as Test['type']
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="multiple_choice">Múltipla Escolha</SelectItem>
                      <SelectItem value="essay">Dissertativa</SelectItem>
                      <SelectItem value="mixed">Mista</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="test-description">Descrição *</Label>
                <Textarea
                  id="test-description"
                  value={testForm.description || ''}
                  onChange={(e) => setTestForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Descreva o objetivo e conteúdo da prova..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="time-limit">Tempo Limite (minutos)</Label>
                  <Input
                    id="time-limit"
                    type="number"
                    value={testForm.timeLimit || 60}
                    onChange={(e) => setTestForm(prev => ({ ...prev, timeLimit: parseInt(e.target.value) }))}
                    min="1"
                    max="300"
                  />
                </div>
                <div>
                  <Label htmlFor="passing-score">Nota Mínima para Aprovação (%)</Label>
                  <Input
                    id="passing-score"
                    type="number"
                    value={testForm.passingScore || 70}
                    onChange={(e) => setTestForm(prev => ({ ...prev, passingScore: parseInt(e.target.value) }))}
                    min="0"
                    max="100"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={testForm.isActive}
                  onCheckedChange={(checked) => setTestForm(prev => ({ ...prev, isActive: checked }))}
                />
                <Label>Prova ativa (disponível para aplicação)</Label>
              </div>
            </TabsContent>

            {/* Questions Tab */}
            <TabsContent value="questions" className="space-y-6">
              {/* Add Question Form */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Adicionar Nova Questão</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="question-type">Tipo da Questão</Label>
                      <Select
                        value={currentQuestion.type || 'multiple_choice'}
                        onValueChange={(value) => setCurrentQuestion(prev => ({
                          ...prev,
                          type: value as TestQuestion['type']
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="multiple_choice">Múltipla Escolha</SelectItem>
                          <SelectItem value="essay">Dissertativa</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="question-weight">Peso (pontos)</Label>
                      <Input
                        id="question-weight"
                        type="number"
                        value={currentQuestion.weight || 1}
                        onChange={(e) => setCurrentQuestion(prev => ({ 
                          ...prev, 
                          weight: parseInt(e.target.value) 
                        }))}
                        min="1"
                        max="10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="question-text">Texto da Questão *</Label>
                    <Textarea
                      id="question-text"
                      value={currentQuestion.text || ''}
                      onChange={(e) => setCurrentQuestion(prev => ({ ...prev, text: e.target.value }))}
                      placeholder="Digite o enunciado da questão..."
                      rows={3}
                    />
                  </div>

                  {currentQuestion.type === 'multiple_choice' && (
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <Label>Opções de Resposta</Label>
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={addQuestionOption}
                        >
                          <PlusCircle className="w-4 h-4 mr-2" />
                          Adicionar Opção
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {currentQuestion.options?.map((option, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name="correct-answer"
                              checked={currentQuestion.correctAnswer === index}
                              onChange={() => setCurrentQuestion(prev => ({ 
                                ...prev, 
                                correctAnswer: index 
                              }))}
                              className="w-4 h-4 text-purple-600"
                            />
                            <Input
                              value={option}
                              onChange={(e) => updateQuestionOption(index, e.target.value)}
                              placeholder={`Opção ${index + 1}`}
                              className="flex-1"
                            />
                            {(currentQuestion.options?.length || 0) > 2 && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => removeQuestionOption(index)}
                                className="text-red-600"
                              >
                                <MinusCircle className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                      <p className="text-sm text-gray-600 mt-2">
                        Selecione a opção correta marcando o círculo ao lado
                      </p>
                    </div>
                  )}

                  <div>
                    <Label htmlFor="question-category">Categoria (opcional)</Label>
                    <Input
                      id="question-category"
                      value={currentQuestion.category || ''}
                      onChange={(e) => setCurrentQuestion(prev => ({ ...prev, category: e.target.value }))}
                      placeholder="Ex: Conhecimentos Técnicos, Lógica, etc."
                    />
                  </div>

                  <Button onClick={addQuestion} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Questão
                  </Button>
                </CardContent>
              </Card>

              {/* Questions List */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">
                    Questões Adicionadas ({testForm.questions?.length || 0})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {testForm.questions && testForm.questions.length > 0 ? (
                    <div className="space-y-4">
                      {testForm.questions.map((question, index) => (
                        <div key={question.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Badge variant="outline" className="text-xs">
                                  Questão {index + 1}
                                </Badge>
                                {getQuestionTypeBadge(question.type)}
                                <Badge variant="secondary" className="text-xs">
                                  {question.weight} ponto(s)
                                </Badge>
                              </div>
                              <p className="font-medium mb-2">{question.text}</p>
                              {question.type === 'multiple_choice' && question.options && (
                                <div className="space-y-1">
                                  {question.options.map((option, optIndex) => (
                                    <div 
                                      key={optIndex} 
                                      className={`text-sm px-2 py-1 rounded ${
                                        optIndex === question.correctAnswer 
                                          ? 'bg-green-100 text-green-700 font-medium'
                                          : 'text-gray-600'
                                      }`}
                                    >
                                      {String.fromCharCode(65 + optIndex)}) {option}
                                      {optIndex === question.correctAnswer && (
                                        <CheckCircle className="w-4 h-4 inline ml-2 text-green-600" />
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}
                              {question.category && (
                                <Badge variant="outline" className="text-xs mt-2">
                                  {question.category}
                                </Badge>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeQuestion(question.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p>Nenhuma questão adicionada ainda</p>
                      <p className="text-sm">Adicione questões para criar a prova</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button variant="outline" onClick={() => {
              setIsCreateDialogOpen(false);
              setIsEditMode(false);
              setSelectedTest(null);
              setTestForm({
                name: '',
                description: '',
                type: 'multiple_choice',
                timeLimit: 60,
                passingScore: 70,
                questions: [],
                isActive: true
              });
            }}>
              Cancelar
            </Button>
            <Button onClick={handleCreateTest}>
              {isEditMode ? 'Atualizar Prova' : 'Criar Prova'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Test Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Prova</DialogTitle>
          </DialogHeader>

          {selectedTest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Nome:</Label>
                  <p className="font-medium">{selectedTest.name}</p>
                </div>
                <div>
                  <Label>Tipo:</Label>
                  <div>{getTypeBadge(selectedTest.type)}</div>
                </div>
                <div>
                  <Label>Tempo Limite:</Label>
                  <p className="font-medium">{selectedTest.timeLimit} minutos</p>
                </div>
                <div>
                  <Label>Nota de Corte:</Label>
                  <p className="font-medium">{selectedTest.passingScore}%</p>
                </div>
              </div>

              <div>
                <Label>Descrição:</Label>
                <p className="text-gray-600">{selectedTest.description}</p>
              </div>

              <div>
                <Label>Link Público:</Label>
                <div className="flex mt-2">
                  <Input
                    value={generateTestLink(selectedTest)}
                    readOnly
                    className="rounded-r-none"
                  />
                  <Button
                    onClick={() => copyTestLink(selectedTest)}
                    className="rounded-l-none"
                    variant="outline"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div>
                <Label>Questões ({selectedTest.questions.length}):</Label>
                <ScrollArea className="h-40 mt-2">
                  <div className="space-y-2">
                    {selectedTest.questions.map((question, index) => (
                      <div key={question.id} className="p-2 bg-gray-50 rounded text-sm">
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge variant="outline" className="text-xs">
                            Q{index + 1}
                          </Badge>
                          {getQuestionTypeBadge(question.type)}
                          <Badge variant="secondary" className="text-xs">
                            {question.weight}pts
                          </Badge>
                        </div>
                        <p className="font-medium">{question.text}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Candidate Test Area Dialog */}
      <Dialog open={isCandidateTestAreaOpen} onOpenChange={setIsCandidateTestAreaOpen}>
        <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Brain className="w-6 h-6 text-purple-600" />
              <span>Área de Testes - Visão do Candidato</span>
            </DialogTitle>
            <DialogDescription>
              Simule a experiência do candidato realizando provas e veja os resultados
            </DialogDescription>
          </DialogHeader>

          <CandidateTestArea
            candidateId="demo_candidate"
            onClose={() => setIsCandidateTestAreaOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
