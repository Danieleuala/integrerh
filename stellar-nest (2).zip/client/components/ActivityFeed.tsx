import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { IntegratedDataStore } from '@/lib/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  User, 
  Briefcase, 
  BookOpen, 
  Award, 
  MessageSquare, 
  Megaphone,
  FileText,
  Activity,
  Clock,
  TrendingUp
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  module: string;
  description: string;
  timestamp: string;
  relatedData?: any;
}

interface ActivityFeedProps {
  userId?: string;
  module?: string;
  limit?: number;
  showHeader?: boolean;
}

export function ActivityFeed({ 
  userId, 
  module, 
  limit = 20, 
  showHeader = true 
}: ActivityFeedProps) {
  const { user } = useAuth();
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [employees] = useState(IntegratedDataStore.getEmployees());

  useEffect(() => {
    loadActivities();
  }, [userId, module, limit]);

  const loadActivities = () => {
    const activityLog = IntegratedDataStore.getActivityLog(userId, module, limit);
    setActivities(activityLog);
  };

  const getEmployee = (employeeId: string) => {
    return employees.find(emp => emp.id === employeeId);
  };

  const getModuleIcon = (moduleName: string) => {
    switch (moduleName) {
      case 'employees':
        return <User className="w-4 h-4 text-blue-600" />;
      case 'jobs':
        return <Briefcase className="w-4 h-4 text-green-600" />;
      case 'trainings':
        return <BookOpen className="w-4 h-4 text-purple-600" />;
      case 'evaluations':
        return <Award className="w-4 h-4 text-yellow-600" />;
      case 'feedback':
        return <MessageSquare className="w-4 h-4 text-pink-600" />;
      case 'communications':
        return <Megaphone className="w-4 h-4 text-orange-600" />;
      case 'documents':
        return <FileText className="w-4 h-4 text-indigo-600" />;
      default:
        return <Activity className="w-4 h-4 text-gray-600" />;
    }
  };

  const getModuleColor = (moduleName: string) => {
    switch (moduleName) {
      case 'employees':
        return 'bg-blue-100 text-blue-700';
      case 'jobs':
        return 'bg-green-100 text-green-700';
      case 'trainings':
        return 'bg-purple-100 text-purple-700';
      case 'evaluations':
        return 'bg-yellow-100 text-yellow-700';
      case 'feedback':
        return 'bg-pink-100 text-pink-700';
      case 'communications':
        return 'bg-orange-100 text-orange-700';
      case 'documents':
        return 'bg-indigo-100 text-indigo-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getActionDescription = (action: string) => {
    switch (action) {
      case 'employee_onboard':
        return 'Novo colaborador';
      case 'job_application':
        return 'Candidatura';
      case 'training_enrollment':
        return 'Inscrição em treinamento';
      case 'evaluation_complete':
        return 'Avaliação concluída';
      case 'feedback_sent':
        return 'Feedback enviado';
      case 'announcement_created':
        return 'Comunicado criado';
      case 'document_upload':
        return 'Documento enviado';
      default:
        return action.replace('_', ' ');
    }
  };

  if (activities.length === 0) {
    return (
      <Card>
        {showHeader && (
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              Timeline de Atividades
            </CardTitle>
          </CardHeader>
        )}
        <CardContent className="text-center py-8">
          <Activity className="w-12 h-12 mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500">Nenhuma atividade registrada</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      {showHeader && (
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="w-5 h-5 mr-2" />
            Timeline de Atividades
            <Badge variant="secondary" className="ml-2">
              {activities.length}
            </Badge>
          </CardTitle>
        </CardHeader>
      )}
      <CardContent className="p-0">
        <ScrollArea className="h-96">
          <div className="space-y-0">
            {activities.map((activity, index) => {
              const employee = getEmployee(activity.userId);
              const isLast = index === activities.length - 1;
              
              return (
                <div key={activity.id} className="relative">
                  {/* Timeline line */}
                  {!isLast && (
                    <div className="absolute left-8 top-12 w-0.5 h-16 bg-gray-200"></div>
                  )}
                  
                  <div className="flex items-start space-x-4 p-4 hover:bg-gray-50 transition-colors">
                    {/* Avatar */}
                    <div className="relative">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={employee?.avatar} alt={employee?.name} />
                        <AvatarFallback className="bg-purple-100 text-purple-600 text-xs">
                          {employee?.name ? 
                            employee.name.split(' ').map(n => n[0]).join('').toUpperCase() : 
                            'SYS'
                          }
                        </AvatarFallback>
                      </Avatar>
                      
                      {/* Module icon overlay */}
                      <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 border">
                        {getModuleIcon(activity.module)}
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <p className="text-sm font-medium text-gray-900">
                            {employee?.name || 'Sistema'}
                          </p>
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${getModuleColor(activity.module)}`}
                          >
                            {getActionDescription(activity.action)}
                          </Badge>
                        </div>
                        <div className="flex items-center text-xs text-gray-500">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatDistanceToNow(new Date(activity.timestamp), { 
                            addSuffix: true, 
                            locale: ptBR 
                          })}
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-600 mt-1">
                        {activity.description}
                      </p>

                      {/* Related data display */}
                      {activity.relatedData && (
                        <div className="mt-2 text-xs text-gray-500">
                          {activity.action === 'evaluation_complete' && activity.relatedData.score && (
                            <div className="flex items-center space-x-2">
                              <TrendingUp className="w-3 h-3" />
                              <span>Pontuação: {activity.relatedData.score}/10</span>
                            </div>
                          )}
                          {activity.action === 'training_enrollment' && (
                            <div className="flex items-center space-x-2">
                              <BookOpen className="w-3 h-3" />
                              <span>Inscrição em treinamento</span>
                            </div>
                          )}
                          {activity.action === 'feedback_sent' && activity.relatedData.type && (
                            <div className="flex items-center space-x-2">
                              <MessageSquare className="w-3 h-3" />
                              <span>Tipo: {activity.relatedData.type}</span>
                            </div>
                          )}
                          {activity.action === 'document_upload' && activity.relatedData.type && (
                            <div className="flex items-center space-x-2">
                              <FileText className="w-3 h-3" />
                              <span>Tipo: {activity.relatedData.type}</span>
                            </div>
                          )}
                        </div>
                      )}

                      <p className="text-xs text-gray-400 mt-1">
                        {format(new Date(activity.timestamp), 'dd/MM/yyyy \'às\' HH:mm', { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
