import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  Users, Plus, Minus, Edit, AlertTriangle, CheckCircle, 
  TrendingUp, Building2, Crown, Shield
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Company {
  id: string;
  name: string;
  plan: 'basic' | 'professional' | 'enterprise';
  cnpj?: string;
  currentEmployees: number;
  employeeLimit: number;
  status: 'active' | 'inactive' | 'suspended';
}

interface EmployeeLimitManagerProps {
  companies: Company[];
  onUpdateCompany: (companyId: string, updates: Partial<Company>) => void;
}

export default function EmployeeLimitManager({ companies, onUpdateCompany }: EmployeeLimitManagerProps) {
  const { toast } = useToast();
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newLimit, setNewLimit] = useState(0);
  const [newEmployeeCount, setNewEmployeeCount] = useState(0);

  const planLimits = {
    basic: 50,
    professional: 200, 
    enterprise: 1000
  };

  const planLabels = {
    basic: 'Básico',
    professional: 'Profissional',
    enterprise: 'Enterprise'
  };

  const getUtilizationPercentage = (current: number, limit: number) => {
    return limit > 0 ? Math.round((current / limit) * 100) : 0;
  };

  const getUtilizationColor = (percentage: number) => {
    if (percentage >= 90) return 'text-red-600';
    if (percentage >= 80) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getUtilizationBadge = (percentage: number) => {
    if (percentage >= 90) return <Badge className="bg-red-100 text-red-800">Crítico</Badge>;
    if (percentage >= 80) return <Badge className="bg-yellow-100 text-yellow-800">Atenção</Badge>;
    return <Badge className="bg-green-100 text-green-800">Normal</Badge>;
  };

  const getPlanIcon = (plan: string) => {
    switch (plan) {
      case 'basic':
        return <Users className="w-4 h-4 text-blue-600" />;
      case 'professional':
        return <Crown className="w-4 h-4 text-purple-600" />;
      case 'enterprise':
        return <Shield className="w-4 h-4 text-green-600" />;
      default:
        return <Building2 className="w-4 h-4 text-gray-600" />;
    }
  };

  const openEditDialog = (company: Company) => {
    setSelectedCompany(company);
    setNewLimit(company.employeeLimit);
    setNewEmployeeCount(company.currentEmployees);
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    setSelectedCompany(null);
    setNewLimit(0);
    setNewEmployeeCount(0);
  };

  const handleUpdateLimits = () => {
    if (!selectedCompany) return;

    if (newEmployeeCount > newLimit) {
      toast({
        title: "Erro de validação",
        description: "O número atual de funcionários não pode ser maior que o limite.",
        variant: "destructive",
      });
      return;
    }

    onUpdateCompany(selectedCompany.id, {
      employeeLimit: newLimit,
      currentEmployees: newEmployeeCount
    });

    toast({
      title: "Limites atualizados",
      description: `Limites da empresa ${selectedCompany.name} foram atualizados com sucesso.`,
    });

    closeDialog();
  };

  const adjustEmployeeCount = (companyId: string, adjustment: number) => {
    const company = companies.find(c => c.id === companyId);
    if (!company) return;

    const newCount = Math.max(0, company.currentEmployees + adjustment);
    
    if (newCount > company.employeeLimit) {
      toast({
        title: "Limite excedido",
        description: `Não é possível adicionar funcionários. Limite atual: ${company.employeeLimit}`,
        variant: "destructive",
      });
      return;
    }

    onUpdateCompany(companyId, { currentEmployees: newCount });
    
    toast({
      title: "Funcionários atualizados",
      description: `Número de funcionários da ${company.name} atualizado para ${newCount}.`,
    });
  };

  const stats = {
    totalCompanies: companies.length,
    activeCompanies: companies.filter(c => c.status === 'active').length,
    totalEmployees: companies.reduce((sum, c) => sum + c.currentEmployees, 0),
    totalLimits: companies.reduce((sum, c) => sum + c.employeeLimit, 0),
    companiesNearLimit: companies.filter(c => getUtilizationPercentage(c.currentEmployees, c.employeeLimit) >= 90).length,
    averageUtilization: Math.round(
      companies.reduce((sum, c) => sum + getUtilizationPercentage(c.currentEmployees, c.employeeLimit), 0) / 
      (companies.length || 1)
    )
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Funcionários</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">de {stats.totalLimits} vagas disponíveis</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Empresas Ativas</CardTitle>
            <CheckCircle className="w-4 h-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.activeCompanies}</div>
            <p className="text-xs text-muted-foreground">de {stats.totalCompanies} empresas total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Próximas do Limite</CardTitle>
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.companiesNearLimit}</div>
            <p className="text-xs text-muted-foreground">empresas acima de 90%</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Utilização Média</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.averageUtilization}%</div>
            <p className="text-xs text-muted-foreground">across all companies</p>
          </CardContent>
        </Card>
      </div>

      {/* Companies Table */}
      <Card>
        <CardHeader>
          <CardTitle>Gestão de Limites por Empresa</CardTitle>
          <CardDescription>
            Controle e ajuste dos limites de funcionários para cada empresa
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Empresa</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Funcionários</TableHead>
                <TableHead>Utilização</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {companies.map((company) => {
                const percentage = getUtilizationPercentage(company.currentEmployees, company.employeeLimit);
                return (
                  <TableRow key={company.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{company.name}</div>
                        {company.cnpj && (
                          <div className="text-sm text-gray-500">{company.cnpj}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getPlanIcon(company.plan)}
                        <span>{planLabels[company.plan]}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-4">
                        <span className="font-medium">
                          {company.currentEmployees}/{company.employeeLimit}
                        </span>
                        <div className="flex items-center space-x-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => adjustEmployeeCount(company.id, -1)}
                            disabled={company.currentEmployees <= 0}
                            className="h-6 w-6 p-0"
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => adjustEmployeeCount(company.id, 1)}
                            disabled={company.currentEmployees >= company.employeeLimit}
                            className="h-6 w-6 p-0"
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className={`text-sm font-medium ${getUtilizationColor(percentage)}`}>
                            {percentage}%
                          </span>
                          {getUtilizationBadge(percentage)}
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        className={
                          company.status === 'active' ? 'bg-green-100 text-green-800' :
                          company.status === 'inactive' ? 'bg-gray-100 text-gray-800' :
                          'bg-red-100 text-red-800'
                        }
                      >
                        {company.status === 'active' ? 'Ativo' :
                         company.status === 'inactive' ? 'Inativo' : 'Suspenso'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditDialog(company)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={closeDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Ajustar Limites - {selectedCompany?.name}</DialogTitle>
            <DialogDescription>
              Defina o limite de funcionários e o número atual de funcionários da empresa
            </DialogDescription>
          </DialogHeader>
          
          {selectedCompany && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="employee-limit">Limite de Funcionários</Label>
                <Input
                  id="employee-limit"
                  type="number"
                  min="1"
                  max={planLimits[selectedCompany.plan]}
                  value={newLimit}
                  onChange={(e) => setNewLimit(Number(e.target.value))}
                />
                <p className="text-xs text-gray-500">
                  Limite máximo do plano {planLabels[selectedCompany.plan]}: {planLimits[selectedCompany.plan]} funcionários
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="current-employees">Funcionários Atuais</Label>
                <Input
                  id="current-employees"
                  type="number"
                  min="0"
                  max={newLimit}
                  value={newEmployeeCount}
                  onChange={(e) => setNewEmployeeCount(Number(e.target.value))}
                />
                <p className="text-xs text-gray-500">
                  Número atual de funcionários cadastrados na empresa
                </p>
              </div>

              {newEmployeeCount > newLimit && (
                <div className="p-3 bg-red-50 rounded-lg">
                  <div className="flex items-center">
                    <AlertTriangle className="w-4 h-4 text-red-600 mr-2" />
                    <p className="text-sm text-red-800">
                      O número de funcionários não pode ser maior que o limite
                    </p>
                  </div>
                </div>
              )}

              {newLimit > planLimits[selectedCompany.plan] && (
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center">
                    <AlertTriangle className="w-4 h-4 text-yellow-600 mr-2" />
                    <p className="text-sm text-yellow-800">
                      Limite excede o máximo do plano atual
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>
              Cancelar
            </Button>
            <Button 
              onClick={handleUpdateLimits}
              disabled={!selectedCompany || newEmployeeCount > newLimit || newLimit > planLimits[selectedCompany?.plan || 'basic']}
            >
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
