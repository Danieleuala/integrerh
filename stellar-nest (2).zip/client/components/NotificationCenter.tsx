import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { 
  Bell, 
  BellRing, 
  Check, 
  User, 
  Briefcase, 
  BookOpen, 
  Award, 
  MessageSquare, 
  Megaphone,
  FileText,
  X
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: string;
  userId: string;
  read: boolean;
  relatedModule: string;
  relatedId?: string;
  actionUrl?: string;
}

// Mock notifications for demo purposes - no external dependencies
const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'info',
    title: 'Bem-vindo ao Sistema!',
    message: 'Explore todos os módulos disponíveis na plataforma.',
    timestamp: new Date().toISOString(),
    userId: 'all',
    read: false,
    relatedModule: 'system'
  },
  {
    id: '2',
    type: 'success',
    title: 'Sistema Funcionando',
    message: 'Todos os módulos estão operacionais e funcionando perfeitamente.',
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    userId: 'all',
    read: false,
    relatedModule: 'system'
  },
  {
    id: '3',
    type: 'info',
    title: 'Acesso Liberado',
    message: 'Você tem acesso completo a todas as funcionalidades.',
    timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    userId: 'all',
    read: false,
    relatedModule: 'employees'
  }
];

export function NotificationCenter() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  // Stable notification loading with useMemo to prevent re-renders
  const loadNotifications = useCallback(() => {
    if (user?.id) {
      try {
        // Use mock data instead of external store to avoid infinite re-renders
        const userNotifications = mockNotifications.filter(n => 
          n.userId === user.id.toString() || n.userId === 'all'
        ).sort((a, b) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
        setNotifications(userNotifications);
      } catch (error) {
        console.warn('Error loading notifications:', error);
        setNotifications([]);
      }
    } else {
      setNotifications([]);
    }
  }, [user?.id]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  const markAsRead = useCallback((notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true }
          : notification
      )
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
  }, []);

  const getModuleIcon = (module: string) => {
    switch (module) {
      case 'employees':
        return <User className="w-4 h-4" />;
      case 'jobs':
        return <Briefcase className="w-4 h-4" />;
      case 'trainings':
        return <BookOpen className="w-4 h-4" />;
      case 'evaluations':
        return <Award className="w-4 h-4" />;
      case 'feedback':
        return <MessageSquare className="w-4 h-4" />;
      case 'communications':
        return <Megaphone className="w-4 h-4" />;
      case 'documents':
        return <FileText className="w-4 h-4" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'warning':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'error':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-blue-600 bg-blue-50 border-blue-200';
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  if (!user) return null;

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          {unreadCount > 0 ? (
            <BellRing className="w-5 h-5" />
          ) : (
            <Bell className="w-5 h-5" />
          )}
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <Card className="border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Notificações</CardTitle>
            <div className="flex items-center space-x-2">
              {unreadCount > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={markAllAsRead}
                  className="text-xs"
                >
                  <Check className="w-3 h-3 mr-1" />
                  Marcar Todas
                </Button>
              )}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsOpen(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-96">
              {notifications.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <Bell className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">Nenhuma notificação</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border-l-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                        !notification.read ? 'bg-blue-50/50' : ''
                      } ${getNotificationColor(notification.type)}`}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          {getModuleIcon(notification.relatedModule)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {notification.title}
                            </p>
                            {!notification.read && (
                              <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mt-1">
                            {notification.message}
                          </p>
                          <div className="flex items-center justify-between mt-2">
                            <p className="text-xs text-gray-500">
                              {formatDistanceToNow(new Date(notification.timestamp), { 
                                addSuffix: true, 
                                locale: ptBR 
                              })}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {notification.relatedModule === 'employees' && 'Colaboradores'}
                              {notification.relatedModule === 'jobs' && 'Vagas'}
                              {notification.relatedModule === 'trainings' && 'Treinamentos'}
                              {notification.relatedModule === 'evaluations' && 'Avaliações'}
                              {notification.relatedModule === 'feedback' && 'Feedback'}
                              {notification.relatedModule === 'communications' && 'Comunicações'}
                              {notification.relatedModule === 'documents' && 'Documentos'}
                              {notification.relatedModule === 'system' && 'Sistema'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  );
}
