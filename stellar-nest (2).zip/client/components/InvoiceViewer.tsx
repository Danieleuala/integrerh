import React from 'react';
import { 
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Building2, Calendar, DollarSign, FileText, 
  CreditCard, Phone, Mail, MapPin 
} from 'lucide-react';

interface Invoice {
  id: string;
  companyId: string;
  companyName: string;
  plan: 'basic' | 'professional' | 'enterprise';
  month: string;
  year: number;
  dueDate: string;
  issueDate: string;
  amount: number;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  paymentDate?: string;
  paymentMethod?: string;
  barcode?: string;
  notes?: string;
}

interface Company {
  id: string;
  name: string;
  plan: 'basic' | 'professional' | 'enterprise';
  cnpj?: string;
  email?: string;
  phone?: string;
  address?: string;
}

interface InvoiceViewerProps {
  invoice: Invoice | null;
  company: Company | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function InvoiceViewer({ invoice, company, isOpen, onClose }: InvoiceViewerProps) {
  if (!invoice || !company) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Pago</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800">Vencido</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-100 text-gray-800">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case 'basic':
        return <Badge variant="outline" className="text-blue-600 border-blue-300">Básico</Badge>;
      case 'professional':
        return <Badge variant="outline" className="text-purple-600 border-purple-300">Profissional</Badge>;
      case 'enterprise':
        return <Badge variant="outline" className="text-green-600 border-green-300">Enterprise</Badge>;
      default:
        return <Badge variant="outline">{plan}</Badge>;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Detalhes do Boleto</span>
            {getStatusBadge(invoice.status)}
          </DialogTitle>
          <DialogDescription>
            Informações completas do boleto {invoice.id}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Invoice Header */}
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <div className="flex items-center mb-2">
                  <FileText className="w-5 h-5 text-gray-600 mr-2" />
                  <h3 className="font-semibold text-gray-900">Número do Boleto</h3>
                </div>
                <p className="text-lg font-mono">{invoice.id}</p>
              </div>
              
              <div>
                <div className="flex items-center mb-2">
                  <Calendar className="w-5 h-5 text-gray-600 mr-2" />
                  <h3 className="font-semibold text-gray-900">Competência</h3>
                </div>
                <p className="text-lg">{invoice.month}/{invoice.year}</p>
              </div>
              
              <div>
                <div className="flex items-center mb-2">
                  <DollarSign className="w-5 h-5 text-gray-600 mr-2" />
                  <h3 className="font-semibold text-gray-900">Valor</h3>
                </div>
                <p className="text-lg font-bold text-green-600">
                  {invoice.amount > 0 ? (
                    `R$ ${invoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                  ) : (
                    'Consulta Gratuita'
                  )}
                </p>
              </div>
            </div>
          </div>

          {/* Company Information */}
          <div>
            <div className="flex items-center mb-4">
              <Building2 className="w-5 h-5 text-gray-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Dados da Empresa</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-gray-500">Razão Social</label>
                  <p className="text-gray-900">{company.name}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-500">CNPJ</label>
                  <p className="text-gray-900 font-mono">{company.cnpj || 'Não informado'}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-500">Plano Contratado</label>
                  <div className="mt-1">
                    {getPlanBadge(company.plan)}
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-gray-500">Email</label>
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 text-gray-400 mr-2" />
                    <p className="text-gray-900">{company.email || 'Não informado'}</p>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-500">Telefone</label>
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 text-gray-400 mr-2" />
                    <p className="text-gray-900">{company.phone || 'Não informado'}</p>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-500">Endereço</label>
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 text-gray-400 mr-2" />
                    <p className="text-gray-900">{company.address || 'Não informado'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Payment Details */}
          <div>
            <div className="flex items-center mb-4">
              <CreditCard className="w-5 h-5 text-gray-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Detalhes do Pagamento</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-sm font-medium text-gray-500">Data de Emissão</label>
                <p className="text-gray-900">
                  {new Date(invoice.issueDate).toLocaleDateString('pt-BR')}
                </p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Data de Vencimento</label>
                <p className="text-gray-900">
                  {new Date(invoice.dueDate).toLocaleDateString('pt-BR')}
                </p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Status</label>
                <div className="mt-1">
                  {getStatusBadge(invoice.status)}
                </div>
              </div>
            </div>

            {invoice.paymentDate && (
              <div className="mt-4 p-4 bg-green-50 rounded-lg">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-green-700">Data do Pagamento</label>
                    <p className="text-green-900">
                      {new Date(invoice.paymentDate).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-green-700">Forma de Pagamento</label>
                    <p className="text-green-900">{invoice.paymentMethod || 'Não informado'}</p>
                  </div>
                </div>
              </div>
            )}

            {invoice.status === 'overdue' && (
              <div className="mt-4 p-4 bg-red-50 rounded-lg">
                <div className="flex items-center">
                  <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
                  <div>
                    <p className="text-red-800 font-medium">Boleto Vencido</p>
                    <p className="text-red-600 text-sm">
                      Vencido há {Math.floor((Date.now() - new Date(invoice.dueDate).getTime()) / (1000 * 60 * 60 * 24))} dias
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Barcode */}
          {invoice.barcode && (
            <div>
              <Separator />
              <div className="mt-6">
                <label className="text-sm font-medium text-gray-500">Código de Barras</label>
                <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                  <p className="font-mono text-sm text-gray-900 break-all">
                    {invoice.barcode}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Notes */}
          {invoice.notes && (
            <div>
              <label className="text-sm font-medium text-gray-500">Observações</label>
              <div className="mt-2 p-4 bg-yellow-50 rounded-lg">
                <p className="text-gray-900">{invoice.notes}</p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
