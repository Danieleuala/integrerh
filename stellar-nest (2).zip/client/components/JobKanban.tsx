import { useState, useMemo } from 'react';
import { EnhancedJob, EnhancedJobApplication, Candidate } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  Users, Clock, Calendar, CheckCircle, XCircle, AlertCircle,
  MoreHorizontal, Eye, Edit, ArrowRight, TestTube, Phone,
  Video, FileText, MessageSquare, Star, Target, Mail,
  ChevronRight, UserCheck, UserX, Send, Award, Building2,
  MapPin, DollarSign
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface JobKanbanProps {
  job: EnhancedJob;
  candidates: Candidate[];
  onUpdateApplication: (applicationId: string, updates: Partial<EnhancedJobApplication>) => void;
  onBack: () => void;
}

// Define the specific Kanban columns as requested
const KANBAN_COLUMNS = [
  { id: 'inscritos', name: 'Inscritos', color: 'bg-blue-50 border-blue-200', textColor: 'text-blue-700' },
  { id: 'avaliacao', name: 'Avaliação', color: 'bg-yellow-50 border-yellow-200', textColor: 'text-yellow-700' },
  { id: 'entrevista', name: 'Entrevista', color: 'bg-purple-50 border-purple-200', textColor: 'text-purple-700' },
  { id: 'finalista', name: 'Finalista', color: 'bg-orange-50 border-orange-200', textColor: 'text-orange-700' },
  { id: 'contratado', name: 'Contratado', color: 'bg-green-50 border-green-200', textColor: 'text-green-700' },
  { id: 'reprovado', name: 'Reprovado', color: 'bg-red-50 border-red-200', textColor: 'text-red-700' }
];

export default function JobKanban({ job, candidates, onUpdateApplication, onBack }: JobKanbanProps) {
  const { toast } = useToast();
  const [selectedApplication, setSelectedApplication] = useState<EnhancedJobApplication | null>(null);
  const [isApplicationDialogOpen, setIsApplicationDialogOpen] = useState(false);
  const [notes, setNotes] = useState('');

  const getCandidateById = (candidateId: string) => {
    return candidates.find(c => c.id === candidateId);
  };

  // Map applications to Kanban columns based on stage names and status
  const getApplicationsForKanbanColumn = (columnId: string) => {
    switch (columnId) {
      case 'inscritos':
        return job.applications.filter(app => {
          const stage = job.stages.find(s => s.id === app.currentStage);
          return app.status === 'active' && stage && (stage.name.toLowerCase().includes('análise') || stage.name.toLowerCase().includes('inicial') || stage.order === 1);
        });
      case 'avaliacao':
        return job.applications.filter(app => {
          const stage = job.stages.find(s => s.id === app.currentStage);
          return app.status === 'active' && stage && (stage.name.toLowerCase().includes('avaliação') || stage.name.toLowerCase().includes('prova') || stage.name.toLowerCase().includes('técnica'));
        });
      case 'entrevista':
        return job.applications.filter(app => {
          const stage = job.stages.find(s => s.id === app.currentStage);
          return app.status === 'active' && stage && stage.name.toLowerCase().includes('entrevista');
        });
      case 'finalista':
        return job.applications.filter(app => {
          const stage = job.stages.find(s => s.id === app.currentStage);
          return app.status === 'active' && stage && (stage.name.toLowerCase().includes('final') || stage.name.toLowerCase().includes('selecionado') || stage.order === job.stages.length);
        });
      case 'contratado':
        return job.applications.filter(app => app.status === 'approved');
      case 'reprovado':
        return job.applications.filter(app => app.status === 'rejected');
      default:
        return [];
    }
  };

  const moveToKanbanColumn = (application: EnhancedJobApplication, targetColumnId: string) => {
    const targetColumn = KANBAN_COLUMNS.find(c => c.id === targetColumnId);
    if (!targetColumn) return;

    let updates: Partial<EnhancedJobApplication> = {};
    let notes = `Movido para coluna: ${targetColumn.name}`;

    // Update status based on target column
    if (targetColumnId === 'contratado') {
      updates.status = 'approved';
      notes = 'Candidato aprovado e contratado';
    } else if (targetColumnId === 'reprovado') {
      updates.status = 'rejected';
      notes = 'Candidato rejeitado';
    } else {
      updates.status = 'active';
      // For other columns, try to find appropriate stage
      let targetStage = job.stages[0]; // default to first stage

      if (targetColumnId === 'avaliacao') {
        targetStage = job.stages.find(s => s.name.toLowerCase().includes('avaliação') || s.name.toLowerCase().includes('prova') || s.name.toLowerCase().includes('técnica')) || job.stages[1] || job.stages[0];
      } else if (targetColumnId === 'entrevista') {
        targetStage = job.stages.find(s => s.name.toLowerCase().includes('entrevista')) || job.stages[2] || job.stages[0];
      } else if (targetColumnId === 'finalista') {
        targetStage = job.stages.find(s => s.name.toLowerCase().includes('final') || s.name.toLowerCase().includes('selecionado')) || job.stages[job.stages.length - 1];
      }

      updates.currentStage = targetStage.id;
    }

    // Update stage history
    const updatedHistory = [
      ...application.stageHistory,
      {
        stageId: application.currentStage,
        enteredDate: application.stageHistory.find(h => h.stageId === application.currentStage)?.enteredDate || new Date().toISOString(),
        exitedDate: new Date().toISOString(),
        result: targetColumnId === 'contratado' ? 'passed' as const : targetColumnId === 'reprovado' ? 'failed' as const : 'moved' as const,
        notes: notes
      }
    ];

    if (updates.currentStage && updates.currentStage !== application.currentStage) {
      updatedHistory.push({
        stageId: updates.currentStage,
        enteredDate: new Date().toISOString(),
        result: 'pending' as const
      });
    }

    updates.stageHistory = updatedHistory;

    onUpdateApplication(application.id, updates);

    toast({
      title: "Candidato movido",
      description: `Candidato movido para: ${targetColumn.name}`,
    });
  };

  const approveApplication = (application: EnhancedJobApplication) => {
    const updatedHistory = [
      ...application.stageHistory,
      {
        stageId: application.currentStage,
        enteredDate: application.stageHistory.find(h => h.stageId === application.currentStage)?.enteredDate || new Date().toISOString(),
        exitedDate: new Date().toISOString(),
        result: 'passed',
        notes: 'Candidato aprovado no processo seletivo'
      }
    ];

    onUpdateApplication(application.id, {
      status: 'approved',
      stageHistory: updatedHistory
    });

    toast({
      title: "Candidato aprovado",
      description: "O candidato foi aprovado no processo seletivo",
    });
  };

  const rejectApplication = (application: EnhancedJobApplication) => {
    const updatedHistory = [
      ...application.stageHistory,
      {
        stageId: application.currentStage,
        enteredDate: application.stageHistory.find(h => h.stageId === application.currentStage)?.enteredDate || new Date().toISOString(),
        exitedDate: new Date().toISOString(),
        result: 'failed',
        notes: 'Candidato rejeitado'
      }
    ];

    onUpdateApplication(application.id, {
      status: 'rejected',
      stageHistory: updatedHistory
    });

    toast({
      title: "Candidato rejeitado",
      description: "O candidato foi marcado como rejeitado",
      variant: "destructive"
    });
  };

  const handleViewApplication = (application: EnhancedJobApplication) => {
    setSelectedApplication(application);
    setIsApplicationDialogOpen(true);
  };

  const KanbanColumn = ({ column, applications }: { column: any, applications: EnhancedJobApplication[] }) => (
    <div className="flex-1 min-w-80">
      <Card className={`h-full ${column.color}`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className={`text-sm font-medium ${column.textColor}`}>{column.name}</CardTitle>
            <Badge variant="outline" className={column.textColor}>{applications.length}</Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {applications.map((application) => {
              const candidate = getCandidateById(application.candidateId);
              if (!candidate) return null;

              return (
                <Card 
                  key={application.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow border-l-4 border-l-purple-500"
                  onClick={() => handleViewApplication(application)}
                >
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-purple-100 text-purple-600 text-xs">
                            {candidate.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <h4 className="font-medium text-sm truncate">{candidate.name}</h4>
                          <p className="text-xs text-gray-600 truncate">{candidate.email}</p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" onClick={(e) => e.stopPropagation()}>
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={(e) => {
                            e.stopPropagation();
                            handleViewApplication(application);
                          }}>
                            <Eye className="w-4 h-4 mr-2" />
                            Ver Detalhes
                          </DropdownMenuItem>
                          {/* Move to Kanban columns */}
                          <DropdownMenuSeparator />
                          {KANBAN_COLUMNS.map((targetColumn) => {
                            if (targetColumn.id === column.id) return null;
                            return (
                              <DropdownMenuItem
                                key={targetColumn.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  moveToKanbanColumn(application, targetColumn.id);
                                }}
                              >
                                <ArrowRight className="w-4 h-4 mr-2" />
                                Mover para {targetColumn.name}
                              </DropdownMenuItem>
                            );
                          })}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <div className="text-xs text-gray-500 space-y-1">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {format(new Date(application.appliedDate), 'dd/MM', { locale: ptBR })}
                      </div>
                      {application.stageHistory.length > 0 && (
                        <div className="flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {Math.ceil((new Date().getTime() - new Date(application.stageHistory[application.stageHistory.length - 1].enteredDate).getTime()) / (1000 * 60 * 60 * 24))} dia(s)
                        </div>
                      )}
                    </div>

                    {/* Test Results */}
                    {candidate.testResults.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {candidate.testResults.slice(0, 2).map((result, index) => (
                          <Badge 
                            key={index} 
                            variant={result.passed ? "default" : "destructive"}
                            className="text-xs"
                          >
                            {result.percentage.toFixed(0)}%
                          </Badge>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
            
            {applications.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Nenhum candidato</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Enhanced Job Header */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <Button variant="outline" onClick={onBack} className="bg-white shadow-sm">
            ← Voltar para Vagas
          </Button>
          <div className="flex items-center space-x-3">
            <Badge className={job.status === 'open' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}>
              {job.status === 'open' ? 'Vaga Aberta' : job.status === 'closed' ? 'Vaga Fechada' : 'Rascunho'}
            </Badge>
            <Badge variant="outline" className="bg-white">
              Código: {job.id.toUpperCase()}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{job.title}</h1>
            <div className="space-y-2 text-gray-600">
              <div className="flex items-center space-x-2">
                <Building2 className="w-4 h-4" />
                <span><strong>Departamento:</strong> {job.department}</span>
              </div>
              {job.location && (
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4" />
                  <span><strong>Local:</strong> {job.location}</span>
                </div>
              )}
              {job.salary && (
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-4 h-4" />
                  <span><strong>Salário:</strong> {job.salary}</span>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span><strong>Criada em:</strong> {format(new Date(job.createdDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-white shadow-sm">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">{job.applications.length}</div>
                <div className="text-sm text-gray-600">Total Candidatos</div>
              </CardContent>
            </Card>
            <Card className="bg-white shadow-sm">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {job.applications.filter(a => a.status === 'active').length}
                </div>
                <div className="text-sm text-gray-600">Em Processo</div>
              </CardContent>
            </Card>
            <Card className="bg-white shadow-sm">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {job.applications.filter(a => a.status === 'approved').length}
                </div>
                <div className="text-sm text-gray-600">Contratados</div>
              </CardContent>
            </Card>
            <Card className="bg-white shadow-sm">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-600">
                  {job.applications.filter(a => a.status === 'rejected').length}
                </div>
                <div className="text-sm text-gray-600">Rejeitados</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>


      {/* Kanban Board with Specific Columns */}
      <Card>
        <CardHeader>
          <CardTitle>Pipeline de Candidatos - Processo Seletivo</CardTitle>
          <CardDescription>
            Gerencie os candidatos através das etapas do processo seletivo usando o menu de ações
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {KANBAN_COLUMNS.map((column) => {
              const columnApplications = getApplicationsForKanbanColumn(column.id);
              return (
                <KanbanColumn
                  key={column.id}
                  column={column}
                  applications={columnApplications}
                />
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Application Details Dialog */}
      <Dialog open={isApplicationDialogOpen} onOpenChange={setIsApplicationDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Candidatura</DialogTitle>
            <DialogDescription>
              Informações completas do candidato e histórico no processo
            </DialogDescription>
          </DialogHeader>
          
          {selectedApplication && (
            <div className="space-y-6">
              {(() => {
                const candidate = getCandidateById(selectedApplication.candidateId);
                if (!candidate) return null;

                return (
                  <>
                    {/* Candidate Info */}
                    <div className="flex items-start space-x-4">
                      <Avatar className="w-16 h-16">
                        <AvatarFallback className="bg-purple-100 text-purple-600 text-lg">
                          {candidate.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-gray-900">{candidate.name}</h3>
                        <p className="text-gray-600">{candidate.email}</p>
                        <p className="text-gray-600">{candidate.phone}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <Badge className="bg-blue-100 text-blue-700">
                            {job.stages.find(s => s.id === selectedApplication.currentStage)?.name}
                          </Badge>
                          <span className="text-sm text-gray-500">
                            Aplicou em {format(new Date(selectedApplication.appliedDate), 'dd/MM/yyyy', { locale: ptBR })}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Application Data */}
                    {selectedApplication.experience && (
                      <div>
                        <Label className="font-medium">Experiência Relevante:</Label>
                        <p className="text-gray-700 mt-1">{selectedApplication.experience}</p>
                      </div>
                    )}

                    {selectedApplication.coverLetter && (
                      <div>
                        <Label className="font-medium">Carta de Apresentação:</Label>
                        <p className="text-gray-700 mt-1">{selectedApplication.coverLetter}</p>
                      </div>
                    )}

                    {/* Stage History */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Histórico no Processo</h4>
                      <div className="space-y-2">
                        {selectedApplication.stageHistory.map((history, index) => {
                          const stage = job.stages.find(s => s.id === history.stageId);
                          return (
                            <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                              <div className={`w-3 h-3 rounded-full ${
                                history.result === 'passed' ? 'bg-green-500' :
                                history.result === 'failed' ? 'bg-red-500' : 'bg-yellow-500'
                              }`} />
                              <div className="flex-1">
                                <p className="font-medium">{stage?.name}</p>
                                <p className="text-sm text-gray-600">
                                  Entrada: {format(new Date(history.enteredDate), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                                  {history.exitedDate && (
                                    <> | Saída: {format(new Date(history.exitedDate), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</>
                                  )}
                                </p>
                                {history.notes && (
                                  <p className="text-sm text-gray-500 mt-1">{history.notes}</p>
                                )}
                              </div>
                              {history.result === 'passed' && <CheckCircle className="w-5 h-5 text-green-500" />}
                              {history.result === 'failed' && <XCircle className="w-5 h-5 text-red-500" />}
                              {history.result === 'pending' && <Clock className="w-5 h-5 text-yellow-500" />}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Test Results */}
                    {candidate.testResults.length > 0 && (
                      <div>
                        <h4 className="font-medium text-gray-900 mb-3">Resultados de Provas</h4>
                        <div className="space-y-2">
                          {candidate.testResults.map((result, index) => (
                            <div key={index} className="p-3 border rounded-lg">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">Prova #{index + 1}</p>
                                  <p className="text-sm text-gray-600">
                                    {format(new Date(result.startedAt), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <div className={`text-2xl font-bold ${
                                    result.passed ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {result.percentage.toFixed(0)}%
                                  </div>
                                  <div className="text-sm text-gray-600">
                                    {result.passed ? 'Aprovado' : 'Reprovado'}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex justify-end space-x-3 pt-6 border-t">
                      {selectedApplication.status === 'active' && (
                        <>
                          <Button
                            variant="outline"
                            onClick={() => rejectApplication(selectedApplication)}
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Rejeitar
                          </Button>
                          <Button
                            onClick={() => approveApplication(selectedApplication)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <UserCheck className="w-4 h-4 mr-2" />
                            Aprovar
                          </Button>
                        </>
                      )}
                    </div>
                  </>
                );
              })()}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
