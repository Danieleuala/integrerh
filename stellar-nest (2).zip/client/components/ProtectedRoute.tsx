import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[];
}

export default function ProtectedRoute({ 
  children, 
  requiredRoles = [] 
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Verificando acesso...</p>
        </div>
      </div>
    );
  }

  // If no user, redirect to login with return URL
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If specific roles required, check permissions
  if (requiredRoles.length > 0) {
    // Map old role names to new ones for compatibility
    const roleMapping: { [key: string]: string[] } = {
      'rh_admin': ['admin', 'hr'],
      'manager': ['manager'],
      'employee': ['employee'],
      'candidate': ['candidate'],
      'admin': ['admin'],
      'hr': ['hr']
    };

    const userRoles = roleMapping[user.role] || [user.role];
    const hasRequiredRole = requiredRoles.some(role => 
      userRoles.includes(role) || userRoles.includes('admin')
    );

    if (!hasRequiredRole) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center max-w-md mx-auto p-6">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 15.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Acesso Restrito</h1>
            <p className="text-gray-600 mb-6">
              Você não tem permissão para acessar esta área. 
              Entre com uma conta que tenha os privilégios necessários.
            </p>
            <div className="space-y-2">
              <button 
                onClick={() => window.location.href = '/login'}
                className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors"
              >
                Fazer Login com Outra Conta
              </button>
              <button 
                onClick={() => window.location.href = '/dashboard'}
                className="w-full bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors"
              >
                Voltar ao Dashboard
              </button>
            </div>
            <div className="mt-4 text-sm text-gray-500">
              Perfil atual: <span className="font-medium">{user.name}</span> ({user.role})
            </div>
          </div>
        </div>
      );
    }
  }

  // User has access, render children
  return <>{children}</>;
}
