import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Upload, Video, CheckCircle, AlertCircle, X, Play } from 'lucide-react';
import { DataAdapter } from '@/lib/dataAdapter';
import { fileUploadService, formatFileSize, validateFile, FILE_TYPES, MAX_FILE_SIZES } from '@/lib/fileUploadService';

interface VideoUploadProps {
  trainingId: string;
  onVideoAdded: (material: any) => void;
  onCancel?: () => void;
}

export function VideoUpload({ trainingId, onVideoAdded, onCancel }: VideoUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [videoName, setVideoName] = useState('');
  const [videoDuration, setVideoDuration] = useState('');

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    setError(null);
    
    if (file) {
      // Validate file
      const allowedTypes = FILE_TYPES.VIDEOS;
      const maxSize = MAX_FILE_SIZES.VIDEO;

      const validation = validateFile(file, allowedTypes, maxSize);
      if (!validation.valid) {
        setError(validation.error || 'Arquivo inválido');
        return;
      }
      
      setSelectedFile(file);
      setVideoName(file.name.replace(/\.[^/.]+$/, "")); // Remove extension
      
      // Try to get video duration (basic estimate)
      const videoElement = document.createElement('video');
      videoElement.preload = 'metadata';
      videoElement.onloadedmetadata = () => {
        const duration = Math.round(videoElement.duration);
        const minutes = Math.floor(duration / 60);
        const seconds = duration % 60;
        setVideoDuration(`${minutes}:${seconds.toString().padStart(2, '0')} min`);
        window.URL.revokeObjectURL(videoElement.src);
      };
      videoElement.src = URL.createObjectURL(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile || !videoName.trim()) return;

    setUploading(true);
    setUploadProgress(0);
    setError(null);

    try {
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 5, 90));
      }, 500);

      // Upload video to Supabase storage
      const uploadResult = await fileUploadService.uploadTrainingMaterial(
        selectedFile,
        trainingId || 'general'
      );

      clearInterval(progressInterval);

      if (!uploadResult.success) {
        throw new Error(uploadResult.error || 'Erro ao fazer upload do vídeo');
      }

      // Create training material object
      const newMaterial = {
        name: videoName.trim(),
        type: 'video' as const,
        url: uploadResult.url,
        storage_path: uploadResult.path,
        duration: videoDuration || 'Não especificado',
        order_index: 0 // Will be updated based on existing materials
      };

      setUploadProgress(100);
      setUploading(false);
      setSuccess(true);

      // Call the callback with the new material
      setTimeout(() => {
        onVideoAdded(newMaterial);
        setSelectedFile(null);
        setVideoName('');
        setVideoDuration('');
        setSuccess(false);
        setUploadProgress(0);
      }, 1500);
    } catch (error) {
      setUploading(false);
      setUploadProgress(0);
      setError(error instanceof Error ? error.message : 'Erro desconhecido');
      console.error('Error uploading video:', error);
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setVideoName('');
    setVideoDuration('');
    setError(null);
    setUploadProgress(0);
  };

  if (success) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800">
          Vídeo enviado com sucesso!
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            {error}
          </AlertDescription>
        </Alert>
      )}

      <Card className="border-dashed border-2 border-gray-300 hover:border-purple-400 transition-colors">
        <CardContent className="p-6">
          <div className="text-center">
            <Video className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Enviar Vídeo de Treinamento
            </h3>
            <p className="text-gray-600 mb-4">
              Selecione um arquivo de vídeo para fazer upload
            </p>
            <p className="text-sm text-gray-500 mb-4">
              Formatos aceitos: MP4, AVI, MOV, WMV, FLV, WEBM, MKV<br />
              Tamanho máximo: {formatFileSize(MAX_FILE_SIZES.VIDEO)}
            </p>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="video-upload">Arquivo de Vídeo</Label>
                <Input
                  id="video-upload"
                  type="file"
                  accept=".mp4,.avi,.mov,.wmv,.flv,.webm,.mkv"
                  onChange={handleFileSelect}
                  className="cursor-pointer"
                  disabled={uploading}
                />
              </div>

              {selectedFile && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Video className="w-5 h-5 text-gray-500" />
                      <div>
                        <p className="font-medium text-sm">{selectedFile.name}</p>
                        <p className="text-xs text-gray-500">
                          {formatFileSize(selectedFile.size)}
                          {videoDuration && ` • ${videoDuration}`}
                        </p>
                      </div>
                    </div>
                    {!uploading && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearFile}
                        className="h-8 w-8 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="video-name">Nome do Vídeo</Label>
                      <Input
                        id="video-name"
                        value={videoName}
                        onChange={(e) => setVideoName(e.target.value)}
                        placeholder="Digite o nome do vídeo..."
                        disabled={uploading}
                      />
                    </div>

                    <div>
                      <Label htmlFor="video-duration">Duração (opcional)</Label>
                      <Input
                        id="video-duration"
                        value={videoDuration}
                        onChange={(e) => setVideoDuration(e.target.value)}
                        placeholder="Ex: 15:30 min"
                        disabled={uploading}
                      />
                    </div>
                  </div>

                  {uploading && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Enviando vídeo...</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <Progress value={uploadProgress} className="w-full" />
                      <p className="text-xs text-gray-500 text-center">
                        Isso pode levar alguns minutos para vídeos grandes
                      </p>
                    </div>
                  )}
                </div>
              )}
              
              <div className="flex justify-end space-x-3">
                {onCancel && (
                  <Button
                    variant="outline"
                    onClick={onCancel}
                    disabled={uploading}
                  >
                    Cancelar
                  </Button>
                )}
                {selectedFile && !uploading && (
                  <Button
                    variant="outline"
                    onClick={clearFile}
                  >
                    Limpar
                  </Button>
                )}
                <Button
                  onClick={handleUpload}
                  disabled={!selectedFile || !videoName.trim() || uploading}
                  className="bg-gradient-to-r from-purple-600 to-blue-600"
                >
                  {uploading ? `Enviando... ${uploadProgress}%` : 'Enviar Vídeo'}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
