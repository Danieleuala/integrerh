import { useState } from 'react';
import { Employee, EmployeeHistoryEntry } from '@/lib/mockData';
import { IntegratedDataStore } from '@/lib/mockData';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Calendar, Clock, RefreshCw, AlertCircle, CheckCircle,
  UserCheck, UserX, ClipboardList, FileText
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export interface LeaveRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  leaveType: 'medical' | 'maternity' | 'paternity' | 'vacation' | 'personal' | 'study' | 'inss' | 'other';
  startDate: string;
  expectedReturnDate?: string;
  actualReturnDate?: string;
  reason: string;
  status: 'active' | 'returned' | 'extended';
  authorizedBy: string;
  documents: string[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

interface LeaveManagementProps {
  employee: Employee;
  onLeaveStatusChanged: () => void;
}

export function LeaveManagement({ employee, onLeaveStatusChanged }: LeaveManagementProps) {
  const { user } = useAuth();
  const [isCreateLeaveOpen, setIsCreateLeaveOpen] = useState(false);
  const [isReturnDialogOpen, setIsReturnDialogOpen] = useState(false);
  const [leaveForm, setLeaveForm] = useState({
    leaveType: '',
    startDate: '',
    expectedReturnDate: '',
    reason: '',
    notes: ''
  });

  // Get current active leave for employee
  const currentLeave = getCurrentActiveLeave(employee.id);
  const leaveHistory = getLeaveHistory(employee.id);

  const leaveTypeLabels = {
    medical: 'Licença Médica',
    maternity: 'Licença Maternidade',
    paternity: 'Licença Paternidade',
    vacation: 'Férias',
    personal: 'Licença Pessoal',
    study: 'Licença Estudo',
    inss: 'Afastamento INSS',
    other: 'Outro'
  };

  const handleCreateLeave = () => {
    if (!leaveForm.leaveType || !leaveForm.startDate || !leaveForm.reason) {
      alert('Preencha todos os campos obrigatórios: Tipo, Data de Início e Motivo');
      return;
    }

    // Create leave record
    const leaveRecord: LeaveRecord = {
      id: `leave_${Date.now()}`,
      employeeId: employee.id,
      employeeName: employee.name,
      leaveType: leaveForm.leaveType as LeaveRecord['leaveType'],
      startDate: leaveForm.startDate,
      expectedReturnDate: leaveForm.expectedReturnDate || undefined,
      reason: leaveForm.reason,
      status: 'ongoing',
      authorizedBy: user?.name || 'Sistema',
      documents: [],
      notes: leaveForm.notes || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Save leave record (mock implementation)
    saveLeaveRecord(leaveRecord);

    // Update employee status to on_leave
    const employeeHistory = Array.isArray(employee.history) ? employee.history : [];
    const updatedEmployee = {
      ...employee,
      status: 'on_leave' as const,
      history: [
        ...employeeHistory,
        {
          id: `h_${Date.now()}`,
          date: new Date().toISOString(),
          type: 'status_change' as const,
          description: `Colaborador em afastamento - ${leaveTypeLabels[leaveRecord.leaveType]}`,
          details: {
            oldValue: employee.status,
            newValue: 'on_leave',
            reason: leaveRecord.reason,
            leaveType: leaveRecord.leaveType,
            expectedReturn: leaveRecord.expectedReturnDate,
            authorizedBy: user?.name || 'Sistema'
          }
        }
      ]
    };

    const success = IntegratedDataStore.updateEmployee(employee.id, updatedEmployee);
    if (success) {
      onLeaveStatusChanged();
      setIsCreateLeaveOpen(false);
      setLeaveForm({
        leaveType: '',
        startDate: '',
        expectedReturnDate: '',
        reason: '',
        notes: ''
      });
      alert('Afastamento configurado com sucesso!');
    }
  };

  const handleReturnFromLeave = () => {
    if (!currentLeave) return;

    const returnDate = new Date().toISOString();

    // Update leave record
    const updatedLeave = {
      ...currentLeave,
      actualReturnDate: returnDate,
      status: 'returned' as const,
      updatedAt: returnDate
    };
    updateLeaveRecord(updatedLeave);

    // Update employee status back to active
    const employeeHistory = Array.isArray(employee.history) ? employee.history : [];
    const updatedEmployee = {
      ...employee,
      status: 'active' as const,
      history: [
        ...employeeHistory,
        {
          id: `h_${Date.now()}`,
          date: returnDate,
          type: 'status_change' as const,
          description: `Retorno do afastamento - ${leaveTypeLabels[currentLeave.leaveType]}`,
          details: {
            oldValue: 'on_leave',
            newValue: 'active',
            reason: 'Retorno programado do afastamento',
            leaveType: currentLeave.leaveType,
            actualReturn: returnDate,
            authorizedBy: user?.name || 'Sistema'
          }
        }
      ]
    };

    const success = IntegratedDataStore.updateEmployee(employee.id, updatedEmployee);
    if (success) {
      onLeaveStatusChanged();
      setIsReturnDialogOpen(false);
      alert('Colaborador retornou do afastamento com sucesso!');
    }
  };

  return (
    <div className="space-y-4">
      {/* Current Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <ClipboardList className="w-5 h-5 text-blue-600" />
              <span>Status de Afastamento</span>
            </div>
            {employee.status === 'on_leave' ? (
              <Badge variant="outline" className="border-orange-200 text-orange-700">
                Em Afastamento
              </Badge>
            ) : (
              <Badge variant="default" className="bg-green-100 text-green-700">
                Ativo
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {employee.status === 'on_leave' && currentLeave ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Tipo de Afastamento</Label>
                  <p className="mt-1">{leaveTypeLabels[currentLeave.leaveType]}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Data de Início</Label>
                  <p className="mt-1">{format(new Date(currentLeave.startDate), 'dd/MM/yyyy', { locale: ptBR })}</p>
                </div>
              </div>
              
              {currentLeave.expectedReturnDate && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">Retorno Previsto</Label>
                  <p className="mt-1">{format(new Date(currentLeave.expectedReturnDate), 'dd/MM/yyyy', { locale: ptBR })}</p>
                </div>
              )}

              <div>
                <Label className="text-sm font-medium text-gray-500">Motivo</Label>
                <p className="mt-1">{currentLeave.reason}</p>
              </div>

              {currentLeave.notes && (
                <div>
                  <Label className="text-sm font-medium text-gray-500">Observações</Label>
                  <p className="mt-1 text-sm text-gray-600">{currentLeave.notes}</p>
                </div>
              )}

              <div className="flex space-x-3 pt-4 border-t">
                <Button 
                  onClick={() => setIsReturnDialogOpen(true)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Registrar Retorno
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-6">
              <UserCheck className="w-12 h-12 mx-auto text-green-500 mb-3" />
              <p className="text-gray-600 mb-4">Colaborador está ativo e disponível</p>
              <Dialog open={isCreateLeaveOpen} onOpenChange={setIsCreateLeaveOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <UserX className="w-4 h-4 mr-2" />
                    Configurar Afastamento
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Configurar Afastamento</DialogTitle>
                    <DialogDescription>
                      Configure um afastamento temporário para {employee.name}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="leaveType">Tipo de Afastamento *</Label>
                        <Select value={leaveForm.leaveType} onValueChange={(value) => setLeaveForm({...leaveForm, leaveType: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="medical">Licença Médica</SelectItem>
                            <SelectItem value="maternity">Licença Maternidade</SelectItem>
                            <SelectItem value="paternity">Licença Paternidade</SelectItem>
                            <SelectItem value="vacation">Férias</SelectItem>
                            <SelectItem value="personal">Licença Pessoal</SelectItem>
                            <SelectItem value="study">Licença Estudo</SelectItem>
                            <SelectItem value="inss">Afastamento INSS</SelectItem>
                            <SelectItem value="other">Outro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="startDate">Data de Início *</Label>
                        <Input
                          id="startDate"
                          type="date"
                          value={leaveForm.startDate}
                          onChange={(e) => setLeaveForm({...leaveForm, startDate: e.target.value})}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="expectedReturnDate">Data Prevista de Retorno</Label>
                      <Input
                        id="expectedReturnDate"
                        type="date"
                        value={leaveForm.expectedReturnDate}
                        onChange={(e) => setLeaveForm({...leaveForm, expectedReturnDate: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="reason">Motivo do Afastamento *</Label>
                      <Textarea
                        id="reason"
                        value={leaveForm.reason}
                        onChange={(e) => setLeaveForm({...leaveForm, reason: e.target.value})}
                        placeholder="Descreva o motivo do afastamento..."
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes">Observações</Label>
                      <Textarea
                        id="notes"
                        value={leaveForm.notes}
                        onChange={(e) => setLeaveForm({...leaveForm, notes: e.target.value})}
                        placeholder="Observações adicionais..."
                        rows={2}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-3 pt-4 border-t">
                    <Button variant="outline" onClick={() => setIsCreateLeaveOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleCreateLeave}>
                      <UserX className="w-4 h-4 mr-2" />
                      Configurar Afastamento
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Leave History */}
      {leaveHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-gray-600" />
              <span>Histórico de Afastamentos</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leaveHistory.map((leave) => (
                <div key={leave.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{leaveTypeLabels[leave.leaveType]}</h4>
                    <Badge 
                      variant={leave.status === 'returned' ? 'default' : 'outline'}
                      className={leave.status === 'returned' 
                        ? 'bg-green-100 text-green-700' 
                        : 'border-orange-200 text-orange-700'
                      }
                    >
                      {leave.status === 'returned' ? 'Retornado' : 'Ativo'}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Início:</span> {format(new Date(leave.startDate), 'dd/MM/yyyy', { locale: ptBR })}
                    </div>
                    {leave.actualReturnDate && (
                      <div>
                        <span className="text-gray-500">Retorno:</span> {format(new Date(leave.actualReturnDate), 'dd/MM/yyyy', { locale: ptBR })}
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{leave.reason}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Return Dialog */}
      <Dialog open={isReturnDialogOpen} onOpenChange={setIsReturnDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <RefreshCw className="w-5 h-5 text-green-600" />
              <span>Registrar Retorno</span>
            </DialogTitle>
            <DialogDescription>
              Confirme o retorno de {employee.name} do afastamento
            </DialogDescription>
          </DialogHeader>
          
          {currentLeave && (
            <div className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium mb-1">Detalhes do Afastamento:</p>
                    <ul className="space-y-1">
                      <li>• Tipo: {leaveTypeLabels[currentLeave.leaveType]}</li>
                      <li>• Início: {format(new Date(currentLeave.startDate), 'dd/MM/yyyy', { locale: ptBR })}</li>
                      {currentLeave.expectedReturnDate && (
                        <li>• Retorno Previsto: {format(new Date(currentLeave.expectedReturnDate), 'dd/MM/yyyy', { locale: ptBR })}</li>
                      )}
                      <li>• Motivo: {currentLeave.reason}</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div className="text-sm text-green-800">
                    <p className="font-medium">O colaborador será reativado e marcado como disponível para trabalho.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsReturnDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleReturnFromLeave} className="bg-green-600 hover:bg-green-700">
              <CheckCircle className="w-4 h-4 mr-2" />
              Confirmar Retorno
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Mock functions for leave management (replace with real API calls)
function getCurrentActiveLeave(employeeId: string): LeaveRecord | null {
  // This would typically fetch from a database
  const mockLeaves = getStoredLeaves();
  return mockLeaves.find(leave => 
    leave.employeeId === employeeId && leave.status === 'active'
  ) || null;
}

function getLeaveHistory(employeeId: string): LeaveRecord[] {
  // This would typically fetch from a database
  const mockLeaves = getStoredLeaves();
  return mockLeaves
    .filter(leave => leave.employeeId === employeeId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

function saveLeaveRecord(leave: LeaveRecord): void {
  const leaves = getStoredLeaves();
  leaves.push(leave);
  localStorage.setItem('employeeLeaves', JSON.stringify(leaves));
}

function updateLeaveRecord(updatedLeave: LeaveRecord): void {
  const leaves = getStoredLeaves();
  const index = leaves.findIndex(leave => leave.id === updatedLeave.id);
  if (index !== -1) {
    leaves[index] = updatedLeave;
    localStorage.setItem('employeeLeaves', JSON.stringify(leaves));
  }
}

function getStoredLeaves(): LeaveRecord[] {
  try {
    const stored = localStorage.getItem('employeeLeaves');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}
