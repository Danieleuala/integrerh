import { useState, useMemo } from 'react';
import { EnhancedJob, EnhancedJobApplication, Candidate, SelectionStage } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import {
  Users, Clock, Calendar, CheckCircle, XCircle, AlertCircle,
  MoreHorizontal, Eye, Edit, ArrowRight, TestTube, Phone,
  Video, FileText, MessageSquare, Star, Target, Mail,
  ChevronRight, DragHandleHorizontal, UserCheck, UserX,
  Workflow, BarChart3, TrendingUp, Award, Timer
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface JobPipelineProps {
  job: EnhancedJob;
  candidates: Candidate[];
  onUpdateApplication: (applicationId: string, updates: Partial<EnhancedJobApplication>) => void;
  onClose: () => void;
}

export default function JobPipeline({ job, candidates, onUpdateApplication, onClose }: JobPipelineProps) {
  const { toast } = useToast();
  const [selectedStage, setSelectedStage] = useState<string>('all');
  const [selectedApplication, setSelectedApplication] = useState<EnhancedJobApplication | null>(null);
  const [isApplicationDialogOpen, setIsApplicationDialogOpen] = useState(false);

  const applicationsByStage = useMemo(() => {
    const stages = job.stages.reduce((acc, stage) => {
      acc[stage.id] = {
        stage,
        applications: job.applications.filter(app => app.currentStage === stage.id)
      };
      return acc;
    }, {} as Record<string, { stage: SelectionStage; applications: EnhancedJobApplication[] }>);

    return stages;
  }, [job.stages, job.applications]);

  const getApplicationsForStage = (stageId: string) => {
    return job.applications.filter(app => app.currentStage === stageId);
  };

  const getCandidateById = (candidateId: string) => {
    return candidates.find(c => c.id === candidateId);
  };

  const getStatusBadge = (status: EnhancedJobApplication['status']) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-blue-100 text-blue-700">Ativo</Badge>;
      case 'approved':
        return <Badge className="bg-green-100 text-green-700">Aprovado</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-700">Rejeitado</Badge>;
      case 'withdrawn':
        return <Badge variant="outline">Desistiu</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const moveToNextStage = (application: EnhancedJobApplication) => {
    const currentStageIndex = job.stages.findIndex(s => s.id === application.currentStage);
    if (currentStageIndex < job.stages.length - 1) {
      const nextStage = job.stages[currentStageIndex + 1];
      
      // Update stage history
      const updatedHistory = [
        ...application.stageHistory,
        {
          stageId: application.currentStage,
          enteredDate: application.stageHistory.find(h => h.stageId === application.currentStage)?.enteredDate || new Date().toISOString(),
          exitedDate: new Date().toISOString(),
          result: 'passed' as const,
          notes: 'Passou para próxima etapa'
        }
      ];

      // Add new stage entry
      updatedHistory.push({
        stageId: nextStage.id,
        enteredDate: new Date().toISOString(),
        result: 'pending' as const
      });

      onUpdateApplication(application.id, {
        currentStage: nextStage.id,
        stageHistory: updatedHistory
      });

      toast({
        title: "Candidato movido",
        description: `Candidato movido para: ${nextStage.name}`,
      });
    }
  };

  const rejectApplication = (application: EnhancedJobApplication) => {
    // Update stage history with rejection
    const updatedHistory = [
      ...application.stageHistory,
      {
        stageId: application.currentStage,
        enteredDate: application.stageHistory.find(h => h.stageId === application.currentStage)?.enteredDate || new Date().toISOString(),
        exitedDate: new Date().toISOString(),
        result: 'failed' as const,
        notes: 'Candidato rejeitado'
      }
    ];

    onUpdateApplication(application.id, {
      status: 'rejected',
      stageHistory: updatedHistory
    });

    toast({
      title: "Candidato rejeitado",
      description: "O candidato foi marcado como rejeitado",
      variant: "destructive"
    });
  };

  const approveApplication = (application: EnhancedJobApplication) => {
    // Update stage history with approval
    const updatedHistory = [
      ...application.stageHistory,
      {
        stageId: application.currentStage,
        enteredDate: application.stageHistory.find(h => h.stageId === application.currentStage)?.enteredDate || new Date().toISOString(),
        exitedDate: new Date().toISOString(),
        result: 'passed' as const,
        notes: 'Candidato aprovado'
      }
    ];

    onUpdateApplication(application.id, {
      status: 'approved',
      stageHistory: updatedHistory
    });

    toast({
      title: "Candidato aprovado",
      description: "O candidato foi aprovado no processo seletivo",
    });
  };

  const handleViewApplication = (application: EnhancedJobApplication) => {
    setSelectedApplication(application);
    setIsApplicationDialogOpen(true);
  };

  const ApplicationCard = ({ application }: { application: EnhancedJobApplication }) => {
    const candidate = getCandidateById(application.candidateId);
    const currentStage = job.stages.find(s => s.id === application.currentStage);
    
    if (!candidate) return null;

    return (
      <Card className="mb-3 hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleViewApplication(application)}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={candidate.name} alt={candidate.name} />
                <AvatarFallback className="bg-purple-100 text-purple-600">
                  {candidate.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h4 className="font-medium text-gray-900">{candidate.name}</h4>
                <p className="text-sm text-gray-600">{candidate.email}</p>
                <p className="text-xs text-gray-500">
                  Aplicou em {format(new Date(application.appliedDate), 'dd/MM/yyyy', { locale: ptBR })}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusBadge(application.status)}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" onClick={(e) => e.stopPropagation()}>
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={(e) => {
                    e.stopPropagation();
                    handleViewApplication(application);
                  }}>
                    <Eye className="w-4 h-4 mr-2" />
                    Ver Detalhes
                  </DropdownMenuItem>
                  {currentStage?.hasTest && (
                    <DropdownMenuItem onClick={(e) => {
                      e.stopPropagation();
                      // Open test for candidate
                      window.open(`/candidate-test/job_${job.id}`, '_blank');
                    }}>
                      <TestTube className="w-4 h-4 mr-2" />
                      Aplicar Teste
                    </DropdownMenuItem>
                  )}
                  {application.status === 'active' && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        moveToNextStage(application);
                      }}>
                        <ArrowRight className="w-4 h-4 mr-2" />
                        Próxima Etapa
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        approveApplication(application);
                      }}>
                        <UserCheck className="w-4 h-4 mr-2" />
                        Aprovar
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-red-600"
                        onClick={(e) => {
                          e.stopPropagation();
                          rejectApplication(application);
                        }}
                      >
                        <UserX className="w-4 h-4 mr-2" />
                        Rejeitar
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          {/* Progress Information */}
          <div className="mt-3 pt-3 border-t space-y-3">
            {/* Current Stage Progress */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Progresso no Processo:</span>
                <span className="text-sm text-gray-500">
                  Etapa {job.stages.findIndex(s => s.id === application.currentStage) + 1} de {job.stages.length}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${((job.stages.findIndex(s => s.id === application.currentStage) + 1) / job.stages.length) * 100}%`
                  }}
                ></div>
              </div>
            </div>

            {/* Stage Duration */}
            {application.stageHistory.length > 0 && (
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Timer className="w-4 h-4" />
                <span>
                  Na etapa atual há {Math.ceil((new Date().getTime() - new Date(application.stageHistory[application.stageHistory.length - 1].enteredDate).getTime()) / (1000 * 60 * 60 * 24))} dia(s)
                </span>
              </div>
            )}

            {/* Test Results */}
            {candidate.testResults.length > 0 && (
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <TestTube className="w-4 h-4 text-blue-500" />
                  <span className="text-sm font-medium">Resultados de Provas:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {candidate.testResults.map((result, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Badge
                        variant={result.passed ? "default" : "destructive"}
                        className="text-xs"
                      >
                        {result.percentage.toFixed(0)}% {result.passed ? '✓' : '✗'}
                      </Badge>
                      {result.passed && (
                        <Award className="w-3 h-3 text-green-500" />
                      )}
                    </div>
                  ))}
                </div>
                <div className="mt-1 text-xs text-gray-500">
                  Média: {(candidate.testResults.reduce((acc, r) => acc + r.percentage, 0) / candidate.testResults.length).toFixed(1)}%
                </div>
              </div>
            )}

            {/* Stage History Summary */}
            {application.stageHistory.length > 1 && (
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <BarChart3 className="w-4 h-4 text-purple-500" />
                  <span className="text-sm font-medium">Histórico:</span>
                </div>
                <div className="text-xs text-gray-600">
                  Passou por {application.stageHistory.filter(h => h.result === 'passed').length} etapa(s) com sucesso
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{job.title}</h2>
          <p className="text-gray-600">Pipeline de Candidatos - {job.department}</p>
        </div>

        {/* Enhanced Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{job.applications.length}</div>
              <div className="text-sm text-gray-600">Total de Candidatos</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {job.applications.filter(a => a.status === 'active').length}
              </div>
              <div className="text-sm text-gray-600">Em Processo</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {job.applications.filter(a => a.status === 'approved').length}
              </div>
              <div className="text-sm text-gray-600">Aprovados</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-600">
                {job.applications.filter(a => a.status === 'rejected').length}
              </div>
              <div className="text-sm text-gray-600">Rejeitados</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{job.stages.length}</div>
              <div className="text-sm text-gray-600">Etapas Configuradas</div>
            </CardContent>
          </Card>
        </div>

        {/* Process Flow Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Workflow className="w-5 h-5 text-purple-600" />
              <span>Fluxo do Processo Seletivo</span>
            </CardTitle>
            <CardDescription>
              Visão geral das etapas e distribuição dos candidatos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Process Flow Visualization */}
              <div className="flex items-center justify-between overflow-x-auto pb-4">
                {job.stages.map((stage, index) => {
                  const stageApplications = getApplicationsForStage(stage.id);
                  const isLast = index === job.stages.length - 1;

                  return (
                    <div key={stage.id} className="flex items-center">
                      <div className="flex flex-col items-center min-w-[120px]">
                        <div className={`relative w-16 h-16 rounded-full border-4 flex items-center justify-center mb-2 ${
                          stageApplications.length > 0
                            ? 'border-purple-500 bg-purple-50'
                            : 'border-gray-300 bg-gray-50'
                        }`}>
                          <div className="text-center">
                            <div className="text-lg font-bold text-purple-600">
                              {stageApplications.length}
                            </div>
                          </div>
                          {stage.hasTest && (
                            <TestTube className="absolute -top-1 -right-1 w-5 h-5 text-blue-500 bg-white rounded-full p-1" />
                          )}
                          {stage.isRequired && (
                            <Star className="absolute -bottom-1 -right-1 w-5 h-5 text-orange-500 bg-white rounded-full p-1" />
                          )}
                        </div>
                        <div className="text-center">
                          <div className="font-medium text-sm">{stage.name}</div>
                          <div className="text-xs text-gray-500 mt-1">
                            {stageApplications.length} candidato(s)
                          </div>
                        </div>
                      </div>
                      {!isLast && (
                        <ChevronRight className="w-6 h-6 text-gray-400 mx-2 flex-shrink-0" />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Stage Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t">
                {job.stages.map((stage, index) => {
                  const stageApplications = getApplicationsForStage(stage.id);
                  const completionRate = job.applications.length > 0
                    ? ((stageApplications.length / job.applications.length) * 100).toFixed(1)
                    : '0';

                  return (
                    <div key={stage.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center text-sm font-medium">
                            {index + 1}
                          </div>
                          <h4 className="font-medium">{stage.name}</h4>
                        </div>
                        <div className="flex items-center space-x-1">
                          {stage.hasTest && <TestTube className="w-4 h-4 text-blue-500" />}
                          {stage.isRequired && <Star className="w-4 h-4 text-orange-500" />}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm text-gray-600">
                          {stage.description || 'Sem descrição'}
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500">Candidatos:</span>
                          <span className="font-medium">{stageApplications.length}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-500">% do Total:</span>
                          <span className="font-medium">{completionRate}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${completionRate}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pipeline Stages */}
        <Tabs value={selectedStage} onValueChange={setSelectedStage}>
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="all">Todas</TabsTrigger>
            {job.stages.map((stage) => (
              <TabsTrigger key={stage.id} value={stage.id} className="flex items-center space-x-2">
                <span>{stage.name}</span>
                <Badge variant="secondary" className="ml-1">
                  {getApplicationsForStage(stage.id).length}
                </Badge>
              </TabsTrigger>
            ))}
          </TabsList>

          {/* All Applications */}
          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {job.stages.map((stage) => {
                const stageApplications = getApplicationsForStage(stage.id);
                return (
                  <div key={stage.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium text-gray-900">{stage.name}</h3>
                      <Badge variant="outline">{stageApplications.length}</Badge>
                    </div>
                    <ScrollArea className="h-96">
                      <div className="space-y-3">
                        {stageApplications.map((application) => (
                          <ApplicationCard key={application.id} application={application} />
                        ))}
                        {stageApplications.length === 0 && (
                          <div className="text-center py-8 text-gray-500">
                            <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            <p className="text-sm">Nenhum candidato nesta etapa</p>
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                );
              })}
            </div>
          </TabsContent>

          {/* Individual Stage Tabs */}
          {job.stages.map((stage) => (
            <TabsContent key={stage.id} value={stage.id} className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <span>{stage.name}</span>
                    {stage.hasTest && <TestTube className="w-5 h-5 text-blue-500" />}
                    {stage.isRequired && <Star className="w-5 h-5 text-orange-500" />}
                  </CardTitle>
                  <CardDescription>
                    {stage.description || 'Nenhuma descrição disponível'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {getApplicationsForStage(stage.id).map((application) => (
                      <ApplicationCard key={application.id} application={application} />
                    ))}
                    {getApplicationsForStage(stage.id).length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <h3 className="text-lg font-medium mb-2">Nenhum candidato nesta etapa</h3>
                        <p className="text-sm">
                          Candidatos aparecerão aqui quando forem movidos para esta etapa
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* Application Details Dialog */}
      <Dialog open={isApplicationDialogOpen} onOpenChange={setIsApplicationDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes da Candidatura</DialogTitle>
            <DialogDescription>
              Informações completas do candidato e histórico no processo
            </DialogDescription>
          </DialogHeader>
          
          {selectedApplication && (
            <div className="space-y-6">
              {(() => {
                const candidate = getCandidateById(selectedApplication.candidateId);
                if (!candidate) return null;

                return (
                  <>
                    {/* Candidate Info */}
                    <div className="flex items-start space-x-4">
                      <Avatar className="w-16 h-16">
                        <AvatarImage src={candidate.name} alt={candidate.name} />
                        <AvatarFallback className="bg-purple-100 text-purple-600 text-lg">
                          {candidate.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-gray-900">{candidate.name}</h3>
                        <p className="text-gray-600">{candidate.email}</p>
                        <p className="text-gray-600">{candidate.phone}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          {getStatusBadge(selectedApplication.status)}
                          <Badge variant="outline">
                            {job.stages.find(s => s.id === selectedApplication.currentStage)?.name}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    {/* Stage History */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Histórico no Processo</h4>
                      <div className="space-y-2">
                        {selectedApplication.stageHistory.map((history, index) => {
                          const stage = job.stages.find(s => s.id === history.stageId);
                          return (
                            <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                              <div className={`w-3 h-3 rounded-full ${
                                history.result === 'passed' ? 'bg-green-500' :
                                history.result === 'failed' ? 'bg-red-500' : 'bg-yellow-500'
                              }`} />
                              <div className="flex-1">
                                <p className="font-medium">{stage?.name}</p>
                                <p className="text-sm text-gray-600">
                                  Entrada: {format(new Date(history.enteredDate), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                                  {history.exitedDate && (
                                    <> | Saída: {format(new Date(history.exitedDate), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</>
                                  )}
                                </p>
                                {history.notes && (
                                  <p className="text-sm text-gray-500 mt-1">{history.notes}</p>
                                )}
                              </div>
                              {history.result === 'passed' && <CheckCircle className="w-5 h-5 text-green-500" />}
                              {history.result === 'failed' && <XCircle className="w-5 h-5 text-red-500" />}
                              {history.result === 'pending' && <Clock className="w-5 h-5 text-yellow-500" />}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Test Results */}
                    {candidate.testResults.length > 0 && (
                      <div>
                        <h4 className="font-medium text-gray-900 mb-3">Resultados de Provas</h4>
                        <div className="space-y-2">
                          {candidate.testResults.map((result, index) => (
                            <div key={index} className="p-3 border rounded-lg">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">Prova #{index + 1}</p>
                                  <p className="text-sm text-gray-600">
                                    {format(new Date(result.startedAt), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <div className={`text-2xl font-bold ${
                                    result.passed ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {result.percentage.toFixed(0)}%
                                  </div>
                                  <div className="text-sm text-gray-600">
                                    {result.passed ? 'Aprovado' : 'Reprovado'}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex justify-end space-x-3 pt-6 border-t">
                      {selectedApplication.status === 'active' && (
                        <>
                          <Button
                            variant="outline"
                            onClick={() => rejectApplication(selectedApplication)}
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Rejeitar
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => moveToNextStage(selectedApplication)}
                          >
                            <ArrowRight className="w-4 h-4 mr-2" />
                            Próxima Etapa
                          </Button>
                          <Button
                            onClick={() => approveApplication(selectedApplication)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <UserCheck className="w-4 h-4 mr-2" />
                            Aprovar
                          </Button>
                        </>
                      )}
                    </div>
                  </>
                );
              })()}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
