import { useState, useCallback } from 'react';
import { database } from '@/lib/database';
import { Document as DocType } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Upload, 
  CheckCircle, 
  AlertTriangle, 
  FileText,
  X
} from 'lucide-react';

interface DocumentStorageProps {
  employeeId: string;
  documentType: string;
  description?: string;
  onUploadComplete?: (success: boolean, documents: DocType[]) => void;
  maxFiles?: number;
  maxSizePerFile?: number; // in KB
}

interface UploadProgress {
  fileName: string;
  progress: number;
  status: 'uploading' | 'success' | 'error';
  errorMessage?: string;
}

export default function DocumentStorage({
  employeeId,
  documentType,
  description,
  onUploadComplete,
  maxFiles = 10,
  maxSizePerFile = 10240 // 10MB
}: DocumentStorageProps) {
  const [uploadProgress, setUploadProgress] = useState<UploadProgress[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const validateFile = (file: File): { valid: boolean; error?: string } => {
    // Check file size
    if (file.size > maxSizePerFile * 1024) {
      return { 
        valid: false, 
        error: `Arquivo muito grande. Máximo ${maxSizePerFile / 1024}MB permitido.` 
      };
    }

    // Check file type
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/png',
      'image/gif',
      'text/plain'
    ];

    if (!allowedTypes.includes(file.type)) {
      return { 
        valid: false, 
        error: 'Tipo de arquivo não suportado. Use PDF, DOC, DOCX, JPG, PNG, GIF ou TXT.' 
      };
    }

    return { valid: true };
  };

  const processFile = async (file: File): Promise<DocType> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = () => {
        const result = reader.result as string;
        
        const document: Omit<DocType, 'id'> = {
          name: file.name,
          type: documentType as DocType['type'],
          uploadDate: new Date().toISOString(),
          size: `${(file.size / 1024).toFixed(0)} KB`,
          url: result, // Store as base64 for persistence
          ...(description && { description })
        };

        const success = database.addDocument(employeeId, document);
        
        if (success) {
          // Get the newly created document with ID
          const employee = database.getEmployee(employeeId);
          const newDocument = employee?.documents?.find(
            doc => doc.name === file.name && 
                   doc.uploadDate === document.uploadDate
          );
          
          if (newDocument) {
            resolve(newDocument);
          } else {
            reject(new Error('Documento criado mas não encontrado'));
          }
        } else {
          reject(new Error('Falha ao salvar documento no banco de dados'));
        }
      };

      reader.onerror = () => {
        reject(new Error('Erro ao ler arquivo'));
      };

      reader.readAsDataURL(file);
    });
  };

  const handleFiles = async (files: FileList) => {
    if (files.length > maxFiles) {
      alert(`Máximo de ${maxFiles} arquivos permitido`);
      return;
    }

    setIsUploading(true);
    const filesArray = Array.from(files);
    const initialProgress = filesArray.map(file => ({
      fileName: file.name,
      progress: 0,
      status: 'uploading' as const
    }));
    
    setUploadProgress(initialProgress);

    const uploadedDocuments: DocType[] = [];
    const results = await Promise.allSettled(
      filesArray.map(async (file, index) => {
        try {
          // Validate file
          const validation = validateFile(file);
          if (!validation.valid) {
            throw new Error(validation.error);
          }

          // Simulate upload progress
          for (let progress = 0; progress <= 100; progress += 10) {
            await new Promise(resolve => setTimeout(resolve, 50));
            setUploadProgress(prev => 
              prev.map((item, idx) => 
                idx === index ? { ...item, progress } : item
              )
            );
          }

          // Process the file
          const document = await processFile(file);
          uploadedDocuments.push(document);

          // Mark as success
          setUploadProgress(prev => 
            prev.map((item, idx) => 
              idx === index ? { ...item, status: 'success', progress: 100 } : item
            )
          );

          return { success: true, document };
        } catch (error) {
          // Mark as error
          setUploadProgress(prev => 
            prev.map((item, idx) => 
              idx === index ? { 
                ...item, 
                status: 'error', 
                errorMessage: error instanceof Error ? error.message : 'Erro desconhecido'
              } : item
            )
          );

          return { success: false, error: error instanceof Error ? error.message : 'Erro desconhecido' };
        }
      })
    );

    setIsUploading(false);

    // Check results
    const successCount = results.filter(result => 
      result.status === 'fulfilled' && result.value.success
    ).length;

    const errorCount = results.length - successCount;

    if (successCount > 0) {
      setTimeout(() => {
        setUploadProgress([]);
        onUploadComplete?.(true, uploadedDocuments);
      }, 2000);
    }

    if (errorCount > 0) {
      console.warn(`${errorCount} arquivo(s) falharam no upload`);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  }, []);

  const clearProgress = () => {
    setUploadProgress([]);
  };

  return (
    <div className="space-y-4">
      {/* Drop Zone */}
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
          dragActive 
            ? 'border-blue-400 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        <Upload className={`w-12 h-12 mx-auto mb-4 ${
          dragActive ? 'text-blue-500' : 'text-gray-400'
        }`} />
        
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          {dragActive ? 'Solte os arquivos aqui' : 'Arraste arquivos ou clique para selecionar'}
        </h3>
        
        <input
          type="file"
          multiple
          accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif,.txt"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
          className="hidden"
          id="file-upload"
          disabled={isUploading}
        />
        
        <label
          htmlFor="file-upload"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 cursor-pointer disabled:opacity-50"
        >
          Selecionar Arquivos
        </label>
        
        <p className="text-sm text-gray-500 mt-2">
          PDF, DOC, DOCX, JPG, PNG, GIF, TXT até {maxSizePerFile / 1024}MB
        </p>
      </div>

      {/* Upload Progress */}
      {uploadProgress.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-gray-900">
              Progresso do Upload
            </h4>
            {!isUploading && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearProgress}
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
          
          {uploadProgress.map((item, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center space-x-2">
                <FileText className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium flex-1">{item.fileName}</span>
                {item.status === 'success' && (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
                {item.status === 'error' && (
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                )}
              </div>
              
              {item.status !== 'error' && (
                <Progress value={item.progress} className="h-2" />
              )}
              
              {item.status === 'error' && item.errorMessage && (
                <Alert className="border-red-200">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-sm text-red-700">
                    {item.errorMessage}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Success Message */}
      {uploadProgress.length > 0 && 
       uploadProgress.every(item => item.status === 'success') && 
       !isUploading && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4" />
          <AlertDescription className="text-green-800">
            Todos os documentos foram enviados com sucesso! 
            Os arquivos foram salvos com segurança no sistema.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
