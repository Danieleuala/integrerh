import React, { useState, useEffect, useRef, useMemo } from 'react';
import { TrainingMaterial } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Play, Pause, SkipBack, SkipForward, Volume2, Maximize,
  CheckCircle, Clock, FileText, Video, Image, File,
  Download, Eye, BookOpen, Target, Award, AlertCircle,
  PlayCircle, Loader2
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';


interface TrainingProgress {
  materialId: string;
  completed: boolean;
  progress: number; // 0-100
  timeSpent: number; // in seconds
  completedAt?: string;
  lastAccessed: string;
}

interface TrainingPlayerProps {
  training: {
    id: string;
    title: string;
    description: string;
    materials: TrainingMaterial[];
    instructor?: string;
    duration?: number;
  };
  userProgress: TrainingProgress[];
  onUpdateProgress: (materialId: string, progress: Partial<TrainingProgress>) => void;
  onComplete?: () => void;
}

export function TrainingPlayer({ training, userProgress, onUpdateProgress, onComplete }: TrainingPlayerProps) {
  const [currentMaterialIndex, setCurrentMaterialIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const progressInterval = useRef<NodeJS.Timeout>();

  const currentMaterial = training.materials[currentMaterialIndex];
  const currentProgress = userProgress.find(p => p.materialId === currentMaterial?.id);

  // Calculate overall training progress
  const overallProgress = useMemo(() => {
    if (training.materials.length === 0) return 0;
    const completedMaterials = userProgress.filter(p => p.completed).length;
    return Math.round((completedMaterials / training.materials.length) * 100);
  }, [userProgress, training.materials.length]);

  // Start progress tracking
  useEffect(() => {
    if (currentMaterial && isPlaying) {
      progressInterval.current = setInterval(() => {
        const timeSpent = (currentProgress?.timeSpent || 0) + 1;
        const progress = duration > 0 ? Math.round((currentTime / duration) * 100) : 0;
        
        onUpdateProgress(currentMaterial.id, {
          progress,
          timeSpent,
          lastAccessed: new Date().toISOString(),
          completed: progress >= 90 // Mark as completed at 90%
        });
      }, 1000);
    }

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [currentMaterial, isPlaying, currentTime, duration, currentProgress, onUpdateProgress]);

  // Video event handlers
  const handleVideoLoad = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setIsLoading(false);
    }
  };

  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handlePlay = () => {
    if (videoRef.current) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handlePause = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleSeek = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleVolumeChange = (newVolume: number) => {
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement && playerRef.current) {
      playerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const goToNextMaterial = () => {
    if (currentMaterialIndex < training.materials.length - 1) {
      setCurrentMaterialIndex(currentMaterialIndex + 1);
      setIsPlaying(false);
      setCurrentTime(0);
    } else if (onComplete) {
      onComplete();
    }
  };

  const goToPreviousMaterial = () => {
    if (currentMaterialIndex > 0) {
      setCurrentMaterialIndex(currentMaterialIndex - 1);
      setIsPlaying(false);
      setCurrentTime(0);
    }
  };

  const selectMaterial = (index: number) => {
    setCurrentMaterialIndex(index);
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getMaterialIcon = (type: string) => {
    switch (type) {
      case 'video': return Video;
      case 'pdf': return FileText;
      case 'image': return Image;
      case 'quiz': return Target;
      case 'presentation': return FileText;
      default: return File;
    }
  };

  const renderMaterialPlayer = () => {
    if (!currentMaterial) return null;

    switch (currentMaterial.type) {
      case 'video':
        return (
          <div className="relative bg-black rounded-lg overflow-hidden">
            {isLoading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 z-10">
                <Loader2 className="w-8 h-8 animate-spin text-white" />
              </div>
            )}
            <video
              ref={videoRef}
              src={currentMaterial.url}
              className="w-full h-auto max-h-96"
              onLoadedData={handleVideoLoad}
              onTimeUpdate={handleVideoTimeUpdate}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onLoadStart={() => setIsLoading(true)}
              poster={`https://picsum.photos/800/450?random=${currentMaterial.id}`}
            />
            
            {/* Video Controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
              <div className="flex items-center space-x-4 text-white">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={isPlaying ? handlePause : handlePlay}
                  className="text-white hover:bg-white hover:bg-opacity-20"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </Button>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2 text-sm">
                    <span>{formatTime(currentTime)}</span>
                    <div className="flex-1 bg-white bg-opacity-30 rounded-full h-1">
                      <div
                        className="bg-white h-full rounded-full cursor-pointer"
                        style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                        onClick={(e) => {
                          const rect = e.currentTarget.parentElement!.getBoundingClientRect();
                          const clickX = e.clientX - rect.left;
                          const newTime = (clickX / rect.width) * duration;
                          handleSeek(newTime);
                        }}
                      />
                    </div>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Volume2 className="w-4 h-4" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                    className="w-16"
                  />
                </div>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleFullscreen}
                  className="text-white hover:bg-white hover:bg-opacity-20"
                >
                  <Maximize className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        );

      case 'pdf':
        return (
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <FileText className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">{currentMaterial.name}</h3>
            <p className="text-gray-600 mb-4">Documento PDF</p>
            <div className="flex justify-center space-x-3">
              <Button onClick={() => window.open(currentMaterial.url, '_blank')}>
                <Eye className="w-4 h-4 mr-2" />
                Visualizar
              </Button>
              <Button variant="outline" onClick={() => window.open(currentMaterial.url, '_blank')}>
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        );

      case 'image':
        return (
          <div className="text-center">
            <img
              src={currentMaterial.url}
              alt={currentMaterial.name}
              className="w-full h-auto max-h-96 object-contain rounded-lg"
              onLoad={() => {
                // Mark as completed when image loads
                onUpdateProgress(currentMaterial.id, {
                  progress: 100,
                  completed: true,
                  lastAccessed: new Date().toISOString(),
                  completedAt: new Date().toISOString()
                });
              }}
            />
          </div>
        );

      case 'presentation':
        return (
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <FileText className="w-16 h-16 mx-auto text-blue-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">{currentMaterial.name}</h3>
            <p className="text-gray-600 mb-4">Apresentação</p>
            <div className="flex justify-center space-x-3">
              <Button onClick={() => window.open(currentMaterial.url, '_blank')}>
                <Eye className="w-4 h-4 mr-2" />
                Visualizar
              </Button>
              <Button variant="outline" onClick={() => window.open(currentMaterial.url, '_blank')}>
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        );

      default:
        return (
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <File className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">{currentMaterial.name}</h3>
            <p className="text-gray-600 mb-4">Arquivo para download</p>
            <Button onClick={() => window.open(currentMaterial.url, '_blank')}>
              <Download className="w-4 h-4 mr-2" />
              Baixar arquivo
            </Button>
          </div>
        );
    }
  };

  return (
    <div ref={playerRef} className="space-y-6">
      {/* Training Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <BookOpen className="w-6 h-6 text-blue-600" />
                <span>{training.title}</span>
              </CardTitle>
              <p className="text-gray-600 mt-2">{training.description}</p>
              {training.instructor && (
                <p className="text-sm text-gray-500 mt-1">
                  Instrutor: {training.instructor}
                </p>
              )}
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{overallProgress}%</div>
              <div className="text-sm text-gray-600">Progresso Geral</div>
            </div>
          </div>
          
          <div className="mt-4">
            <Progress value={overallProgress} className="h-2" />
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Material Player */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  {React.createElement(getMaterialIcon(currentMaterial?.type || 'document'), {
                    className: "w-5 h-5 text-blue-600"
                  })}
                  <span>{currentMaterial?.name}</span>
                </CardTitle>
                <Badge variant={currentProgress?.completed ? "default" : "secondary"}>
                  {currentProgress?.completed ? 'Concluído' : 'Em andamento'}
                </Badge>
              </div>
              {currentMaterial?.description && (
                <p className="text-gray-600">{currentMaterial.description}</p>
              )}
            </CardHeader>
            <CardContent>
              {renderMaterialPlayer()}
            </CardContent>
          </Card>

          {/* Navigation Controls */}
          <div className="flex justify-between items-center">
            <Button
              variant="outline"
              onClick={goToPreviousMaterial}
              disabled={currentMaterialIndex === 0}
            >
              <SkipBack className="w-4 h-4 mr-2" />
              Anterior
            </Button>
            
            <div className="text-sm text-gray-600">
              Aula {currentMaterialIndex + 1} de {training.materials.length}
            </div>
            
            <Button
              onClick={goToNextMaterial}
              disabled={currentMaterialIndex === training.materials.length - 1 && overallProgress < 90}
            >
              {currentMaterialIndex === training.materials.length - 1 ? (
                <>
                  <Award className="w-4 h-4 mr-2" />
                  Concluir
                </>
              ) : (
                <>
                  Próxima
                  <SkipForward className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Material List */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Conteúdo do Curso</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {training.materials.map((material, index) => {
                const progress = userProgress.find(p => p.materialId === material.id);
                const Icon = getMaterialIcon(material.type);
                
                return (
                  <div
                    key={material.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      index === currentMaterialIndex
                        ? 'bg-blue-50 border-blue-200'
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => selectMaterial(index)}
                  >
                    <div className="flex items-start space-x-3">
                      <Icon className="w-5 h-5 text-gray-600 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium truncate">{material.name}</h4>
                        <div className="flex items-center space-x-2 mt-1">
                          {progress?.completed ? (
                            <CheckCircle className="w-4 h-4 text-green-500" />
                          ) : (
                            <Clock className="w-4 h-4 text-gray-400" />
                          )}
                          <span className="text-xs text-gray-500">
                            {material.duration ? formatTime(material.duration) : material.type.toUpperCase()}
                          </span>
                        </div>
                        {progress && progress.progress > 0 && (
                          <Progress value={progress.progress} className="h-1 mt-2" />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Progress Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Seu Progresso</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Aulas concluídas:</span>
                <span>{userProgress.filter(p => p.completed).length} / {training.materials.length}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Tempo total gasto:</span>
                <span>{formatTime(userProgress.reduce((acc, p) => acc + (p.timeSpent || 0), 0))}</span>
              </div>
              <Separator />
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600 mb-1">{overallProgress}%</div>
                <div className="text-sm text-gray-600">Progresso do curso</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
