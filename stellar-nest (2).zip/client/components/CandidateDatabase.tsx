import { useState, useMemo } from 'react';
import { EnhancedDataStore, Candidate, TestResult } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  Database, Search, Eye, Edit, MoreHorizontal, Users, Download,
  Mail, Phone, MapPin, Calendar, Star, Tag, TestTube, Award,
  ExternalLink, FileText, Filter, BarChart3, TrendingUp,
  CheckCircle, XCircle, Clock, Building2, GraduationCap,
  Briefcase, Target, MessageSquare, LinkIcon, User, Globe
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface CandidateDatabaseProps {
  onClose: () => void;
}

export default function CandidateDatabase({ onClose }: CandidateDatabaseProps) {
  const { toast } = useToast();
  
  // State management
  const [candidates, setCandidates] = useState<Candidate[]>(EnhancedDataStore.getCandidates());
  const [searchTerm, setSearchTerm] = useState('');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [skillFilter, setSkillFilter] = useState<string>('');
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  
  // Dialog states
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  const filteredCandidates = useMemo(() => {
    return candidates.filter(candidate => {
      const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           candidate.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           candidate.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesSource = sourceFilter === 'all' || candidate.source === sourceFilter;
      
      const matchesSkill = skillFilter === 'all' || !skillFilter || candidate.skills.some(skill =>
        skill.toLowerCase().includes(skillFilter.toLowerCase())
      );
      
      return matchesSearch && matchesSource && matchesSkill;
    });
  }, [candidates, searchTerm, sourceFilter, skillFilter]);

  const candidateStats = useMemo(() => {
    const total = candidates.length;
    const withTests = candidates.filter(c => c.testResults.length > 0).length;
    const withApplications = candidates.filter(c => c.applications.length > 0).length;
    const avgTestScore = candidates.reduce((acc, c) => {
      const scores = c.testResults.map(r => r.percentage);
      const avgScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
      return acc + avgScore;
    }, 0) / (withTests || 1);

    const sources = candidates.reduce((acc, c) => {
      acc[c.source] = (acc[c.source] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return { total, withTests, withApplications, avgTestScore, sources };
  }, [candidates]);

  const getAllSkills = () => {
    const skills = candidates.flatMap(c => c.skills);
    return [...new Set(skills)].sort();
  };

  const getSourceBadge = (source: Candidate['source']) => {
    const sourceMap = {
      website: { label: 'Website', color: 'bg-blue-100 text-blue-700' },
      linkedin: { label: 'LinkedIn', color: 'bg-blue-100 text-blue-700' },
      referral: { label: 'Indicação', color: 'bg-green-100 text-green-700' },
      direct: { label: 'Direto', color: 'bg-purple-100 text-purple-700' },
      other: { label: 'Outros', color: 'bg-gray-100 text-gray-700' }
    };

    const sourceInfo = sourceMap[source] || sourceMap.other;
    return <Badge className={sourceInfo.color}>{sourceInfo.label}</Badge>;
  };

  const handleViewCandidate = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setIsViewDialogOpen(true);
  };

  const exportCandidates = () => {
    const exportData = filteredCandidates.map(candidate => ({
      nome: candidate.name,
      email: candidate.email,
      telefone: candidate.phone,
      habilidades: candidate.skills.join(', '),
      experiencia: candidate.experience,
      educacao: candidate.education,
      localizacao: candidate.location,
      fonte: candidate.source,
      candidaturas: candidate.applications.length,
      provas_realizadas: candidate.testResults.length,
      nota_media_provas: candidate.testResults.length > 0 
        ? (candidate.testResults.reduce((acc, r) => acc + r.percentage, 0) / candidate.testResults.length).toFixed(1) + '%'
        : 'N/A',
      data_cadastro: format(new Date(candidate.createdDate), 'dd/MM/yyyy', { locale: ptBR })
    }));

    const csv = [
      Object.keys(exportData[0] || {}).join(','),
      ...exportData.map(row => Object.values(row).map(value => `"${value}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `candidatos_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Exportação concluída",
      description: "O arquivo CSV foi baixado com sucesso.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <Database className="w-7 h-7 mr-3 text-purple-600" />
            Banco de Candidatos
          </h2>
          <p className="text-gray-600 mt-1">
            Base permanente de todos os candidatos que interagiram com a empresa
          </p>
        </div>
        <Button onClick={exportCandidates} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Exportar para Excel
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{candidateStats.total}</div>
            <div className="text-sm text-gray-600">Total de Candidatos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{candidateStats.withApplications}</div>
            <div className="text-sm text-gray-600">Com Candidaturas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{candidateStats.withTests}</div>
            <div className="text-sm text-gray-600">Fizeram Provas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">
              {candidateStats.avgTestScore.toFixed(0)}%
            </div>
            <div className="text-sm text-gray-600">Nota Média</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar candidatos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={sourceFilter} onValueChange={setSourceFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Fonte" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Fontes</SelectItem>
                  <SelectItem value="website">Website</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="referral">Indicação</SelectItem>
                  <SelectItem value="direct">Direto</SelectItem>
                  <SelectItem value="other">Outros</SelectItem>
                </SelectContent>
              </Select>

              <Select value={skillFilter} onValueChange={setSkillFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Habilidade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Habilidades</SelectItem>
                  {getAllSkills().slice(0, 20).map(skill => (
                    <SelectItem key={skill} value={skill}>{skill}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredCandidates.length} de {candidates.length} candidato(s)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Candidates List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Candidatos</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Candidato</TableHead>
                <TableHead>Contato</TableHead>
                <TableHead>Habilidades</TableHead>
                <TableHead>Fonte</TableHead>
                <TableHead>Candidaturas</TableHead>
                <TableHead>Provas</TableHead>
                <TableHead>Última Atividade</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCandidates.map((candidate) => (
                <TableRow key={candidate.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={candidate.name} alt={candidate.name} />
                        <AvatarFallback className="bg-purple-100 text-purple-600">
                          {candidate.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium text-gray-900">{candidate.name}</div>
                        {candidate.location && (
                          <div className="text-sm text-gray-600 flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {candidate.location}
                          </div>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="text-sm flex items-center">
                        <Mail className="w-3 h-3 mr-1 text-gray-400" />
                        {candidate.email}
                      </div>
                      {candidate.phone && (
                        <div className="text-sm flex items-center">
                          <Phone className="w-3 h-3 mr-1 text-gray-400" />
                          {candidate.phone}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {candidate.skills.slice(0, 3).map((skill, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {candidate.skills.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{candidate.skills.length - 3}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{getSourceBadge(candidate.source)}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Briefcase className="w-4 h-4 text-blue-500" />
                      <span>{candidate.applications.length}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <TestTube className="w-4 h-4 text-green-500" />
                      <span>{candidate.testResults.length}</span>
                      {candidate.testResults.length > 0 && (
                        <Badge variant="outline" className="text-xs">
                          {(candidate.testResults.reduce((acc, r) => acc + r.percentage, 0) / candidate.testResults.length).toFixed(0)}%
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm text-gray-600">
                      {format(new Date(candidate.lastUpdated), 'dd/MM/yyyy', { locale: ptBR })}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleViewCandidate(candidate)}>
                          <Eye className="w-4 h-4 mr-2" />
                          Ver Perfil Completo
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Mail className="w-4 h-4 mr-2" />
                          Enviar E-mail
                        </DropdownMenuItem>
                        {candidate.linkedInUrl && (
                          <DropdownMenuItem onClick={() => window.open(candidate.linkedInUrl, '_blank')}>
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Ver LinkedIn
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Tag className="w-4 h-4 mr-2" />
                          Adicionar Tags
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredCandidates.length === 0 && (
            <div className="text-center py-12">
              <Database className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum candidato encontrado
              </h3>
              <p className="text-gray-600">
                {searchTerm || sourceFilter !== 'all' || skillFilter
                  ? 'Tente ajustar os filtros de busca'
                  : 'Os candidatos aparecerão aqui quando se candidatarem para vagas ou fizerem provas'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Candidate Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Perfil Completo do Candidato</DialogTitle>
            <DialogDescription>
              Informações detalhadas e histórico completo
            </DialogDescription>
          </DialogHeader>
          
          {selectedCandidate && (
            <Tabs defaultValue="profile" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="profile">Perfil</TabsTrigger>
                <TabsTrigger value="applications">Candidaturas ({selectedCandidate.applications.length})</TabsTrigger>
                <TabsTrigger value="tests">Provas ({selectedCandidate.testResults.length})</TabsTrigger>
                <TabsTrigger value="interviews">Entrevistas ({selectedCandidate.interviewHistory.length})</TabsTrigger>
              </TabsList>

              {/* Profile Tab */}
              <TabsContent value="profile" className="space-y-6">
                <div className="flex items-start space-x-6">
                  <Avatar className="w-20 h-20">
                    <AvatarImage src={selectedCandidate.name} alt={selectedCandidate.name} />
                    <AvatarFallback className="bg-purple-100 text-purple-600 text-xl">
                      {selectedCandidate.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-gray-900">{selectedCandidate.name}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                      <div className="flex items-center space-x-2">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <span className="text-sm">{selectedCandidate.email}</span>
                      </div>
                      {selectedCandidate.phone && (
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">{selectedCandidate.phone}</span>
                        </div>
                      )}
                      {selectedCandidate.location && (
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <span className="text-sm">{selectedCandidate.location}</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span className="text-sm">
                          Cadastro: {format(new Date(selectedCandidate.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    {getSourceBadge(selectedCandidate.source)}
                  </div>
                </div>

                <Separator />

                {/* Skills */}
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Habilidades</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedCandidate.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                    {selectedCandidate.skills.length === 0 && (
                      <p className="text-gray-500 text-sm">Nenhuma habilidade informada</p>
                    )}
                  </div>
                </div>

                {/* Experience */}
                {selectedCandidate.experience && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Experiência</h4>
                    <p className="text-gray-600">{selectedCandidate.experience}</p>
                  </div>
                )}

                {/* Education */}
                {selectedCandidate.education && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Educação</h4>
                    <p className="text-gray-600">{selectedCandidate.education}</p>
                  </div>
                )}

                {/* Links */}
                <div className="flex space-x-4">
                  {selectedCandidate.resumeUrl && (
                    <Button variant="outline" size="sm" onClick={() => window.open(selectedCandidate.resumeUrl, '_blank')}>
                      <FileText className="w-4 h-4 mr-2" />
                      Ver Currículo
                    </Button>
                  )}
                  {selectedCandidate.portfolioUrl && (
                    <Button variant="outline" size="sm" onClick={() => window.open(selectedCandidate.portfolioUrl, '_blank')}>
                      <Globe className="w-4 h-4 mr-2" />
                      Ver Portfólio
                    </Button>
                  )}
                  {selectedCandidate.linkedInUrl && (
                    <Button variant="outline" size="sm" onClick={() => window.open(selectedCandidate.linkedInUrl, '_blank')}>
                      <LinkIcon className="w-4 h-4 mr-2" />
                      Ver LinkedIn
                    </Button>
                  )}
                </div>

                {/* Tags */}
                {selectedCandidate.tags.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Tags</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedCandidate.tags.map((tag, index) => (
                        <Badge key={index} variant="outline">
                          <Tag className="w-3 h-3 mr-1" />
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </TabsContent>

              {/* Applications Tab */}
              <TabsContent value="applications">
                <div className="space-y-4">
                  {selectedCandidate.applications.length > 0 ? (
                    selectedCandidate.applications.map((application, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">Candidatura #{index + 1}</h4>
                              <p className="text-sm text-gray-600">
                                Aplicou em {format(new Date(application.appliedDate), 'dd/MM/yyyy', { locale: ptBR })}
                              </p>
                            </div>
                            <Badge className={
                              application.status === 'active' ? "bg-blue-100 text-blue-700" :
                              application.status === 'approved' ? "bg-green-100 text-green-700" :
                              application.status === 'rejected' ? "bg-red-100 text-red-700" :
                              "bg-gray-100 text-gray-700"
                            }>
                              {application.status === 'active' ? 'Ativo' :
                               application.status === 'approved' ? 'Aprovado' :
                               application.status === 'rejected' ? 'Rejeitado' : 'Desistiu'}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Briefcase className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p>Nenhuma candidatura registrada</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* Tests Tab */}
              <TabsContent value="tests">
                <div className="space-y-4">
                  {selectedCandidate.testResults.length > 0 ? (
                    selectedCandidate.testResults.map((result, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">Prova #{index + 1}</h4>
                              <p className="text-sm text-gray-600">
                                Realizada em {format(new Date(result.completedAt || result.startedAt), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                              </p>
                              <p className="text-sm text-gray-600">
                                Tempo: {result.timeSpent} minutos
                              </p>
                            </div>
                            <div className="text-right">
                              <div className={`text-2xl font-bold ${result.passed ? 'text-green-600' : 'text-red-600'}`}>
                                {result.percentage.toFixed(0)}%
                              </div>
                              <Badge className={result.passed ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                                {result.passed ? 'Aprovado' : 'Reprovado'}
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <TestTube className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p>Nenhuma prova realizada</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              {/* Interviews Tab */}
              <TabsContent value="interviews">
                <div className="space-y-4">
                  {selectedCandidate.interviewHistory.length > 0 ? (
                    selectedCandidate.interviewHistory.map((interview, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium">Entrevista #{index + 1}</h4>
                              <p className="text-sm text-gray-600">
                                {format(new Date(interview.date), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                              </p>
                              <p className="text-sm text-gray-600">{interview.type}</p>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center space-x-2">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`w-4 h-4 ${i < interview.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                                  />
                                ))}
                              </div>
                              <Badge variant="outline">{interview.recommendation}</Badge>
                            </div>
                          </div>
                          {interview.feedback && (
                            <div className="mt-3 p-3 bg-gray-50 rounded">
                              <p className="text-sm">{interview.feedback}</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p>Nenhuma entrevista registrada</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
