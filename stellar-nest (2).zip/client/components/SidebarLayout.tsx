import { useAuth, getRoleDisplayName } from '@/hooks/useAuth';
import { NotificationCenter } from '@/components/NotificationCenter';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Heart, Search, Bell, User, LogOut, Settings,
  Users, Briefcase, Award, BookOpen, MessageSquare,
  BarChart3, FileText, Megaphone, Home, ChevronDown,
  PlusCircle, Download, Upload, Eye, Edit, Trash2,
  Target, Calendar, Building2, Globe, Zap, GitBranch,
  CreditCard, Shield, DollarSign, TrendingUp, Star
} from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ReactNode, useState, useCallback, useMemo, memo } from 'react';
import { useNavigationOptimization, useSmoothScroll } from '@/hooks/useNavigationOptimization';

interface SidebarLayoutProps {
  children: ReactNode;
}

export const SidebarLayout = memo(function SidebarLayout({ children }: SidebarLayoutProps) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const { enhancedNavigate } = useNavigationOptimization();
  const { scrollToTop } = useSmoothScroll();

  const [searchTerm, setSearchTerm] = useState('');

  if (!user) return null;

  const handleLogout = useCallback(() => {
    logout();
  }, [logout]);

  const searchRoutes = useMemo(() => [
    { keywords: ['dashboard', 'inicio', 'home', 'painel'], route: '/dashboard' },
    { keywords: ['colaboradores', 'funcionarios', 'employees', 'usuarios'], route: '/employees' },
    { keywords: ['vagas', 'jobs', 'emprego', 'recrutamento'], route: '/enhanced-jobs' },
    { keywords: ['treinamentos', 'trainings', 'cursos', 'capacitacao'], route: '/trainings' },
    { keywords: ['avaliacoes', 'evaluations', 'performance'], route: '/evaluations' },
    { keywords: ['feedback', 'retorno'], route: '/feedback' },
    { keywords: ['comunicacoes', 'communications', 'mensagens'], route: '/communications' },
    { keywords: ['documentos', 'documents', 'arquivos'], route: '/documents' },
    { keywords: ['relatorios', 'reports', 'analytics'], route: '/reports' },
    { keywords: ['configuracoes', 'settings', 'config'], route: '/settings' },
    { keywords: ['perfil', 'profile', 'conta'], route: '/profile' },
    { keywords: ['empresas', 'clients', 'clientes'], route: '/companies' },
    { keywords: ['faturamento', 'billing', 'boletos'], route: '/billing' },
    { keywords: ['teste', 'test', 'prova'], route: '/test' }
  ], []);

  const handleSearch = useCallback((query: string) => {
    if (!query.trim()) return;

    const queryLower = query.toLowerCase();
    const matchedRoute = searchRoutes.find(route =>
      route.keywords.some(keyword => keyword.includes(queryLower) || queryLower.includes(keyword))
    );

    if (matchedRoute) {
      enhancedNavigate(matchedRoute.route);
      setSearchTerm('');
      scrollToTop();
    } else {
      alert(`Nenhum resultado encontrado para: "${query}"`);
    }
  }, [searchRoutes, enhancedNavigate, scrollToTop]);

  // Definindo navegação específica por papel
  const getNavigationItems = () => {
    if (user.role === 'admin') {
      // ADMINISTRADOR: Gestão de empresas clientes, faturamento, limites
      return [
        {
          title: 'Dashboard Admin',
          href: '/dashboard',
          icon: Home,
          description: 'Visão geral do sistema'
        },
        {
          title: 'Gestão de Empresas',
          href: '/company-management',
          icon: Building2,
          description: 'Cadastro e gestão de empresas clientes'
        },
        {
          title: 'Faturamento',
          href: '/billing',
          icon: DollarSign,
          description: 'Boletos e pagamentos'
        },
        {
          title: 'Limites e Quotas',
          href: '/quotas',
          icon: Shield,
          description: 'Controle de colaboradores por empresa'
        },
        {
          title: 'Relatórios Financeiros',
          href: '/financial-reports',
          icon: TrendingUp,
          description: 'Análises financeiras e receita'
        },
        {
          title: 'Configurações Sistema',
          href: '/system-settings',
          icon: Settings,
          description: 'Configurações gerais do sistema'
        },
        {
          title: 'Status das Integrações',
          href: '/integration-status',
          icon: Shield,
          description: 'Monitor de serviços e APIs'
        }
      ];
    } else if (user.role === 'hr' || user.role === 'rh_admin') {
      // RH: ACESSO COMPLETO A TODOS OS MÓDULOS OPERACIONAIS
      return [
        {
          title: 'Dashboard',
          href: '/dashboard',
          icon: Home,
          description: 'Visão geral e métricas'
        },
        {
          title: 'Colaboradores',
          href: '/employees',
          icon: Users,
          description: 'Gestão completa de funcionários'
        },
        {
          title: 'Vagas & Recrutamento',
          href: '/enhanced-jobs',
          icon: Briefcase,
          description: 'Oportunidades e processo seletivo'
        },
        {
          title: 'Banco de Talentos',
          href: '/talent-bank',
          icon: Star,
          description: 'Candidatos qualificados para futuras oportunidades'
        },
        {
          title: 'Treinamentos',
          href: '/trainings',
          icon: BookOpen,
          description: 'Cursos e capacitações'
        },
        {
          title: 'Avaliações',
          href: '/evaluations',
          icon: Award,
          description: 'Performance e competências'
        },
        {
          title: 'Feedback',
          href: '/feedback',
          icon: MessageSquare,
          description: 'Retornos e melhorias'
        },
        {
          title: 'Comunicações',
          href: '/communications',
          icon: Megaphone,
          description: 'Comunicados e newsletters'
        },
        {
          title: 'Documentos',
          href: '/documents',
          icon: FileText,
          description: 'Arquivos e contratos'
        },
        {
          title: 'Relatórios',
          href: '/reports',
          icon: BarChart3,
          description: 'Analytics e insights'
        },
        {
          title: 'Configurações',
          href: '/settings',
          icon: Settings,
          description: 'Configurações do RH'
        },
        {
          title: 'Status das Integrações',
          href: '/integration-status',
          icon: Shield,
          description: 'Monitor de serviços e APIs'
        }
      ];
    } else if (user.role === 'manager') {
      // GESTOR: Acesso limitado aos módulos de gestão
      return [
        {
          title: 'Dashboard',
          href: '/dashboard',
          icon: Home,
          description: 'Visão geral da equipe'
        },
        {
          title: 'Minha Equipe',
          href: '/employees',
          icon: Users,
          description: 'Gestão da equipe'
        },
        {
          title: 'Vagas',
          href: '/enhanced-jobs',
          icon: Briefcase,
          description: 'Oportunidades disponíveis'
        },
        {
          title: 'Avaliações',
          href: '/evaluations',
          icon: Award,
          description: 'Avaliações da equipe'
        },
        {
          title: 'Treinamentos',
          href: '/trainings',
          icon: BookOpen,
          description: 'Desenvolvimento da equipe'
        },
        {
          title: 'Relatórios',
          href: '/reports',
          icon: BarChart3,
          description: 'Performance da equipe'
        }
      ];
    } else if (user.role === 'employee') {
      // FUNCIONÁRIO: Acesso ao próprio perfil e desenvolvimento
      return [
        {
          title: 'Dashboard',
          href: '/dashboard',
          icon: Home,
          description: 'Meu painel pessoal'
        },
        {
          title: 'Meu Perfil',
          href: '/profile',
          icon: User,
          description: 'Dados pessoais'
        },
        {
          title: 'Treinamentos',
          href: '/trainings',
          icon: BookOpen,
          description: 'Meus cursos'
        },
        {
          title: 'Avaliações',
          href: '/evaluations',
          icon: Award,
          description: 'Minhas avaliações'
        },
        {
          title: 'Documentos',
          href: '/documents',
          icon: FileText,
          description: 'Meus documentos'
        },
        {
          title: 'Comunicações',
          href: '/communications',
          icon: Megaphone,
          description: 'Comunicados'
        }
      ];
    } else if (user.role === 'candidate') {
      // CANDIDATO: Acesso ao portal de candidatura
      return [
        {
          title: 'Portal',
          href: '/dashboard',
          icon: Home,
          description: 'Portal do candidato'
        },
        {
          title: 'Vagas Disponíveis',
          href: '/enhanced-jobs',
          icon: Briefcase,
          description: 'Oportunidades de emprego'
        },
        {
          title: 'Minhas Candidaturas',
          href: '/candidate-status',
          icon: Eye,
          description: 'Status das aplicações'
        },
        {
          title: 'Meu Perfil',
          href: '/profile',
          icon: User,
          description: 'Dados do candidato'
        }
      ];
    }
    return [];
  };

  const navigationItems = useMemo(() => getNavigationItems(), [user.role]);

  const isActiveRoute = useCallback((href: string) => {
    return location.pathname === href;
  }, [location.pathname]);

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'hr':
      case 'rh_admin':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'manager':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'employee':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'candidate':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getRoleDisplayText = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Administrador Sistema';
      case 'hr':
      case 'rh_admin':
        return 'Recursos Humanos';
      case 'manager':
        return 'Gestor';
      case 'employee':
        return 'Funcionário';
      case 'candidate':
        return 'Candidato';
      default:
        return role;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">Integre RH</h1>
          </div>
          
          {/* User info with role */}
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src={user.avatar} />
              <AvatarFallback className="bg-purple-100 text-purple-600">
                {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {user.name}
              </p>
              <Badge className={`text-xs mt-1 ${getRoleBadgeColor(user.role)}`}>
                {getRoleDisplayText(user.role)}
              </Badge>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch(searchTerm)}
              className="pl-10 h-9 text-sm"
            />
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = isActiveRoute(item.href);
            
            return (
              <Link
                key={item.href}
                to={item.href}
                onClick={() => scrollToTop()}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 group ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-gray-600'}`} />
                <span className="truncate">{item.title}</span>
                {isActive && (
                  <div className="w-2 h-2 bg-white rounded-full ml-auto" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="space-y-2">
            <Link
              to="/profile"
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-100 transition-colors"
            >
              <User className="w-4 h-4" />
              <span>Meu Perfil</span>
            </Link>
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="sm"
              className="w-full justify-start text-gray-600 hover:text-red-600 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4 mr-3" />
              Sair
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-gray-900">
                {navigationItems.find(item => isActiveRoute(item.href))?.title || 'Dashboard'}
              </h2>
              <Badge variant="outline" className="text-xs">
                Sistema Operacional
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <NotificationCenter />
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback className="bg-purple-100 text-purple-600 text-xs">
                        {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center">
                      <User className="w-4 h-4 mr-2" />
                      Meu Perfil
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/settings" className="flex items-center">
                      <Settings className="w-4 h-4 mr-2" />
                      Configurações
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
});
