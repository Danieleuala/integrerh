import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  FileText, Download, Calendar, Filter, Settings,
  Loader2, CheckCircle, AlertCircle, FileSpreadsheet,
  BarChart3, Users, Briefcase, BookOpen, Award, MessageSquare,
  Building2, TrendingUp, TrendingDown, Target, Clock
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ReportField {
  id: string;
  name: string;
  description: string;
  type: 'text' | 'number' | 'date' | 'status' | 'email' | 'phone';
  required?: boolean;
}

interface ReportModule {
  id: string;
  name: string;
  description: string;
  icon: any;
  fields: ReportField[];
  getData: () => any[];
}

interface ReportGeneratorProps {
  modules: ReportModule[];
  onGenerate: (config: ReportConfig) => Promise<void>;
}

interface ReportConfig {
  moduleId: string;
  format: 'pdf' | 'xlsx';
  title: string;
  description?: string;
  dateRange: {
    start?: string;
    end?: string;
  };
  filters: Record<string, any>;
  fields: string[];
  groupBy?: string;
  sortBy?: string;
  sortOrder: 'asc' | 'desc';
}

// Default report modules
export const DEFAULT_REPORT_MODULES: ReportModule[] = [
  {
    id: 'employees',
    name: 'Relatório de Colaboradores',
    description: 'Relatório completo dos colaboradores da empresa',
    icon: Users,
    fields: [
      { id: 'name', name: 'Nome', description: 'Nome completo do colaborador', type: 'text', required: true },
      { id: 'email', name: 'E-mail', description: 'Endereço de e-mail', type: 'email', required: true },
      { id: 'phone', name: 'Telefone', description: 'Número de telefone', type: 'phone' },
      { id: 'position', name: 'Cargo', description: 'Cargo atual', type: 'text', required: true },
      { id: 'department', name: 'Setor', description: 'Departamento', type: 'text', required: true },
      { id: 'joinDate', name: 'Data de Admissão', description: 'Data de entrada na empresa', type: 'date', required: true },
      { id: 'status', name: 'Situação', description: 'Status atual do colaborador', type: 'status', required: true },
      { id: 'salary', name: 'Salário', description: 'Salário atual', type: 'number' },
      { id: 'terminationDate', name: 'Data de Desligamento', description: 'Data de saída da empresa', type: 'date' },
      { id: 'terminationReason', name: 'Motivo do Desligamento', description: 'Razão do desligamento', type: 'text' }
    ],
    getData: () => [] // This will be populated by the parent component
  },
  {
    id: 'jobs',
    name: 'Relatório de Vagas',
    description: 'Relatório das vagas de emprego e processo seletivo',
    icon: Briefcase,
    fields: [
      { id: 'title', name: 'Vaga', description: 'Título da vaga', type: 'text', required: true },
      { id: 'department', name: 'Departamento', description: 'Departamento responsável', type: 'text', required: true },
      { id: 'status', name: 'Status', description: 'Status atual da vaga', type: 'status', required: true },
      { id: 'applications', name: 'Número de Candidatos', description: 'Total de candidaturas', type: 'number', required: true },
      { id: 'createdDate', name: 'Data de Abertura', description: 'Data de criação da vaga', type: 'date', required: true },
      { id: 'responsible', name: 'Responsável', description: 'Responsável pela vaga', type: 'text' },
      { id: 'salary', name: 'Faixa Salarial', description: 'Salário oferecido', type: 'text' },
      { id: 'type', name: 'Tipo de Contrato', description: 'Modalidade de contratação', type: 'text' }
    ],
    getData: () => []
  },
  {
    id: 'trainings',
    name: 'Relatório de Treinamentos',
    description: 'Relatório dos treinamentos e capacitações',
    icon: BookOpen,
    fields: [
      { id: 'title', name: 'Título', description: 'Nome do treinamento', type: 'text', required: true },
      { id: 'target', name: 'Público-alvo', description: 'Público destinado', type: 'text', required: true },
      { id: 'status', name: 'Status', description: 'Status atual', type: 'status', required: true },
      { id: 'participants', name: 'Número de Participantes', description: 'Total de participantes', type: 'number', required: true },
      { id: 'startDate', name: 'Data Início', description: 'Data de início', type: 'date' },
      { id: 'endDate', name: 'Data Fim', description: 'Data de término', type: 'date' },
      { id: 'duration', name: 'Duração (horas)', description: 'Carga horária', type: 'number' },
      { id: 'instructor', name: 'Instrutor', description: 'Responsável pelo treinamento', type: 'text' }
    ],
    getData: () => []
  },
  {
    id: 'evaluations',
    name: 'Relatório de Avaliações',
    description: 'Relatório das avaliações de desempenho',
    icon: Award,
    fields: [
      { id: 'employeeName', name: 'Nome', description: 'Nome do colaborador avaliado', type: 'text', required: true },
      { id: 'position', name: 'Cargo', description: 'Cargo do colaborador', type: 'text', required: true },
      { id: 'evaluationType', name: 'Avaliação', description: 'Tipo de avaliação', type: 'text', required: true },
      { id: 'overallScore', name: 'Nota Média', description: 'Pontuação geral', type: 'number', required: true },
      { id: 'evaluationDate', name: 'Data da Avaliação', description: 'Data da avaliação', type: 'date', required: true },
      { id: 'status', name: 'Status', description: 'Status da avaliação', type: 'status', required: true },
      { id: 'evaluator', name: 'Avaliador', description: 'Quem fez a avaliação', type: 'text' },
      { id: 'period', name: 'Período', description: 'Período avaliado', type: 'text' }
    ],
    getData: () => []
  },
  {
    id: 'terminations',
    name: 'Relatório de Desligamentos',
    description: 'Relatório dos desligamentos de colaboradores',
    icon: TrendingDown,
    fields: [
      { id: 'name', name: 'Nome', description: 'Nome do colaborador', type: 'text', required: true },
      { id: 'position', name: 'Cargo', description: 'Cargo que ocupava', type: 'text', required: true },
      { id: 'terminationDate', name: 'Data do Desligamento', description: 'Data de saída', type: 'date', required: true },
      { id: 'terminationReason', name: 'Motivo', description: 'Razão do desligamento', type: 'text', required: true },
      { id: 'responsible', name: 'Responsável', description: 'Responsável pelo processo', type: 'text', required: true },
      { id: 'type', name: 'Tipo', description: 'Pedido/Justa causa/Demissão', type: 'text', required: true },
      { id: 'department', name: 'Departamento', description: 'Setor do colaborador', type: 'text' },
      { id: 'timeInCompany', name: 'Tempo na Empresa', description: 'Período trabalhado', type: 'text' }
    ],
    getData: () => []
  }
];

export function ReportGenerator({ modules = DEFAULT_REPORT_MODULES, onGenerate }: ReportGeneratorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [selectedModule, setSelectedModule] = useState<string>('');
  const [format, setFormat] = useState<'pdf' | 'xlsx'>('pdf');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  const selectedModuleData = modules.find(m => m.id === selectedModule);

  const handleModuleChange = (moduleId: string) => {
    setSelectedModule(moduleId);
    const module = modules.find(m => m.id === moduleId);
    if (module) {
      setTitle(`${module.name} - ${format(new Date(), 'dd/MM/yyyy')}`);
      setSelectedFields(module.fields.filter(f => f.required).map(f => f.id));
    }
  };

  const handleFieldToggle = (fieldId: string) => {
    setSelectedFields(prev => 
      prev.includes(fieldId) 
        ? prev.filter(id => id !== fieldId)
        : [...prev, fieldId]
    );
  };

  const handleGenerate = async () => {
    if (!selectedModule || !title || selectedFields.length === 0) {
      setError('Preencha todos os campos obrigatórios');
      return;
    }

    // Ensure all required fields are included
    const module = modules.find(m => m.id === selectedModule);
    const requiredFields = module?.fields.filter(f => f.required).map(f => f.id) || [];
    const allSelectedFields = [...new Set([...requiredFields, ...selectedFields])];

    setIsGenerating(true);
    setError(null);

    try {
      const config: ReportConfig = {
        moduleId: selectedModule,
        format,
        title,
        description,
        dateRange: {
          start: startDate || undefined,
          end: endDate || undefined
        },
        filters: {},
        fields: allSelectedFields,
        sortBy: sortBy || allSelectedFields[0],
        sortOrder
      };

      await onGenerate(config);
      setSuccess(true);
      
      // Reset form after successful generation
      setTimeout(() => {
        setIsOpen(false);
        setSuccess(false);
        resetForm();
      }, 2000);

    } catch (err) {
      setError('Erro ao gerar relatório. Tente novamente.');
      console.error('Report generation error:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const resetForm = () => {
    setSelectedModule('');
    setFormat('pdf');
    setTitle('');
    setDescription('');
    setStartDate('');
    setEndDate('');
    setSelectedFields([]);
    setSortBy('');
    setSortOrder('asc');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700">
          <FileText className="w-4 h-4 mr-2" />
          Gerar Relatório
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-green-600" />
            <span>Gerador de Relatórios</span>
          </DialogTitle>
          <DialogDescription>
            Configure e gere relatórios personalizados em PDF ou Excel
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Module Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="module">Tipo de Relatório *</Label>
              <Select value={selectedModule} onValueChange={handleModuleChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo de relatório" />
                </SelectTrigger>
                <SelectContent>
                  {modules.map((module) => {
                    const Icon = module.icon;
                    return (
                      <SelectItem key={module.id} value={module.id}>
                        <div className="flex items-center space-x-2">
                          <Icon className="w-4 h-4" />
                          <span>{module.name}</span>
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              {selectedModuleData && (
                <p className="text-sm text-gray-600 mt-1">
                  {selectedModuleData.description}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="format">Formato *</Label>
              <Select value={format} onValueChange={(value: 'pdf' | 'xlsx') => setFormat(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">
                    <div className="flex items-center space-x-2">
                      <FileText className="w-4 h-4" />
                      <span>PDF - Documento</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="xlsx">
                    <div className="flex items-center space-x-2">
                      <FileSpreadsheet className="w-4 h-4" />
                      <span>XLSX - Planilha Excel</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Report Configuration */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Título do Relatório *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Relatório de Colaboradores - Janeiro 2024"
              />
            </div>

            <div>
              <Label htmlFor="description">Descrição (Opcional)</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrição adicional sobre o relatório..."
                rows={2}
              />
            </div>

            {/* Date Range */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">Data Inicial</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="endDate">Data Final</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Field Selection */}
          {selectedModuleData && (
            <div>
              <Label className="text-base font-medium">Campos do Relatório</Label>
              <p className="text-sm text-gray-600 mb-3">
                Selecione os campos que devem aparecer no relatório
              </p>

              {/* Required Fields Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-800">Campos Obrigatórios</span>
                </div>
                <p className="text-xs text-blue-700 mt-1">
                  Os campos marcados como obrigatórios são sempre incluídos no relatório e não podem ser desmarcados.
                </p>
              </div>

              <div className="space-y-4">
                {/* Required Fields Section */}
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                    Campos Obrigatórios
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 border border-green-200 rounded-lg p-3 bg-green-50">
                    {selectedModuleData.fields.filter(field => field.required).map((field) => (
                      <div key={field.id} className="flex items-start space-x-3">
                        <Checkbox
                          id={field.id}
                          checked={true}
                          disabled={true}
                          className="mt-0.5"
                        />
                        <div className="flex-1">
                          <label
                            htmlFor={field.id}
                            className="text-sm font-medium text-green-800 flex items-center space-x-2"
                          >
                            <span>{field.name}</span>
                            <Badge className="bg-green-600 text-white text-xs">Obrigatório</Badge>
                          </label>
                          <p className="text-xs text-green-700 mt-1">{field.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Optional Fields Section */}
                {selectedModuleData.fields.filter(field => !field.required).length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                      <Settings className="w-4 h-4 text-gray-600 mr-2" />
                      Campos Opcionais
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 border rounded-lg p-3">
                      {selectedModuleData.fields.filter(field => !field.required).map((field) => (
                        <div key={field.id} className="flex items-start space-x-3">
                          <Checkbox
                            id={field.id}
                            checked={selectedFields.includes(field.id)}
                            onCheckedChange={() => handleFieldToggle(field.id)}
                            className="mt-0.5"
                          />
                          <div className="flex-1">
                            <label
                              htmlFor={field.id}
                              className="text-sm font-medium cursor-pointer flex items-center space-x-2"
                            >
                              <span>{field.name}</span>
                              <Badge variant="outline" className="text-xs">Opcional</Badge>
                            </label>
                            <p className="text-xs text-gray-500 mt-1">{field.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Sorting Options */}
          {selectedModuleData && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="sortBy">Ordenar por</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o campo para ordenação" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedModuleData.fields
                      .filter(field => selectedFields.includes(field.id))
                      .map((field) => (
                        <SelectItem key={field.id} value={field.id}>
                          {field.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="sortOrder">Ordem</Label>
                <Select value={sortOrder} onValueChange={(value: 'asc' | 'desc') => setSortOrder(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="asc">Crescente (A-Z)</SelectItem>
                    <SelectItem value="desc">Decrescente (Z-A)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Error/Success Messages */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="w-4 h-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <AlertDescription className="text-green-800">
                Relatório gerado com sucesso! O download iniciará automaticamente.
              </AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button
              variant="outline"
              onClick={() => setIsOpen(false)}
              disabled={isGenerating}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={isGenerating || !selectedModule || !title || selectedFields.length === 0}
              className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              {isGenerating ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Download className="w-4 h-4 mr-2" />
              )}
              {isGenerating ? 'Gerando...' : `Gerar ${format.toUpperCase()}`}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
