import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/hooks/useRealAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import { SidebarLayout } from "@/components/SidebarLayout";
import ErrorBoundary from "@/components/ErrorBoundary";
import { Suspense, lazy } from "react";

// Pages
import Index from "./pages/Index";
import Login from "./pages/Login";
import LoginRH from "./pages/LoginRH";
import LoginGestor from "./pages/LoginGestor";
import LoginColaborador from "./pages/LoginColaborador";
import LoginCandidato from "./pages/LoginCandidato";
import Register from "./pages/Register";
import Payment from "./pages/Payment";
import Planos from "./pages/Planos";
import Pagamento from "./pages/Pagamento";
import PublicTest from "./pages/PublicTest";
import PublicCandidateTest from "./pages/PublicCandidateTest";
import PublicJobs from "./pages/PublicJobs";
import PublicEvaluation from "./pages/PublicEvaluation";
import CandidateApply from "./pages/CandidateApply";
import TestCandidateLink from "./pages/TestCandidateLink";
import PasswordRecovery from "./pages/PasswordRecovery";
import PasswordReset from "./pages/PasswordReset";
import Dashboard from "./pages/Dashboard";
import Employees from "./pages/Employees";
import Jobs from "./pages/Jobs";
import EnhancedJobs from "./pages/EnhancedJobs";
import Trainings from "./pages/Trainings";
import Evaluations from "./pages/Evaluations";
import Feedback from "./pages/Feedback";
import Communications from "./pages/Communications";
import Documents from "./pages/Documents";
import Demo from "./pages/Demo";
import Profile from "./pages/Profile";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Test from "./pages/Test";
import SystemTest from "./pages/SystemTest";
import CandidateStatus from "./pages/CandidateStatus";
import NotFound from "./pages/NotFound";

// New Admin Pages
import Companies from "./pages/Companies";
import Billing from "./pages/Billing";
import Quotas from "./pages/Quotas";
import IntegrationStatus from "./pages/IntegrationStatus";
import CompanyManagement from "./pages/CompanyManagement";
import CompanyJobs from "./pages/CompanyJobs";
import TalentBank from "./pages/TalentBank";
import ClientRegister from "./pages/ClientRegister";

// Configure QueryClient with optimizations
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 3,
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      refetchOnWindowFocus: false,
      refetchOnReconnect: true
    },
    mutations: {
      retry: 2,
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 10000)
    }
  }
});

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <AuthProvider>
          <ErrorBoundary>
            <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/login/rh" element={<LoginRH />} />
            <Route path="/login/gestor" element={<LoginGestor />} />
            <Route path="/login/colaborador" element={<LoginColaborador />} />
            <Route path="/login/candidato" element={<LoginCandidato />} />
            <Route path="/register" element={<Register />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/planos" element={<Planos />} />
            <Route path="/pagamento" element={<Pagamento />} />
            <Route path="/test/public/:testId" element={<PublicTest />} />
            <Route path="/candidate-test/:testId" element={<PublicCandidateTest />} />
            <Route path="/candidate-test" element={<PublicCandidateTest />} />
            <Route path="/public-jobs" element={<PublicJobs />} />
            <Route path="/company/:companySlug/jobs" element={<CompanyJobs />} />
            <Route path="/candidate-apply/:jobId" element={<CandidateApply />} />
            <Route path="/candidate-status" element={<CandidateStatus />} />
            <Route path="/evaluation/:linkId" element={<PublicEvaluation />} />
            <Route path="/test-links" element={<TestCandidateLink />} />
            <Route path="/test" element={<Test />} />
            <Route path="/client-register" element={<ClientRegister />} />
            <Route path="/recuperar-senha" element={<PasswordRecovery />} />
            <Route path="/redefinir-senha" element={<PasswordReset />} />

            {/* ADMIN ROUTES - Gestão de Empresas Clientes */}
            <Route path="/companies" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <Companies />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/billing" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <Billing />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/quotas" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <Quotas />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/financial-reports" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <Reports />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/system-settings" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <Settings />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/integration-status" element={
              <ProtectedRoute requiredRoles={['admin', 'hr', 'rh_admin']}>
                <SidebarLayout>
                  <IntegrationStatus />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/company-management" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <CompanyManagement />
                </SidebarLayout>
              </ProtectedRoute>
            } />

            {/* SHARED ROUTES - Dashboard (todos podem acessar) */}
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <SidebarLayout>
                  <Dashboard />
                </SidebarLayout>
              </ProtectedRoute>
            } />

            {/* RH ROUTES - Acesso completo a todos os módulos operacionais */}
            <Route path="/employees" element={
              <ProtectedRoute requiredRoles={['hr', 'manager']}>
                <SidebarLayout>
                  <Employees />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/jobs" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'candidate']}>
                <SidebarLayout>
                  <Jobs />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/enhanced-jobs" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'candidate']}>
                <SidebarLayout>
                  <EnhancedJobs />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/trainings" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'employee']}>
                <SidebarLayout>
                  <Trainings />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/evaluations" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'employee']}>
                <SidebarLayout>
                  <Evaluations />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/feedback" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'employee']}>
                <SidebarLayout>
                  <Feedback />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/communications" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'employee', 'candidate']}>
                <SidebarLayout>
                  <Communications />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/documents" element={
              <ProtectedRoute requiredRoles={['hr', 'manager', 'employee']}>
                <SidebarLayout>
                  <Documents />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/talent-bank" element={
              <ProtectedRoute requiredRoles={['hr', 'manager']}>
                <SidebarLayout>
                  <TalentBank />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/reports" element={
              <ProtectedRoute requiredRoles={['hr', 'manager']}>
                <SidebarLayout>
                  <Reports />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/settings" element={
              <ProtectedRoute requiredRoles={['hr']}>
                <SidebarLayout>
                  <Settings />
                </SidebarLayout>
              </ProtectedRoute>
            } />

            {/* SHARED ROUTES - Profile (todos os usuários logados) */}
            <Route path="/profile" element={
              <ProtectedRoute>
                <SidebarLayout>
                  <Profile />
                </SidebarLayout>
              </ProtectedRoute>
            } />

            {/* SYSTEM ROUTES */}
            <Route path="/demo" element={
              <ProtectedRoute>
                <SidebarLayout>
                  <Demo />
                </SidebarLayout>
              </ProtectedRoute>
            } />
            <Route path="/system-test" element={
              <ProtectedRoute requiredRoles={['admin']}>
                <SidebarLayout>
                  <SystemTest />
                </SidebarLayout>
              </ProtectedRoute>
            } />

            {/* Redirect for authenticated users trying to access root */}
            <Route path="/home" element={<Navigate to="/dashboard" replace />} />

            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
            </BrowserRouter>
          </ErrorBoundary>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

createRoot(document.getElementById("root")!).render(<App />);
