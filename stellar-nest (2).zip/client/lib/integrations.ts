// Integre RH - Sistema de Integrações Reais
// Este arquivo gerencia todas as integrações externas da plataforma

import { supabase, supabaseConfig } from './supabase';

// =============================================================================
// CONFIGURAÇÕES DE INTEGRAÇÃO
// =============================================================================

export interface IntegrationConfig {
  name: string;
  enabled: boolean;
  configured: boolean;
  status: 'active' | 'inactive' | 'error' | 'testing';
  lastChecked?: Date;
  error?: string;
}

export interface PlatformStatus {
  database: IntegrationConfig;
  email: IntegrationConfig;
  storage: IntegrationConfig;
  whatsapp: IntegrationConfig;
  analytics: IntegrationConfig;
  realtime: IntegrationConfig;
}

// =============================================================================
// EMAIL INTEGRATION (Resend)
// =============================================================================

export interface EmailService {
  sendWelcomeEmail: (to: string, name: string) => Promise<{ success: boolean; error?: string }>;
  sendJobApplicationNotification: (to: string, jobTitle: string, candidateName: string) => Promise<{ success: boolean; error?: string }>;
  sendTrainingReminder: (to: string, trainingTitle: string, startDate: string) => Promise<{ success: boolean; error?: string }>;
  sendEvaluationNotification: (to: string, evaluationType: string, dueDate: string) => Promise<{ success: boolean; error?: string }>;
  sendDocumentApprovalNotification: (to: string, documentName: string) => Promise<{ success: boolean; error?: string }>;
}

class ResendEmailService implements EmailService {
  private apiKey: string;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.apiKey = import.meta.env.VITE_RESEND_API_KEY || '';
    this.fromEmail = import.meta.env.VITE_FROM_EMAIL || 'noreply@integrerh.com';
    this.fromName = import.meta.env.VITE_FROM_NAME || 'Integre RH';
  }

  private async sendEmail(to: string, subject: string, html: string): Promise<{ success: boolean; error?: string }> {
    if (!this.apiKey) {
      console.warn('Email service not configured - missing API key');
      return { success: false, error: 'Email service not configured' };
    }

    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: `${this.fromName} <${this.fromEmail}>`,
          to: [to],
          subject,
          html,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        return { success: false, error: `Email failed: ${error}` };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: `Email error: ${error}` };
    }
  }

  async sendWelcomeEmail(to: string, name: string): Promise<{ success: boolean; error?: string }> {
    const subject = '🎉 Bem-vindo(a) ao Integre RH!';
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #7c3aed;">Bem-vindo(a), ${name}!</h1>
        <p>Sua conta foi criada com sucesso no Integre RH.</p>
        <p>Agora você pode acessar todos os recursos da plataforma:</p>
        <ul>
          <li>📊 Dashboard personalizado</li>
          <li>👥 Gestão de colaboradores</li>
          <li>🎯 Avaliações de performance</li>
          <li>📚 Treinamentos e capacitações</li>
          <li>📄 Documentos e relatórios</li>
        </ul>
        <p><a href="${import.meta.env.VITE_APP_URL}/dashboard" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Acessar Plataforma</a></p>
        <hr>
        <p style="color: #666; font-size: 12px;">Integre RH - Sua solução completa de gestão de pessoas</p>
      </div>
    `;
    return this.sendEmail(to, subject, html);
  }

  async sendJobApplicationNotification(to: string, jobTitle: string, candidateName: string): Promise<{ success: boolean; error?: string }> {
    const subject = `Nova candidatura: ${jobTitle}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #7c3aed;">Nova Candidatura Recebida</h1>
        <p><strong>Vaga:</strong> ${jobTitle}</p>
        <p><strong>Candidato:</strong> ${candidateName}</p>
        <p>Uma nova candidatura foi recebida e está aguardando análise.</p>
        <p><a href="${import.meta.env.VITE_APP_URL}/enhanced-jobs" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Ver Candidaturas</a></p>
      </div>
    `;
    return this.sendEmail(to, subject, html);
  }

  async sendTrainingReminder(to: string, trainingTitle: string, startDate: string): Promise<{ success: boolean; error?: string }> {
    const subject = `Lembrete: Treinamento ${trainingTitle}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #7c3aed;">Lembrete de Treinamento</h1>
        <p><strong>Treinamento:</strong> ${trainingTitle}</p>
        <p><strong>Data de Início:</strong> ${startDate}</p>
        <p>Não se esqueça de participar do seu treinamento agendado.</p>
        <p><a href="${import.meta.env.VITE_APP_URL}/trainings" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Ver Treinamentos</a></p>
      </div>
    `;
    return this.sendEmail(to, subject, html);
  }

  async sendEvaluationNotification(to: string, evaluationType: string, dueDate: string): Promise<{ success: boolean; error?: string }> {
    const subject = `Nova avaliação disponível: ${evaluationType}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #7c3aed;">Nova Avaliação Disponível</h1>
        <p><strong>Tipo:</strong> ${evaluationType}</p>
        <p><strong>Prazo:</strong> ${dueDate}</p>
        <p>Uma nova avaliação está disponível para você.</p>
        <p><a href="${import.meta.env.VITE_APP_URL}/evaluations" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Fazer Avaliação</a></p>
      </div>
    `;
    return this.sendEmail(to, subject, html);
  }

  async sendDocumentApprovalNotification(to: string, documentName: string): Promise<{ success: boolean; error?: string }> {
    const subject = `Documento aprovado: ${documentName}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #7c3aed;">Documento Aprovado</h1>
        <p><strong>Documento:</strong> ${documentName}</p>
        <p>Seu documento foi aprovado e está disponível para download.</p>
        <p><a href="${import.meta.env.VITE_APP_URL}/documents" style="background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Ver Documentos</a></p>
      </div>
    `;
    return this.sendEmail(to, subject, html);
  }
}

// =============================================================================
// WHATSAPP INTEGRATION (Meta Business API)
// =============================================================================

export interface WhatsAppService {
  sendMessage: (to: string, message: string) => Promise<{ success: boolean; error?: string }>;
  sendTemplate: (to: string, templateName: string, parameters: string[]) => Promise<{ success: boolean; error?: string }>;
  verifyWebhook: (token: string) => boolean;
}

class MetaWhatsAppService implements WhatsAppService {
  private phoneNumberId: string;
  private accessToken: string;
  private verifyToken: string;

  constructor() {
    this.phoneNumberId = import.meta.env.VITE_WHATSAPP_PHONE_NUMBER_ID || '';
    this.accessToken = import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN || '';
    this.verifyToken = import.meta.env.VITE_WHATSAPP_VERIFY_TOKEN || '';
  }

  async sendMessage(to: string, message: string): Promise<{ success: boolean; error?: string }> {
    if (!this.phoneNumberId || !this.accessToken) {
      console.warn('WhatsApp service not configured');
      return { success: false, error: 'WhatsApp service not configured' };
    }

    try {
      const response = await fetch(`https://graph.facebook.com/v17.0/${this.phoneNumberId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: to.replace(/\D/g, ''), // Remove non-digit characters
          type: 'text',
          text: { body: message },
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        return { success: false, error: `WhatsApp failed: ${error}` };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: `WhatsApp error: ${error}` };
    }
  }

  async sendTemplate(to: string, templateName: string, parameters: string[]): Promise<{ success: boolean; error?: string }> {
    if (!this.phoneNumberId || !this.accessToken) {
      return { success: false, error: 'WhatsApp service not configured' };
    }

    try {
      const response = await fetch(`https://graph.facebook.com/v17.0/${this.phoneNumberId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: to.replace(/\D/g, ''),
          type: 'template',
          template: {
            name: templateName,
            language: { code: 'pt_BR' },
            components: parameters.length > 0 ? [{
              type: 'body',
              parameters: parameters.map(param => ({ type: 'text', text: param }))
            }] : undefined
          },
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        return { success: false, error: `WhatsApp template failed: ${error}` };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: `WhatsApp template error: ${error}` };
    }
  }

  verifyWebhook(token: string): boolean {
    return token === this.verifyToken;
  }
}

// =============================================================================
// ANALYTICS INTEGRATION (Google Analytics 4)
// =============================================================================

export interface AnalyticsService {
  trackEvent: (event: string, parameters?: Record<string, any>) => void;
  trackPageView: (page: string) => void;
  trackUserAction: (action: string, module: string, details?: Record<string, any>) => void;
}

class GoogleAnalyticsService implements AnalyticsService {
  private measurementId: string;

  constructor() {
    this.measurementId = import.meta.env.VITE_GOOGLE_ANALYTICS_ID || '';
    
    if (this.measurementId && typeof window !== 'undefined') {
      this.initializeGA();
    }
  }

  private initializeGA() {
    // Load Google Analytics script
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${this.measurementId}`;
    document.head.appendChild(script);

    // Initialize gtag
    (window as any).dataLayer = (window as any).dataLayer || [];
    function gtag(...args: any[]) {
      (window as any).dataLayer.push(args);
    }
    (window as any).gtag = gtag;

    gtag('js', new Date());
    gtag('config', this.measurementId);
  }

  trackEvent(event: string, parameters?: Record<string, any>) {
    if (!this.measurementId || typeof window === 'undefined') return;
    
    (window as any).gtag?.('event', event, parameters);
  }

  trackPageView(page: string) {
    this.trackEvent('page_view', {
      page_title: document.title,
      page_location: window.location.href,
      page_path: page,
    });
  }

  trackUserAction(action: string, module: string, details?: Record<string, any>) {
    this.trackEvent('user_action', {
      action,
      module,
      ...details,
    });
  }
}

// =============================================================================
// NOTIFICATION SERVICE (Real-time)
// =============================================================================

export interface NotificationService {
  subscribe: (userId: string, callback: (notification: any) => void) => void;
  unsubscribe: () => void;
  sendNotification: (userId: string, notification: any) => Promise<{ success: boolean; error?: string }>;
}

class RealtimeNotificationService implements NotificationService {
  private subscription: any = null;

  subscribe(userId: string, callback: (notification: any) => void) {
    if (this.subscription) {
      this.unsubscribe();
    }

    this.subscription = supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`,
        },
        callback
      )
      .subscribe();
  }

  unsubscribe() {
    if (this.subscription) {
      supabase.removeChannel(this.subscription);
      this.subscription = null;
    }
  }

  async sendNotification(userId: string, notification: any): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          user_id: userId,
          ...notification,
        });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: `Notification error: ${error}` };
    }
  }
}

// =============================================================================
// INTEGRATION MANAGER
// =============================================================================

export class IntegrationManager {
  public email: EmailService;
  public whatsapp: WhatsAppService;
  public analytics: AnalyticsService;
  public notifications: NotificationService;

  constructor() {
    this.email = new ResendEmailService();
    this.whatsapp = new MetaWhatsAppService();
    this.analytics = new GoogleAnalyticsService();
    this.notifications = new RealtimeNotificationService();
  }

  async checkPlatformStatus(): Promise<PlatformStatus> {
    const status: PlatformStatus = {
      database: {
        name: 'Supabase Database',
        enabled: Boolean(import.meta.env.VITE_USE_REAL_DATABASE),
        configured: supabaseConfig.isConfigured && !supabaseConfig.isDummy,
        status: 'inactive',
      },
      email: {
        name: 'Resend Email Service',
        enabled: Boolean(import.meta.env.VITE_ENABLE_EMAIL_NOTIFICATIONS),
        configured: Boolean(import.meta.env.VITE_RESEND_API_KEY),
        status: 'inactive',
      },
      storage: {
        name: 'Supabase Storage',
        enabled: Boolean(import.meta.env.VITE_ENABLE_FILE_UPLOAD),
        configured: supabaseConfig.isConfigured && !supabaseConfig.isDummy,
        status: 'inactive',
      },
      whatsapp: {
        name: 'WhatsApp Business API',
        enabled: Boolean(import.meta.env.VITE_ENABLE_WHATSAPP_NOTIFICATIONS),
        configured: Boolean(
          import.meta.env.VITE_WHATSAPP_PHONE_NUMBER_ID &&
          import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN
        ),
        status: 'inactive',
      },
      analytics: {
        name: 'Google Analytics',
        enabled: true,
        configured: Boolean(import.meta.env.VITE_GOOGLE_ANALYTICS_ID),
        status: 'inactive',
      },
      realtime: {
        name: 'Real-time Updates',
        enabled: Boolean(import.meta.env.VITE_ENABLE_REAL_TIME_UPDATES),
        configured: supabaseConfig.isConfigured && !supabaseConfig.isDummy,
        status: 'inactive',
      },
    };

    // Test database connection
    if (status.database.configured) {
      try {
        const { connected } = await supabase.from('employees').select('id').limit(1);
        status.database.status = connected ? 'active' : 'error';
      } catch (error) {
        status.database.status = 'error';
        status.database.error = 'Connection failed';
      }
    }

    // Test email service
    if (status.email.configured) {
      status.email.status = 'active'; // Assume working if configured
    }

    // Test WhatsApp service
    if (status.whatsapp.configured) {
      status.whatsapp.status = 'active'; // Assume working if configured
    }

    // Test analytics
    if (status.analytics.configured) {
      status.analytics.status = 'active';
    }

    // Test real-time
    if (status.realtime.configured) {
      status.realtime.status = 'active';
    }

    return status;
  }

  async initializeAllServices(): Promise<void> {
    console.log('🚀 Initializing Integre RH integrations...');
    
    const status = await this.checkPlatformStatus();
    
    Object.entries(status).forEach(([service, config]) => {
      if (config.configured && config.enabled) {
        console.log(`✅ ${config.name} - Active`);
      } else if (!config.configured) {
        console.log(`⚠️ ${config.name} - Not configured`);
      } else {
        console.log(`⏸️ ${config.name} - Disabled`);
      }
    });

    // Track initialization
    this.analytics.trackEvent('platform_initialized', {
      database_status: status.database.status,
      email_status: status.email.status,
      whatsapp_status: status.whatsapp.status,
    });
  }
}

// Export singleton instance
export const integrationManager = new IntegrationManager();

// Initialize on module load
if (typeof window !== 'undefined') {
  integrationManager.initializeAllServices();
}
