import { Employee, Job, Training, Evaluation, Feedback, Announcement, Document } from './mockData';

// Message interface for internal communications
interface Message {
  id: string;
  fromId: string;
  toId: string[];
  subject: string;
  content: string;
  date: string;
  isRead: boolean;
  attachments?: string[];
  type: 'message' | 'announcement' | 'notification';
  priority: 'low' | 'medium' | 'high';
}

// Event system for cross-module communication
type EventType =
  | 'employee_created' | 'employee_updated' | 'employee_deleted'
  | 'job_created' | 'job_updated' | 'job_deleted' | 'job_application_created'
  | 'training_created' | 'training_updated' | 'training_enrollment'
  | 'evaluation_created' | 'evaluation_updated' | 'evaluation_completed'
  | 'feedback_created' | 'feedback_updated'
  | 'announcement_created' | 'announcement_updated'
  | 'document_uploaded' | 'document_deleted'
  | 'message_sent' | 'message_received';

interface DatabaseEvent {
  type: EventType;
  data: any;
  timestamp: string;
  userId?: string;
  targetId?: string;
  metadata?: Record<string, any>;
}

interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: string;
  userId: string;
  read: boolean;
  relatedModule: string;
  relatedId?: string;
  actionUrl?: string;
}

interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  module: string;
  description: string;
  timestamp: string;
  relatedData?: any;
}

// Enhanced Database with relationships and events
export class IntegratedDatabase {
  private static instance: IntegratedDatabase;
  private data: Record<string, any> = {};
  private eventListeners: Record<EventType, Function[]> = {} as any;
  private notifications: Notification[] = [];
  private activityLog: ActivityLog[] = [];

  static getInstance(): IntegratedDatabase {
    if (!IntegratedDatabase.instance) {
      IntegratedDatabase.instance = new IntegratedDatabase();
      IntegratedDatabase.instance.initializeDatabase();
    }
    return IntegratedDatabase.instance;
  }

  private initializeDatabase(): void {
    // Initialize event listeners for all event types
    const eventTypes: EventType[] = [
      'employee_created', 'employee_updated', 'employee_deleted',
      'job_created', 'job_updated', 'job_deleted', 'job_application_created',
      'training_created', 'training_updated', 'training_enrollment',
      'evaluation_created', 'evaluation_updated', 'evaluation_completed',
      'feedback_created', 'feedback_updated',
      'announcement_created', 'announcement_updated',
      'document_uploaded', 'document_deleted',
      'message_sent', 'message_received'
    ];

    eventTypes.forEach(eventType => {
      this.eventListeners[eventType] = [];
    });

    // Load existing data
    this.loadFromStorage();

    // Set up cross-module integrations
    this.setupCrossModuleIntegrations();
  }

  private setupCrossModuleIntegrations(): void {
    // When an employee is created, create welcome notifications
    this.addEventListener('employee_created', (employee: Employee) => {
      this.createNotification({
        type: 'success',
        title: 'Novo Colaborador',
        message: `${employee.name} foi adicionado à equipe!`,
        userId: 'all', // Broadcast to all HR admins
        relatedModule: 'employees',
        relatedId: employee.id
      });

      this.logActivity({
        userId: 'system',
        action: 'employee_onboard',
        module: 'employees',
        description: `Novo colaborador ${employee.name} adicionado ao sistema`,
        relatedData: { employeeId: employee.id, department: employee.department }
      });
    });

    // When a job application is created, notify relevant people
    this.addEventListener('job_application_created', (data: { job: Job, application: any }) => {
      this.createNotification({
        type: 'info',
        title: 'Nova Candidatura',
        message: `${data.application.candidateName} se candidatou para ${data.job.title}`,
        userId: 'hr_admin',
        relatedModule: 'jobs',
        relatedId: data.job.id,
        actionUrl: `/jobs?jobId=${data.job.id}`
      });

      this.logActivity({
        userId: data.application.candidateEmail,
        action: 'job_application',
        module: 'jobs',
        description: `Candidatura para vaga ${data.job.title}`,
        relatedData: { jobId: data.job.id, applicationId: data.application.id }
      });
    });

    // When an evaluation is completed, update employee performance data
    this.addEventListener('evaluation_completed', (evaluation: Evaluation) => {
      const employee = this.getEmployee(evaluation.employeeId);
      if (employee) {
        this.createNotification({
          type: 'success',
          title: 'Avaliação Concluída',
          message: `Avaliação de ${employee.name} foi finalizada com nota ${evaluation.overallScore.toFixed(1)}`,
          userId: evaluation.evaluatorId,
          relatedModule: 'evaluations',
          relatedId: evaluation.id,
          actionUrl: `/evaluations?employeeId=${employee.id}`
        });

        // Notify the employee about their evaluation
        this.createNotification({
          type: 'info',
          title: 'Sua Avaliação',
          message: `Sua avalia��ão de performance foi concluída. Nota: ${evaluation.overallScore.toFixed(1)}/10`,
          userId: evaluation.employeeId,
          relatedModule: 'evaluations',
          relatedId: evaluation.id,
          actionUrl: `/evaluations`
        });

        this.logActivity({
          userId: evaluation.evaluatorId,
          action: 'evaluation_complete',
          module: 'evaluations',
          description: `Avaliação de ${employee.name} concluída`,
          relatedData: { evaluationId: evaluation.id, score: evaluation.overallScore }
        });
      }
    });

    // When feedback is created, create notifications
    this.addEventListener('feedback_created', (feedback: Feedback) => {
      const fromEmployee = this.getEmployee(feedback.fromId);
      const toEmployee = this.getEmployee(feedback.toId);
      
      if (fromEmployee && toEmployee) {
        this.createNotification({
          type: 'info',
          title: 'Novo Feedback',
          message: `Você recebeu um feedback ${feedback.type} de ${fromEmployee.name}`,
          userId: feedback.toId,
          relatedModule: 'feedback',
          relatedId: feedback.id,
          actionUrl: `/feedback`
        });

        this.logActivity({
          userId: feedback.fromId,
          action: 'feedback_sent',
          module: 'feedback',
          description: `Feedback ${feedback.type} enviado para ${toEmployee.name}`,
          relatedData: { feedbackId: feedback.id, type: feedback.type }
        });
      }
    });

    // When training enrollment happens
    this.addEventListener('training_enrollment', (data: { trainingId: string, userId: string }) => {
      const training = this.getTraining(data.trainingId);
      const employee = this.getEmployee(data.userId);
      
      if (training && employee) {
        this.createNotification({
          type: 'success',
          title: 'Inscrição em Treinamento',
          message: `Você foi inscrito no treinamento: ${training.title}`,
          userId: data.userId,
          relatedModule: 'trainings',
          relatedId: training.id,
          actionUrl: `/trainings?trainingId=${training.id}`
        });

        this.logActivity({
          userId: data.userId,
          action: 'training_enrollment',
          module: 'trainings',
          description: `Inscrição no treinamento ${training.title}`,
          relatedData: { trainingId: training.id }
        });
      }
    });

    // When a document is uploaded
    this.addEventListener('document_uploaded', (data: { employeeId: string, document: Document }) => {
      const employee = this.getEmployee(data.employeeId);
      if (employee) {
        this.createNotification({
          type: 'info',
          title: 'Documento Enviado',
          message: `Documento ${data.document.name} foi enviado com sucesso`,
          userId: data.employeeId,
          relatedModule: 'documents',
          relatedId: data.document.id
        });

        this.logActivity({
          userId: data.employeeId,
          action: 'document_upload',
          module: 'documents',
          description: `Upload do documento ${data.document.name}`,
          relatedData: { documentId: data.document.id, type: data.document.type }
        });
      }
    });

    // When announcement is created
    this.addEventListener('announcement_created', (announcement: Announcement) => {
      this.createNotification({
        type: announcement.priority === 'high' ? 'warning' : 'info',
        title: 'Novo Comunicado',
        message: announcement.title,
        userId: 'all',
        relatedModule: 'communications',
        relatedId: announcement.id,
        actionUrl: `/communications`
      });

      this.logActivity({
        userId: 'hr_admin',
        action: 'announcement_created',
        module: 'communications',
        description: `Comunicado criado: ${announcement.title}`,
        relatedData: { announcementId: announcement.id, priority: announcement.priority }
      });
    });
  }

  // Event management
  addEventListener(eventType: EventType, callback: Function): void {
    if (!this.eventListeners[eventType]) {
      this.eventListeners[eventType] = [];
    }
    this.eventListeners[eventType].push(callback);
  }

  removeEventListener(eventType: EventType, callback: Function): void {
    if (this.eventListeners[eventType]) {
      const index = this.eventListeners[eventType].indexOf(callback);
      if (index > -1) {
        this.eventListeners[eventType].splice(index, 1);
      }
    }
  }

  private emitEvent(eventType: EventType, data: any, userId?: string, targetId?: string, metadata?: Record<string, any>): void {
    const event: DatabaseEvent = {
      type: eventType,
      data,
      timestamp: new Date().toISOString(),
      userId,
      targetId,
      metadata
    };

    // Store event for audit
    this.storeEvent(event);

    // Notify listeners
    if (this.eventListeners[eventType]) {
      this.eventListeners[eventType].forEach(callback => {
        try {
          callback(data, event);
        } catch (error) {
          console.error('Error in event listener:', error);
        }
      });
    }
  }

  private storeEvent(event: DatabaseEvent): void {
    const events = this.get('events', []);
    events.push(event);
    
    // Keep only last 1000 events
    if (events.length > 1000) {
      events.splice(0, events.length - 1000);
    }
    
    this.set('events', events);
  }

  // Notification management
  createNotification(notification: Omit<Notification, 'id' | 'timestamp' | 'read'>): void {
    const newNotification: Notification = {
      ...notification,
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      read: false
    };

    this.notifications.push(newNotification);
    this.set('notifications', this.notifications);
  }

  getNotifications(userId: string): Notification[] {
    return this.notifications.filter(n => n.userId === userId || n.userId === 'all').sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  markNotificationAsRead(notificationId: string): void {
    const notification = this.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.read = true;
      this.set('notifications', this.notifications);
    }
  }

  // Activity logging
  logActivity(activity: Omit<ActivityLog, 'id' | 'timestamp'>): void {
    const newActivity: ActivityLog = {
      ...activity,
      id: `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString()
    };

    this.activityLog.push(newActivity);
    
    // Keep only last 500 activities
    if (this.activityLog.length > 500) {
      this.activityLog.splice(0, this.activityLog.length - 500);
    }
    
    this.set('activityLog', this.activityLog);
  }

  getActivityLog(userId?: string, module?: string, limit: number = 50): ActivityLog[] {
    let activities = [...this.activityLog];
    
    if (userId) {
      activities = activities.filter(a => a.userId === userId);
    }
    
    if (module) {
      activities = activities.filter(a => a.module === module);
    }
    
    return activities
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  // Data management with events
  set(key: string, value: any): void {
    this.data[key] = value;
    this.saveToStorage();
  }

  get(key: string, defaultValue: any = null): any {
    if (this.data[key] !== undefined) {
      return this.data[key];
    }
    return defaultValue;
  }

  // Employee operations with events
  addEmployee(employee: Omit<Employee, 'id'>): Employee {
    const newEmployee: Employee = {
      ...employee,
      id: `emp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      history: Array.isArray(employee.history) ? employee.history : []
    };

    const employees = this.get('employees', []);
    employees.push(newEmployee);
    this.set('employees', employees);

    this.emitEvent('employee_created', newEmployee);
    return newEmployee;
  }

  updateEmployee(id: string, data: Partial<Employee>): boolean {
    const employees = this.get('employees', []);
    const index = employees.findIndex((emp: Employee) => emp.id === id);
    
    if (index !== -1) {
      const oldEmployee = { ...employees[index] };
      employees[index] = { ...employees[index], ...data };
      this.set('employees', employees);
      
      this.emitEvent('employee_updated', { old: oldEmployee, new: employees[index] });
      return true;
    }
    return false;
  }

  getEmployee(id: string): Employee | undefined {
    const employees = this.get('employees', []);
    const employee = employees.find((emp: Employee) => emp.id === id);
    if (employee && !Array.isArray(employee.history)) {
      employee.history = [];
    }
    return employee;
  }

  getEmployees(): Employee[] {
    const employees = this.get('employees', []);
    // Ensure all employees have history array initialized
    return employees.map((employee: Employee) => ({
      ...employee,
      history: Array.isArray(employee.history) ? employee.history : []
    }));
  }

  // Job operations with events
  addJob(job: Omit<Job, 'id'>): Job {
    const newJob: Job = {
      ...job,
      id: `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    const jobs = this.get('jobs', []);
    jobs.push(newJob);
    this.set('jobs', jobs);

    this.emitEvent('job_created', newJob);
    return newJob;
  }

  getJob(id: string): Job | undefined {
    const jobs = this.get('jobs', []);
    return jobs.find((job: Job) => job.id === id);
  }

  getJobs(): Job[] {
    return this.get('jobs', []);
  }

  // Training operations with events
  addTraining(training: Omit<Training, 'id'>): Training {
    const newTraining: Training = {
      ...training,
      id: `training_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    const trainings = this.get('trainings', []);
    trainings.push(newTraining);
    this.set('trainings', trainings);

    this.emitEvent('training_created', newTraining);
    return newTraining;
  }

  enrollInTraining(trainingId: string, userId: string): boolean {
    const trainings = this.get('trainings', []);
    const training = trainings.find((t: Training) => t.id === trainingId);

    if (training && !training.participants.includes(userId)) {
      training.participants.push(userId);
      this.set('trainings', trainings);

      this.emitEvent('training_enrollment', { trainingId, userId });
      return true;
    }
    return false;
  }

  updateTraining(trainingId: string, updates: Partial<Training>): boolean {
    const trainings = this.get('trainings', []);
    const trainingIndex = trainings.findIndex((t: Training) => t.id === trainingId);

    if (trainingIndex !== -1) {
      trainings[trainingIndex] = { ...trainings[trainingIndex], ...updates };
      this.set('trainings', trainings);

      this.emitEvent('training_updated', { trainingId, updates });
      return true;
    }
    return false;
  }

  getTraining(id: string): Training | undefined {
    const trainings = this.get('trainings', []);
    return trainings.find((training: Training) => training.id === id);
  }

  getTrainings(): Training[] {
    return this.get('trainings', []);
  }

  // Evaluation operations with events
  addEvaluation(evaluation: Omit<Evaluation, 'id'>): Evaluation {
    const newEvaluation: Evaluation = {
      ...evaluation,
      id: `eval_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    const evaluations = this.get('evaluations', []);
    evaluations.push(newEvaluation);
    this.set('evaluations', evaluations);

    this.emitEvent('evaluation_created', newEvaluation);
    
    // If status is completed, emit completion event
    if (newEvaluation.status === 'completed') {
      this.emitEvent('evaluation_completed', newEvaluation);
    }
    
    return newEvaluation;
  }

  getEvaluations(): Evaluation[] {
    return this.get('evaluations', []);
  }

  // Feedback operations with events
  addFeedback(feedback: Omit<Feedback, 'id'>): Feedback {
    const newFeedback: Feedback = {
      ...feedback,
      id: `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    const feedbacks = this.get('feedbacks', []);
    feedbacks.push(newFeedback);
    this.set('feedbacks', feedbacks);

    this.emitEvent('feedback_created', newFeedback);
    return newFeedback;
  }

  getFeedbacks(): Feedback[] {
    return this.get('feedbacks', []);
  }

  // Announcement operations with events
  addAnnouncement(announcement: Omit<Announcement, 'id'>): Announcement {
    const newAnnouncement: Announcement = {
      ...announcement,
      id: `ann_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    const announcements = this.get('announcements', []);
    announcements.push(newAnnouncement);
    this.set('announcements', announcements);

    this.emitEvent('announcement_created', newAnnouncement);
    return newAnnouncement;
  }

  getAnnouncements(): Announcement[] {
    return this.get('announcements', []);
  }

  // Message operations with events
  addMessage(message: Omit<Message, 'id'>): Message {
    const newMessage: Message = {
      ...message,
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    const messages = this.get('messages', []);
    messages.push(newMessage);
    this.set('messages', messages);

    this.emitEvent('message_sent', newMessage);

    // Notify recipients
    newMessage.toId.forEach(recipientId => {
      this.createNotification({
        type: 'info',
        title: 'Nova Mensagem',
        message: `Você recebeu uma mensagem: ${newMessage.subject}`,
        userId: recipientId,
        relatedModule: 'communications',
        relatedId: newMessage.id,
        actionUrl: '/communications'
      });
    });

    return newMessage;
  }

  getMessages(): Message[] {
    return this.get('messages', []);
  }

  getUserMessages(userId: string): { inbox: Message[], sent: Message[] } {
    const allMessages = this.getMessages();

    const inbox = allMessages.filter(msg => msg.toId.includes(userId));
    const sent = allMessages.filter(msg => msg.fromId === userId);

    return { inbox, sent };
  }

  markMessageAsRead(messageId: string, userId: string): boolean {
    const messages = this.get('messages', []);
    const message = messages.find((msg: Message) => msg.id === messageId);

    if (message && message.toId.includes(userId)) {
      message.isRead = true;
      this.set('messages', messages);
      return true;
    }
    return false;
  }

  // Document operations with events
  addDocument(employeeId: string, document: Omit<Document, 'id'>): boolean {
    const employee = this.getEmployee(employeeId);
    if (employee) {
      const newDocument: Document = {
        ...document,
        id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      };

      // Ensure documents array exists
      if (!employee.documents) {
        employee.documents = [];
      }

      employee.documents.push(newDocument);
      this.updateEmployee(employeeId, employee);

      this.emitEvent('document_uploaded', { employeeId, document: newDocument });

      // Log activity
      this.logActivity({
        userId: employeeId,
        action: 'document_upload',
        module: 'documents',
        description: `Upload do documento ${newDocument.name}`,
        relatedData: { documentId: newDocument.id, type: newDocument.type }
      });

      return true;
    }
    return false;
  }

  // Get all documents across all employees
  getAllDocuments(): (Document & { employeeId: string; employeeName: string })[] {
    const employees = this.getEmployees();
    return employees.flatMap(emp =>
      (emp.documents || []).map(doc => ({
        ...doc,
        employeeId: emp.id,
        employeeName: emp.name
      }))
    );
  }

  // Get documents by type
  getDocumentsByType(type: string): (Document & { employeeId: string; employeeName: string })[] {
    return this.getAllDocuments().filter(doc => doc.type === type);
  }

  // Get documents by employee
  getEmployeeDocuments(employeeId: string): Document[] {
    const employee = this.getEmployee(employeeId);
    return employee?.documents || [];
  }

  // Delete document
  deleteDocument(employeeId: string, documentId: string): boolean {
    const employee = this.getEmployee(employeeId);
    if (employee && employee.documents) {
      const documentIndex = employee.documents.findIndex(doc => doc.id === documentId);
      if (documentIndex !== -1) {
        const deletedDocument = employee.documents[documentIndex];
        employee.documents.splice(documentIndex, 1);

        const success = this.updateEmployee(employeeId, employee);

        if (success) {
          this.emitEvent('document_deleted', { employeeId, document: deletedDocument });

          // Log activity
          this.logActivity({
            userId: employeeId,
            action: 'document_delete',
            module: 'documents',
            description: `Documento ${deletedDocument.name} foi excluído`,
            relatedData: { documentId: deletedDocument.id, type: deletedDocument.type }
          });
        }

        return success;
      }
    }
    return false;
  }

  // Get document statistics
  getDocumentStats(): {
    totalDocuments: number;
    documentsByType: Record<string, number>;
    documentsByEmployee: Record<string, number>;
    totalSize: number;
    averageDocumentsPerEmployee: number;
  } {
    const allDocuments = this.getAllDocuments();
    const employees = this.getEmployees();

    const documentsByType = allDocuments.reduce((acc, doc) => {
      acc[doc.type] = (acc[doc.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const documentsByEmployee = allDocuments.reduce((acc, doc) => {
      acc[doc.employeeName] = (acc[doc.employeeName] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const totalSize = allDocuments.reduce((acc, doc) => {
      const sizeInKB = parseInt(doc.size.replace(' KB', '')) || 0;
      return acc + sizeInKB;
    }, 0);

    return {
      totalDocuments: allDocuments.length,
      documentsByType,
      documentsByEmployee,
      totalSize,
      averageDocumentsPerEmployee: employees.length > 0 ? allDocuments.length / employees.length : 0
    };
  }

  // Cross-module analytics
  getCrossModuleStats(): any {
    const employees = this.getEmployees();
    const jobs = this.getJobs();
    const trainings = this.getTrainings();
    const evaluations = this.getEvaluations();
    const feedbacks = this.getFeedbacks();
    const announcements = this.getAnnouncements();
    
    return {
      employees: {
        total: employees.length,
        active: employees.filter(emp => emp.status === 'active').length,
        departments: [...new Set(employees.map(emp => emp.department))].length
      },
      jobs: {
        total: jobs.length,
        open: jobs.filter(job => job.status === 'open').length,
        applications: jobs.reduce((acc, job) => acc + job.applications.length, 0)
      },
      trainings: {
        total: trainings.length,
        active: trainings.filter(t => t.status === 'in_progress').length,
        enrollments: trainings.reduce((acc, t) => acc + t.participants.length, 0)
      },
      evaluations: {
        total: evaluations.length,
        completed: evaluations.filter(e => e.status === 'completed').length,
        avgScore: evaluations.length > 0 
          ? evaluations.reduce((acc, e) => acc + e.overallScore, 0) / evaluations.length 
          : 0
      },
      feedback: {
        total: feedbacks.length,
        positive: feedbacks.filter(f => f.type === 'positive').length,
        thisWeek: feedbacks.filter(f => {
          const weekAgo = new Date();
          weekAgo.setDate(weekAgo.getDate() - 7);
          return new Date(f.date) >= weekAgo;
        }).length
      },
      communications: {
        announcements: announcements.length,
        highPriority: announcements.filter(a => a.priority === 'high').length
      }
    };
  }

  // Employee comprehensive profile
  getEmployeeComprehensiveProfile(employeeId: string): any {
    const employee = this.getEmployee(employeeId);
    if (!employee) return null;

    const evaluations = this.getEvaluations().filter(e => e.employeeId === employeeId);
    const feedbacksReceived = this.getFeedbacks().filter(f => f.toId === employeeId);
    const feedbacksSent = this.getFeedbacks().filter(f => f.fromId === employeeId);
    const trainings = this.getTrainings().filter(t => t.participants.includes(employeeId));
    const activities = this.getActivityLog(employeeId);
    const notifications = this.getNotifications(employeeId);

    return {
      employee,
      performance: {
        evaluations,
        avgScore: evaluations.length > 0 
          ? evaluations.reduce((acc, e) => acc + e.overallScore, 0) / evaluations.length 
          : 0,
        lastEvaluation: evaluations.sort((a, b) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        )[0]
      },
      communication: {
        feedbacksReceived,
        feedbacksSent,
        totalFeedbacks: feedbacksReceived.length + feedbacksSent.length
      },
      development: {
        trainings,
        completedTrainings: trainings.filter(t => t.status === 'completed').length,
        activeTrainings: trainings.filter(t => t.status === 'in_progress').length
      },
      activities: activities.slice(0, 10),
      notifications: notifications.slice(0, 10),
      documents: employee.documents || []
    };
  }

  // Storage management
  private saveToStorage(): void {
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('integrerh_database', JSON.stringify({
          data: this.data,
          notifications: this.notifications,
          activityLog: this.activityLog
        }));
      } catch (error) {
        console.error('Failed to save to localStorage:', error);
      }
    }
  }

  private loadFromStorage(): void {
    if (typeof localStorage !== 'undefined') {
      try {
        const stored = localStorage.getItem('integrerh_database');
        if (stored) {
          const parsed = JSON.parse(stored);
          this.data = parsed.data || {};
          this.notifications = parsed.notifications || [];
          this.activityLog = parsed.activityLog || [];
        }
      } catch (error) {
        console.error('Failed to load from localStorage:', error);
      }
    }
  }

  // Clear all data
  clearDatabase(): void {
    this.data = {};
    this.notifications = [];
    this.activityLog = [];
    this.saveToStorage();
  }
}

// Export singleton instance
export const database = IntegratedDatabase.getInstance();
