interface RecoveryToken {
  token: string;
  email: string;
  expiresAt: string;
  used: boolean;
  createdAt: string;
}

interface RecoveryEmailData {
  email: string;
  token: string;
  resetLink: string;
}

export class PasswordRecoveryService {
  private static tokens: RecoveryToken[] = [];
  private static contactEmail = "admdanielecruz@gmail.com";
  private static contactPhone = "(87) 98138-9271";

  static generateRecoveryToken(email: string): string {
    // Generate a secure token (in production, use crypto.randomBytes)
    const token = Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => 
      byte.toString(16).padStart(2, '0')
    ).join('');

    // Token expires in 1 hour
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();

    const recoveryToken: RecoveryToken = {
      token,
      email: email.toLowerCase(),
      expiresAt,
      used: false,
      createdAt: new Date().toISOString()
    };

    // Remove any existing tokens for this email
    this.tokens = this.tokens.filter(t => t.email !== email.toLowerCase());
    
    // Add new token
    this.tokens.push(recoveryToken);
    
    // Store in localStorage for persistence
    this.persistTokens();

    return token;
  }

  static validateToken(token: string): { valid: boolean; email?: string; error?: string } {
    const recoveryToken = this.tokens.find(t => t.token === token);

    if (!recoveryToken) {
      return { valid: false, error: 'Token inválido ou não encontrado' };
    }

    if (recoveryToken.used) {
      return { valid: false, error: 'Este link de recuperação já foi utilizado' };
    }

    if (new Date() > new Date(recoveryToken.expiresAt)) {
      return { valid: false, error: 'Este link de recuperação expirou. Solicite um novo.' };
    }

    return { valid: true, email: recoveryToken.email };
  }

  static markTokenAsUsed(token: string): boolean {
    const tokenIndex = this.tokens.findIndex(t => t.token === token);
    if (tokenIndex !== -1) {
      this.tokens[tokenIndex].used = true;
      this.persistTokens();
      return true;
    }
    return false;
  }

  static async sendRecoveryEmail(email: string): Promise<{ success: boolean; message: string }> {
    try {
      // Check if email exists in the system (basic validation)
      const normalizedEmail = email.toLowerCase();
      
      // Generate recovery token
      const token = this.generateRecoveryToken(normalizedEmail);
      const resetLink = `${window.location.origin}/redefinir-senha?token=${token}`;

      // Create email content
      const emailData = this.generateRecoveryEmail({ email: normalizedEmail, token, resetLink });

      // Simulate email sending (in production, integrate with email service)
      console.log('Sending recovery email:', emailData);

      // Store email in localStorage for demo purposes
      const sentEmails = JSON.parse(localStorage.getItem('sentRecoveryEmails') || '[]');
      sentEmails.push({
        to: normalizedEmail,
        subject: emailData.subject,
        content: emailData.content,
        token,
        resetLink,
        sentAt: new Date().toISOString()
      });
      localStorage.setItem('sentRecoveryEmails', JSON.stringify(sentEmails));

      return {
        success: true,
        message: 'Um link de recuperação foi enviado para seu e-mail. Verifique sua caixa de entrada e spam.'
      };
    } catch (error) {
      console.error('Error sending recovery email:', error);
      return {
        success: false,
        message: 'Erro ao enviar e-mail de recuperação. Tente novamente em alguns minutos.'
      };
    }
  }

  static generateRecoveryEmail(data: RecoveryEmailData) {
    const subject = "Recuperação de Senha - Integre RH";
    
    const content = `
Olá!

Você solicitou a recuperação da sua senha para acessar a plataforma Integre RH.

Para redefinir sua senha, clique no link abaixo:
${data.resetLink}

⚠️ IMPORTANTE:
• Este link é válido por apenas 1 hora
• Após utilizar o link, ele não poderá ser usado novamente
• Se você não solicitou esta recuperação, ignore este e-mail

Caso tenha problemas para acessar o link, copie e cole o endereço completo no seu navegador.

Precisa de ajuda?
📞 ${this.contactPhone}
📧 ${this.contactEmail}

Atenciosamente,
Equipe Integre RH

---
Este é um e-mail automático, não responda a esta mensagem.
    `.trim();

    return { subject, content };
  }

  static cleanExpiredTokens(): void {
    const now = new Date();
    this.tokens = this.tokens.filter(token => 
      new Date(token.expiresAt) > now && !token.used
    );
    this.persistTokens();
  }

  private static persistTokens(): void {
    try {
      localStorage.setItem('passwordRecoveryTokens', JSON.stringify(this.tokens));
    } catch (error) {
      console.error('Error persisting recovery tokens:', error);
    }
  }

  static loadTokens(): void {
    try {
      const stored = localStorage.getItem('passwordRecoveryTokens');
      if (stored) {
        this.tokens = JSON.parse(stored);
        // Clean expired tokens on load
        this.cleanExpiredTokens();
      }
    } catch (error) {
      console.error('Error loading recovery tokens:', error);
    }
  }

  static getContactInfo() {
    return {
      email: this.contactEmail,
      phone: this.contactPhone
    };
  }
}

// Initialize on load
PasswordRecoveryService.loadTokens();

// Clean expired tokens every 5 minutes
setInterval(() => {
  PasswordRecoveryService.cleanExpiredTokens();
}, 5 * 60 * 1000);
