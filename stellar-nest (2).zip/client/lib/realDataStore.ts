import { supabase, Database } from './supabase';
import { Employee, Job, JobApplication, Training, Evaluation, Document, Feedback, Announcement, TrainingMaterial } from './mockData';

// Type helpers for Supabase data
type EmployeeRow = Database['public']['Tables']['employees']['Row'];
type JobRow = Database['public']['Tables']['jobs']['Row'];
type JobApplicationRow = Database['public']['Tables']['job_applications']['Row'];
type TrainingRow = Database['public']['Tables']['trainings']['Row'];
type TrainingParticipantRow = Database['public']['Tables']['training_participants']['Row'];
type TrainingMaterialRow = Database['public']['Tables']['training_materials']['Row'];
type EvaluationRow = Database['public']['Tables']['evaluations']['Row'];
type DocumentRow = Database['public']['Tables']['documents']['Row'];
type FeedbackRow = Database['public']['Tables']['feedbacks']['Row'];
type AnnouncementRow = Database['public']['Tables']['announcements']['Row'];

// Data transformation utilities
function transformEmployee(row: EmployeeRow): Employee {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone || '',
    cpf: row.cpf || '',
    rg: row.rg || '',
    position: row.position,
    department: row.department,
    address: row.address || '',
    manager: row.manager_id || undefined,
    joinDate: row.join_date,
    terminationDate: row.termination_date || undefined,
    terminationReason: row.termination_reason || undefined,
    ctps: row.ctps || undefined,
    salary: row.salary || undefined,
    status: row.status,
    avatar: row.avatar || undefined,
    documents: [], // Will be loaded separately
    evaluations: [], // Will be loaded separately
    trainings: [], // Will be loaded separately
    history: [] // Will be loaded separately
  };
}

function transformJob(row: JobRow, applications: JobApplicationRow[] = []): Job {
  return {
    id: row.id,
    title: row.title,
    department: row.department,
    description: row.description,
    requirements: row.requirements || [],
    benefits: row.benefits || [],
    salary: row.salary || undefined,
    type: row.type,
    status: row.status,
    createdDate: row.created_date,
    applications: applications.map(transformJobApplication)
  };
}

function transformJobApplication(row: JobApplicationRow): JobApplication {
  return {
    id: row.id,
    jobId: row.job_id,
    candidateName: row.candidate_name,
    candidateEmail: row.candidate_email,
    phone: row.phone || undefined,
    location: row.location || undefined,
    resumeUrl: row.resume_url || undefined,
    status: row.status,
    appliedDate: row.applied_date,
    currentStage: row.current_stage || 0,
    notes: row.notes || undefined,
    stageHistory: [] // Will be loaded separately if needed
  };
}

function transformTraining(row: TrainingRow, participants: string[] = [], materials: TrainingMaterial[] = []): Training {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    category: row.category,
    duration: row.duration,
    format: row.format,
    instructor: row.instructor || undefined,
    startDate: row.start_date,
    endDate: row.end_date || undefined,
    status: row.status,
    participants,
    materials,
    certificate: row.certificate || undefined
  };
}

function transformTrainingMaterial(row: TrainingMaterialRow): TrainingMaterial {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    url: row.url || undefined,
    duration: row.duration || undefined
  };
}

function transformEvaluation(row: EvaluationRow): Evaluation {
  return {
    id: row.id,
    employeeId: row.employee_id,
    evaluatorId: row.evaluator_id,
    type: row.type,
    period: row.period,
    competencies: row.competencies as any || [],
    overallScore: Number(row.overall_score),
    feedback: row.feedback || '',
    date: row.date,
    status: row.status
  };
}

function transformDocument(row: DocumentRow): Document {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    uploadDate: row.upload_date,
    size: row.size || '',
    url: row.url || undefined
  };
}

function transformFeedback(row: FeedbackRow): Feedback {
  return {
    id: row.id,
    fromId: row.from_id,
    toId: row.to_id,
    message: row.message,
    type: row.type,
    competency: row.competency || undefined,
    date: row.date,
    isPrivate: row.is_private
  };
}

function transformAnnouncement(row: AnnouncementRow): Announcement {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    author: row.author,
    date: row.date,
    priority: row.priority,
    departments: row.departments || undefined
  };
}

export class SupabaseDataStore {
  // Employees
  static async getEmployees(): Promise<Employee[]> {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .order('name');
    
    if (error) {
      console.error('Error fetching employees:', error);
      return [];
    }
    
    return data.map(transformEmployee);
  }

  static async getEmployee(id: string): Promise<Employee | undefined> {
    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error || !data) {
      console.error('Error fetching employee:', error);
      return undefined;
    }
    
    // Load related data
    const employee = transformEmployee(data);
    employee.documents = await this.getEmployeeDocuments(id);
    employee.evaluations = await this.getEvaluationsByEmployee(id);
    
    return employee;
  }

  static async addEmployee(employee: Omit<Employee, 'id'>): Promise<Employee | null> {
    const { data, error } = await supabase
      .from('employees')
      .insert({
        name: employee.name,
        email: employee.email,
        phone: employee.phone,
        cpf: employee.cpf,
        rg: employee.rg,
        position: employee.position,
        department: employee.department,
        address: employee.address,
        manager_id: employee.manager,
        join_date: employee.joinDate,
        termination_date: employee.terminationDate,
        termination_reason: employee.terminationReason,
        ctps: employee.ctps,
        salary: employee.salary,
        status: employee.status,
        avatar: employee.avatar
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding employee:', error);
      return null;
    }
    
    return transformEmployee(data);
  }

  static async updateEmployee(id: string, updates: Partial<Employee>): Promise<boolean> {
    const { error } = await supabase
      .from('employees')
      .update({
        ...(updates.name && { name: updates.name }),
        ...(updates.email && { email: updates.email }),
        ...(updates.phone && { phone: updates.phone }),
        ...(updates.cpf && { cpf: updates.cpf }),
        ...(updates.rg && { rg: updates.rg }),
        ...(updates.position && { position: updates.position }),
        ...(updates.department && { department: updates.department }),
        ...(updates.address && { address: updates.address }),
        ...(updates.manager && { manager_id: updates.manager }),
        ...(updates.joinDate && { join_date: updates.joinDate }),
        ...(updates.terminationDate && { termination_date: updates.terminationDate }),
        ...(updates.terminationReason && { termination_reason: updates.terminationReason }),
        ...(updates.ctps && { ctps: updates.ctps }),
        ...(updates.salary !== undefined && { salary: updates.salary }),
        ...(updates.status && { status: updates.status }),
        ...(updates.avatar && { avatar: updates.avatar })
      })
      .eq('id', id);
    
    if (error) {
      console.error('Error updating employee:', error);
      return false;
    }
    
    return true;
  }

  static async deleteEmployee(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('employees')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting employee:', error);
      return false;
    }
    
    return true;
  }

  // Jobs
  static async getJobs(): Promise<Job[]> {
    // Check if Supabase is properly configured
    if (!import.meta.env.VITE_SUPABASE_URL || import.meta.env.VITE_SUPABASE_URL.includes('dummy-project')) {
      console.warn('Supabase not configured, using mock data');
      return [];
    }

    try {
      const { data: jobs, error: jobsError } = await supabase
        .from('jobs')
        .select('*')
        .order('created_date', { ascending: false });

      if (jobsError || !jobs) {
        console.error('Error fetching jobs from Supabase:', jobsError);
        console.warn('Falling back to empty data due to database connection issue');
        return [];
      }

      // Load applications for each job
      const { data: applications, error: applicationsError } = await supabase
        .from('job_applications')
        .select('*');

      if (applicationsError) {
        console.error('Error fetching applications:', applicationsError);
      }

      return jobs.map(job => {
        const jobApplications = applications?.filter(app => app.job_id === job.id) || [];
        return transformJob(job, jobApplications);
      });
    } catch (error) {
      console.error('Network error fetching jobs:', error);
      console.warn('Falling back to empty data due to network error');
      return [];
    }
  }

  static async getJob(id: string): Promise<Job | undefined> {
    const { data: job, error: jobError } = await supabase
      .from('jobs')
      .select('*')
      .eq('id', id)
      .single();
    
    if (jobError || !job) {
      console.error('Error fetching job:', jobError);
      return undefined;
    }
    
    const { data: applications, error: applicationsError } = await supabase
      .from('job_applications')
      .select('*')
      .eq('job_id', id);
    
    if (applicationsError) {
      console.error('Error fetching applications:', applicationsError);
    }
    
    return transformJob(job, applications || []);
  }

  static async addJob(job: Omit<Job, 'id'>): Promise<Job | null> {
    const { data, error } = await supabase
      .from('jobs')
      .insert({
        title: job.title,
        department: job.department,
        description: job.description,
        requirements: job.requirements,
        benefits: job.benefits,
        salary: job.salary,
        type: job.type,
        status: job.status,
        created_date: job.createdDate
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding job:', error);
      return null;
    }
    
    return transformJob(data);
  }

  static async updateJob(id: string, updates: Partial<Job>): Promise<boolean> {
    const { error } = await supabase
      .from('jobs')
      .update({
        ...(updates.title && { title: updates.title }),
        ...(updates.department && { department: updates.department }),
        ...(updates.description && { description: updates.description }),
        ...(updates.requirements && { requirements: updates.requirements }),
        ...(updates.benefits && { benefits: updates.benefits }),
        ...(updates.salary && { salary: updates.salary }),
        ...(updates.type && { type: updates.type }),
        ...(updates.status && { status: updates.status })
      })
      .eq('id', id);
    
    if (error) {
      console.error('Error updating job:', error);
      return false;
    }
    
    return true;
  }

  static async addApplicationToJob(jobId: string, application: Omit<JobApplication, 'id' | 'jobId'>): Promise<boolean> {
    const { error } = await supabase
      .from('job_applications')
      .insert({
        job_id: jobId,
        candidate_name: application.candidateName,
        candidate_email: application.candidateEmail,
        phone: application.phone,
        location: application.location,
        resume_url: application.resumeUrl,
        status: application.status,
        applied_date: application.appliedDate,
        current_stage: application.currentStage,
        notes: application.notes
      });
    
    if (error) {
      console.error('Error adding job application:', error);
      return false;
    }
    
    return true;
  }

  // Trainings
  static async getTrainings(): Promise<Training[]> {
    const { data: trainings, error: trainingsError } = await supabase
      .from('trainings')
      .select('*')
      .order('start_date', { ascending: false });
    
    if (trainingsError || !trainings) {
      console.error('Error fetching trainings:', trainingsError);
      return [];
    }

    // Load participants and materials for each training
    const trainingsWithData = await Promise.all(
      trainings.map(async (training) => {
        const [participants, materials] = await Promise.all([
          this.getTrainingParticipants(training.id),
          this.getTrainingMaterials(training.id)
        ]);
        
        return transformTraining(training, participants, materials);
      })
    );
    
    return trainingsWithData;
  }

  static async getTraining(id: string): Promise<Training | undefined> {
    const { data, error } = await supabase
      .from('trainings')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error || !data) {
      console.error('Error fetching training:', error);
      return undefined;
    }
    
    const [participants, materials] = await Promise.all([
      this.getTrainingParticipants(id),
      this.getTrainingMaterials(id)
    ]);
    
    return transformTraining(data, participants, materials);
  }

  static async addTraining(training: Omit<Training, 'id'>): Promise<Training | null> {
    const { data, error } = await supabase
      .from('trainings')
      .insert({
        title: training.title,
        description: training.description,
        category: training.category,
        duration: training.duration,
        format: training.format,
        instructor: training.instructor,
        start_date: training.startDate,
        end_date: training.endDate,
        status: training.status,
        certificate: training.certificate
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding training:', error);
      return null;
    }
    
    return transformTraining(data);
  }

  // Training participants
  static async getTrainingParticipants(trainingId: string): Promise<string[]> {
    const { data, error } = await supabase
      .from('training_participants')
      .select('employee_id')
      .eq('training_id', trainingId);
    
    if (error) {
      console.error('Error fetching training participants:', error);
      return [];
    }
    
    return data.map(row => row.employee_id);
  }

  static async addTrainingParticipant(trainingId: string, employeeId: string): Promise<boolean> {
    const { error } = await supabase
      .from('training_participants')
      .insert({
        training_id: trainingId,
        employee_id: employeeId,
        progress: 0
      });
    
    if (error) {
      console.error('Error adding training participant:', error);
      return false;
    }
    
    return true;
  }

  // Training materials
  static async getTrainingMaterials(trainingId: string): Promise<TrainingMaterial[]> {
    const { data, error } = await supabase
      .from('training_materials')
      .select('*')
      .eq('training_id', trainingId)
      .order('order_index');
    
    if (error) {
      console.error('Error fetching training materials:', error);
      return [];
    }
    
    return data.map(transformTrainingMaterial);
  }

  static async addTrainingMaterial(
    trainingId: string, 
    material: Omit<TrainingMaterial, 'id'> & { storage_path?: string }
  ): Promise<TrainingMaterial | null> {
    // Get current max order_index
    const { data: existingMaterials } = await supabase
      .from('training_materials')
      .select('order_index')
      .eq('training_id', trainingId)
      .order('order_index', { ascending: false })
      .limit(1);
    
    const nextOrderIndex = existingMaterials?.[0]?.order_index + 1 || 0;
    
    const { data, error } = await supabase
      .from('training_materials')
      .insert({
        training_id: trainingId,
        name: material.name,
        type: material.type,
        url: material.url,
        storage_path: (material as any).storage_path,
        duration: material.duration,
        order_index: nextOrderIndex
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding training material:', error);
      return null;
    }
    
    return transformTrainingMaterial(data);
  }

  static async deleteTrainingMaterial(materialId: string): Promise<boolean> {
    const { error } = await supabase
      .from('training_materials')
      .delete()
      .eq('id', materialId);
    
    if (error) {
      console.error('Error deleting training material:', error);
      return false;
    }
    
    return true;
  }

  // Evaluations
  static async getEvaluations(): Promise<Evaluation[]> {
    const { data, error } = await supabase
      .from('evaluations')
      .select('*')
      .order('date', { ascending: false });
    
    if (error) {
      console.error('Error fetching evaluations:', error);
      return [];
    }
    
    return data.map(transformEvaluation);
  }

  static async getEvaluationsByEmployee(employeeId: string): Promise<Evaluation[]> {
    const { data, error } = await supabase
      .from('evaluations')
      .select('*')
      .eq('employee_id', employeeId)
      .order('date', { ascending: false });
    
    if (error) {
      console.error('Error fetching employee evaluations:', error);
      return [];
    }
    
    return data.map(transformEvaluation);
  }

  static async addEvaluation(evaluation: Omit<Evaluation, 'id'>): Promise<Evaluation | null> {
    const { data, error } = await supabase
      .from('evaluations')
      .insert({
        employee_id: evaluation.employeeId,
        evaluator_id: evaluation.evaluatorId,
        type: evaluation.type,
        period: evaluation.period,
        competencies: evaluation.competencies as any,
        overall_score: evaluation.overallScore,
        feedback: evaluation.feedback,
        date: evaluation.date,
        status: evaluation.status
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding evaluation:', error);
      return null;
    }
    
    return transformEvaluation(data);
  }

  // Documents
  static async getEmployeeDocuments(employeeId: string): Promise<Document[]> {
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('employee_id', employeeId)
      .order('upload_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching employee documents:', error);
      return [];
    }
    
    return data.map(transformDocument);
  }

  static async addDocument(employeeId: string, document: Omit<Document, 'id'> & { storage_path?: string }): Promise<boolean> {
    const { error } = await supabase
      .from('documents')
      .insert({
        employee_id: employeeId,
        name: document.name,
        type: document.type,
        upload_date: document.uploadDate,
        size: document.size,
        url: document.url,
        storage_path: (document as any).storage_path
      });
    
    if (error) {
      console.error('Error adding document:', error);
      return false;
    }
    
    return true;
  }

  static async deleteDocument(employeeId: string, documentId: string): Promise<boolean> {
    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', documentId)
      .eq('employee_id', employeeId);
    
    if (error) {
      console.error('Error deleting document:', error);
      return false;
    }
    
    return true;
  }

  // Feedbacks
  static async getFeedbacks(): Promise<Feedback[]> {
    const { data, error } = await supabase
      .from('feedbacks')
      .select('*')
      .order('date', { ascending: false });
    
    if (error) {
      console.error('Error fetching feedbacks:', error);
      return [];
    }
    
    return data.map(transformFeedback);
  }

  static async getFeedbacksByEmployee(employeeId: string): Promise<Feedback[]> {
    const { data, error } = await supabase
      .from('feedbacks')
      .select('*')
      .eq('to_id', employeeId)
      .order('date', { ascending: false });
    
    if (error) {
      console.error('Error fetching employee feedbacks:', error);
      return [];
    }
    
    return data.map(transformFeedback);
  }

  static async addFeedback(feedback: Omit<Feedback, 'id'>): Promise<Feedback | null> {
    const { data, error } = await supabase
      .from('feedbacks')
      .insert({
        from_id: feedback.fromId,
        to_id: feedback.toId,
        message: feedback.message,
        type: feedback.type,
        competency: feedback.competency,
        date: feedback.date,
        is_private: feedback.isPrivate
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding feedback:', error);
      return null;
    }
    
    return transformFeedback(data);
  }

  // Announcements
  static async getAnnouncements(): Promise<Announcement[]> {
    const { data, error } = await supabase
      .from('announcements')
      .select('*')
      .order('date', { ascending: false });
    
    if (error) {
      console.error('Error fetching announcements:', error);
      return [];
    }
    
    return data.map(transformAnnouncement);
  }

  static async addAnnouncement(announcement: Omit<Announcement, 'id'>): Promise<Announcement | null> {
    const { data, error } = await supabase
      .from('announcements')
      .insert({
        title: announcement.title,
        content: announcement.content,
        author: announcement.author,
        date: announcement.date,
        priority: announcement.priority,
        departments: announcement.departments
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error adding announcement:', error);
      return null;
    }
    
    return transformAnnouncement(data);
  }

  // File upload to Supabase Storage
  static async uploadFile(bucket: string, path: string, file: File): Promise<string | null> {
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file);
    
    if (error) {
      console.error('Error uploading file:', error);
      return null;
    }
    
    const { data: urlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);
    
    return urlData.publicUrl;
  }

  // Get statistics
  static async getCrossModuleStats(): Promise<any> {
    try {
      const [employees, jobs, trainings, evaluations, announcements, feedbacks] = await Promise.all([
        this.getEmployees(),
        this.getJobs(),
        this.getTrainings(),
        this.getEvaluations(),
        this.getAnnouncements(),
        this.getFeedbacks()
      ]);

      const activeEmployees = employees.filter(emp => emp.status === 'active');

      return {
        employees: {
          total: employees.length,
          active: activeEmployees.length,
          withDocuments: employees.filter(emp => emp.documents.length > 0).length,
          averageDocuments: employees.reduce((acc, emp) => acc + emp.documents.length, 0) / employees.length
        },
        performance: {
          totalEvaluations: evaluations.length,
          averageScore: evaluations.reduce((acc, evaluation) => acc + evaluation.overallScore, 0) / evaluations.length,
          completedEvaluations: evaluations.filter(evaluation => evaluation.status === 'completed').length,
          pendingEvaluations: evaluations.filter(evaluation => evaluation.status === 'pending').length
        },
        training: {
          totalTrainings: trainings.length,
          activeTrainings: trainings.filter(training => training.status === 'in_progress').length,
          completedTrainings: trainings.filter(training => training.status === 'completed').length,
          totalParticipants: trainings.reduce((acc, training) => acc + training.participants.length, 0)
        },
        communication: {
          totalAnnouncements: announcements.length,
          highPriority: announcements.filter(ann => ann.priority === 'high').length,
          totalFeedbacks: feedbacks.length,
          recentFeedbacks: feedbacks.filter(fb =>
            new Date(fb.date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
          ).length
        }
      };
    } catch (error) {
      console.error('Error getting cross-module stats:', error);
      return {
        employees: { total: 0, active: 0, withDocuments: 0, averageDocuments: 0 },
        performance: { totalEvaluations: 0, averageScore: 0, completedEvaluations: 0, pendingEvaluations: 0 },
        training: { totalTrainings: 0, activeTrainings: 0, completedTrainings: 0, totalParticipants: 0 },
        communication: { totalAnnouncements: 0, highPriority: 0, totalFeedbacks: 0, recentFeedbacks: 0 }
      };
    }
  }
}
