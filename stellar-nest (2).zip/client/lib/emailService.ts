// Real Email Service Implementation with Resend API
// Configure environment variables for production use

interface EmailConfig {
  apiKey: string;
  fromEmail: string;
  fromName: string;
}

interface EmailTemplate {
  subject: string;
  html: string;
  text?: string;
}

interface EmailData {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  attachments?: Array<{
    filename: string;
    content: string | Buffer;
    contentType?: string;
  }>;
}

class ResendEmailService {
  private config: EmailConfig;
  private baseUrl = 'https://api.resend.com';

  constructor() {
    this.config = {
      apiKey: import.meta.env.VITE_RESEND_API_KEY || '',
      fromEmail: import.meta.env.VITE_FROM_EMAIL || 'noreply@integrerh.com',
      fromName: import.meta.env.VITE_FROM_NAME || 'Integre RH'
    };
  }

  private async makeRequest(endpoint: string, data: any) {
    const url = `${this.baseUrl}${endpoint}`;
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Email API Error: ${errorData.message || response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Email API Request failed:', error);
      throw error;
    }
  }

  async sendEmail(emailData: EmailData): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      if (!this.config.apiKey) {
        throw new Error('Email API key not configured');
      }

      const response = await this.makeRequest('/emails', {
        from: `${this.config.fromName} <${this.config.fromEmail}>`,
        to: Array.isArray(emailData.to) ? emailData.to : [emailData.to],
        subject: emailData.subject,
        html: emailData.html,
        ...(emailData.text && { text: emailData.text }),
        ...(emailData.attachments && { attachments: emailData.attachments })
      });

      return {
        success: true,
        messageId: response.id
      };
    } catch (error) {
      console.error('Failed to send email:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  // Email templates
  private generatePasswordResetTemplate(resetLink: string, userName: string): EmailTemplate {
    return {
      subject: 'Redefinição de Senha - Integre RH',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Redefinição de Senha</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h1 style="color: #2563eb; margin: 0;">Integre RH</h1>
          </div>
          
          <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2 style="color: #333; margin-bottom: 20px;">Redefinição de Senha</h2>
            
            <p>Olá, ${userName}!</p>
            
            <p>Recebemos uma solicitação para redefinir sua senha no Integre RH. Se você não fez esta solicitação, pode ignorar este email.</p>
            
            <p>Para redefinir sua senha, clique no botão abaixo:</p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
                Redefinir Senha
              </a>
            </div>
            
            <p>Ou copie e cole este link no seu navegador:</p>
            <p style="word-break: break-all; background-color: #f8f9fa; padding: 10px; border-radius: 4px; font-family: monospace;">
              ${resetLink}
            </p>
            
            <p style="color: #666; font-size: 14px; margin-top: 30px;">
              Este link expira em 1 hora por motivos de segurança.
            </p>
          </div>
          
          <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
            <p>© 2024 Integre RH. Todos os direitos reservados.</p>
            <p>Se você não solicitou esta redefinição, entre em contato conosco imediatamente.</p>
          </div>
        </body>
        </html>
      `,
      text: `
        Integre RH - Redefinição de Senha
        
        Olá, ${userName}!
        
        Recebemos uma solicitação para redefinir sua senha no Integre RH.
        
        Para redefinir sua senha, acesse o link: ${resetLink}
        
        Este link expira em 1 hora por motivos de segurança.
        
        Se você não fez esta solicitação, pode ignorar este email.
        
        © 2024 Integre RH
      `
    };
  }

  private generateWelcomeTemplate(userName: string, userRole: string, loginLink: string): EmailTemplate {
    return {
      subject: 'Bem-vindo ao Integre RH!',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Bem-vindo ao Integre RH</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h1 style="color: #2563eb; margin: 0;">Integre RH</h1>
          </div>
          
          <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2 style="color: #333; margin-bottom: 20px;">Bem-vindo(a)!</h2>
            
            <p>Olá, ${userName}!</p>
            
            <p>Seja bem-vindo(a) ao <strong>Integre RH</strong>, sua nova plataforma de gestão de recursos humanos!</p>
            
            <p>Sua conta foi criada com o perfil de <strong>${userRole}</strong>. Você agora pode acessar todas as funcionalidades disponíveis para seu nível de acesso.</p>
            
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #2563eb; margin-top: 0;">O que você pode fazer:</h3>
              <ul style="margin: 0; padding-left: 20px;">
                <li>Gerenciar informações de funcionários</li>
                <li>Acompanhar processos seletivos</li>
                <li>Participar de treinamentos</li>
                <li>Realizar avaliações de desempenho</li>
                <li>Acessar comunicados e feedbacks</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${loginLink}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
                Acessar Plataforma
              </a>
            </div>
            
            <p>Se você tiver dúvidas ou precisar de ajuda, não hesite em entrar em contato com nossa equipe de suporte.</p>
          </div>
          
          <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
            <p>© 2024 Integre RH. Todos os direitos reservados.</p>
          </div>
        </body>
        </html>
      `,
      text: `
        Integre RH - Bem-vindo!
        
        Olá, ${userName}!
        
        Seja bem-vindo(a) ao Integre RH, sua nova plataforma de gestão de recursos humanos!
        
        Sua conta foi criada com o perfil de ${userRole}.
        
        Acesse a plataforma: ${loginLink}
        
        © 2024 Integre RH
      `
    };
  }

  private generateJobNotificationTemplate(candidateName: string, jobTitle: string, companyName: string, statusUrl: string): EmailTemplate {
    return {
      subject: `Nova Oportunidade: ${jobTitle}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Nova Oportunidade de Emprego</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h1 style="color: #2563eb; margin: 0;">Integre RH</h1>
          </div>
          
          <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2 style="color: #333; margin-bottom: 20px;">🎯 Nova Oportunidade!</h2>
            
            <p>Olá, ${candidateName}!</p>
            
            <p>Temos uma excelente notícia! Sua candidatura para a vaga de <strong>${jobTitle}</strong> na <strong>${companyName}</strong> foi recebida com sucesso.</p>
            
            <div style="background-color: #e7f3ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #2563eb;">
              <h3 style="color: #2563eb; margin-top: 0;">Próximos Passos:</h3>
              <p style="margin: 0;">Nossa equipe de recrutamento analisará seu perfil e entrará em contato em breve. Acompanhe o status da sua candidatura através do nosso portal.</p>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${statusUrl}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">
                Acompanhar Status
              </a>
            </div>
            
            <p>Boa sorte! Estamos ansiosos para conhecê-lo(a) melhor.</p>
          </div>
          
          <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
            <p>© 2024 Integre RH. Todos os direitos reservados.</p>
          </div>
        </body>
        </html>
      `,
      text: `
        Integre RH - Nova Oportunidade!
        
        Olá, ${candidateName}!
        
        Sua candidatura para ${jobTitle} na ${companyName} foi recebida com sucesso.
        
        Acompanhe o status: ${statusUrl}
        
        © 2024 Integre RH
      `
    };
  }
}

// High-level email service for HR platform
export class HREmailService {
  private static emailService: ResendEmailService | null = null;

  private static getEmailService(): ResendEmailService {
    if (!this.emailService) {
      this.emailService = new ResendEmailService();
    }
    return this.emailService;
  }

  static async sendPasswordReset(email: string, userName: string, resetToken: string): Promise<boolean> {
    const resetLink = `${window.location.origin}/reset-password?token=${resetToken}`;
    const template = this.getEmailService().generatePasswordResetTemplate(resetLink, userName);

    const result = await this.getEmailService().sendEmail({
      to: email,
      subject: template.subject,
      html: template.html,
      text: template.text
    });
    
    return result.success;
  }

  static async sendWelcomeEmail(email: string, userName: string, userRole: string): Promise<boolean> {
    const loginLink = `${window.location.origin}/login`;
    const template = this.getEmailService().generateWelcomeTemplate(userName, userRole, loginLink);

    const result = await this.getEmailService().sendEmail({
      to: email,
      subject: template.subject,
      html: template.html,
      text: template.text
    });
    
    return result.success;
  }

  static async sendJobApplicationNotification(
    email: string, 
    candidateName: string, 
    jobTitle: string, 
    companyName: string
  ): Promise<boolean> {
    const statusUrl = `${window.location.origin}/candidate-portal`;
    const template = this.getEmailService().generateJobNotificationTemplate(candidateName, jobTitle, companyName, statusUrl);

    const result = await this.getEmailService().sendEmail({
      to: email,
      subject: template.subject,
      html: template.html,
      text: template.text
    });
    
    return result.success;
  }

  static async sendInterviewSchedule(
    email: string,
    candidateName: string,
    jobTitle: string,
    interviewDate: string,
    interviewTime: string,
    interviewLocation?: string,
    meetingLink?: string
  ): Promise<boolean> {
    const subject = `Entrevista Agendada - ${jobTitle}`;
    const html = `
      <h2>Entrevista Agendada</h2>
      <p>Olá, ${candidateName}!</p>
      <p>Sua entrevista para a vaga de <strong>${jobTitle}</strong> foi agendada:</p>
      <ul>
        <li><strong>Data:</strong> ${interviewDate}</li>
        <li><strong>Horário:</strong> ${interviewTime}</li>
        ${interviewLocation ? `<li><strong>Local:</strong> ${interviewLocation}</li>` : ''}
        ${meetingLink ? `<li><strong>Link da reunião:</strong> <a href="${meetingLink}">${meetingLink}</a></li>` : ''}
      </ul>
      <p>Prepare-se e boa sorte!</p>
    `;
    
    const result = await this.getEmailService().sendEmail({
      to: email,
      subject,
      html,
      text: `Entrevista agendada para ${candidateName} - ${jobTitle} em ${interviewDate} às ${interviewTime}`
    });
    
    return result.success;
  }

  static async sendStatusUpdate(
    email: string,
    candidateName: string,
    jobTitle: string,
    newStatus: string,
    message?: string
  ): Promise<boolean> {
    const statusMessages: Record<string, string> = {
      'screening': 'Sua candidatura passou para a triagem de currículo',
      'phone_interview': 'Parabéns! Você foi selecionado(a) para entrevista por telefone',
      'technical_test': 'Próxima etapa: teste técnico',
      'final_interview': 'Última etapa: entrevista final',
      'approved': 'Parabéns! Você foi aprovado(a)! 🎉',
      'rejected': 'Infelizmente não seguiremos com sua candidatura desta vez'
    };

    const statusText = statusMessages[newStatus] || 'Status da candidatura atualizado';
    const subject = `Atualização da Candidatura - ${jobTitle}`;
    const html = `
      <h2>Atualização da Candidatura</h2>
      <p>Olá, ${candidateName}!</p>
      <p>${statusText} para a vaga <strong>${jobTitle}</strong>.</p>
      ${message ? `<p><strong>Observações:</strong> ${message}</p>` : ''}
      <p>Continue acompanhando através do nosso portal.</p>
    `;
    
    const result = await this.getEmailService().sendEmail({
      to: email,
      subject,
      html,
      text: `${candidateName}, ${statusText} para ${jobTitle}. ${message || ''}`
    });
    
    return result.success;
  }

  static async sendTrainingNotification(
    email: string,
    employeeName: string,
    trainingTitle: string,
    startDate: string,
    accessLink?: string
  ): Promise<boolean> {
    const subject = `Novo Treinamento: ${trainingTitle}`;
    const html = `
      <h2>Novo Treinamento Disponível</h2>
      <p>Olá, ${employeeName}!</p>
      <p>Você foi inscrito(a) no treinamento <strong>${trainingTitle}</strong>.</p>
      <p><strong>Início:</strong> ${startDate}</p>
      ${accessLink ? `<p><a href="${accessLink}">Acessar Treinamento</a></p>` : ''}
      <p>Acesse a plataforma Integre RH para mais detalhes.</p>
    `;
    
    const result = await this.getEmailService().sendEmail({
      to: email,
      subject,
      html,
      text: `${employeeName}, você foi inscrito no treinamento ${trainingTitle} que inicia em ${startDate}.`
    });
    
    return result.success;
  }

  static async sendEvaluationReminder(
    email: string,
    employeeName: string,
    evaluationType: string,
    dueDate: string
  ): Promise<boolean> {
    const subject = `Lembrete: Avaliação ${evaluationType}`;
    const html = `
      <h2>Lembrete de Avaliação</h2>
      <p>Olá, ${employeeName}!</p>
      <p>Sua avaliação <strong>${evaluationType}</strong> deve ser concluída até <strong>${dueDate}</strong>.</p>
      <p>Acesse o sistema Integre RH para responder.</p>
    `;
    
    const result = await this.getEmailService().sendEmail({
      to: email,
      subject,
      html,
      text: `${employeeName}, lembrete: sua avaliação ${evaluationType} deve ser concluída até ${dueDate}.`
    });
    
    return result.success;
  }

  static async sendBulkEmail(recipients: string[], subject: string, htmlContent: string, textContent?: string): Promise<boolean> {
    const result = await this.getEmailService().sendEmail({
      to: recipients,
      subject,
      html: htmlContent,
      text: textContent
    });
    
    return result.success;
  }
}

// Mock email service for development/demo
export class MockEmailService {
  static async sendPasswordReset(email: string, userName: string, resetToken: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Password reset sent to ${email} for ${userName} with token ${resetToken}`);
    return true;
  }

  static async sendWelcomeEmail(email: string, userName: string, userRole: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Welcome email sent to ${email} for ${userName} (${userRole})`);
    return true;
  }

  static async sendJobApplicationNotification(email: string, candidateName: string, jobTitle: string, companyName: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Job application notification sent to ${email}: ${candidateName} applied for ${jobTitle} at ${companyName}`);
    return true;
  }

  static async sendInterviewSchedule(email: string, candidateName: string, jobTitle: string, interviewDate: string, interviewTime: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Interview scheduled for ${candidateName} at ${email}: ${jobTitle} on ${interviewDate} at ${interviewTime}`);
    return true;
  }

  static async sendStatusUpdate(email: string, candidateName: string, jobTitle: string, newStatus: string, message?: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Status update sent to ${email}: ${candidateName} for ${jobTitle} - ${newStatus}. ${message || ''}`);
    return true;
  }

  static async sendTrainingNotification(email: string, employeeName: string, trainingTitle: string, startDate: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Training notification sent to ${email}: ${employeeName} enrolled in ${trainingTitle} starting ${startDate}`);
    return true;
  }

  static async sendEvaluationReminder(email: string, employeeName: string, evaluationType: string, dueDate: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Evaluation reminder sent to ${email}: ${employeeName} for ${evaluationType} due ${dueDate}`);
    return true;
  }

  static async sendBulkEmail(recipients: string[], subject: string, htmlContent: string): Promise<boolean> {
    console.log(`[MOCK EMAIL] Bulk email sent to ${recipients.length} recipients: ${subject}`);
    return true;
  }
}

// Export the appropriate service based on environment
const isProduction = import.meta.env.PROD && import.meta.env.VITE_RESEND_API_KEY;
export const EmailService = isProduction ? HREmailService : MockEmailService;
