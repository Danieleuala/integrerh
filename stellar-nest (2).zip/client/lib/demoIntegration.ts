import { IntegratedDataStore } from './mockData';

// Demonstração de como os módulos se integram
export function demonstrateModuleIntegration() {
  console.log('🚀 Demonstrando integração entre módulos...');

  // 1. Adicionar um novo colaborador
  console.log('📝 Adicionando novo colaborador...');
  const newEmployee = IntegratedDataStore.addEmployee({
    name: 'João Silva',
    email: 'joao.silva@integrerh.com',
    phone: '(11) 99999-9999',
    position: 'Desenvolvedor Junior',
    department: 'Tecnologia',
    joinDate: new Date().toISOString(),
    status: 'active',
    documents: [],
    evaluations: [],
    trainings: []
  });
  console.log('✅ Colaborador criado:', newEmployee.name);
  console.log('🔔 Notificação criada automaticamente para RH');

  // 2. Criar uma vaga relacionada
  console.log('📝 Criando vaga para o mesmo departamento...');
  const newJob = IntegratedDataStore.addJob({
    title: 'Desenvolvedor Senior',
    department: 'Tecnologia',
    description: 'Vaga para desenvolvedor com experiência em React e Node.js',
    requirements: ['React', 'Node.js', 'MongoDB'],
    benefits: ['Vale refeição', 'Plano de saúde'],
    salary: 'R$ 8.000 - R$ 12.000',
    type: 'full_time',
    status: 'open',
    createdDate: new Date().toISOString(),
    applications: []
  });
  console.log('✅ Vaga criada:', newJob.title);

  // 3. Inscrever o colaborador em um treinamento
  console.log('📝 Inscrevendo colaborador em treinamento...');
  const newTraining = IntegratedDataStore.addTraining({
    title: 'React Avançado',
    description: 'Curso completo de React com hooks e contexto',
    category: 'technical',
    duration: '40 horas',
    format: 'online',
    instructor: 'Prof. Maria Santos',
    startDate: new Date().toISOString(),
    status: 'not_started',
    participants: [],
    materials: []
  });
  
  // Inscrever o colaborador
  IntegratedDataStore.enrollInTraining(newTraining.id, newEmployee.id);
  console.log('✅ Colaborador inscrito no treinamento:', newTraining.title);
  console.log('🔔 Notificação enviada para o colaborador');

  // 4. Criar uma avaliação para o colaborador
  console.log('📝 Criando avaliação de performance...');
  const newEvaluation = IntegratedDataStore.addEvaluation({
    employeeId: newEmployee.id,
    evaluatorId: 'hr_admin',
    type: 'manager',
    period: '2024 - Q1',
    competencies: [
      { name: 'Comunicação', score: 8, maxScore: 10 },
      { name: 'Trabalho em Equipe', score: 9, maxScore: 10 },
      { name: 'Conhecimento Técnico', score: 7, maxScore: 10 },
      { name: 'Proatividade', score: 8, maxScore: 10 }
    ],
    overallScore: 8.0,
    feedback: 'Excelente colaborador com grande potencial de crescimento.',
    date: new Date().toISOString(),
    status: 'completed'
  });
  console.log('✅ Avaliação criada com nota:', newEvaluation.overallScore);
  console.log('🔔 Notificações enviadas para colaborador e avaliador');

  // 5. Enviar feedback
  console.log('📝 Enviando feedback...');
  const newFeedback = IntegratedDataStore.addFeedback({
    fromId: 'hr_admin',
    toId: newEmployee.id,
    message: 'Parabéns pelo excelente trabalho no último projeto!',
    type: 'positive',
    competency: 'Qualidade de Código',
    date: new Date().toISOString(),
    isPrivate: false
  });
  console.log('✅ Feedback enviado:', newFeedback.type);
  console.log('🔔 Notificação de feedback enviada');

  // 6. Criar comunicado
  console.log('📝 Criando comunicado...');
  const newAnnouncement = IntegratedDataStore.addAnnouncement({
    title: 'Bem-vindo à equipe de Tecnologia!',
    content: `Damos as boas-vindas ao ${newEmployee.name} que se juntou à nossa equipe de Tecnologia. Estamos ansiosos para trabalhar juntos!`,
    author: 'RH',
    date: new Date().toISOString(),
    priority: 'medium',
    departments: ['Tecnologia']
  });
  console.log('✅ Comunicado criado:', newAnnouncement.title);
  console.log('🔔 Notificação de comunicado enviada para o departamento');

  // 7. Mostrar estatísticas integradas
  console.log('📊 Estatísticas integradas:');
  const stats = IntegratedDataStore.getCrossModuleStats();
  console.log('   - Colaboradores ativos:', stats.employees.active);
  console.log('   - Vagas abertas:', stats.jobs.open);
  console.log('   - Inscrições em treinamentos:', stats.trainings.enrollments);
  console.log('   - Avaliações concluídas:', stats.evaluations.completed);
  console.log('   - Feedbacks desta semana:', stats.feedback.thisWeek);

  // 8. Mostrar perfil integrado do colaborador
  console.log('👤 Perfil integrado do colaborador:');
  const profile = IntegratedDataStore.getEmployeeProfile(newEmployee.id);
  if (profile) {
    console.log('   - Avaliações:', profile.performance.evaluations.length);
    console.log('   - Feedbacks recebidos:', profile.communication.feedbacksReceived.length);
    console.log('   - Treinamentos:', profile.development.trainings.length);
    console.log('   - Notificações:', profile.notifications.length);
    console.log('   - Atividades recentes:', profile.activities.length);
  }

  console.log('🎉 Demonstração concluída! Todos os módulos estão integrados.');
  
  return {
    employee: newEmployee,
    job: newJob,
    training: newTraining,
    evaluation: newEvaluation,
    feedback: newFeedback,
    announcement: newAnnouncement,
    stats,
    profile
  };
}

// Executar demonstração automaticamente se necessário
if (typeof window !== 'undefined' && window.location.search.includes('demo=true')) {
  setTimeout(() => {
    demonstrateModuleIntegration();
  }, 2000);
}
