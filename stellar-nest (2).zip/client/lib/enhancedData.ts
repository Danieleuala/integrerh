// Enhanced data structures for Jobs and Evaluations modules

// Selection Process Stages
export interface SelectionStage {
  id: string;
  name: string;
  description?: string;
  order: number;
  isRequired: boolean;
  hasTest?: boolean;
  testId?: string;
}

// Enhanced Job with pipeline stages
export interface EnhancedJob {
  id: string;
  title: string;
  department: string;
  description: string;
  requirements: string[];
  benefits: string[];
  salary?: string;
  type: 'full_time' | 'part_time' | 'contract';
  status: 'open' | 'closed' | 'draft';
  createdDate: string;
  applications: EnhancedJobApplication[];
  stages: SelectionStage[];
  shareableLink?: string;
  shareCount: number;
  viewCount: number;
}

// Enhanced Job Application with stage tracking
export interface EnhancedJobApplication {
  id: string;
  jobId: string;
  candidateId: string; // Link to permanent candidate database
  currentStage: string; // stage ID
  stageHistory: StageHistory[];
  testResults?: TestResult[];
  status: 'active' | 'approved' | 'rejected' | 'withdrawn';
  appliedDate: string;
  notes?: string;
  interviewDates?: InterviewSchedule[];
}

// Candidate in permanent database
export interface Candidate {
  id: string;
  name: string;
  email: string;
  phone: string;
  resumeUrl?: string;
  portfolioUrl?: string;
  linkedInUrl?: string;
  skills: string[];
  experience: string;
  education: string;
  location: string;
  salaryExpectation?: string;
  availabilityDate?: string;
  applications: EnhancedJobApplication[];
  testResults: TestResult[];
  interviewHistory: InterviewRecord[];
  tags: string[];
  source: 'website' | 'linkedin' | 'referral' | 'direct' | 'other';
  createdDate: string;
  lastUpdated: string;
}

// Stage tracking
export interface StageHistory {
  stageId: string;
  enteredDate: string;
  exitedDate?: string;
  result?: 'passed' | 'failed' | 'pending';
  notes?: string;
  evaluatedBy?: string;
}

// Test system
export interface Test {
  id: string;
  name: string;
  description: string;
  type: 'multiple_choice' | 'essay' | 'mixed';
  timeLimit: number; // minutes
  passingScore: number; // percentage
  questions: TestQuestion[];
  isActive: boolean;
  createdDate: string;
  createdBy: string;
}

export interface TestQuestion {
  id: string;
  text: string;
  type: 'multiple_choice' | 'essay';
  options?: string[]; // for multiple choice
  correctAnswer?: number; // index for multiple choice
  weight: number; // points
  category?: string;
}

export interface TestResult {
  id: string;
  testId: string;
  candidateId: string;
  answers: TestAnswer[];
  score: number;
  percentage: number;
  passed: boolean;
  startedAt: string;
  completedAt?: string;
  timeSpent: number; // minutes
}

export interface TestAnswer {
  questionId: string;
  answer: string | number; // string for essay, number for multiple choice index
  isCorrect?: boolean;
  points: number;
}

// Interview scheduling
export interface InterviewSchedule {
  id: string;
  type: 'phone' | 'video' | 'in_person';
  scheduledDate: string;
  duration: number; // minutes
  interviewers: string[]; // employee IDs
  location?: string;
  meetingLink?: string;
  status: 'scheduled' | 'completed' | 'cancelled' | 'rescheduled';
  notes?: string;
}

export interface InterviewRecord {
  id: string;
  jobId: string;
  applicationId: string;
  interviewerId: string;
  type: 'phone' | 'video' | 'in_person';
  date: string;
  duration: number;
  rating: number; // 1-5
  feedback: string;
  recommendation: 'hire' | 'reject' | 'maybe' | 'next_round';
  competencyScores?: {
    competency: string;
    score: number;
  }[];
}

// Enhanced Evaluation System
export interface Competency {
  id: string;
  name: string;
  description: string;
  category: 'technical' | 'behavioral' | 'leadership' | 'communication' | 'custom';
  scale: {
    min: number;
    max: number;
    labels?: string[]; // e.g., ['Poor', 'Fair', 'Good', 'Excellent']
  };
  questions: CompetencyQuestion[];
  isActive: boolean;
  createdDate: string;
  createdBy: string;
}

export interface CompetencyQuestion {
  id: string;
  text: string;
  type: 'rating' | 'text' | 'multiple_choice';
  options?: string[];
  weight: number;
  isRequired: boolean;
}

export interface EvaluationTemplate {
  id: string;
  name: string;
  description: string;
  type: 'performance' | 'technical' | '360_feedback' | 'probation' | 'custom';
  competencies: string[]; // competency IDs
  evaluatorTypes: ('self' | 'manager' | 'peer' | 'subordinate' | 'client')[];
  frequency: 'one_time' | 'monthly' | 'quarterly' | 'semi_annual' | 'annual';
  isActive: boolean;
  shareableLink?: string;
  allowAnonymous: boolean;
  createdDate: string;
  createdBy: string;
}

export interface EvaluationInstance {
  id: string;
  templateId: string;
  evalueeId: string; // employee being evaluated
  evaluatorId?: string; // if not anonymous
  type: 'self' | 'manager' | 'peer' | 'subordinate' | 'client';
  responses: EvaluationResponse[];
  overallScore: number;
  status: 'pending' | 'in_progress' | 'completed' | 'expired';
  startedDate?: string;
  completedDate?: string;
  dueDate?: string;
  accessToken?: string; // for shareable links
  feedback?: string;
  developmentPlan?: string;
}

export interface EvaluationResponse {
  competencyId: string;
  questionId: string;
  response: string | number;
  score?: number;
}

// Results and Analytics
export interface EvaluationResults {
  evaluationId: string;
  evalueeId: string;
  competencyScores: {
    competencyId: string;
    competencyName: string;
    averageScore: number;
    responseCount: number;
    breakdown: {
      evaluatorType: string;
      score: number;
    }[];
  }[];
  overallScore: number;
  participationRate: number;
  strengths: string[];
  improvementAreas: string[];
  generatedAt: string;
}

// Data Store Extensions
export class EnhancedDataStore {
  private static candidates: Candidate[] = [];
  private static tests: Test[] = [];
  private static competencies: Competency[] = [];
  private static evaluationTemplates: EvaluationTemplate[] = [];
  private static evaluationInstances: EvaluationInstance[] = [];

  // Candidate Management
  static addCandidate(candidate: Omit<Candidate, 'id' | 'createdDate' | 'lastUpdated'>): Candidate {
    const newCandidate: Candidate = {
      ...candidate,
      id: `candidate_${Date.now()}`,
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString()
    };
    this.candidates.push(newCandidate);
    this.persistToStorage();
    return newCandidate;
  }

  static getCandidates(): Candidate[] {
    return [...this.candidates];
  }

  static getCandidateById(id: string): Candidate | undefined {
    return this.candidates.find(c => c.id === id);
  }

  static updateCandidate(id: string, updates: Partial<Candidate>): boolean {
    const index = this.candidates.findIndex(c => c.id === id);
    if (index !== -1) {
      this.candidates[index] = {
        ...this.candidates[index],
        ...updates,
        lastUpdated: new Date().toISOString()
      };
      this.persistToStorage();
      return true;
    }
    return false;
  }

  // Test Management
  static addTest(test: Omit<Test, 'id' | 'createdDate'>): Test {
    const newTest: Test = {
      ...test,
      id: `test_${Date.now()}`,
      createdDate: new Date().toISOString()
    };
    this.tests.push(newTest);
    this.persistToStorage();
    return newTest;
  }

  static getTests(): Test[] {
    return [...this.tests];
  }

  static getTestById(id: string): Test | undefined {
    return this.tests.find(t => t.id === id);
  }

  // Competency Management
  static addCompetency(competency: Omit<Competency, 'id' | 'createdDate'>): Competency {
    const newCompetency: Competency = {
      ...competency,
      id: `competency_${Date.now()}`,
      createdDate: new Date().toISOString()
    };
    this.competencies.push(newCompetency);
    this.persistToStorage();
    return newCompetency;
  }

  static getCompetencies(): Competency[] {
    return [...this.competencies];
  }

  // Evaluation Template Management
  static addEvaluationTemplate(template: Omit<EvaluationTemplate, 'id' | 'createdDate'>): EvaluationTemplate {
    const newTemplate: EvaluationTemplate = {
      ...template,
      id: `eval_template_${Date.now()}`,
      createdDate: new Date().toISOString()
    };
    this.evaluationTemplates.push(newTemplate);
    this.persistToStorage();
    return newTemplate;
  }

  static getEvaluationTemplates(): EvaluationTemplate[] {
    return [...this.evaluationTemplates];
  }

  // Evaluation Instance Management
  static addEvaluationInstance(instance: Omit<EvaluationInstance, 'id'>): EvaluationInstance {
    const newInstance: EvaluationInstance = {
      ...instance,
      id: `eval_instance_${Date.now()}`
    };
    this.evaluationInstances.push(newInstance);
    this.persistToStorage();
    return newInstance;
  }

  static getEvaluationInstances(): EvaluationInstance[] {
    return [...this.evaluationInstances];
  }

  // Persistence
  private static persistToStorage(): void {
    try {
      localStorage.setItem('enhancedCandidates', JSON.stringify(this.candidates));
      localStorage.setItem('enhancedTests', JSON.stringify(this.tests));
      localStorage.setItem('enhancedCompetencies', JSON.stringify(this.competencies));
      localStorage.setItem('enhancedEvaluationTemplates', JSON.stringify(this.evaluationTemplates));
      localStorage.setItem('enhancedEvaluationInstances', JSON.stringify(this.evaluationInstances));
    } catch (error) {
      console.error('Error persisting enhanced data:', error);
    }
  }

  static loadFromStorage(): void {
    try {
      const candidates = localStorage.getItem('enhancedCandidates');
      const tests = localStorage.getItem('enhancedTests');
      const competencies = localStorage.getItem('enhancedCompetencies');
      const evaluationTemplates = localStorage.getItem('enhancedEvaluationTemplates');
      const evaluationInstances = localStorage.getItem('enhancedEvaluationInstances');

      if (candidates) this.candidates = JSON.parse(candidates);
      if (tests) this.tests = JSON.parse(tests);
      if (competencies) this.competencies = JSON.parse(competencies);
      if (evaluationTemplates) this.evaluationTemplates = JSON.parse(evaluationTemplates);
      if (evaluationInstances) this.evaluationInstances = JSON.parse(evaluationInstances);
    } catch (error) {
      console.error('Error loading enhanced data:', error);
    }
  }

  // Initialize with default data
  static initializeDefaultData(): void {
    if (this.competencies.length === 0) {
      // Add default competencies
      this.addCompetency({
        name: 'Comunicação',
        description: 'Capacidade de se expressar de forma clara e eficaz',
        category: 'communication',
        scale: { min: 1, max: 5, labels: ['Insuficiente', 'Básico', 'Bom', 'Muito Bom', 'Excelente'] },
        questions: [
          {
            id: 'comm_q1',
            text: 'Expressa ideias de forma clara e objetiva',
            type: 'rating',
            weight: 1,
            isRequired: true
          }
        ],
        isActive: true,
        createdBy: 'system'
      });

      this.addCompetency({
        name: 'Trabalho em Equipe',
        description: 'Habilidade para colaborar efetivamente em grupo',
        category: 'behavioral',
        scale: { min: 1, max: 5, labels: ['Insuficiente', 'Básico', 'Bom', 'Muito Bom', 'Excelente'] },
        questions: [
          {
            id: 'team_q1',
            text: 'Colabora efetivamente com colegas',
            type: 'rating',
            weight: 1,
            isRequired: true
          }
        ],
        isActive: true,
        createdBy: 'system'
      });

      this.addCompetency({
        name: 'Liderança',
        description: 'Capacidade de liderar e influenciar positivamente',
        category: 'leadership',
        scale: { min: 1, max: 5, labels: ['Insuficiente', 'Básico', 'Bom', 'Muito Bom', 'Excelente'] },
        questions: [
          {
            id: 'lead_q1',
            text: 'Demonstra habilidades de liderança',
            type: 'rating',
            weight: 1,
            isRequired: true
          }
        ],
        isActive: true,
        createdBy: 'system'
      });
    }
  }
}

// Initialize on load
EnhancedDataStore.loadFromStorage();
EnhancedDataStore.initializeDefaultData();
