// Integre RH - Sistema de Analytics e Relatórios
// Coleta de dados, métricas e geração de relatórios automatizados

import { supabase } from './supabase';
import { integrationManager } from './integrations';

// =============================================================================
// TIPOS E INTERFACES
// =============================================================================

export interface AnalyticsEvent {
  event: string;
  module: string;
  action: string;
  userId?: string;
  data?: Record<string, any>;
  timestamp: Date;
  sessionId?: string;
  deviceInfo?: DeviceInfo;
}

export interface DeviceInfo {
  userAgent: string;
  screen: { width: number; height: number };
  language: string;
  timezone: string;
  platform: string;
}

export interface MetricData {
  key: string;
  value: number;
  label: string;
  category: string;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  date: Date;
}

export interface DashboardMetrics {
  employees: {
    total: number;
    active: number;
    newHires: number;
    turnover: number;
  };
  recruitment: {
    openJobs: number;
    applications: number;
    hiredCandidates: number;
    averageTimeToHire: number;
  };
  training: {
    activePrograms: number;
    completedTrainings: number;
    averageScore: number;
    participationRate: number;
  };
  performance: {
    completedEvaluations: number;
    averageScore: number;
    improvementPlans: number;
    feedbackCount: number;
  };
}

export interface ReportData {
  title: string;
  description: string;
  type: 'employee' | 'recruitment' | 'training' | 'performance' | 'financial';
  period: { start: Date; end: Date };
  data: any[];
  charts: ChartData[];
  summary: Record<string, any>;
  generatedAt: Date;
  generatedBy: string;
}

export interface ChartData {
  type: 'line' | 'bar' | 'pie' | 'area' | 'scatter';
  title: string;
  data: Array<{ label: string; value: number; [key: string]: any }>;
  options?: Record<string, any>;
}

// =============================================================================
// COLLECTOR DE EVENTOS
// =============================================================================

export class AnalyticsCollector {
  private sessionId: string;
  private deviceInfo: DeviceInfo;
  private eventQueue: AnalyticsEvent[] = [];
  private flushInterval: number = 30000; // 30 segundos

  constructor() {
    this.sessionId = this.generateSessionId();
    this.deviceInfo = this.collectDeviceInfo();
    this.startAutoFlush();
  }

  private generateSessionId(): string {
    return `${Date.now()}-${Math.random().toString(36).substring(2)}`;
  }

  private collectDeviceInfo(): DeviceInfo {
    return {
      userAgent: navigator.userAgent,
      screen: {
        width: window.screen.width,
        height: window.screen.height
      },
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      platform: navigator.platform
    };
  }

  private startAutoFlush(): void {
    setInterval(() => {
      this.flushEvents();
    }, this.flushInterval);

    // Flush on page unload
    window.addEventListener('beforeunload', () => {
      this.flushEvents();
    });
  }

  trackEvent(
    event: string,
    module: string,
    action: string,
    data?: Record<string, any>,
    userId?: string
  ): void {
    const analyticsEvent: AnalyticsEvent = {
      event,
      module,
      action,
      userId,
      data,
      timestamp: new Date(),
      sessionId: this.sessionId,
      deviceInfo: this.deviceInfo
    };

    this.eventQueue.push(analyticsEvent);

    // Track in Google Analytics too
    integrationManager.analytics.trackUserAction(action, module, data);

    // Flush immediately for critical events
    if (this.isCriticalEvent(event)) {
      this.flushEvents();
    }
  }

  private isCriticalEvent(event: string): boolean {
    const criticalEvents = ['user_login', 'user_logout', 'data_export', 'user_delete'];
    return criticalEvents.includes(event);
  }

  private async flushEvents(): Promise<void> {
    if (this.eventQueue.length === 0) return;

    try {
      const events = [...this.eventQueue];
      this.eventQueue = [];

      // Save to database
      const { error } = await supabase
        .from('activity_log')
        .insert(
          events.map(event => ({
            user_id: event.userId || 'anonymous',
            action: event.action,
            module: event.module,
            description: event.event,
            related_data: {
              ...event.data,
              session_id: event.sessionId,
              device_info: event.deviceInfo,
              timestamp: event.timestamp.toISOString()
            }
          }))
        );

      if (error) {
        console.error('Error saving analytics events:', error);
        // Re-add events to queue for retry
        this.eventQueue.unshift(...events);
      }
    } catch (error) {
      console.error('Error flushing analytics events:', error);
    }
  }

  // Métodos específicos para diferentes ações
  trackPageView(page: string, userId?: string): void {
    this.trackEvent('page_view', 'navigation', 'view', { page }, userId);
    integrationManager.analytics.trackPageView(page);
  }

  trackUserAction(action: string, module: string, data?: Record<string, any>, userId?: string): void {
    this.trackEvent('user_action', module, action, data, userId);
  }

  trackError(error: Error, context: string, userId?: string): void {
    this.trackEvent('error', 'system', 'error_occurred', {
      error_message: error.message,
      error_stack: error.stack,
      context
    }, userId);
  }

  trackPerformance(metric: string, value: number, context: string): void {
    this.trackEvent('performance', 'system', 'performance_metric', {
      metric,
      value,
      context
    });
  }
}

// =============================================================================
// METRICS CALCULATOR
// =============================================================================

export class MetricsCalculator {
  async calculateDashboardMetrics(): Promise<DashboardMetrics> {
    try {
      // Métricas de funcionários
      const { data: employees } = await supabase
        .from('employees')
        .select('*');

      const activeEmployees = employees?.filter(emp => emp.status === 'active') || [];
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const newHires = employees?.filter(emp => 
        new Date(emp.join_date) >= thirtyDaysAgo
      ) || [];

      const terminated = employees?.filter(emp => 
        emp.status === 'terminated' && 
        emp.termination_date && 
        new Date(emp.termination_date) >= thirtyDaysAgo
      ) || [];

      // Métricas de recrutamento
      const { data: jobs } = await supabase
        .from('jobs')
        .select('*');

      const { data: applications } = await supabase
        .from('job_applications')
        .select('*');

      const openJobs = jobs?.filter(job => job.status === 'open') || [];
      const recentApplications = applications?.filter(app => 
        new Date(app.applied_date) >= thirtyDaysAgo
      ) || [];
      const hiredCandidates = applications?.filter(app => app.status === 'approved') || [];

      // Métricas de treinamentos
      const { data: trainings } = await supabase
        .from('trainings')
        .select('*, training_participants(*)');

      const activeTrainings = trainings?.filter(training => 
        training.status === 'in_progress'
      ) || [];

      const { data: evaluations } = await supabase
        .from('evaluations')
        .select('*');

      const completedEvaluations = evaluations?.filter(eval => 
        eval.status === 'completed'
      ) || [];

      const { data: feedbacks } = await supabase
        .from('feedbacks')
        .select('*');

      return {
        employees: {
          total: employees?.length || 0,
          active: activeEmployees.length,
          newHires: newHires.length,
          turnover: terminated.length
        },
        recruitment: {
          openJobs: openJobs.length,
          applications: recentApplications.length,
          hiredCandidates: hiredCandidates.length,
          averageTimeToHire: this.calculateAverageTimeToHire(applications || [])
        },
        training: {
          activePrograms: activeTrainings.length,
          completedTrainings: this.calculateCompletedTrainings(trainings || []),
          averageScore: this.calculateAverageTrainingScore(trainings || []),
          participationRate: this.calculateParticipationRate(trainings || [])
        },
        performance: {
          completedEvaluations: completedEvaluations.length,
          averageScore: this.calculateAverageEvaluationScore(evaluations || []),
          improvementPlans: 0, // TODO: implementar
          feedbackCount: feedbacks?.length || 0
        }
      };
    } catch (error) {
      console.error('Error calculating dashboard metrics:', error);
      return this.getEmptyMetrics();
    }
  }

  private calculateAverageTimeToHire(applications: any[]): number {
    const hired = applications.filter(app => app.status === 'approved');
    if (hired.length === 0) return 0;

    const totalDays = hired.reduce((sum, app) => {
      const applied = new Date(app.applied_date);
      const updated = new Date(app.updated_at);
      const days = Math.ceil((updated.getTime() - applied.getTime()) / (1000 * 60 * 60 * 24));
      return sum + days;
    }, 0);

    return Math.round(totalDays / hired.length);
  }

  private calculateCompletedTrainings(trainings: any[]): number {
    return trainings.filter(training => training.status === 'completed').length;
  }

  private calculateAverageTrainingScore(trainings: any[]): number {
    // TODO: implementar quando tivermos scores de treinamento
    return 0;
  }

  private calculateParticipationRate(trainings: any[]): number {
    // TODO: implementar taxa de participação baseada em training_participants
    return 0;
  }

  private calculateAverageEvaluationScore(evaluations: any[]): number {
    if (evaluations.length === 0) return 0;
    
    const totalScore = evaluations.reduce((sum, eval) => sum + (eval.overall_score || 0), 0);
    return Math.round((totalScore / evaluations.length) * 10) / 10;
  }

  private getEmptyMetrics(): DashboardMetrics {
    return {
      employees: { total: 0, active: 0, newHires: 0, turnover: 0 },
      recruitment: { openJobs: 0, applications: 0, hiredCandidates: 0, averageTimeToHire: 0 },
      training: { activePrograms: 0, completedTrainings: 0, averageScore: 0, participationRate: 0 },
      performance: { completedEvaluations: 0, averageScore: 0, improvementPlans: 0, feedbackCount: 0 }
    };
  }
}

// =============================================================================
// REPORT GENERATOR
// =============================================================================

export class ReportGenerator {
  async generateEmployeeReport(startDate: Date, endDate: Date): Promise<ReportData> {
    try {
      const { data: employees } = await supabase
        .from('employees')
        .select('*')
        .gte('join_date', startDate.toISOString())
        .lte('join_date', endDate.toISOString());

      const charts: ChartData[] = [
        {
          type: 'bar',
          title: 'Funcionários por Departamento',
          data: this.groupByDepartment(employees || [])
        },
        {
          type: 'line',
          title: 'Contratações por Mês',
          data: this.groupByMonth(employees || [], 'join_date')
        }
      ];

      return {
        title: 'Relatório de Funcionários',
        description: `Análise de funcionários de ${startDate.toLocaleDateString()} a ${endDate.toLocaleDateString()}`,
        type: 'employee',
        period: { start: startDate, end: endDate },
        data: employees || [],
        charts,
        summary: {
          total: employees?.length || 0,
          departments: new Set(employees?.map(emp => emp.department)).size || 0
        },
        generatedAt: new Date(),
        generatedBy: 'system'
      };
    } catch (error) {
      console.error('Error generating employee report:', error);
      throw error;
    }
  }

  async generateTrainingReport(startDate: Date, endDate: Date): Promise<ReportData> {
    try {
      const { data: trainings } = await supabase
        .from('trainings')
        .select('*, training_participants(*)')
        .gte('start_date', startDate.toISOString())
        .lte('start_date', endDate.toISOString());

      const charts: ChartData[] = [
        {
          type: 'pie',
          title: 'Treinamentos por Categoria',
          data: this.groupByCategory(trainings || [])
        },
        {
          type: 'bar',
          title: 'Taxa de Conclusão',
          data: this.calculateCompletionRates(trainings || [])
        }
      ];

      return {
        title: 'Relatório de Treinamentos',
        description: `Análise de treinamentos de ${startDate.toLocaleDateString()} a ${endDate.toLocaleDateString()}`,
        type: 'training',
        period: { start: startDate, end: endDate },
        data: trainings || [],
        charts,
        summary: {
          total: trainings?.length || 0,
          completed: trainings?.filter(t => t.status === 'completed').length || 0
        },
        generatedAt: new Date(),
        generatedBy: 'system'
      };
    } catch (error) {
      console.error('Error generating training report:', error);
      throw error;
    }
  }

  private groupByDepartment(employees: any[]): Array<{ label: string; value: number }> {
    const grouped = employees.reduce((acc, emp) => {
      acc[emp.department] = (acc[emp.department] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped).map(([department, count]) => ({
      label: department,
      value: count
    }));
  }

  private groupByMonth(data: any[], dateField: string): Array<{ label: string; value: number }> {
    const grouped = data.reduce((acc, item) => {
      const date = new Date(item[dateField]);
      const month = date.toLocaleDateString('pt-BR', { year: 'numeric', month: 'short' });
      acc[month] = (acc[month] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped).map(([month, count]) => ({
      label: month,
      value: count
    }));
  }

  private groupByCategory(trainings: any[]): Array<{ label: string; value: number }> {
    const grouped = trainings.reduce((acc, training) => {
      acc[training.category] = (acc[training.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped).map(([category, count]) => ({
      label: category,
      value: count
    }));
  }

  private calculateCompletionRates(trainings: any[]): Array<{ label: string; value: number }> {
    return trainings.map(training => {
      const participants = training.training_participants || [];
      const completed = participants.filter((p: any) => p.progress === 100).length;
      const rate = participants.length > 0 ? (completed / participants.length) * 100 : 0;
      
      return {
        label: training.title,
        value: Math.round(rate)
      };
    });
  }
}

// =============================================================================
// SCHEDULER PARA RELATÓRIOS AUTOMÁTICOS
// =============================================================================

export class AutoReportScheduler {
  private intervals: Record<string, number> = {};

  scheduleWeeklyReports(): void {
    // Relatório semanal de RH às segundas-feiras às 9h
    this.scheduleReport('weekly_hr', this.getNextMonday9AM(), async () => {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 7);

      const reportGenerator = new ReportGenerator();
      const report = await reportGenerator.generateEmployeeReport(startDate, endDate);
      
      await this.sendReportByEmail(report, ['rh@integrerh.com']);
    });
  }

  scheduleMonthlyReports(): void {
    // Relatório mensal no primeiro dia do mês
    this.scheduleReport('monthly_complete', this.getFirstDayOfNextMonth(), async () => {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 1);

      const reportGenerator = new ReportGenerator();
      const reports = await Promise.all([
        reportGenerator.generateEmployeeReport(startDate, endDate),
        reportGenerator.generateTrainingReport(startDate, endDate)
      ]);

      await this.sendReportByEmail(reports[0], ['rh@integrerh.com', 'gestao@integrerh.com']);
      await this.sendReportByEmail(reports[1], ['rh@integrerh.com']);
    });
  }

  private scheduleReport(id: string, nextRun: Date, callback: () => Promise<void>): void {
    const now = new Date();
    const delay = nextRun.getTime() - now.getTime();

    if (delay > 0) {
      this.intervals[id] = window.setTimeout(async () => {
        await callback();
        // Reagendar para próxima execução
        this.scheduleReport(id, this.calculateNextRun(id), callback);
      }, delay);
    }
  }

  private getNextMonday9AM(): Date {
    const date = new Date();
    const day = date.getDay();
    const diff = day === 0 ? 1 : 8 - day; // Se domingo (0), próxima segunda é 1 dia, senão 8-day
    date.setDate(date.getDate() + diff);
    date.setHours(9, 0, 0, 0);
    return date;
  }

  private getFirstDayOfNextMonth(): Date {
    const date = new Date();
    date.setMonth(date.getMonth() + 1, 1);
    date.setHours(9, 0, 0, 0);
    return date;
  }

  private calculateNextRun(id: string): Date {
    switch (id) {
      case 'weekly_hr':
        return this.getNextMonday9AM();
      case 'monthly_complete':
        return this.getFirstDayOfNextMonth();
      default:
        return new Date();
    }
  }

  private async sendReportByEmail(report: ReportData, recipients: string[]): Promise<void> {
    try {
      for (const email of recipients) {
        await integrationManager.email.sendDocumentApprovalNotification(
          email,
          `${report.title} - ${report.period.start.toLocaleDateString()}`
        );
      }
    } catch (error) {
      console.error('Error sending report by email:', error);
    }
  }

  stopAllSchedules(): void {
    Object.values(this.intervals).forEach(interval => {
      clearTimeout(interval);
    });
    this.intervals = {};
  }
}

// =============================================================================
// EXPORTS E SINGLETON
// =============================================================================

export const analyticsCollector = new AnalyticsCollector();
export const metricsCalculator = new MetricsCalculator();
export const reportGenerator = new ReportGenerator();
export const autoReportScheduler = new AutoReportScheduler();

// Inicializar agendamento automático
if (typeof window !== 'undefined') {
  autoReportScheduler.scheduleWeeklyReports();
  autoReportScheduler.scheduleMonthlyReports();
}
