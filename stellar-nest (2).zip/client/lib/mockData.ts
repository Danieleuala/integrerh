import { User } from "@/hooks/useAuth";

export interface Employee {
  id: string;
  name: string; // Nome completo - obrigatório
  email: string;
  phone: string; // Telefone - obrigatório
  cpf: string; // CPF - obrigatório
  rg: string; // RG - obrigatório
  position: string; // Cargo - obrigatório
  department: string; // Setor - obrigatório
  address: string; // Endereço - obrigatório
  manager?: string;
  joinDate: string; // Data de admissão - obrigatório
  terminationDate?: string; // Data de desligamento - opcional
  terminationReason?: string; // Motivo do desligamento - opcional
  ctps?: string; // CTPS - opcional
  salary?: number;
  status: "active" | "inactive" | "on_leave" | "terminated";
  avatar?: string;
  documents: Document[];
  evaluations: Evaluation[];
  trainings: Training[];
  history: EmployeeHistoryEntry[]; // Histórico do colaborador
}

export interface EmployeeHistoryEntry {
  id: string;
  date: string;
  type:
    | "hire"
    | "promotion"
    | "transfer"
    | "termination"
    | "status_change"
    | "salary_change";
  description: string;
  details?: {
    oldValue?: string;
    newValue?: string;
    reason?: string;
    authorizedBy?: string;
  };
}

export interface Document {
  id: string;
  name: string;
  type: "contract" | "id" | "certificate" | "other";
  uploadDate: string;
  size: string;
  url?: string;
}

export interface Job {
  id: string;
  title: string;
  department: string;
  description: string;
  requirements: string[];
  benefits: string[];
  salary?: string;
  type: "full_time" | "part_time" | "contract";
  status: "open" | "closed" | "draft";
  createdDate: string;
  applications: JobApplication[];
}

export interface JobApplication {
  id: string;
  jobId: string;
  candidateName: string;
  candidateEmail: string;
  resumeUrl?: string;
  status:
    | "pending"
    | "screening"
    | "phone_interview"
    | "technical_test"
    | "final_interview"
    | "approved"
    | "rejected";
  appliedDate: string;
  notes?: string;
  currentStage?: number; // 0-6 representing the pipeline stages
  stageHistory?: Array<{
    stage: string;
    date: string;
    notes?: string;
    evaluator?: string;
  }>;
  phone?: string;
  location?: string;
}

export interface Evaluation {
  id: string;
  employeeId: string;
  evaluatorId: string;
  type: "360" | "self" | "manager";
  period: string;
  competencies: {
    name: string;
    score: number;
    maxScore: number;
  }[];
  overallScore: number;
  feedback: string;
  date: string;
  status: "pending" | "completed" | "approved";
}

export interface Training {
  id: string;
  title: string;
  description: string;
  category: "technical" | "soft_skills" | "compliance" | "leadership";
  duration: string;
  format: "online" | "presencial" | "hybrid";
  instructor?: string;
  startDate: string;
  endDate?: string;
  status: "not_started" | "in_progress" | "completed" | "expired";
  participants: string[]; // employee IDs
  materials: TrainingMaterial[];
  certificate?: string;
}

export interface TrainingMaterial {
  id: string;
  name: string;
  type: "video" | "pdf" | "quiz" | "presentation";
  url?: string;
  duration?: string;
}

export interface Feedback {
  id: string;
  fromId: string;
  toId: string;
  message: string;
  type: "positive" | "constructive" | "goal";
  competency?: string;
  date: string;
  isPrivate: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  date: string;
  priority: "low" | "medium" | "high";
  departments?: string[];
  attachments?: Document[];
}

// Mock data
export const mockEmployees: Employee[] = [
  {
    id: "1",
    name: "Ana Silva",
    email: "ana.silva@integrerh.com",
    phone: "(11) 99999-0001",
    cpf: "123.456.789-01",
    rg: "12.345.678-9",
    position: "Gerente de RH",
    department: "Recursos Humanos",
    address: "Rua das Flores, 123 - São Paulo, SP",
    joinDate: "2023-01-15",
    ctps: "1234567890",
    salary: 8500,
    status: "active",
    avatar:
      "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
    documents: [
      {
        id: "d1",
        name: "Contrato de Trabalho.pdf",
        type: "contract",
        uploadDate: "2023-01-15",
        size: "245 KB",
      },
      {
        id: "d2",
        name: "RG - Ana Silva.pdf",
        type: "id",
        uploadDate: "2023-01-15",
        size: "180 KB",
      },
    ],
    evaluations: [],
    trainings: [],
    history: [
      {
        id: "h1",
        date: "2023-01-15",
        type: "hire",
        description: "Contratação como Gerente de RH",
        details: {
          reason: "Nova contratação",
          authorizedBy: "Diretoria",
        },
      },
    ],
  },
  {
    id: "2",
    name: "Carlos Mendes",
    email: "carlos.mendes@integrerh.com",
    phone: "(11) 99999-0002",
    cpf: "987.654.321-01",
    rg: "98.765.432-1",
    position: "Gerente de TI",
    department: "Tecnologia",
    address: "Av. Paulista, 456 - São Paulo, SP",
    manager: "1",
    joinDate: "2022-03-10",
    ctps: "0987654321",
    salary: 9200,
    status: "active",
    avatar:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
    documents: [
      {
        id: "d3",
        name: "Contrato de Trabalho.pdf",
        type: "contract",
        uploadDate: "2022-03-10",
        size: "251 KB",
      },
    ],
    evaluations: [],
    trainings: [],
    history: [
      {
        id: "h2",
        date: "2022-03-10",
        type: "hire",
        description: "Contratação como Gerente de TI",
        details: {
          reason: "Nova contratação",
          authorizedBy: "Ana Silva",
        },
      },
    ],
  },
  {
    id: "3",
    name: "Maria Santos",
    email: "maria.santos@integrerh.com",
    phone: "(11) 99999-0003",
    cpf: "456.789.123-01",
    rg: "45.678.912-3",
    position: "Analista de Vendas",
    department: "Vendas",
    address: "Rua Augusta, 789 - São Paulo, SP",
    manager: "2",
    joinDate: "2023-06-20",
    ctps: "4567891230",
    salary: 4500,
    status: "active",
    avatar:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    documents: [],
    evaluations: [],
    trainings: [],
    history: [
      {
        id: "h3",
        date: "2023-06-20",
        type: "hire",
        description: "Contratação como Analista de Vendas",
        details: {
          reason: "Expansão da equipe de vendas",
          authorizedBy: "Carlos Mendes",
        },
      },
    ],
  },
  {
    id: "4",
    name: "Roberto Lima",
    email: "roberto.lima@integrerh.com",
    phone: "(11) 99999-0004",
    cpf: "789.123.456-01",
    rg: "78.912.345-6",
    position: "Desenvolvedor Sênior",
    department: "Tecnologia",
    address: "Rua das Palmeiras, 321 - São Paulo, SP",
    manager: "2",
    joinDate: "2022-08-15",
    ctps: "7891234560",
    salary: 7800,
    status: "active",
    avatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    documents: [],
    evaluations: [],
    trainings: [],
    history: [
      {
        id: "h4",
        date: "2022-08-15",
        type: "hire",
        description: "Contratação como Desenvolvedor Sênior",
        details: {
          reason: "Reforço da equipe de desenvolvimento",
          authorizedBy: "Carlos Mendes",
        },
      },
    ],
  },
  {
    id: "5",
    name: "Julia Costa",
    email: "julia.costa@integrerh.com",
    phone: "(11) 99999-0005",
    cpf: "321.654.987-01",
    rg: "32.165.498-7",
    position: "Designer UX",
    department: "Produto",
    address: "Alameda Santos, 654 - São Paulo, SP",
    manager: "2",
    joinDate: "2023-02-01",
    ctps: "3216549870",
    salary: 6200,
    status: "on_leave",
    avatar:
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face",
    documents: [],
    evaluations: [],
    trainings: [],
    history: [
      {
        id: "h5",
        date: "2023-02-01",
        type: "hire",
        description: "Contratação como Designer UX",
        details: {
          reason: "Criação da área de produto",
          authorizedBy: "Carlos Mendes",
        },
      },
      {
        id: "h6",
        date: "2024-01-10",
        type: "status_change",
        description: "Colaboradora em licença maternidade",
        details: {
          oldValue: "active",
          newValue: "on_leave",
          reason: "Licença maternidade",
          authorizedBy: "Ana Silva",
        },
      },
    ],
  },
];

export const mockJobs: Job[] = [
  {
    id: "j1",
    title: "Desenvolvedor Full Stack",
    department: "Tecnologia",
    description:
      "Responsável pelo desenvolvimento de aplicações web utilizando React, Node.js e PostgreSQL.",
    requirements: ["React", "Node.js", "PostgreSQL", "3+ anos de experiência"],
    benefits: ["Vale refeição", "Plano de saúde", "Home office flexível"],
    salary: "R$ 6.000 - R$ 8.000",
    type: "full_time",
    status: "open",
    createdDate: "2024-01-15",
    applications: [
      {
        id: "a1",
        jobId: "j1",
        candidateName: "Pedro Silva",
        candidateEmail: "pedro.silva@email.com",
        phone: "(11) 98765-4321",
        location: "São Paulo, SP",
        status: "technical_test",
        appliedDate: "2024-01-16",
        currentStage: 3,
        stageHistory: [
          {
            stage: "Aplicação Recebida",
            date: "2024-01-16",
            notes: "Candidato aplicou para a vaga",
          },
          {
            stage: "Triagem de Currículo",
            date: "2024-01-17",
            notes: "Currículo aprovado na triagem inicial",
            evaluator: "Ana Silva",
          },
          {
            stage: "Entrevista por Telefone",
            date: "2024-01-18",
            notes:
              "Entrevista inicial aprovada. Candidato demonstrou boa comunicaç��o.",
            evaluator: "Carlos Mendes",
          },
          {
            stage: "Teste Técnico",
            date: "2024-01-20",
            notes: "Em andamento - Teste de desenvolvimento React/Node.js",
            evaluator: "João Santos",
          },
        ],
        notes:
          "Candidato com experiência sólida em desenvolvimento. Aguardando resultado do teste técnico.",
      },
      {
        id: "a2",
        jobId: "j1",
        candidateName: "Maria Oliveira",
        candidateEmail: "maria.oliveira@email.com",
        phone: "(11) 91234-5678",
        location: "São Paulo, SP",
        status: "screening",
        appliedDate: "2024-01-18",
        currentStage: 1,
        stageHistory: [
          {
            stage: "Aplicação Recebida",
            date: "2024-01-18",
            notes: "Candidata aplicou para a vaga",
          },
          {
            stage: "Triagem de Currículo",
            date: "2024-01-19",
            notes: "Em análise - Verificando experiência em React",
            evaluator: "Ana Silva",
          },
        ],
        notes: "Candidata com experiência em frontend. Em análise inicial.",
      },
    ],
  },
  {
    id: "j2",
    title: "Analista de Marketing",
    department: "Marketing",
    description:
      "Desenvolver e executar estratégias de marketing digital para aumentar o engajamento.",
    requirements: ["Marketing Digital", "Google Analytics", "Redes Sociais"],
    benefits: ["Vale refeição", "Plano de saúde"],
    salary: "R$ 4.000 - R$ 5.500",
    type: "full_time",
    status: "open",
    createdDate: "2024-01-10",
    applications: [
      {
        id: "a3",
        jobId: "j2",
        candidateName: "Carlos Roberto",
        candidateEmail: "carlos.roberto@email.com",
        phone: "(11) 95555-5555",
        location: "São Paulo, SP",
        status: "pending",
        appliedDate: "2024-01-20",
        currentStage: 0,
        stageHistory: [
          {
            stage: "Aplicação Recebida",
            date: "2024-01-20",
            notes: "Candidato aplicou para a vaga",
          },
        ],
        notes: "Candidato recém aplicado, aguardando análise inicial.",
      },
    ],
  },
];

export const mockTrainings: Training[] = [
  {
    id: "t1",
    title: "Liderança e Gestão de Equipes",
    description:
      "Curso completo sobre técnicas de liderança e gestão de pessoas.",
    category: "leadership",
    duration: "20 horas",
    format: "online",
    instructor: "Dra. Fernanda Alves",
    startDate: "2024-02-01",
    endDate: "2024-02-15",
    status: "in_progress",
    participants: ["1", "2"],
    materials: [
      {
        id: "m1",
        name: "Introdução à Liderança",
        type: "video",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        duration: "45 min",
      },
      {
        id: "m2",
        name: "Manual de Gestão",
        type: "pdf",
        url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
        duration: "15 min",
      },
      {
        id: "m3",
        name: "Técnicas de Comunica��ão",
        type: "video",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        duration: "30 min",
      },
      {
        id: "m4",
        name: "Quiz de Liderança",
        type: "quiz",
        duration: "10 min",
      },
    ],
  },
  {
    id: "t2",
    title: "Segurança da Informação",
    description: "Treinamento obrigatório sobre políticas de segurança.",
    category: "compliance",
    duration: "8 horas",
    format: "online",
    startDate: "2024-01-20",
    endDate: "2024-01-25",
    status: "completed",
    participants: ["1", "2", "3", "4", "5"],
    materials: [
      {
        id: "m5",
        name: "Fundamentos de Segurança",
        type: "video",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        duration: "25 min",
      },
      {
        id: "m6",
        name: "Políticas de Senha",
        type: "pdf",
        url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
        duration: "10 min",
      },
      {
        id: "m7",
        name: "Teste de Conhecimento",
        type: "quiz",
        duration: "15 min",
      },
    ],
  },
  {
    id: "t3",
    title: "Desenvolvimento Web Moderno",
    description:
      "Curso completo de desenvolvimento web com React, TypeScript e Node.js.",
    category: "technical",
    duration: "40 horas",
    format: "online",
    instructor: "Prof. João Santos",
    startDate: "2024-02-10",
    endDate: "2024-03-10",
    status: "not_started",
    participants: ["1", "3"],
    materials: [
      {
        id: "m8",
        name: "Introdução ao React",
        type: "video",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        duration: "60 min",
      },
      {
        id: "m9",
        name: "TypeScript Fundamentals",
        type: "video",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        duration: "45 min",
      },
      {
        id: "m10",
        name: "Documentação React",
        type: "pdf",
        url: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
        duration: "30 min",
      },
      {
        id: "m11",
        name: "Hooks Avançados",
        type: "video",
        url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        duration: "50 min",
      },
      {
        id: "m12",
        name: "Avaliação Final",
        type: "quiz",
        duration: "20 min",
      },
    ],
  },
];

export const mockEvaluations: Evaluation[] = [
  {
    id: "e1",
    employeeId: "3",
    evaluatorId: "2",
    type: "manager",
    period: "2024 - Q1",
    competencies: [
      { name: "Comunicação", score: 8, maxScore: 10 },
      { name: "Trabalho em Equipe", score: 9, maxScore: 10 },
      { name: "Proatividade", score: 7, maxScore: 10 },
      { name: "Conhecimento Técnico", score: 8, maxScore: 10 },
    ],
    overallScore: 8.0,
    feedback:
      "Maria tem demonstrado excelente desempenho na área de vendas. Recomendo investir em treinamentos técnicos.",
    date: "2024-01-30",
    status: "completed",
  },
];

export const mockFeedbacks: Feedback[] = [
  {
    id: "f1",
    fromId: "2",
    toId: "3",
    message:
      "Excelente trabalho na apresentação do projeto! Muito bem estruturada e clara.",
    type: "positive",
    competency: "Comunicação",
    date: "2024-01-25",
    isPrivate: false,
  },
  {
    id: "f2",
    fromId: "1",
    toId: "2",
    message:
      "Sugiro melhorar a organização do tempo nas reuniões para ser mais eficiente.",
    type: "constructive",
    competency: "Gestão de Tempo",
    date: "2024-01-22",
    isPrivate: true,
  },
];

export const mockAnnouncements: Announcement[] = [
  {
    id: "an1",
    title: "Nova Política de Home Office",
    content:
      "A partir de fevereiro, todos os colaboradores poderão trabalhar até 3 dias por semana em home office. Consulte o manual para mais detalhes.",
    author: "Ana Silva",
    date: "2024-01-20",
    priority: "high",
    departments: ["Todos"],
  },
  {
    id: "an2",
    title: "Treinamento Obrigatório de Segurança",
    content:
      "Todos os colaboradores devem completar o treinamento de segurança da informação até o final do mês.",
    author: "Ana Silva",
    date: "2024-01-18",
    priority: "medium",
    departments: ["Todos"],
  },
];

// Enhanced storage with persistence simulation
class DataStorage {
  private static instance: DataStorage;
  private data: any = {};

  static getInstance(): DataStorage {
    if (!DataStorage.instance) {
      DataStorage.instance = new DataStorage();
    }
    return DataStorage.instance;
  }

  set(key: string, value: any): void {
    this.data[key] = value;
    // Simular persistência local
    if (typeof localStorage !== "undefined") {
      try {
        localStorage.setItem(`integrerh_${key}`, JSON.stringify(value));
      } catch (error) {
        console.warn("Failed to save to localStorage:", error);
      }
    }
  }

  get(key: string, defaultValue: any = null): any {
    // Primeiro tenta buscar da memória
    if (this.data[key] !== undefined) {
      return this.data[key];
    }

    // Depois tenta buscar do localStorage
    if (typeof localStorage !== "undefined") {
      try {
        const stored = localStorage.getItem(`integrerh_${key}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          this.data[key] = parsed;
          return parsed;
        }
      } catch (error) {
        console.warn("Failed to load from localStorage:", error);
      }
    }

    return defaultValue;
  }

  clear(): void {
    this.data = {};
    if (typeof localStorage !== "undefined") {
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith("integrerh_")) {
          localStorage.removeItem(key);
        }
      });
    }
  }
}

// Data access functions with enhanced integration
export class MockDataStore {
  private static storage = DataStorage.getInstance();

  // Initialize data with persistence
  static initializeData(): void {
    const storedEmployees = this.storage.get("employees", mockEmployees);
    const storedJobs = this.storage.get("jobs", mockJobs);
    const storedTrainings = this.storage.get("trainings", mockTrainings);
    const storedEvaluations = this.storage.get("evaluations", mockEvaluations);
    const storedFeedbacks = this.storage.get("feedbacks", mockFeedbacks);
    const storedAnnouncements = this.storage.get(
      "announcements",
      mockAnnouncements,
    );

    // Update arrays with stored data
    mockEmployees.length = 0;
    mockEmployees.push(...storedEmployees);

    mockJobs.length = 0;
    mockJobs.push(...storedJobs);

    mockTrainings.length = 0;
    mockTrainings.push(...storedTrainings);

    mockEvaluations.length = 0;
    mockEvaluations.push(...storedEvaluations);

    mockFeedbacks.length = 0;
    mockFeedbacks.push(...storedFeedbacks);

    mockAnnouncements.length = 0;
    mockAnnouncements.push(...storedAnnouncements);
  }

  // Save data to persistence
  static saveData(): void {
    this.storage.set("employees", mockEmployees);
    this.storage.set("jobs", mockJobs);
    this.storage.set("trainings", mockTrainings);
    this.storage.set("evaluations", mockEvaluations);
    this.storage.set("feedbacks", mockFeedbacks);
    this.storage.set("announcements", mockAnnouncements);
  }

  // Get comprehensive employee profile with all related data
  static getEmployeeProfile(employeeId: string): {
    employee: Employee | undefined;
    evaluations: Evaluation[];
    feedbacks: Feedback[];
    trainings: Training[];
    recentActivities: any[];
  } | null {
    const employee = mockEmployees.find((emp) => emp.id === employeeId);
    if (!employee) return null;

    const evaluations = mockEvaluations.filter(
      (evaluation) => evaluation.employeeId === employeeId,
    );
    const feedbacks = mockFeedbacks.filter(
      (fb) => fb.toId === employeeId || fb.fromId === employeeId,
    );
    const trainings = mockTrainings.filter((training) =>
      training.participants.includes(employeeId),
    );

    // Create activity timeline
    const recentActivities = [
      ...evaluations.map((evaluation) => ({
        type: "evaluation",
        date: evaluation.date,
        description: `Avaliação ${evaluation.type} realizada`,
        details: evaluation,
      })),
      ...feedbacks.map((fb) => ({
        type: "feedback",
        date: fb.date,
        description:
          fb.fromId === employeeId ? "Feedback enviado" : "Feedback recebido",
        details: fb,
      })),
      ...trainings.map((training) => ({
        type: "training",
        date: training.startDate,
        description: `Participação no treinamento: ${training.title}`,
        details: training,
      })),
    ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return {
      employee,
      evaluations,
      feedbacks,
      trainings,
      recentActivities: recentActivities.slice(0, 10), // Last 10 activities
    };
  }

  // Get cross-module statistics
  static getCrossModuleStats(): {
    employees: any;
    performance: any;
    training: any;
    communication: any;
  } {
    const activeEmployees = mockEmployees.filter(
      (emp) => emp.status === "active",
    );

    return {
      employees: {
        total: mockEmployees.length,
        active: activeEmployees.length,
        withDocuments: mockEmployees.filter((emp) => emp.documents.length > 0)
          .length,
        averageDocuments:
          mockEmployees.reduce((acc, emp) => acc + emp.documents.length, 0) /
          mockEmployees.length,
      },
      performance: {
        totalEvaluations: mockEvaluations.length,
        averageScore:
          mockEvaluations.reduce(
            (acc, evaluation) => acc + evaluation.overallScore,
            0,
          ) / mockEvaluations.length,
        completedEvaluations: mockEvaluations.filter(
          (evaluation) => evaluation.status === "completed",
        ).length,
        pendingEvaluations: mockEvaluations.filter(
          (evaluation) => evaluation.status === "pending",
        ).length,
      },
      training: {
        totalTrainings: mockTrainings.length,
        activeTrainings: mockTrainings.filter(
          (training) => training.status === "in_progress",
        ).length,
        completedTrainings: mockTrainings.filter(
          (training) => training.status === "completed",
        ).length,
        totalParticipants: mockTrainings.reduce(
          (acc, training) => acc + training.participants.length,
          0,
        ),
      },
      communication: {
        totalAnnouncements: mockAnnouncements.length,
        highPriority: mockAnnouncements.filter((ann) => ann.priority === "high")
          .length,
        totalFeedbacks: mockFeedbacks.length,
        recentFeedbacks: mockFeedbacks.filter(
          (fb) =>
            new Date(fb.date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        ).length,
      },
    };
  }

  // Employees
  static getEmployees(): Employee[] {
    // Ensure all employees have history array initialized
    return mockEmployees.map(employee => ({
      ...employee,
      history: Array.isArray(employee.history) ? employee.history : []
    }));
  }

  static getEmployee(id: string): Employee | undefined {
    const employee = mockEmployees.find((emp) => emp.id === id);
    if (employee && !Array.isArray(employee.history)) {
      employee.history = [];
    }
    return employee;
  }

  static updateEmployee(id: string, data: Partial<Employee>): boolean {
    const index = mockEmployees.findIndex((emp) => emp.id === id);
    if (index !== -1) {
      mockEmployees[index] = { ...mockEmployees[index], ...data };
      this.saveData(); // Auto-save
      return true;
    }
    return false;
  }

  static addEmployee(employee: Omit<Employee, "id">): Employee {
    const newEmployee = {
      ...employee,
      id: `emp_${Date.now()}`,
      history: Array.isArray(employee.history) ? employee.history : []
    };
    mockEmployees.push(newEmployee);
    this.saveData(); // Auto-save
    return newEmployee;
  }

  static deleteEmployee(id: string): boolean {
    const index = mockEmployees.findIndex((emp) => emp.id === id);
    if (index !== -1) {
      mockEmployees.splice(index, 1);
      this.saveData(); // Auto-save
      return true;
    }
    return false;
  }

  // Jobs
  static getJobs(): Job[] {
    return mockJobs;
  }

  static getJob(id: string): Job | undefined {
    return mockJobs.find((job) => job.id === id);
  }

  static addJob(job: Omit<Job, "id">): Job {
    const newJob = { ...job, id: `job_${Date.now()}` };
    mockJobs.push(newJob);
    this.saveData(); // Auto-save
    return newJob;
  }

  static updateJob(id: string, data: Partial<Job>): boolean {
    const index = mockJobs.findIndex((job) => job.id === id);
    if (index !== -1) {
      mockJobs[index] = { ...mockJobs[index], ...data };
      this.saveData(); // Auto-save
      return true;
    }
    return false;
  }

  // Trainings
  static getTrainings(): Training[] {
    return mockTrainings;
  }

  static getTraining(id: string): Training | undefined {
    return mockTrainings.find((training) => training.id === id);
  }

  static addTraining(training: Omit<Training, "id">): Training {
    const newTraining = { ...training, id: `training_${Date.now()}` };
    mockTrainings.push(newTraining);
    this.saveData(); // Auto-save
    return newTraining;
  }

  // Evaluations
  static getEvaluations(): Evaluation[] {
    return mockEvaluations;
  }

  static getEvaluationsByEmployee(employeeId: string): Evaluation[] {
    return mockEvaluations.filter(
      (evaluation) => evaluation.employeeId === employeeId,
    );
  }

  static addEvaluation(evaluation: Omit<Evaluation, "id">): Evaluation {
    const newEvaluation = { ...evaluation, id: `eval_${Date.now()}` };
    mockEvaluations.push(newEvaluation);
    this.saveData(); // Auto-save
    return newEvaluation;
  }

  // Feedbacks
  static getFeedbacks(): Feedback[] {
    return mockFeedbacks;
  }

  static getFeedbacksByEmployee(employeeId: string): Feedback[] {
    return mockFeedbacks.filter((feedback) => feedback.toId === employeeId);
  }

  static addFeedback(feedback: Omit<Feedback, "id">): Feedback {
    const newFeedback = { ...feedback, id: `feedback_${Date.now()}` };
    mockFeedbacks.push(newFeedback);
    this.saveData(); // Auto-save
    return newFeedback;
  }

  // Announcements
  static getAnnouncements(): Announcement[] {
    return mockAnnouncements;
  }

  static addAnnouncement(announcement: Omit<Announcement, "id">): Announcement {
    const newAnnouncement = { ...announcement, id: `ann_${Date.now()}` };
    mockAnnouncements.push(newAnnouncement);
    this.saveData(); // Auto-save
    return newAnnouncement;
  }

  // Documents
  static addDocument(
    employeeId: string,
    document: Omit<Document, "id">,
  ): boolean {
    const employee = this.getEmployee(employeeId);
    if (employee) {
      const newDocument = { ...document, id: `doc_${Date.now()}` };
      employee.documents.push(newDocument);
      this.saveData(); // Auto-save
      return true;
    }
    return false;
  }

  static deleteDocument(employeeId: string, documentId: string): boolean {
    const employee = this.getEmployee(employeeId);
    if (employee) {
      const index = employee.documents.findIndex(
        (doc) => doc.id === documentId,
      );
      if (index !== -1) {
        employee.documents.splice(index, 1);
        this.saveData(); // Auto-save
        return true;
      }
    }
    return false;
  }
}

// Initialize data on module load
MockDataStore.initializeData();

// Import and use integrated database
import { database } from "./database";

// Updated MockDataStore to use integrated database
export class IntegratedDataStore {
  // Initialize with existing data if database is empty
  static initializeData(): void {
    const existingEmployees = database.getEmployees();
    console.log(
      "IntegratedDataStore.initializeData() called, existing employees:",
      existingEmployees.length,
    );
    if (existingEmployees.length === 0) {
      console.log("Initializing database with mock data...");
      console.log("Mock jobs to add:", mockJobs.length);
      // Migrate mock data to database
      mockEmployees.forEach((emp) => database.addEmployee(emp));
      mockJobs.forEach((job) => database.addJob(job));
      mockTrainings.forEach((training) => database.addTraining(training));
      mockEvaluations.forEach((evaluation) =>
        database.addEvaluation(evaluation),
      );
      mockFeedbacks.forEach((feedback) => database.addFeedback(feedback));
      mockAnnouncements.forEach((ann) => database.addAnnouncement(ann));
    }
  }

  // Employees
  static getEmployees(): Employee[] {
    return database.getEmployees();
  }

  static getEmployee(id: string): Employee | undefined {
    return database.getEmployee(id);
  }

  static addEmployee(employee: Omit<Employee, "id">): Employee {
    return database.addEmployee(employee);
  }

  static updateEmployee(id: string, data: Partial<Employee>): boolean {
    return database.updateEmployee(id, data);
  }

  static deleteEmployee(id: string): boolean {
    // Implementation for deletion with events
    const employees = database.getEmployees();
    const employee = employees.find((emp) => emp.id === id);
    if (employee) {
      // Remove from database array
      const updatedEmployees = employees.filter((emp) => emp.id !== id);
      database.set("employees", updatedEmployees);
      return true;
    }
    return false;
  }

  // Jobs
  static getJobs(): Job[] {
    this.initializeData(); // Ensure data is initialized
    const jobs = database.getJobs();
    console.log(
      "IntegratedDataStore.getJobs() called, found:",
      jobs.length,
      "jobs",
    );
    return jobs;
  }

  static getJob(id: string): Job | undefined {
    return database.getJob(id);
  }

  static addJob(job: Omit<Job, "id">): Job {
    return database.addJob(job);
  }

  static updateJob(id: string, data: Partial<Job>): boolean {
    const jobs = database.getJobs();
    const index = jobs.findIndex((job) => job.id === id);
    if (index !== -1) {
      jobs[index] = { ...jobs[index], ...data };
      database.set("jobs", jobs);
      return true;
    }
    return false;
  }

  static addApplicationToJob(
    jobId: string,
    application: Omit<JobApplication, "id" | "jobId">,
  ): boolean {
    const jobs = database.getJobs();
    const jobIndex = jobs.findIndex((job) => job.id === jobId);
    if (jobIndex !== -1) {
      const newApplication: JobApplication = {
        ...application,
        id: `app_${Date.now()}`,
        jobId,
        status: "pending", // Start at first stage
        currentStage: 0,
        stageHistory: [
          {
            stage: "Aplicação Recebida",
            date: new Date().toISOString(),
            notes: "Candidato aplicou para a vaga",
          },
        ],
      };

      jobs[jobIndex].applications.push(newApplication);
      database.set("jobs", jobs);
      return true;
    }
    return false;
  }

  // Trainings
  static getTrainings(): Training[] {
    return database.getTrainings();
  }

  static getTraining(id: string): Training | undefined {
    return database.getTraining(id);
  }

  static addTraining(training: Omit<Training, "id">): Training {
    return database.addTraining(training);
  }

  static enrollInTraining(trainingId: string, userId: string): boolean {
    return database.enrollInTraining(trainingId, userId);
  }

  static updateTraining(trainingId: string, updates: Partial<Training>): boolean {
    return database.updateTraining(trainingId, updates);
  }

  // Evaluations
  static getEvaluations(): Evaluation[] {
    return database.getEvaluations();
  }

  static getEvaluationsByEmployee(employeeId: string): Evaluation[] {
    return database
      .getEvaluations()
      .filter((evaluation) => evaluation.employeeId === employeeId);
  }

  static addEvaluation(evaluation: Omit<Evaluation, "id">): Evaluation {
    return database.addEvaluation(evaluation);
  }

  // Feedbacks
  static getFeedbacks(): Feedback[] {
    return database.getFeedbacks();
  }

  static getFeedbacksByEmployee(employeeId: string): Feedback[] {
    return database
      .getFeedbacks()
      .filter((feedback) => feedback.toId === employeeId);
  }

  static addFeedback(feedback: Omit<Feedback, "id">): Feedback {
    return database.addFeedback(feedback);
  }

  // Announcements
  static getAnnouncements(): Announcement[] {
    return database.getAnnouncements();
  }

  static addAnnouncement(announcement: Omit<Announcement, "id">): Announcement {
    return database.addAnnouncement(announcement);
  }

  // Documents
  static addDocument(
    employeeId: string,
    document: Omit<Document, "id">,
  ): boolean {
    return database.addDocument(employeeId, document);
  }

  static addDocumentToEmployee(
    employeeId: string,
    document: Document,
  ): boolean {
    const employee = database.getEmployee(employeeId);
    if (employee) {
      employee.documents.push(document);
      database.updateEmployee(employeeId, employee);
      return true;
    }
    return false;
  }

  static deleteDocument(employeeId: string, documentId: string): boolean {
    const employee = database.getEmployee(employeeId);
    if (employee) {
      const index = employee.documents.findIndex(
        (doc) => doc.id === documentId,
      );
      if (index !== -1) {
        employee.documents.splice(index, 1);
        database.updateEmployee(employeeId, employee);
        return true;
      }
    }
    return false;
  }

  // Cross-module methods
  static getCrossModuleStats(): any {
    return database.getCrossModuleStats();
  }

  static getEmployeeProfile(employeeId: string): any {
    return database.getEmployeeComprehensiveProfile(employeeId);
  }

  static getNotifications(userId: string): any[] {
    return database.getNotifications(userId);
  }

  static markNotificationAsRead(notificationId: string): void {
    database.markNotificationAsRead(notificationId);
  }

  static getActivityLog(
    userId?: string,
    module?: string,
    limit?: number,
  ): any[] {
    return database.getActivityLog(userId, module, limit);
  }

  // Keep original methods for backward compatibility
  static saveData(): void {
    // Data is automatically saved in the new database
  }

  static getEmployeeProfile_OLD = MockDataStore.getEmployeeProfile;
  static getCrossModuleStats_OLD = MockDataStore.getCrossModuleStats;
}

// Initialize integrated database
IntegratedDataStore.initializeData();
