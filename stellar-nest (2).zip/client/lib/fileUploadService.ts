// Integre RH - Serviço de Upload de Arquivos
// Sistema completo de upload, gestão e processamento de arquivos

import { supabase, STORAGE_BUCKETS, uploadFile, deleteFile, getFileUrl } from './supabase';
import { integrationManager } from './integrations';

// =============================================================================
// TIPOS E INTERFACES
// =============================================================================

export interface FileUploadOptions {
  bucket?: keyof typeof STORAGE_BUCKETS;
  folder?: string;
  filename?: string;
  allowedTypes?: string[];
  maxSize?: number; // em bytes
  createThumbnail?: boolean;
  notifyUpload?: boolean;
}

export interface UploadResult {
  success: boolean;
  url?: string;
  path?: string;
  filename?: string;
  size?: number;
  type?: string;
  error?: string;
}

export interface FileMetadata {
  id: string;
  originalName: string;
  filename: string;
  path: string;
  url: string;
  size: number;
  type: string;
  bucket: string;
  folder?: string;
  uploadedBy: string;
  uploadedAt: Date;
  isPublic: boolean;
  metadata?: Record<string, any>;
}

// =============================================================================
// CONFIGURAÇÕES E VALIDAÇÕES
// =============================================================================

const FILE_TYPES = {
  IMAGES: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  DOCUMENTS: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  SPREADSHEETS: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
  PRESENTATIONS: ['application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
  VIDEOS: ['video/mp4', 'video/avi', 'video/quicktime', 'video/x-msvideo'],
  AUDIO: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
};

const MAX_FILE_SIZES = {
  IMAGE: 5 * 1024 * 1024, // 5MB
  DOCUMENT: 25 * 1024 * 1024, // 25MB
  VIDEO: 100 * 1024 * 1024, // 100MB
  AUDIO: 50 * 1024 * 1024, // 50MB
  DEFAULT: 10 * 1024 * 1024, // 10MB
};

// =============================================================================
// UTILITÁRIOS
// =============================================================================

export function validateFile(
  file: File,
  allowedTypes?: string[],
  maxSize?: number
): { valid: boolean; error?: string } {
  // Validar tipo
  if (allowedTypes && !allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: `Tipo de arquivo não permitido. Tipos aceitos: ${allowedTypes.join(', ')}`
    };
  }

  // Validar tamanho
  const sizeLimit = maxSize || MAX_FILE_SIZES.DEFAULT;
  if (file.size > sizeLimit) {
    const sizeMB = (sizeLimit / 1024 / 1024).toFixed(1);
    return {
      valid: false,
      error: `Arquivo muito grande. Tamanho máximo: ${sizeMB}MB`
    };
  }

  return { valid: true };
}

export function generateUniqueFilename(originalName: string): string {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8);
  const extension = originalName.split('.').pop();
  const baseName = originalName.split('.').slice(0, -1).join('.');
  
  return `${baseName}_${timestamp}_${random}.${extension}`;
}

export function getFileCategory(mimeType: string): string {
  if (FILE_TYPES.IMAGES.includes(mimeType)) return 'image';
  if (FILE_TYPES.DOCUMENTS.includes(mimeType)) return 'document';
  if (FILE_TYPES.SPREADSHEETS.includes(mimeType)) return 'spreadsheet';
  if (FILE_TYPES.PRESENTATIONS.includes(mimeType)) return 'presentation';
  if (FILE_TYPES.VIDEOS.includes(mimeType)) return 'video';
  if (FILE_TYPES.AUDIO.includes(mimeType)) return 'audio';
  return 'other';
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// =============================================================================
// SERVIÇO PRINCIPAL DE UPLOAD
// =============================================================================

export class FileUploadService {
  private static instance: FileUploadService;

  static getInstance(): FileUploadService {
    if (!FileUploadService.instance) {
      FileUploadService.instance = new FileUploadService();
    }
    return FileUploadService.instance;
  }

  async uploadFile(
    file: File,
    options: FileUploadOptions = {}
  ): Promise<UploadResult> {
    try {
      // Configurações padrão
      const {
        bucket = 'DOCUMENTS',
        folder = 'general',
        filename,
        allowedTypes,
        maxSize,
        createThumbnail = false,
        notifyUpload = false
      } = options;

      // Validar arquivo
      const validation = validateFile(file, allowedTypes, maxSize);
      if (!validation.valid) {
        return {
          success: false,
          error: validation.error
        };
      }

      // Gerar nome único do arquivo
      const uniqueFilename = filename || generateUniqueFilename(file.name);
      const filePath = folder ? `${folder}/${uniqueFilename}` : uniqueFilename;
      const bucketName = STORAGE_BUCKETS[bucket];

      // Fazer upload
      const { url, error } = await uploadFile(bucketName, filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

      if (error) {
        return {
          success: false,
          error: `Falha no upload: ${error.message}`
        };
      }

      // Salvar metadados no banco
      const metadata: Omit<FileMetadata, 'id'> = {
        originalName: file.name,
        filename: uniqueFilename,
        path: filePath,
        url: url!,
        size: file.size,
        type: file.type,
        bucket: bucketName,
        folder,
        uploadedBy: 'current_user', // TODO: pegar do contexto de auth
        uploadedAt: new Date(),
        isPublic: true,
        metadata: {
          category: getFileCategory(file.type),
          uploadedFromIP: await this.getClientIP(),
        }
      };

      // TODO: Salvar no banco de dados
      // await this.saveFileMetadata(metadata);

      // Criar thumbnail se necessário
      if (createThumbnail && FILE_TYPES.IMAGES.includes(file.type)) {
        await this.createThumbnail(file, filePath, bucketName);
      }

      // Enviar notificação se necessário
      if (notifyUpload) {
        await this.notifyFileUpload(metadata);
      }

      return {
        success: true,
        url: url!,
        path: filePath,
        filename: uniqueFilename,
        size: file.size,
        type: file.type
      };

    } catch (error) {
      return {
        success: false,
        error: `Erro inesperado: ${error}`
      };
    }
  }

  async uploadMultipleFiles(
    files: File[],
    options: FileUploadOptions = {}
  ): Promise<UploadResult[]> {
    const results: UploadResult[] = [];

    for (const file of files) {
      const result = await this.uploadFile(file, options);
      results.push(result);

      // Pequena pausa entre uploads para não sobrecarregar
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    return results;
  }

  async deleteFile(filePath: string, bucket: keyof typeof STORAGE_BUCKETS = 'DOCUMENTS'): Promise<{ success: boolean; error?: string }> {
    try {
      const bucketName = STORAGE_BUCKETS[bucket];
      const { success, error } = await deleteFile(bucketName, filePath);

      if (!success) {
        return {
          success: false,
          error: error?.message || 'Falha ao deletar arquivo'
        };
      }

      // TODO: Remover metadados do banco
      // await this.deleteFileMetadata(filePath);

      return { success: true };

    } catch (error) {
      return {
        success: false,
        error: `Erro ao deletar: ${error}`
      };
    }
  }

  getFileUrl(filePath: string, bucket: keyof typeof STORAGE_BUCKETS = 'DOCUMENTS'): string {
    const bucketName = STORAGE_BUCKETS[bucket];
    return getFileUrl(bucketName, filePath);
  }

  async createThumbnail(file: File, originalPath: string, bucket: string): Promise<void> {
    try {
      // Criar canvas para redimensionar imagem
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      return new Promise((resolve) => {
        img.onload = async () => {
          // Definir tamanho do thumbnail
          const maxSize = 200;
          let { width, height } = img;

          if (width > height) {
            if (width > maxSize) {
              height = (height * maxSize) / width;
              width = maxSize;
            }
          } else {
            if (height > maxSize) {
              width = (width * maxSize) / height;
              height = maxSize;
            }
          }

          canvas.width = width;
          canvas.height = height;

          // Desenhar imagem redimensionada
          ctx?.drawImage(img, 0, 0, width, height);

          // Converter para blob
          canvas.toBlob(async (blob) => {
            if (blob) {
              const thumbnailPath = originalPath.replace(/(\.[^.]+)$/, '_thumb$1');
              await uploadFile(bucket, thumbnailPath, new File([blob], 'thumbnail.jpg'));
            }
            resolve();
          }, 'image/jpeg', 0.8);
        };

        img.src = URL.createObjectURL(file);
      });
    } catch (error) {
      console.error('Erro ao criar thumbnail:', error);
    }
  }

  private async getClientIP(): Promise<string> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      return 'unknown';
    }
  }

  private async notifyFileUpload(metadata: Omit<FileMetadata, 'id'>): Promise<void> {
    try {
      await integrationManager.notifications.sendNotification(metadata.uploadedBy, {
        type: 'success',
        title: 'Upload Concluído',
        message: `Arquivo "${metadata.originalName}" foi enviado com sucesso`,
        related_module: 'files',
        related_id: metadata.path,
      });
    } catch (error) {
      console.error('Erro ao enviar notificação de upload:', error);
    }
  }

  // Métodos para diferentes tipos de upload específicos
  async uploadProfileAvatar(file: File, userId: string): Promise<UploadResult> {
    return this.uploadFile(file, {
      bucket: 'AVATARS',
      folder: 'profiles',
      filename: `avatar_${userId}_${Date.now()}.${file.name.split('.').pop()}`,
      allowedTypes: FILE_TYPES.IMAGES,
      maxSize: MAX_FILE_SIZES.IMAGE,
      createThumbnail: true,
      notifyUpload: false
    });
  }

  async uploadEmployeeDocument(file: File, employeeId: string, documentType: string): Promise<UploadResult> {
    return this.uploadFile(file, {
      bucket: 'DOCUMENTS',
      folder: `employees/${employeeId}/${documentType}`,
      allowedTypes: [...FILE_TYPES.DOCUMENTS, ...FILE_TYPES.IMAGES],
      maxSize: MAX_FILE_SIZES.DOCUMENT,
      notifyUpload: true
    });
  }

  async uploadTrainingMaterial(file: File, trainingId: string): Promise<UploadResult> {
    const category = getFileCategory(file.type);
    const allowedTypes = [
      ...FILE_TYPES.DOCUMENTS,
      ...FILE_TYPES.VIDEOS,
      ...FILE_TYPES.AUDIO,
      ...FILE_TYPES.PRESENTATIONS
    ];

    return this.uploadFile(file, {
      bucket: category === 'video' ? 'VIDEOS' : 'DOCUMENTS',
      folder: `trainings/${trainingId}`,
      allowedTypes,
      maxSize: category === 'video' ? MAX_FILE_SIZES.VIDEO : MAX_FILE_SIZES.DOCUMENT,
      notifyUpload: true
    });
  }

  async uploadJobApplicationResume(file: File, applicationId: string): Promise<UploadResult> {
    return this.uploadFile(file, {
      bucket: 'DOCUMENTS',
      folder: `applications/${applicationId}`,
      allowedTypes: FILE_TYPES.DOCUMENTS,
      maxSize: MAX_FILE_SIZES.DOCUMENT,
      notifyUpload: false
    });
  }
}

// =============================================================================
// COMPONENTES REACT HOOKS
// =============================================================================

export function useFileUpload() {
  const uploadService = FileUploadService.getInstance();

  const upload = async (
    file: File,
    options?: FileUploadOptions
  ): Promise<UploadResult> => {
    return uploadService.uploadFile(file, options);
  };

  const uploadMultiple = async (
    files: File[],
    options?: FileUploadOptions
  ): Promise<UploadResult[]> => {
    return uploadService.uploadMultipleFiles(files, options);
  };

  const deleteFile = async (
    filePath: string,
    bucket?: keyof typeof STORAGE_BUCKETS
  ): Promise<{ success: boolean; error?: string }> => {
    return uploadService.deleteFile(filePath, bucket);
  };

  const getUrl = (
    filePath: string,
    bucket?: keyof typeof STORAGE_BUCKETS
  ): string => {
    return uploadService.getFileUrl(filePath, bucket);
  };

  return {
    upload,
    uploadMultiple,
    deleteFile,
    getUrl,
    validateFile,
    formatFileSize,
    FILE_TYPES,
    MAX_FILE_SIZES
  };
}

// Export singleton
export const fileUploadService = FileUploadService.getInstance();

// Export constants and utilities for direct use
export { FILE_TYPES, MAX_FILE_SIZES };
