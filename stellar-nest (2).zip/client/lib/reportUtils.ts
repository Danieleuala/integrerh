import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export interface ReportConfig {
  moduleId: string;
  format: 'pdf' | 'xlsx';
  title: string;
  description?: string;
  dateRange: {
    start?: string;
    end?: string;
  };
  filters: Record<string, any>;
  fields: string[];
  groupBy?: string;
  sortBy?: string;
  sortOrder: 'asc' | 'desc';
}

export interface ReportData {
  config: ReportConfig;
  data: any[];
  metadata: {
    generatedAt: string;
    generatedBy: string;
    totalRecords: number;
    filteredRecords: number;
  };
}

// Field type formatters
export const formatFieldValue = (value: any, type: string): string => {
  if (value === null || value === undefined || value === '') {
    return '-';
  }

  switch (type) {
    case 'date':
      try {
        return format(new Date(value), 'dd/MM/yyyy', { locale: ptBR });
      } catch {
        return value.toString();
      }
    case 'number':
      return typeof value === 'number' ? value.toLocaleString('pt-BR') : value.toString();
    case 'email':
      return value.toString().toLowerCase();
    case 'phone':
      // Format Brazilian phone numbers
      const phone = value.toString().replace(/\D/g, '');
      if (phone.length === 11) {
        return `(${phone.substr(0,2)}) ${phone.substr(2,5)}-${phone.substr(7,4)}`;
      } else if (phone.length === 10) {
        return `(${phone.substr(0,2)}) ${phone.substr(2,4)}-${phone.substr(6,4)}`;
      }
      return value.toString();
    case 'status':
      // Translate common status values to Portuguese
      const statusMap: Record<string, string> = {
        'active': 'Ativo',
        'inactive': 'Inativo',
        'on_leave': 'Afastado',
        'terminated': 'Desligado',
        'open': 'Aberta',
        'closed': 'Fechada',
        'draft': 'Rascunho',
        'in_progress': 'Em Andamento',
        'completed': 'Concluído',
        'pending': 'Pendente',
        'approved': 'Aprovado',
        'rejected': 'Rejeitado'
      };
      return statusMap[value.toString().toLowerCase()] || value.toString();
    default:
      return value.toString();
  }
};

// PDF Generation using browser print API
export const generatePDFReport = async (reportData: ReportData): Promise<void> => {
  const { config, data, metadata } = reportData;
  
  // Create a new window with the report content
  const printWindow = window.open('', '_blank', 'width=800,height=600');
  
  if (!printWindow) {
    throw new Error('Popup bloqueado. Permita popups para gerar relatórios.');
  }

  // Generate HTML content for the report
  const htmlContent = generateHTMLReport(reportData);
  
  printWindow.document.write(htmlContent);
  printWindow.document.close();

  // Wait for content to load, then trigger print
  printWindow.onload = () => {
    setTimeout(() => {
      printWindow.print();
      // Close the window after printing (user can cancel)
      printWindow.onafterprint = () => {
        printWindow.close();
      };
    }, 500);
  };
};

// Excel Generation using CSV format (compatible with Excel)
export const generateExcelReport = async (reportData: ReportData): Promise<void> => {
  const { config, data } = reportData;
  
  // Get field definitions from the config
  const fieldLabels = getFieldLabelsForModule(config.moduleId);
  
  // Create CSV content
  const headers = config.fields.map(fieldId => fieldLabels[fieldId] || fieldId);
  const csvRows = [headers.join(',')];
  
  // Add data rows
  data.forEach(row => {
    const csvRow = config.fields.map(fieldId => {
      const value = row[fieldId];
      const formattedValue = formatFieldValue(value, getFieldType(config.moduleId, fieldId));
      // Escape commas and quotes for CSV
      return `"${formattedValue.toString().replace(/"/g, '""')}"`;
    });
    csvRows.push(csvRow.join(','));
  });
  
  const csvContent = csvRows.join('\n');
  
  // Add BOM for proper Excel UTF-8 handling
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  
  // Create download link
  const filename = `${config.title.replace(/[^a-zA-Z0-9]/g, '_')}_${format(new Date(), 'dd-MM-yyyy')}.csv`;
  downloadBlob(blob, filename);
};

// Generate HTML content for PDF reports
const generateHTMLReport = (reportData: ReportData): string => {
  const { config, data, metadata } = reportData;
  const fieldLabels = getFieldLabelsForModule(config.moduleId);
  
  return `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${config.title}</title>
      <style>
        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          margin: 20px;
          color: #333;
          line-height: 1.6;
        }
        .header {
          text-align: center;
          border-bottom: 2px solid #6366f1;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .header h1 {
          color: #6366f1;
          margin: 0;
          font-size: 24px;
        }
        .header .subtitle {
          color: #666;
          margin: 10px 0;
          font-size: 14px;
        }
        .metadata {
          background: #f8f9fa;
          padding: 15px;
          border-radius: 8px;
          margin-bottom: 20px;
          font-size: 12px;
        }
        .metadata strong {
          color: #6366f1;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
          font-size: 11px;
        }
        th {
          background: #6366f1;
          color: white;
          padding: 12px 8px;
          text-align: left;
          font-weight: 600;
        }
        td {
          padding: 10px 8px;
          border-bottom: 1px solid #e5e7eb;
        }
        tr:nth-child(even) {
          background: #f9fafb;
        }
        tr:hover {
          background: #f3f4f6;
        }
        .no-data {
          text-align: center;
          padding: 40px;
          color: #6b7280;
          font-style: italic;
        }
        .footer {
          margin-top: 30px;
          text-align: center;
          font-size: 10px;
          color: #6b7280;
          border-top: 1px solid #e5e7eb;
          padding-top: 15px;
        }
        @media print {
          body { margin: 0; }
          .header { page-break-after: avoid; }
          table { page-break-inside: auto; }
          tr { page-break-inside: avoid; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>${config.title}</h1>
        ${config.description ? `<div class="subtitle">${config.description}</div>` : ''}
      </div>
      
      <div class="metadata">
        <strong>Informações do Relatório:</strong><br>
        <strong>Gerado em:</strong> ${format(new Date(metadata.generatedAt), 'dd/MM/yyyy \'às\' HH:mm', { locale: ptBR })}<br>
        <strong>Gerado por:</strong> ${metadata.generatedBy}<br>
        <strong>Total de registros:</strong> ${metadata.totalRecords}<br>
        ${config.dateRange.start || config.dateRange.end ? `<strong>Período:</strong> ${config.dateRange.start ? format(new Date(config.dateRange.start), 'dd/MM/yyyy') : 'Início'} até ${config.dateRange.end ? format(new Date(config.dateRange.end), 'dd/MM/yyyy') : 'Atual'}<br>` : ''}
      </div>

      ${data.length > 0 ? `
        <table>
          <thead>
            <tr>
              ${config.fields.map(fieldId => `<th>${fieldLabels[fieldId] || fieldId}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${data.map(row => `
              <tr>
                ${config.fields.map(fieldId => {
                  const value = row[fieldId];
                  const formattedValue = formatFieldValue(value, getFieldType(config.moduleId, fieldId));
                  return `<td>${formattedValue}</td>`;
                }).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
      ` : `
        <div class="no-data">
          <p>Nenhum registro encontrado para os filtros aplicados.</p>
        </div>
      `}

      <div class="footer">
        <p>Relatório gerado pelo sistema Integre RH em ${format(new Date(), 'dd/MM/yyyy \'às\' HH:mm', { locale: ptBR })}</p>
        <p>© ${new Date().getFullYear()} Integre RH - Conectando gestão e performance</p>
      </div>
    </body>
    </html>
  `;
};

// Utility function to download blob as file
const downloadBlob = (blob: Blob, filename: string): void => {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
};

// Get field labels for each module
const getFieldLabelsForModule = (moduleId: string): Record<string, string> => {
  const fieldLabels: Record<string, Record<string, string>> = {
    employees: {
      name: 'Nome',
      email: 'E-mail',
      phone: 'Telefone',
      position: 'Cargo',
      department: 'Setor',
      joinDate: 'Data de Admissão',
      status: 'Situação',
      salary: 'Salário',
      terminationDate: 'Data de Desligamento',
      terminationReason: 'Motivo do Desligamento'
    },
    jobs: {
      title: 'Vaga',
      department: 'Departamento',
      status: 'Status',
      applications: 'Número de Candidatos',
      createdDate: 'Data de Abertura',
      responsible: 'Responsável',
      salary: 'Faixa Salarial',
      type: 'Tipo de Contrato'
    },
    trainings: {
      title: 'Título',
      target: 'Público-alvo',
      status: 'Status',
      participants: 'Número de Participantes',
      startDate: 'Data Início',
      endDate: 'Data Fim',
      duration: 'Duração (horas)',
      instructor: 'Instrutor'
    },
    evaluations: {
      employeeName: 'Nome',
      position: 'Cargo',
      evaluationType: 'Avaliação',
      overallScore: 'Nota Média',
      evaluationDate: 'Data da Avaliação',
      status: 'Status',
      evaluator: 'Avaliador',
      period: 'Período'
    },
    'selection-process': {
      jobTitle: 'Vaga',
      stages: 'Quantidade de Etapas',
      totalCandidates: 'Candidatos Inscritos',
      hired: 'Contratado',
      responsible: 'Responsável',
      startDate: 'Data de Início',
      endDate: 'Data de Conclusão',
      averageTime: 'Tempo Médio (dias)'
    },
    terminations: {
      name: 'Nome',
      position: 'Cargo',
      terminationDate: 'Data do Desligamento',
      terminationReason: 'Motivo',
      responsible: 'Responsável',
      type: 'Tipo',
      department: 'Departamento',
      timeInCompany: 'Tempo na Empresa'
    }
  };

  return fieldLabels[moduleId] || {};
};

// Get field type for formatting
const getFieldType = (moduleId: string, fieldId: string): string => {
  const fieldTypes: Record<string, Record<string, string>> = {
    employees: {
      name: 'text',
      email: 'email',
      phone: 'phone',
      position: 'text',
      department: 'text',
      joinDate: 'date',
      status: 'status',
      salary: 'number',
      terminationDate: 'date',
      terminationReason: 'text'
    },
    jobs: {
      title: 'text',
      department: 'text',
      status: 'status',
      applications: 'number',
      createdDate: 'date',
      responsible: 'text',
      salary: 'text',
      type: 'text'
    },
    trainings: {
      title: 'text',
      target: 'text',
      status: 'status',
      participants: 'number',
      startDate: 'date',
      endDate: 'date',
      duration: 'number',
      instructor: 'text'
    },
    evaluations: {
      employeeName: 'text',
      position: 'text',
      evaluationType: 'text',
      overallScore: 'number',
      evaluationDate: 'date',
      status: 'status',
      evaluator: 'text',
      period: 'text'
    },
    'selection-process': {
      jobTitle: 'text',
      stages: 'number',
      totalCandidates: 'number',
      hired: 'number',
      responsible: 'text',
      startDate: 'date',
      endDate: 'date',
      averageTime: 'number'
    },
    terminations: {
      name: 'text',
      position: 'text',
      terminationDate: 'date',
      terminationReason: 'text',
      responsible: 'text',
      type: 'text',
      department: 'text',
      timeInCompany: 'text'
    }
  };

  return fieldTypes[moduleId]?.[fieldId] || 'text';
};

// Sort data based on configuration
export const sortReportData = (data: any[], config: ReportConfig): any[] => {
  if (!config.sortBy) return data;

  return [...data].sort((a, b) => {
    const aValue = a[config.sortBy!];
    const bValue = b[config.sortBy!];

    // Handle null/undefined values
    if (aValue == null && bValue == null) return 0;
    if (aValue == null) return config.sortOrder === 'asc' ? -1 : 1;
    if (bValue == null) return config.sortOrder === 'asc' ? 1 : -1;

    // Compare values
    let comparison = 0;
    if (aValue < bValue) comparison = -1;
    else if (aValue > bValue) comparison = 1;

    return config.sortOrder === 'desc' ? -comparison : comparison;
  });
};

// Filter data based on date range
export const filterReportData = (data: any[], config: ReportConfig): any[] => {
  if (!config.dateRange.start && !config.dateRange.end) return data;

  return data.filter(item => {
    // Try to find a date field to filter by
    const dateFields = ['createdDate', 'joinDate', 'uploadDate', 'startDate', 'evaluationDate', 'terminationDate'];
    const dateField = dateFields.find(field => item[field]);
    
    if (!dateField) return true; // If no date field found, include the item

    const itemDate = new Date(item[dateField]);
    const startDate = config.dateRange.start ? new Date(config.dateRange.start) : null;
    const endDate = config.dateRange.end ? new Date(config.dateRange.end) : null;

    if (startDate && itemDate < startDate) return false;
    if (endDate && itemDate > endDate) return false;

    return true;
  });
};
