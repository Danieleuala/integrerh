import { SupabaseDataStore } from "./realDataStore";
import { IntegratedDataStore } from "./mockData";
import {
  Employee,
  Job,
  JobApplication,
  Training,
  Evaluation,
  Document,
  Feedback,
  Announcement,
} from "./mockData";

// Configuration to determine which data store to use
const USE_REAL_DATABASE =
  import.meta.env.VITE_USE_REAL_DATABASE === "true" &&
  import.meta.env.VITE_SUPABASE_URL &&
  import.meta.env.VITE_SUPABASE_ANON_KEY;

console.log('DataAdapter configuration:', {
  VITE_USE_REAL_DATABASE: import.meta.env.VITE_USE_REAL_DATABASE,
  VITE_SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL ? '***configured***' : 'not set',
  VITE_SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY ? '***configured***' : 'not set',
  USE_REAL_DATABASE
});

// Universal data adapter that switches between real and mock data
export class DataAdapter {
  // Employees
  static async getEmployees(): Promise<Employee[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getEmployees();
    }
    return IntegratedDataStore.getEmployees();
  }

  static async getEmployee(id: string): Promise<Employee | undefined> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getEmployee(id);
    }
    return IntegratedDataStore.getEmployee(id);
  }

  static async addEmployee(
    employee: Omit<Employee, "id">,
  ): Promise<Employee | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addEmployee(employee);
    }
    return IntegratedDataStore.addEmployee(employee);
  }

  static async updateEmployee(
    id: string,
    updates: Partial<Employee>,
  ): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.updateEmployee(id, updates);
    }
    return IntegratedDataStore.updateEmployee(id, updates);
  }

  static async deleteEmployee(id: string): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.deleteEmployee(id);
    }
    return IntegratedDataStore.deleteEmployee(id);
  }

  // Jobs
  static async getJobs(): Promise<Job[]> {
    try {
      console.log('DataAdapter.getJobs() - Using real database:', USE_REAL_DATABASE);
      if (USE_REAL_DATABASE) {
        console.log('Fetching jobs from Supabase...');
        const jobs = await SupabaseDataStore.getJobs();
        console.log('Supabase returned:', jobs.length, 'jobs');
        return jobs;
      }
      console.log('Fetching jobs from mock data...');
      const jobs = IntegratedDataStore.getJobs();
      console.log('Mock data returned:', jobs.length, 'jobs');
      return Promise.resolve(jobs);
    } catch (error) {
      console.error('DataAdapter.getJobs() error:', error);
      // Fallback to mock data
      console.log('Falling back to mock data due to error');
      return Promise.resolve(IntegratedDataStore.getJobs());
    }
  }

  static async getJob(id: string): Promise<Job | undefined> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getJob(id);
    }
    return IntegratedDataStore.getJob(id);
  }

  static async addJob(job: Omit<Job, "id">): Promise<Job | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addJob(job);
    }
    return IntegratedDataStore.addJob(job);
  }

  static async updateJob(id: string, updates: Partial<Job>): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.updateJob(id, updates);
    }
    return IntegratedDataStore.updateJob(id, updates);
  }

  static async addApplicationToJob(
    jobId: string,
    application: Omit<JobApplication, "id" | "jobId">,
  ): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addApplicationToJob(jobId, application);
    }
    return IntegratedDataStore.addApplicationToJob(jobId, application);
  }

  // Trainings
  static async getTrainings(): Promise<Training[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getTrainings();
    }
    return IntegratedDataStore.getTrainings();
  }

  static async getTraining(id: string): Promise<Training | undefined> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getTraining(id);
    }
    return IntegratedDataStore.getTraining(id);
  }

  static async addTraining(
    training: Omit<Training, "id">,
  ): Promise<Training | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addTraining(training);
    }
    return IntegratedDataStore.addTraining(training);
  }

  static async enrollInTraining(
    trainingId: string,
    userId: string,
  ): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      // Implementation would need to be added to SupabaseDataStore
      console.log("Enroll in training not yet implemented for real database");
      return false;
    }
    return IntegratedDataStore.enrollInTraining(trainingId, userId);
  }

  // Evaluations
  static async getEvaluations(): Promise<Evaluation[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getEvaluations();
    }
    return IntegratedDataStore.getEvaluations();
  }

  static async getEvaluationsByEmployee(
    employeeId: string,
  ): Promise<Evaluation[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getEvaluationsByEmployee(employeeId);
    }
    return IntegratedDataStore.getEvaluationsByEmployee(employeeId);
  }

  static async addEvaluation(
    evaluation: Omit<Evaluation, "id">,
  ): Promise<Evaluation | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addEvaluation(evaluation);
    }
    return IntegratedDataStore.addEvaluation(evaluation);
  }

  // Documents
  static async addDocument(
    employeeId: string,
    document: Omit<Document, "id">,
  ): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addDocument(employeeId, document);
    }
    return IntegratedDataStore.addDocument(employeeId, document);
  }

  static async deleteDocument(
    employeeId: string,
    documentId: string,
  ): Promise<boolean> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.deleteDocument(employeeId, documentId);
    }
    return IntegratedDataStore.deleteDocument(employeeId, documentId);
  }

  // Feedbacks
  static async getFeedbacks(): Promise<Feedback[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getFeedbacks();
    }
    return IntegratedDataStore.getFeedbacks();
  }

  static async getFeedbacksByEmployee(employeeId: string): Promise<Feedback[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getFeedbacksByEmployee(employeeId);
    }
    return IntegratedDataStore.getFeedbacksByEmployee(employeeId);
  }

  static async addFeedback(
    feedback: Omit<Feedback, "id">,
  ): Promise<Feedback | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addFeedback(feedback);
    }
    return IntegratedDataStore.addFeedback(feedback);
  }

  // Announcements
  static async getAnnouncements(): Promise<Announcement[]> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getAnnouncements();
    }
    return IntegratedDataStore.getAnnouncements();
  }

  static async addAnnouncement(
    announcement: Omit<Announcement, "id">,
  ): Promise<Announcement | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.addAnnouncement(announcement);
    }
    return IntegratedDataStore.addAnnouncement(announcement);
  }

  // Cross-module methods
  static async getCrossModuleStats(): Promise<any> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.getCrossModuleStats();
    }
    return IntegratedDataStore.getCrossModuleStats();
  }

  static getEmployeeProfile(employeeId: string): any {
    if (USE_REAL_DATABASE) {
      // For real database, this would need to be async
      console.log("getEmployeeProfile not yet implemented for real database");
      return null;
    }
    return IntegratedDataStore.getEmployeeProfile(employeeId);
  }

  static getNotifications(userId: string): any[] {
    if (USE_REAL_DATABASE) {
      console.log("getNotifications not yet implemented for real database");
      return [];
    }
    return IntegratedDataStore.getNotifications(userId);
  }

  static markNotificationAsRead(notificationId: string): void {
    if (USE_REAL_DATABASE) {
      console.log(
        "markNotificationAsRead not yet implemented for real database",
      );
      return;
    }
    IntegratedDataStore.markNotificationAsRead(notificationId);
  }

  static getActivityLog(
    userId?: string,
    module?: string,
    limit?: number,
  ): any[] {
    if (USE_REAL_DATABASE) {
      console.log("getActivityLog not yet implemented for real database");
      return [];
    }
    return IntegratedDataStore.getActivityLog(userId, module, limit);
  }

  // File upload (only available with real database via Supabase Storage)
  static async uploadFile(
    bucket: string,
    path: string,
    file: File,
  ): Promise<string | null> {
    if (USE_REAL_DATABASE) {
      return await SupabaseDataStore.uploadFile(bucket, path, file);
    }

    // Mock file upload - return a fake URL
    console.log(`[MOCK] File uploaded: ${file.name} to ${bucket}/${path}`);
    return `https://mock-storage.example.com/${bucket}/${path}`;
  }

  // Utility methods
  static getDatabaseType(): "real" | "mock" {
    return USE_REAL_DATABASE ? "real" : "mock";
  }

  static isUsingRealDatabase(): boolean {
    return USE_REAL_DATABASE;
  }

  static getDatabaseInfo(): {
    type: "real" | "mock";
    configured: boolean;
    supabaseUrl?: string;
  } {
    return {
      type: USE_REAL_DATABASE ? "real" : "mock",
      configured: Boolean(
        import.meta.env.VITE_SUPABASE_URL &&
          import.meta.env.VITE_SUPABASE_ANON_KEY,
      ),
      supabaseUrl: import.meta.env.VITE_SUPABASE_URL,
    };
  }

  // Migration helper - copy mock data to real database
  static async migrateMockDataToReal(): Promise<{
    success: boolean;
    message: string;
  }> {
    if (!USE_REAL_DATABASE) {
      return { success: false, message: "Real database not configured" };
    }

    try {
      // Get all mock data
      const mockEmployees = IntegratedDataStore.getEmployees();
      const mockJobs = IntegratedDataStore.getJobs();
      const mockTrainings = IntegratedDataStore.getTrainings();
      const mockEvaluations = IntegratedDataStore.getEvaluations();
      const mockFeedbacks = IntegratedDataStore.getFeedbacks();
      const mockAnnouncements = IntegratedDataStore.getAnnouncements();

      // Migrate employees
      for (const employee of mockEmployees) {
        const { id, ...employeeData } = employee;
        await SupabaseDataStore.addEmployee(employeeData);
      }

      // Migrate jobs
      for (const job of mockJobs) {
        const { id, applications, ...jobData } = job;
        const newJob = await SupabaseDataStore.addJob(jobData);

        // Migrate job applications
        if (newJob && applications.length > 0) {
          for (const application of applications) {
            const { id: appId, jobId, ...appData } = application;
            await SupabaseDataStore.addApplicationToJob(newJob.id, appData);
          }
        }
      }

      // Migrate trainings
      for (const training of mockTrainings) {
        const { id, ...trainingData } = training;
        await SupabaseDataStore.addTraining(trainingData);
      }

      // Migrate evaluations
      for (const evaluation of mockEvaluations) {
        const { id, ...evaluationData } = evaluation;
        await SupabaseDataStore.addEvaluation(evaluationData);
      }

      // Migrate feedbacks
      for (const feedback of mockFeedbacks) {
        const { id, ...feedbackData } = feedback;
        await SupabaseDataStore.addFeedback(feedbackData);
      }

      // Migrate announcements
      for (const announcement of mockAnnouncements) {
        const { id, ...announcementData } = announcement;
        await SupabaseDataStore.addAnnouncement(announcementData);
      }

      return {
        success: true,
        message: `Migration completed successfully. Migrated ${mockEmployees.length} employees, ${mockJobs.length} jobs, ${mockTrainings.length} trainings, ${mockEvaluations.length} evaluations, ${mockFeedbacks.length} feedbacks, and ${mockAnnouncements.length} announcements.`,
      };
    } catch (error) {
      console.error("Migration failed:", error);
      return {
        success: false,
        message: `Migration failed: ${error instanceof Error ? error.message : "Unknown error"}`,
      };
    }
  }

  // Health check
  static async healthCheck(): Promise<{
    database: "healthy" | "error";
    type: "real" | "mock";
    details?: string;
  }> {
    try {
      if (USE_REAL_DATABASE) {
        // Try to fetch a simple query from Supabase
        const employees = await SupabaseDataStore.getEmployees();
        return {
          database: "healthy",
          type: "real",
          details: `Connected to Supabase. ${employees.length} employees found.`,
        };
      } else {
        // Check mock data
        const employees = IntegratedDataStore.getEmployees();
        return {
          database: "healthy",
          type: "mock",
          details: `Using mock data. ${employees.length} employees loaded.`,
        };
      }
    } catch (error) {
      return {
        database: "error",
        type: USE_REAL_DATABASE ? "real" : "mock",
        details: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }
}

// Export the adapter as the default data store
export default DataAdapter;
