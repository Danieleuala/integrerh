// Real WhatsApp Business API Integration
// Para uso em produção, configure as variáveis de ambiente necessárias

interface WhatsAppConfig {
  phoneNumberId: string;
  accessToken: string;
  verifyToken: string;
  businessAccountId: string;
}

interface WhatsAppMessage {
  to: string;
  type: 'text' | 'template' | 'interactive';
  text?: {
    body: string;
    preview_url?: boolean;
  };
  template?: {
    name: string;
    language: {
      code: string;
    };
    components?: any[];
  };
  interactive?: {
    type: 'button' | 'list';
    body: {
      text: string;
    };
    action: any;
  };
}

class WhatsAppBusinessAPI {
  private config: WhatsAppConfig;
  private baseUrl = 'https://graph.facebook.com/v18.0';

  constructor() {
    this.config = {
      phoneNumberId: import.meta.env.VITE_WHATSAPP_PHONE_NUMBER_ID || '',
      accessToken: import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN || '',
      verifyToken: import.meta.env.VITE_WHATSAPP_VERIFY_TOKEN || '',
      businessAccountId: import.meta.env.VITE_WHATSAPP_BUSINESS_ACCOUNT_ID || ''
    };
  }

  private async makeRequest(endpoint: string, method: 'GET' | 'POST' = 'POST', data?: any) {
    const url = `${this.baseUrl}/${endpoint}`;
    
    const headers: Record<string, string> = {
      'Authorization': `Bearer ${this.config.accessToken}`,
      'Content-Type': 'application/json'
    };

    try {
      const response = await fetch(url, {
        method,
        headers,
        ...(data && { body: JSON.stringify(data) })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`WhatsApp API Error: ${errorData.error?.message || response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('WhatsApp API Request failed:', error);
      throw error;
    }
  }

  async sendMessage(message: WhatsAppMessage): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      if (!this.config.phoneNumberId || !this.config.accessToken) {
        throw new Error('WhatsApp credentials not configured');
      }

      const response = await this.makeRequest(`${this.config.phoneNumberId}/messages`, 'POST', {
        messaging_product: 'whatsapp',
        ...message
      });

      return {
        success: true,
        messageId: response.messages?.[0]?.id
      };
    } catch (error) {
      console.error('Failed to send WhatsApp message:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async sendTextMessage(to: string, text: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
    return this.sendMessage({
      to,
      type: 'text',
      text: {
        body: text,
        preview_url: true
      }
    });
  }

  async sendTemplateMessage(
    to: string, 
    templateName: string, 
    languageCode: string = 'pt_BR',
    components?: any[]
  ): Promise<{ success: boolean; messageId?: string; error?: string }> {
    return this.sendMessage({
      to,
      type: 'template',
      template: {
        name: templateName,
        language: {
          code: languageCode
        },
        ...(components && { components })
      }
    });
  }

  async sendInteractiveMessage(
    to: string,
    bodyText: string,
    buttons: Array<{ id: string; title: string }>
  ): Promise<{ success: boolean; messageId?: string; error?: string }> {
    return this.sendMessage({
      to,
      type: 'interactive',
      interactive: {
        type: 'button',
        body: {
          text: bodyText
        },
        action: {
          buttons: buttons.map(btn => ({
            type: 'reply',
            reply: {
              id: btn.id,
              title: btn.title
            }
          }))
        }
      }
    });
  }

  // Webhook verification for receiving messages
  verifyWebhook(mode: string, token: string, challenge: string): string | null {
    if (mode === 'subscribe' && token === this.config.verifyToken) {
      return challenge;
    }
    return null;
  }

  // Process incoming webhook messages
  processWebhookMessage(body: any): { 
    from?: string; 
    message?: string; 
    messageId?: string; 
    timestamp?: number;
    type?: string;
  } | null {
    try {
      const entry = body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      
      if (value?.messages?.[0]) {
        const message = value.messages[0];
        const contact = value.contacts?.[0];
        
        return {
          from: message.from,
          message: message.text?.body || message.caption || '',
          messageId: message.id,
          timestamp: message.timestamp,
          type: message.type
        };
      }
    } catch (error) {
      console.error('Error processing webhook message:', error);
    }
    
    return null;
  }

  // Get business profile
  async getBusinessProfile(): Promise<any> {
    try {
      return await this.makeRequest(`${this.config.phoneNumberId}`, 'GET');
    } catch (error) {
      console.error('Failed to get business profile:', error);
      return null;
    }
  }

  // Update business profile
  async updateBusinessProfile(profileData: {
    about?: string;
    address?: string;
    description?: string;
    email?: string;
    profile_picture_url?: string;
    websites?: string[];
  }): Promise<boolean> {
    try {
      await this.makeRequest(`${this.config.phoneNumberId}`, 'POST', profileData);
      return true;
    } catch (error) {
      console.error('Failed to update business profile:', error);
      return false;
    }
  }

  // Analytics and insights
  async getAnalytics(start: string, end: string, granularity: 'hour' | 'day' | 'month' = 'day') {
    try {
      return await this.makeRequest(
        `${this.config.businessAccountId}/conversation_analytics?start=${start}&end=${end}&granularity=${granularity}`,
        'GET'
      );
    } catch (error) {
      console.error('Failed to get analytics:', error);
      return null;
    }
  }
}

// Singleton instance
export const whatsappAPI = new WhatsAppBusinessAPI();

// High-level helper functions for the HR platform
export class HRWhatsAppIntegration {
  // Send demo request notification
  static async sendDemoRequest(phoneNumber: string, companyName?: string): Promise<boolean> {
    const message = companyName 
      ? `Olá! Obrigado pelo interesse no Integre RH da ${companyName}. Nossa equipe entrará em contato em breve para agendar uma demonstração personalizada. 📋✨`
      : `Olá! Obrigado pelo interesse no Integre RH. Nossa equipe entrará em contato em breve para agendar uma demonstração. 📋✨`;

    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Send job notification to candidate
  static async sendJobNotification(phoneNumber: string, jobTitle: string, companyName: string): Promise<boolean> {
    const message = `🎯 Nova oportunidade: ${jobTitle} na ${companyName}! Sua candidatura foi recebida e está sendo analisada. Acompanhe o status no nosso portal.`;
    
    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Send interview reminder
  static async sendInterviewReminder(
    phoneNumber: string, 
    candidateName: string, 
    jobTitle: string, 
    interviewDate: string,
    interviewTime: string
  ): Promise<boolean> {
    const message = `📅 Lembrete: ${candidateName}, sua entrevista para ${jobTitle} está agendada para ${interviewDate} às ${interviewTime}. Boa sorte! 🍀`;
    
    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Send status update
  static async sendStatusUpdate(
    phoneNumber: string, 
    candidateName: string, 
    jobTitle: string, 
    newStatus: string
  ): Promise<boolean> {
    const statusMessages: Record<string, string> = {
      'screening': 'Sua candidatura passou para a triagem de currículo',
      'phone_interview': 'Parabéns! Você foi selecionado(a) para entrevista por telefone',
      'technical_test': 'Próxima etapa: teste técnico. Prepare-se!',
      'final_interview': 'Última etapa: entrevista final. Você está quase lá!',
      'approved': 'Parabéns! Você foi aprovado(a)! 🎉',
      'rejected': 'Infelizmente não seguiremos com sua candidatura desta vez'
    };

    const statusText = statusMessages[newStatus] || 'Status da candidatura atualizado';
    const message = `📊 ${candidateName}, ${statusText} para a vaga ${jobTitle}.`;
    
    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Send training notification
  static async sendTrainingNotification(
    phoneNumber: string, 
    employeeName: string, 
    trainingTitle: string, 
    startDate: string
  ): Promise<boolean> {
    const message = `📚 ${employeeName}, você foi inscrito(a) no treinamento "${trainingTitle}" que inicia em ${startDate}. Acesse a plataforma para mais detalhes.`;
    
    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Send evaluation reminder
  static async sendEvaluationReminder(
    phoneNumber: string, 
    employeeName: string, 
    evaluationType: string,
    dueDate: string
  ): Promise<boolean> {
    const message = `⏰ ${employeeName}, lembrete: sua avaliação ${evaluationType} deve ser concluída até ${dueDate}. Acesse o sistema para responder.`;
    
    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Send announcement
  static async sendAnnouncement(
    phoneNumber: string, 
    employeeName: string, 
    announcementTitle: string,
    priority: 'low' | 'medium' | 'high'
  ): Promise<boolean> {
    const priorityEmojis: Record<string, string> = {
      'low': 'ℹ️',
      'medium': '⚠️',
      'high': '🚨'
    };

    const emoji = priorityEmojis[priority] || 'ℹ️';
    const message = `${emoji} ${employeeName}, novo comunicado: ${announcementTitle}. Confira os detalhes na plataforma Integre RH.`;
    
    const result = await whatsappAPI.sendTextMessage(phoneNumber, message);
    return result.success;
  }

  // Interactive menu for candidates
  static async sendCandidateMenu(phoneNumber: string): Promise<boolean> {
    const result = await whatsappAPI.sendInteractiveMessage(
      phoneNumber,
      'Como posso ajudá-lo(a) hoje?',
      [
        { id: 'check_status', title: '📊 Status da Candidatura' },
        { id: 'available_jobs', title: '💼 Vagas Disponíveis' },
        { id: 'support', title: '🆘 Suporte' }
      ]
    );
    return result.success;
  }

  // Interactive menu for employees
  static async sendEmployeeMenu(phoneNumber: string): Promise<boolean> {
    const result = await whatsappAPI.sendInteractiveMessage(
      phoneNumber,
      'Olá! O que você gostaria de acessar?',
      [
        { id: 'my_evaluations', title: '📈 Minhas Avaliações' },
        { id: 'my_trainings', title: '📚 Meus Treinamentos' },
        { id: 'announcements', title: '📢 Comunicados' }
      ]
    );
    return result.success;
  }
}

// Fallback for demo environment (when real API is not configured)
export class MockWhatsAppIntegration {
  static async sendDemoRequest(phoneNumber: string, companyName?: string): Promise<boolean> {
    console.log(`[MOCK] Demo request sent to ${phoneNumber} for ${companyName || 'Integre RH'}`);
    
    // Simulate WhatsApp Web redirect in demo environment
    if (typeof window !== 'undefined') {
      const message = companyName 
        ? `Olá! Demonstração do Integre RH solicitada para ${companyName}. Nossa equipe entrará em contato!`
        : `Olá! Demonstração do Integre RH solicitada. Nossa equipe entrará em contato!`;
      
      const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
    }
    
    return true;
  }

  static async sendJobNotification(phoneNumber: string, jobTitle: string, companyName: string): Promise<boolean> {
    console.log(`[MOCK] Job notification sent to ${phoneNumber}: ${jobTitle} at ${companyName}`);
    return true;
  }

  static async sendInterviewReminder(phoneNumber: string, candidateName: string, jobTitle: string, interviewDate: string, interviewTime: string): Promise<boolean> {
    console.log(`[MOCK] Interview reminder sent to ${phoneNumber}: ${candidateName} for ${jobTitle} on ${interviewDate} at ${interviewTime}`);
    return true;
  }

  static async sendStatusUpdate(phoneNumber: string, candidateName: string, jobTitle: string, newStatus: string): Promise<boolean> {
    console.log(`[MOCK] Status update sent to ${phoneNumber}: ${candidateName} for ${jobTitle} - ${newStatus}`);
    return true;
  }

  static async sendTrainingNotification(phoneNumber: string, employeeName: string, trainingTitle: string, startDate: string): Promise<boolean> {
    console.log(`[MOCK] Training notification sent to ${phoneNumber}: ${employeeName} for ${trainingTitle} starting ${startDate}`);
    return true;
  }

  static async sendEvaluationReminder(phoneNumber: string, employeeName: string, evaluationType: string, dueDate: string): Promise<boolean> {
    console.log(`[MOCK] Evaluation reminder sent to ${phoneNumber}: ${employeeName} for ${evaluationType} due ${dueDate}`);
    return true;
  }

  static async sendAnnouncement(phoneNumber: string, employeeName: string, announcementTitle: string, priority: string): Promise<boolean> {
    console.log(`[MOCK] Announcement sent to ${phoneNumber}: ${employeeName} - ${announcementTitle} (${priority})`);
    return true;
  }

  static async sendCandidateMenu(phoneNumber: string): Promise<boolean> {
    console.log(`[MOCK] Candidate menu sent to ${phoneNumber}`);
    return true;
  }

  static async sendEmployeeMenu(phoneNumber: string): Promise<boolean> {
    console.log(`[MOCK] Employee menu sent to ${phoneNumber}`);
    return true;
  }
}

// Export the appropriate integration based on environment
const isProduction = import.meta.env.PROD && import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN;
export const WhatsAppIntegration = isProduction ? HRWhatsAppIntegration : MockWhatsAppIntegration;
