import { createClient } from '@supabase/supabase-js';

// Configuração do Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://dummy-project.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR1bW15LXByb2plY3QiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTY0NjA2NzI2MCwiZXhwIjoxOTYxNjQzMjYwfQ.dummy-key-for-development';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

// Storage bucket names
export const STORAGE_BUCKETS = {
  DOCUMENTS: import.meta.env.VITE_SUPABASE_STORAGE_BUCKET_DOCUMENTS || 'hr-documents',
  VIDEOS: import.meta.env.VITE_SUPABASE_STORAGE_BUCKET_VIDEOS || 'training-videos',
  AVATARS: import.meta.env.VITE_SUPABASE_STORAGE_BUCKET_AVATARS || 'profile-avatars',
};

// Configuration helper
export const supabaseConfig = {
  url: supabaseUrl,
  isConfigured: Boolean(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY),
  isDummy: supabaseUrl.includes('dummy-project'),
};

// Database types based on the complete schema
export interface Database {
  public: {
    Tables: {
      employees: {
        Row: {
          id: string;
          name: string;
          email: string;
          phone: string;
          cpf: string;
          rg: string;
          position: string;
          department: string;
          address: string;
          manager_id?: string;
          join_date: string;
          termination_date?: string;
          termination_reason?: string;
          ctps?: string;
          salary?: number;
          status: 'active' | 'inactive' | 'on_leave' | 'terminated';
          avatar?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          email: string;
          phone: string;
          cpf: string;
          rg: string;
          position: string;
          department: string;
          address: string;
          manager_id?: string;
          join_date: string;
          termination_date?: string;
          termination_reason?: string;
          ctps?: string;
          salary?: number;
          status?: 'active' | 'inactive' | 'on_leave' | 'terminated';
          avatar?: string;
        };
        Update: {
          id?: string;
          name?: string;
          email?: string;
          phone?: string;
          cpf?: string;
          rg?: string;
          position?: string;
          department?: string;
          address?: string;
          manager_id?: string;
          join_date?: string;
          termination_date?: string;
          termination_reason?: string;
          ctps?: string;
          salary?: number;
          status?: 'active' | 'inactive' | 'on_leave' | 'terminated';
          avatar?: string;
        };
      };
      jobs: {
        Row: {
          id: string;
          title: string;
          department: string;
          description: string;
          requirements: string[];
          benefits: string[];
          salary?: string;
          type: 'full_time' | 'part_time' | 'contract';
          status: 'open' | 'closed' | 'draft';
          created_date: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          department: string;
          description: string;
          requirements?: string[];
          benefits?: string[];
          salary?: string;
          type?: 'full_time' | 'part_time' | 'contract';
          status?: 'open' | 'closed' | 'draft';
          created_date?: string;
        };
        Update: {
          id?: string;
          title?: string;
          department?: string;
          description?: string;
          requirements?: string[];
          benefits?: string[];
          salary?: string;
          type?: 'full_time' | 'part_time' | 'contract';
          status?: 'open' | 'closed' | 'draft';
          created_date?: string;
        };
      };
      job_applications: {
        Row: {
          id: string;
          job_id: string;
          candidate_name: string;
          candidate_email: string;
          phone?: string;
          location?: string;
          resume_url?: string;
          status: 'pending' | 'screening' | 'phone_interview' | 'technical_test' | 'final_interview' | 'approved' | 'rejected';
          applied_date: string;
          current_stage?: number;
          notes?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          job_id: string;
          candidate_name: string;
          candidate_email: string;
          phone?: string;
          location?: string;
          resume_url?: string;
          status?: 'pending' | 'screening' | 'phone_interview' | 'technical_test' | 'final_interview' | 'approved' | 'rejected';
          applied_date?: string;
          current_stage?: number;
          notes?: string;
        };
        Update: {
          id?: string;
          job_id?: string;
          candidate_name?: string;
          candidate_email?: string;
          phone?: string;
          location?: string;
          resume_url?: string;
          status?: 'pending' | 'screening' | 'phone_interview' | 'technical_test' | 'final_interview' | 'approved' | 'rejected';
          applied_date?: string;
          current_stage?: number;
          notes?: string;
        };
      };
      application_stage_history: {
        Row: {
          id: string;
          application_id: string;
          stage: string;
          date: string;
          notes?: string;
          evaluator?: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          application_id: string;
          stage: string;
          date?: string;
          notes?: string;
          evaluator?: string;
        };
        Update: {
          id?: string;
          application_id?: string;
          stage?: string;
          date?: string;
          notes?: string;
          evaluator?: string;
        };
      };
      trainings: {
        Row: {
          id: string;
          title: string;
          description: string;
          category: 'technical' | 'soft_skills' | 'compliance' | 'leadership';
          duration: string;
          format: 'online' | 'presencial' | 'hybrid';
          instructor?: string;
          start_date: string;
          end_date?: string;
          status: 'not_started' | 'in_progress' | 'completed' | 'expired';
          certificate?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          description: string;
          category?: 'technical' | 'soft_skills' | 'compliance' | 'leadership';
          duration: string;
          format?: 'online' | 'presencial' | 'hybrid';
          instructor?: string;
          start_date: string;
          end_date?: string;
          status?: 'not_started' | 'in_progress' | 'completed' | 'expired';
          certificate?: string;
        };
        Update: {
          id?: string;
          title?: string;
          description?: string;
          category?: 'technical' | 'soft_skills' | 'compliance' | 'leadership';
          duration?: string;
          format?: 'online' | 'presencial' | 'hybrid';
          instructor?: string;
          start_date?: string;
          end_date?: string;
          status?: 'not_started' | 'in_progress' | 'completed' | 'expired';
          certificate?: string;
        };
      };
      training_participants: {
        Row: {
          id: string;
          training_id: string;
          employee_id: string;
          enrolled_date: string;
          completion_date?: string;
          progress: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          training_id: string;
          employee_id: string;
          enrolled_date?: string;
          completion_date?: string;
          progress?: number;
        };
        Update: {
          id?: string;
          training_id?: string;
          employee_id?: string;
          enrolled_date?: string;
          completion_date?: string;
          progress?: number;
        };
      };
      training_materials: {
        Row: {
          id: string;
          training_id: string;
          name: string;
          type: 'video' | 'pdf' | 'quiz' | 'presentation';
          url?: string;
          storage_path?: string;
          duration?: string;
          order_index: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          training_id: string;
          name: string;
          type?: 'video' | 'pdf' | 'quiz' | 'presentation';
          url?: string;
          storage_path?: string;
          duration?: string;
          order_index?: number;
        };
        Update: {
          id?: string;
          training_id?: string;
          name?: string;
          type?: 'video' | 'pdf' | 'quiz' | 'presentation';
          url?: string;
          storage_path?: string;
          duration?: string;
          order_index?: number;
        };
      };
      evaluations: {
        Row: {
          id: string;
          employee_id: string;
          evaluator_id: string;
          type: '360' | 'self' | 'manager';
          period: string;
          competencies: Array<{
            name: string;
            score: number;
            maxScore: number;
          }>;
          overall_score: number;
          feedback: string;
          date: string;
          status: 'pending' | 'completed' | 'approved';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          employee_id: string;
          evaluator_id: string;
          type?: '360' | 'self' | 'manager';
          period: string;
          competencies: Array<{
            name: string;
            score: number;
            maxScore: number;
          }>;
          overall_score: number;
          feedback?: string;
          date?: string;
          status?: 'pending' | 'completed' | 'approved';
        };
        Update: {
          id?: string;
          employee_id?: string;
          evaluator_id?: string;
          type?: '360' | 'self' | 'manager';
          period?: string;
          competencies?: Array<{
            name: string;
            score: number;
            maxScore: number;
          }>;
          overall_score?: number;
          feedback?: string;
          date?: string;
          status?: 'pending' | 'completed' | 'approved';
        };
      };
      documents: {
        Row: {
          id: string;
          employee_id: string;
          name: string;
          type: 'contract' | 'id' | 'certificate' | 'other';
          upload_date: string;
          size: string;
          url?: string;
          storage_path?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          employee_id: string;
          name: string;
          type?: 'contract' | 'id' | 'certificate' | 'other';
          upload_date?: string;
          size: string;
          url?: string;
          storage_path?: string;
        };
        Update: {
          id?: string;
          employee_id?: string;
          name?: string;
          type?: 'contract' | 'id' | 'certificate' | 'other';
          upload_date?: string;
          size?: string;
          url?: string;
          storage_path?: string;
        };
      };
      feedbacks: {
        Row: {
          id: string;
          from_id: string;
          to_id: string;
          message: string;
          type: 'positive' | 'constructive' | 'goal';
          competency?: string;
          date: string;
          is_private: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          from_id: string;
          to_id: string;
          message: string;
          type?: 'positive' | 'constructive' | 'goal';
          competency?: string;
          date?: string;
          is_private?: boolean;
        };
        Update: {
          id?: string;
          from_id?: string;
          to_id?: string;
          message?: string;
          type?: 'positive' | 'constructive' | 'goal';
          competency?: string;
          date?: string;
          is_private?: boolean;
        };
      };
      announcements: {
        Row: {
          id: string;
          title: string;
          content: string;
          author: string;
          date: string;
          priority: 'low' | 'medium' | 'high';
          departments?: string[];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          content: string;
          author: string;
          date?: string;
          priority?: 'low' | 'medium' | 'high';
          departments?: string[];
        };
        Update: {
          id?: string;
          title?: string;
          content?: string;
          author?: string;
          date?: string;
          priority?: 'low' | 'medium' | 'high';
          departments?: string[];
        };
      };
      employee_history: {
        Row: {
          id: string;
          employee_id: string;
          date: string;
          type: 'hire' | 'promotion' | 'transfer' | 'termination' | 'status_change' | 'salary_change';
          description: string;
          details: Record<string, any>;
          created_at: string;
        };
        Insert: {
          id?: string;
          employee_id: string;
          date?: string;
          type: 'hire' | 'promotion' | 'transfer' | 'termination' | 'status_change' | 'salary_change';
          description: string;
          details?: Record<string, any>;
        };
        Update: {
          id?: string;
          employee_id?: string;
          date?: string;
          type?: 'hire' | 'promotion' | 'transfer' | 'termination' | 'status_change' | 'salary_change';
          description?: string;
          details?: Record<string, any>;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          type: 'info' | 'success' | 'warning' | 'error';
          title: string;
          message: string;
          related_module?: string;
          related_id?: string;
          action_url?: string;
          read: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type?: 'info' | 'success' | 'warning' | 'error';
          title: string;
          message: string;
          related_module?: string;
          related_id?: string;
          action_url?: string;
          read?: boolean;
        };
        Update: {
          id?: string;
          user_id?: string;
          type?: 'info' | 'success' | 'warning' | 'error';
          title?: string;
          message?: string;
          related_module?: string;
          related_id?: string;
          action_url?: string;
          read?: boolean;
        };
      };
      activity_log: {
        Row: {
          id: string;
          user_id: string;
          action: string;
          module: string;
          description: string;
          related_data: Record<string, any>;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          action: string;
          module: string;
          description: string;
          related_data?: Record<string, any>;
        };
        Update: {
          id?: string;
          user_id?: string;
          action?: string;
          module?: string;
          description?: string;
          related_data?: Record<string, any>;
        };
      };
    };
    Views: {};
    Functions: {};
    Enums: {};
  };
}

// Helper functions for file uploads
export const uploadFile = async (
  bucket: string,
  path: string,
  file: File,
  options?: { cacheControl?: string; upsert?: boolean }
): Promise<{ url: string | null; error: Error | null }> => {
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file, {
        cacheControl: options?.cacheControl || '3600',
        upsert: options?.upsert || false,
      });

    if (error) {
      return { url: null, error };
    }

    const { data: urlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    return { url: urlData.publicUrl, error: null };
  } catch (error) {
    return { url: null, error: error as Error };
  }
};

export const deleteFile = async (
  bucket: string,
  path: string
): Promise<{ success: boolean; error: Error | null }> => {
  try {
    const { error } = await supabase.storage
      .from(bucket)
      .remove([path]);

    return { success: !error, error };
  } catch (error) {
    return { success: false, error: error as Error };
  }
};

export const getFileUrl = (bucket: string, path: string): string => {
  const { data } = supabase.storage
    .from(bucket)
    .getPublicUrl(path);
  
  return data.publicUrl;
};

// Real-time subscriptions helper
export const createRealtimeSubscription = (
  table: string,
  callback: (payload: any) => void
) => {
  return supabase
    .channel(`${table}_changes`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table },
      callback
    )
    .subscribe();
};

// Connection test
export const testConnection = async (): Promise<{
  connected: boolean;
  error?: string;
}> => {
  try {
    const { error } = await supabase.from('employees').select('id').limit(1);
    
    if (error) {
      return { connected: false, error: error.message };
    }
    
    return { connected: true };
  } catch (error) {
    return { 
      connected: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    };
  }
};
