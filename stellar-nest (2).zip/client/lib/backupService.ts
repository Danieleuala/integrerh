// Integre RH - Sistema de Backup Automático
// Backup de dados, configurações e arquivos com múltiplas estratégias

import { supabase } from './supabase';
import { integrationManager } from './integrations';

// =============================================================================
// TIPOS E INTERFACES
// =============================================================================

export interface BackupConfig {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'monthly';
  retention: number; // dias
  includeTables: string[];
  includeStorage: boolean;
  compression: boolean;
  encryption: boolean;
  destination: 'local' | 'cloud' | 'both';
}

export interface BackupMetadata {
  id: string;
  type: 'full' | 'incremental' | 'differential';
  size: number;
  tables: string[];
  files: number;
  startTime: Date;
  endTime: Date;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  error?: string;
  checksum: string;
  version: string;
  retention_until: Date;
}

export interface RestoreOptions {
  backupId: string;
  tables?: string[];
  files?: boolean;
  overwrite: boolean;
  beforeRestore?: () => Promise<void>;
  afterRestore?: () => Promise<void>;
}

// =============================================================================
// BACKUP SERVICE PRINCIPAL
// =============================================================================

export class BackupService {
  private static instance: BackupService;
  private config: BackupConfig;
  private runningBackups: Set<string> = new Set();

  constructor() {
    this.config = this.getDefaultConfig();
    this.initializeScheduler();
  }

  static getInstance(): BackupService {
    if (!BackupService.instance) {
      BackupService.instance = new BackupService();
    }
    return BackupService.instance;
  }

  private getDefaultConfig(): BackupConfig {
    return {
      enabled: Boolean(import.meta.env.VITE_BACKUP_ENABLED !== 'false'),
      frequency: 'daily',
      retention: 30,
      includeTables: [
        'employees',
        'jobs',
        'job_applications',
        'trainings',
        'training_participants',
        'evaluations',
        'documents',
        'feedbacks',
        'announcements',
        'notifications'
      ],
      includeStorage: true,
      compression: true,
      encryption: false,
      destination: 'cloud'
    };
  }

  private initializeScheduler(): void {
    if (!this.config.enabled) {
      console.log('🚫 Backup service disabled');
      return;
    }

    console.log('⏰ Initializing backup scheduler');
    this.scheduleNextBackup();
  }

  private scheduleNextBackup(): void {
    const nextRun = this.calculateNextBackupTime();
    const delay = nextRun.getTime() - Date.now();

    if (delay > 0) {
      setTimeout(async () => {
        await this.performAutomaticBackup();
        this.scheduleNextBackup(); // Reagendar
      }, delay);

      console.log(`📅 Next backup scheduled for: ${nextRun.toLocaleString()}`);
    }
  }

  private calculateNextBackupTime(): Date {
    const now = new Date();
    const next = new Date(now);

    switch (this.config.frequency) {
      case 'daily':
        next.setDate(next.getDate() + 1);
        next.setHours(2, 0, 0, 0); // 2 AM
        break;
      case 'weekly':
        const daysUntilSunday = 7 - next.getDay();
        next.setDate(next.getDate() + daysUntilSunday);
        next.setHours(2, 0, 0, 0); // Sunday 2 AM
        break;
      case 'monthly':
        next.setMonth(next.getMonth() + 1, 1);
        next.setHours(2, 0, 0, 0); // 1st day of month 2 AM
        break;
    }

    return next;
  }

  async performAutomaticBackup(): Promise<BackupMetadata> {
    console.log('🔄 Starting automatic backup...');
    
    return this.createBackup({
      type: 'full',
      tables: this.config.includeTables,
      includeFiles: this.config.includeStorage,
      compress: this.config.compression,
      encrypt: this.config.encryption
    });
  }

  async createBackup(options: {
    type?: 'full' | 'incremental';
    tables?: string[];
    includeFiles?: boolean;
    compress?: boolean;
    encrypt?: boolean;
  } = {}): Promise<BackupMetadata> {
    const backupId = this.generateBackupId();
    
    if (this.runningBackups.has(backupId)) {
      throw new Error('Backup already running');
    }

    this.runningBackups.add(backupId);

    const metadata: BackupMetadata = {
      id: backupId,
      type: options.type || 'full',
      size: 0,
      tables: options.tables || this.config.includeTables,
      files: 0,
      startTime: new Date(),
      endTime: new Date(),
      status: 'running',
      checksum: '',
      version: '1.0.0',
      retention_until: new Date(Date.now() + (this.config.retention * 24 * 60 * 60 * 1000))
    };

    try {
      console.log(`💾 Creating ${metadata.type} backup: ${backupId}`);

      // 1. Backup de dados das tabelas
      const tableData = await this.backupTables(metadata.tables);
      metadata.size += JSON.stringify(tableData).length;

      // 2. Backup de arquivos (se habilitado)
      let fileData: any[] = [];
      if (options.includeFiles) {
        fileData = await this.backupFiles();
        metadata.files = fileData.length;
      }

      // 3. Criar estrutura de backup
      const backupData = {
        metadata,
        tables: tableData,
        files: fileData,
        schema: await this.exportDatabaseSchema(),
        config: this.config,
        timestamp: new Date().toISOString()
      };

      // 4. Aplicar compressão se habilitada
      let finalData = JSON.stringify(backupData);
      if (options.compress) {
        finalData = await this.compressData(finalData);
      }

      // 5. Aplicar criptografia se habilitada
      if (options.encrypt) {
        finalData = await this.encryptData(finalData);
      }

      // 6. Salvar backup
      await this.saveBackup(backupId, finalData);

      // 7. Calcular checksum
      metadata.checksum = await this.calculateChecksum(finalData);
      metadata.size = finalData.length;
      metadata.endTime = new Date();
      metadata.status = 'completed';

      // 8. Salvar metadados
      await this.saveBackupMetadata(metadata);

      // 9. Limpeza de backups antigos
      await this.cleanupOldBackups();

      // 10. Notificar sucesso
      await this.notifyBackupComplete(metadata);

      console.log(`✅ Backup completed: ${backupId} (${this.formatSize(metadata.size)})`);

      return metadata;

    } catch (error) {
      metadata.status = 'failed';
      metadata.error = error instanceof Error ? error.message : 'Unknown error';
      metadata.endTime = new Date();

      await this.saveBackupMetadata(metadata);
      await this.notifyBackupFailed(metadata, error);

      console.error(`❌ Backup failed: ${backupId}`, error);
      throw error;

    } finally {
      this.runningBackups.delete(backupId);
    }
  }

  private async backupTables(tables: string[]): Promise<Record<string, any[]>> {
    const data: Record<string, any[]> = {};

    for (const table of tables) {
      try {
        const { data: tableData, error } = await supabase
          .from(table)
          .select('*');

        if (error) {
          console.warn(`Warning: Could not backup table ${table}:`, error.message);
          data[table] = [];
        } else {
          data[table] = tableData || [];
          console.log(`📊 Backed up table ${table}: ${data[table].length} records`);
        }
      } catch (error) {
        console.warn(`Warning: Error backing up table ${table}:`, error);
        data[table] = [];
      }
    }

    return data;
  }

  private async backupFiles(): Promise<any[]> {
    try {
      // Get list of all files from storage buckets
      const buckets = ['hr-documents', 'training-videos', 'profile-avatars'];
      const fileList: any[] = [];

      for (const bucket of buckets) {
        try {
          const { data: files, error } = await supabase.storage
            .from(bucket)
            .list('', { limit: 1000, offset: 0 });

          if (!error && files) {
            for (const file of files) {
              fileList.push({
                bucket,
                name: file.name,
                size: file.metadata?.size || 0,
                lastModified: file.updated_at,
                path: file.name
              });
            }
          }
        } catch (error) {
          console.warn(`Warning: Could not list files in bucket ${bucket}:`, error);
        }
      }

      console.log(`📁 Backed up file metadata: ${fileList.length} files`);
      return fileList;

    } catch (error) {
      console.warn('Warning: Error backing up files:', error);
      return [];
    }
  }

  private async exportDatabaseSchema(): Promise<string> {
    try {
      // This would need to be implemented based on your database provider
      // For now, return a basic schema description
      return JSON.stringify({
        version: '1.0.0',
        tables: this.config.includeTables,
        exported_at: new Date().toISOString()
      });
    } catch (error) {
      console.warn('Warning: Could not export database schema:', error);
      return '{}';
    }
  }

  private async compressData(data: string): Promise<string> {
    // In a real implementation, you'd use a compression library like pako
    // For now, just return the original data
    console.log('📦 Compression enabled (placeholder)');
    return data;
  }

  private async encryptData(data: string): Promise<string> {
    // In a real implementation, you'd use encryption
    // For now, just return the original data
    console.log('🔐 Encryption enabled (placeholder)');
    return data;
  }

  private async saveBackup(backupId: string, data: string): Promise<void> {
    try {
      // Save to Supabase Storage
      const { error } = await supabase.storage
        .from('hr-documents')
        .upload(`backups/${backupId}.backup`, new Blob([data], { type: 'application/json' }), {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        throw new Error(`Failed to save backup: ${error.message}`);
      }

      console.log(`💾 Backup saved to storage: ${backupId}`);

    } catch (error) {
      // Fallback: save to localStorage for development
      localStorage.setItem(`backup_${backupId}`, data);
      console.log(`💾 Backup saved to localStorage: ${backupId}`);
    }
  }

  private async saveBackupMetadata(metadata: BackupMetadata): Promise<void> {
    try {
      const { error } = await supabase
        .from('backup_metadata')
        .upsert({
          id: metadata.id,
          type: metadata.type,
          size: metadata.size,
          status: metadata.status,
          start_time: metadata.startTime.toISOString(),
          end_time: metadata.endTime.toISOString(),
          checksum: metadata.checksum,
          error_message: metadata.error,
          retention_until: metadata.retention_until.toISOString(),
          metadata: {
            tables: metadata.tables,
            files: metadata.files,
            version: metadata.version
          }
        });

      if (error) {
        console.warn('Could not save backup metadata to database:', error.message);
        // Fallback to localStorage
        const savedMetadata = JSON.parse(localStorage.getItem('backup_metadata') || '[]');
        savedMetadata.push(metadata);
        localStorage.setItem('backup_metadata', JSON.stringify(savedMetadata));
      }

    } catch (error) {
      console.warn('Error saving backup metadata:', error);
    }
  }

  private async cleanupOldBackups(): Promise<void> {
    const cutoffDate = new Date(Date.now() - (this.config.retention * 24 * 60 * 60 * 1000));
    
    try {
      // Delete old backup files
      const { data: oldBackups, error } = await supabase
        .from('backup_metadata')
        .select('id')
        .lt('retention_until', cutoffDate.toISOString());

      if (!error && oldBackups) {
        for (const backup of oldBackups) {
          await this.deleteBackup(backup.id);
        }
        console.log(`🧹 Cleaned up ${oldBackups.length} old backups`);
      }

    } catch (error) {
      console.warn('Warning: Could not cleanup old backups:', error);
    }
  }

  private async deleteBackup(backupId: string): Promise<void> {
    try {
      // Delete from storage
      await supabase.storage
        .from('hr-documents')
        .remove([`backups/${backupId}.backup`]);

      // Delete metadata
      await supabase
        .from('backup_metadata')
        .delete()
        .eq('id', backupId);

    } catch (error) {
      console.warn(`Warning: Could not delete backup ${backupId}:`, error);
    }
  }

  private async notifyBackupComplete(metadata: BackupMetadata): Promise<void> {
    try {
      await integrationManager.notifications.sendNotification('system', {
        type: 'success',
        title: 'Backup Completed',
        message: `Backup ${metadata.id} completed successfully (${this.formatSize(metadata.size)})`,
        related_module: 'backup',
        related_id: metadata.id
      });
    } catch (error) {
      console.warn('Could not send backup notification:', error);
    }
  }

  private async notifyBackupFailed(metadata: BackupMetadata, error: any): Promise<void> {
    try {
      await integrationManager.notifications.sendNotification('system', {
        type: 'error',
        title: 'Backup Failed',
        message: `Backup ${metadata.id} failed: ${error.message}`,
        related_module: 'backup',
        related_id: metadata.id
      });
    } catch (notifyError) {
      console.warn('Could not send backup failure notification:', notifyError);
    }
  }

  private generateBackupId(): string {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const random = Math.random().toString(36).substring(2, 8);
    return `backup_${timestamp}_${random}`;
  }

  private async calculateChecksum(data: string): Promise<string> {
    // Simple checksum for now - in production use a proper hash function
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(16);
  }

  private formatSize(bytes: number): string {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  }

  // Métodos públicos para gestão de backup
  async listBackups(): Promise<BackupMetadata[]> {
    try {
      const { data, error } = await supabase
        .from('backup_metadata')
        .select('*')
        .order('start_time', { ascending: false });

      if (error) {
        // Fallback to localStorage
        const savedMetadata = JSON.parse(localStorage.getItem('backup_metadata') || '[]');
        return savedMetadata;
      }

      return data.map(item => ({
        id: item.id,
        type: item.type,
        size: item.size,
        tables: item.metadata?.tables || [],
        files: item.metadata?.files || 0,
        startTime: new Date(item.start_time),
        endTime: new Date(item.end_time),
        status: item.status,
        error: item.error_message,
        checksum: item.checksum,
        version: item.metadata?.version || '1.0.0',
        retention_until: new Date(item.retention_until)
      }));

    } catch (error) {
      console.error('Error listing backups:', error);
      return [];
    }
  }

  async getBackupStatus(): Promise<{
    enabled: boolean;
    lastBackup?: Date;
    nextBackup?: Date;
    totalBackups: number;
    totalSize: number;
    oldestBackup?: Date;
  }> {
    const backups = await this.listBackups();
    const completedBackups = backups.filter(b => b.status === 'completed');

    return {
      enabled: this.config.enabled,
      lastBackup: completedBackups[0]?.endTime,
      nextBackup: this.calculateNextBackupTime(),
      totalBackups: completedBackups.length,
      totalSize: completedBackups.reduce((sum, b) => sum + b.size, 0),
      oldestBackup: completedBackups[completedBackups.length - 1]?.startTime
    };
  }

  updateConfig(newConfig: Partial<BackupConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log('🔧 Backup configuration updated:', this.config);
  }
}

// Export singleton
export const backupService = BackupService.getInstance();
