import { useState, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore, Training, TrainingMaterial } from '@/lib/mockData';
import { DocumentUpload } from '@/components/DocumentUpload';
import { TrainingPlayer } from '@/components/TrainingPlayer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  BookOpen, Plus, Search, Eye, Edit, MoreHorizontal,
  Users, Clock, Calendar, Award, Download, Upload,
  Play, CheckCircle, XCircle, AlertCircle, Target,
  Video, FileText, Presentation, Paperclip, File,
  Image, Film, BookOpenCheck, X, Trash2, Link, PlayCircle
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Trainings() {
  const { user } = useAuth();
  const [trainings, setTrainings] = useState(IntegratedDataStore.getTrainings());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedTraining, setSelectedTraining] = useState<Training | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [trainingForm, setTrainingForm] = useState<Partial<Training>>({});
  const [trainingMaterials, setTrainingMaterials] = useState<TrainingMaterial[]>([]);
  const [isMaterialDialogOpen, setIsMaterialDialogOpen] = useState(false);
  const [isTrainingPlayerOpen, setIsTrainingPlayerOpen] = useState(false);
  const [userProgress, setUserProgress] = useState<Record<string, any[]>>({});
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [materialForm, setMaterialForm] = useState({
    name: '',
    type: 'pdf' as 'video' | 'pdf' | 'quiz' | 'presentation' | 'image' | 'document',
    url: '',
    duration: '',
    file: null as File | null
  });
  const [isUploading, setIsUploading] = useState(false);

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin']);
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);

  const filteredTrainings = useMemo(() => {
    return trainings.filter(training => {
      const matchesSearch = training.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           training.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (training.instructor?.toLowerCase().includes(searchTerm.toLowerCase()) || false);
      
      const matchesStatus = statusFilter === 'all' || training.status === statusFilter;
      const matchesCategory = categoryFilter === 'all' || training.category === categoryFilter;
      
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [trainings, searchTerm, statusFilter, categoryFilter]);

  const getStatusBadge = (status: Training['status']) => {
    switch (status) {
      case 'not_started':
        return <Badge variant="outline" className="border-gray-200 text-gray-700">Não Iniciado</Badge>;
      case 'in_progress':
        return <Badge className="bg-blue-100 text-blue-700">Em Andamento</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-700">Concluído</Badge>;
      case 'expired':
        return <Badge className="bg-red-100 text-red-700">Expirado</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getCategoryBadge = (category: Training['category']) => {
    switch (category) {
      case 'technical':
        return <Badge variant="outline" className="border-blue-200 text-blue-700">Técnico</Badge>;
      case 'soft_skills':
        return <Badge variant="outline" className="border-green-200 text-green-700">Soft Skills</Badge>;
      case 'compliance':
        return <Badge variant="outline" className="border-orange-200 text-orange-700">Compliance</Badge>;
      case 'leadership':
        return <Badge variant="outline" className="border-purple-200 text-purple-700">Liderança</Badge>;
      default:
        return <Badge variant="secondary">Outros</Badge>;
    }
  };

  const getFormatIcon = (format: Training['format']) => {
    switch (format) {
      case 'online':
        return <Video className="w-4 h-4" />;
      case 'presencial':
        return <Users className="w-4 h-4" />;
      case 'hybrid':
        return <Presentation className="w-4 h-4" />;
      default:
        return <BookOpen className="w-4 h-4" />;
    }
  };

  const handleViewTraining = (training: Training) => {
    setSelectedTraining(training);
    setIsViewDialogOpen(true);
  };

  const handleCreateTraining = () => {
    setTrainingForm({
      title: '',
      description: '',
      category: 'technical',
      duration: '',
      format: 'online',
      instructor: '',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      status: 'not_started',
      participants: [],
      materials: []
    });
    setTrainingMaterials([]);
    setIsCreateDialogOpen(true);
  };

  const handleSaveTraining = () => {
    if (trainingForm.title && trainingForm.description && trainingForm.category && trainingForm.duration && trainingForm.startDate) {
      const trainingData = {
        ...trainingForm,
        materials: trainingMaterials
      };
      const newTraining = IntegratedDataStore.addTraining(trainingData as Omit<Training, 'id'>);
      setTrainings(IntegratedDataStore.getTrainings());
      setIsCreateDialogOpen(false);
      setTrainingForm({});
      setTrainingMaterials([]);
      alert(`Treinamento criado com sucesso! ${trainingMaterials.length} material(ais) anexado(s).`);
    } else {
      alert('Por favor, preencha todos os campos obrigatórios: Título, Descrição, Categoria, Duração e Data de Início.');
    }
  };

  const handleAddMaterial = async () => {
    if (materialForm.name && (materialForm.url || materialForm.file)) {
      setIsUploading(true);

      let finalUrl = materialForm.url;

      // Process file upload
      if (materialForm.file) {
        try {
          // Simulate file upload (in real app, upload to server/cloud storage)
          await new Promise(resolve => setTimeout(resolve, 1500));
          finalUrl = URL.createObjectURL(materialForm.file);
        } catch (error) {
          alert('Erro ao fazer upload do arquivo. Tente novamente.');
          setIsUploading(false);
          return;
        }
      }

      const newMaterial: TrainingMaterial = {
        id: `material_${Date.now()}`,
        name: materialForm.name,
        type: materialForm.type,
        url: finalUrl,
        duration: materialForm.duration || undefined
      };

      setTrainingMaterials([...trainingMaterials, newMaterial]);
      setMaterialForm({
        name: '',
        type: 'pdf',
        url: '',
        duration: '',
        file: null
      });
      setIsUploading(false);
      setIsMaterialDialogOpen(false);
    }
  };

  const handleRemoveMaterial = (materialId: string) => {
    setTrainingMaterials(trainingMaterials.filter(m => m.id !== materialId));
  };

  const getMaterialIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="w-4 h-4 text-red-600" />;
      case 'pdf':
        return <FileText className="w-4 h-4 text-blue-600" />;
      case 'quiz':
        return <BookOpenCheck className="w-4 h-4 text-green-600" />;
      case 'presentation':
        return <Presentation className="w-4 h-4 text-purple-600" />;
      default:
        return <File className="w-4 h-4 text-gray-600" />;
    }
  };

  const handleJoinTraining = (trainingId: string) => {
    if (user) {
      const training = trainings.find(t => t.id === trainingId);
      if (training) {
        // Check if user is already enrolled
        if (training.participants.includes(user.id)) {
          alert('Você já está inscrito neste treinamento!');
          return;
        }

        // Add user to participants
        const updatedTraining = {
          ...training,
          participants: [...training.participants, user.id]
        };

        // Update the training in the store
        const trainingsCopy = trainings.map(t =>
          t.id === trainingId ? updatedTraining : t
        );

        // Manually update the mock data
        const mockTrainings = IntegratedDataStore.getTrainings();
        const trainingIndex = mockTrainings.findIndex(t => t.id === trainingId);
        if (trainingIndex !== -1) {
          mockTrainings[trainingIndex] = updatedTraining;
          IntegratedDataStore.saveData();
        }

        setTrainings(trainingsCopy);
        alert(`Você se inscreveu no treinamento "${training.title}" com sucesso!`);
      }
    } else {
      alert('Você precisa estar logado para se inscrever.');
    }
  };

  const stats = useMemo(() => {
    const userTrainings = trainings.filter(training => 
      training.participants.includes(user?.id || '')
    );
    
    return {
      total: trainings.length,
      notStarted: trainings.filter(t => t.status === 'not_started').length,
      inProgress: trainings.filter(t => t.status === 'in_progress').length,
      completed: trainings.filter(t => t.status === 'completed').length,
      userTotal: userTrainings.length,
      userCompleted: userTrainings.filter(t => t.status === 'completed').length
    };
  }, [trainings, user]);

  const handleEditTraining = (training: Training) => {
    setSelectedTraining(training);
    setTrainingForm(training);
    setTrainingMaterials(training.materials || []);
    setIsEditDialogOpen(true);
  };

  const handleUpdateTraining = () => {
    if (!trainingForm.title || !trainingForm.description || !selectedTraining) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    const updatedTraining: Training = {
      ...selectedTraining,
      ...trainingForm,
      materials: trainingMaterials
    };

    const updatedTrainings = trainings.map(t =>
      t.id === selectedTraining.id ? updatedTraining : t
    );

    setTrainings(updatedTrainings);
    IntegratedDataStore.updateTraining(selectedTraining.id, updatedTraining);

    setIsEditDialogOpen(false);
    setSelectedTraining(null);
    setTrainingForm({});
    setTrainingMaterials([]);
    alert('Treinamento atualizado com sucesso!');
  };

  const handleExportTrainings = () => {
    try {
      const exportData = filteredTrainings.map(training => ({
        titulo: training.title,
        categoria: training.category,
        formato: training.format,
        instrutor: training.instructor || 'Não informado',
        status: training.status,
        participantes: training.participants.length,
        data_inicio: training.startDate,
        data_fim: training.endDate || 'Não informado',
        duracao: training.duration,
        materiais: training.materials.length
      }));

      const headers = Object.keys(exportData[0] || {});
      const csvContent = [
        headers.join(','),
        ...exportData.map(row =>
          headers.map(header => `"${(row as any)[header]}"`).join(',')
        )
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `treinamentos_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      alert('Exportação realizada com sucesso!');
    } catch (error) {
      console.error('Erro ao exportar:', error);
      alert('Erro ao exportar dados. Tente novamente.');
    }
  };

  // Training player functions
  const handleStartTraining = (training: Training) => {
    setSelectedTraining(training);
    setIsTrainingPlayerOpen(true);

    // Initialize user progress if not exists
    if (!userProgress[training.id]) {
      const initialProgress = training.materials.map(material => ({
        materialId: material.id,
        completed: false,
        progress: 0,
        timeSpent: 0,
        lastAccessed: new Date().toISOString()
      }));
      setUserProgress(prev => ({
        ...prev,
        [training.id]: initialProgress
      }));
    }
  };

  const handleUpdateProgress = (materialId: string, progress: any) => {
    if (!selectedTraining) return;

    setUserProgress(prev => ({
      ...prev,
      [selectedTraining.id]: prev[selectedTraining.id]?.map(p =>
        p.materialId === materialId ? { ...p, ...progress } : p
      ) || []
    }));

    // Save to localStorage
    const updatedProgress = {
      ...userProgress,
      [selectedTraining.id]: userProgress[selectedTraining.id]?.map(p =>
        p.materialId === materialId ? { ...p, ...progress } : p
      ) || []
    };
    localStorage.setItem('training_progress', JSON.stringify(updatedProgress));
  };

  const handleCompleteTraining = () => {
    if (!selectedTraining) return;

    // Mark training as completed
    const updatedTrainings = trainings.map(t =>
      t.id === selectedTraining.id ? { ...t, status: 'completed' as const } : t
    );
    setTrainings(updatedTrainings);
    setIsTrainingPlayerOpen(false);

    alert(`🎉 Parabéns! Você concluiu o treinamento "${selectedTraining.title}"!\n\nCertificado disponível para download.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <BookOpen className="w-8 h-8 mr-3 text-purple-600" />
            Treinamentos e Desenvolvimento
          </h1>
          <p className="text-gray-600 mt-1">
            Capacitação profissional e desenvolvimento de competências
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={handleExportTrainings}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          {canCreate && (
            <Button onClick={handleCreateTraining} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Novo Treinamento
            </Button>
          )}
        </div>
      </div>

      {/* User Progress Card */}
      {user?.role === 'employee' && (
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="w-5 h-5 mr-2" />
              Meu Progresso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">{stats.userTotal}</div>
                <p className="text-sm text-gray-600">Treinamentos Inscritos</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{stats.userCompleted}</div>
                <p className="text-sm text-gray-600">Concluídos</p>
              </div>
              <div className="text-center">
                <div className="relative">
                  <Progress 
                    value={(stats.userCompleted / (stats.userTotal || 1)) * 100} 
                    className="h-2 mb-2"
                  />
                  <div className="text-lg font-bold text-blue-600">
                    {Math.round((stats.userCompleted / (stats.userTotal || 1)) * 100)}%
                  </div>
                </div>
                <p className="text-sm text-gray-600">Taxa de Conclusão</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <BookOpen className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Em Andamento</p>
                <p className="text-3xl font-bold text-blue-600">{stats.inProgress}</p>
              </div>
              <Play className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Concluídos</p>
                <p className="text-3xl font-bold text-green-600">{stats.completed}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Não Iniciados</p>
                <p className="text-3xl font-bold text-orange-600">{stats.notStarted}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por título, instrutor..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="not_started">Não Iniciados</SelectItem>
                  <SelectItem value="in_progress">Em Andamento</SelectItem>
                  <SelectItem value="completed">Concluídos</SelectItem>
                  <SelectItem value="expired">Expirados</SelectItem>
                </SelectContent>
              </Select>

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas Categorias</SelectItem>
                  <SelectItem value="technical">Técnico</SelectItem>
                  <SelectItem value="soft_skills">Soft Skills</SelectItem>
                  <SelectItem value="compliance">Compliance</SelectItem>
                  <SelectItem value="leadership">Lideran��a</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredTrainings.length} de {trainings.length} treinamento(s)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trainings Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredTrainings.map((training) => (
          <Card key={training.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    {getFormatIcon(training.format)}
                    <CardTitle className="text-lg">{training.title}</CardTitle>
                  </div>
                  <div className="flex items-center space-x-3 mb-3">
                    {getCategoryBadge(training.category)}
                    {getStatusBadge(training.status)}
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                    {training.description}
                  </p>

                  {/* Training Track Info */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <BookOpen className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-800">Trilha de Aprendizado</span>
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-blue-600">
                      <div className="flex items-center">
                        <Video className="w-3 h-3 mr-1" />
                        {training.materials?.length || 0} aulas
                      </div>
                      <div className="flex items-center">
                        <Target className="w-3 h-3 mr-1" />
                        Interativo
                      </div>
                      <div className="flex items-center">
                        <Award className="w-3 h-3 mr-1" />
                        Certificado
                      </div>
                    </div>

                    {/* Progress for enrolled users */}
                    {training.participants.includes(user?.id || '') && (() => {
                      const userTrainingProgress = userProgress[training.id] || [];
                      const completedMaterials = userTrainingProgress.filter(p => p.completed).length;
                      const totalMaterials = training.materials?.length || 0;
                      const progressPercentage = totalMaterials > 0 ? Math.round((completedMaterials / totalMaterials) * 100) : 0;

                      return (
                        <div className="mt-2">
                          <div className="flex justify-between text-xs text-blue-700 mb-1">
                            <span>Seu progresso</span>
                            <span>{completedMaterials}/{totalMaterials} ({progressPercentage}%)</span>
                          </div>
                          <Progress value={progressPercentage} className="h-1.5" />
                        </div>
                      );
                    })()}
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {training.duration}
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      {training.participants.length} participantes
                    </div>
                    {training.instructor && (
                      <div className="flex items-center">
                        <Award className="w-4 h-4 mr-1" />
                        {training.instructor}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    {format(new Date(training.startDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </div>
                  <div className="capitalize">
                    {training.format === 'online' ? 'Online' : 
                     training.format === 'presencial' ? 'Presencial' : 'Híbrido'}
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {user?.role === 'employee' && !training.participants.includes(user.id) && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleJoinTraining(training.id)}
                    >
                      Inscrever-se
                    </Button>
                  )}
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleViewTraining(training)}>
                        <Eye className="w-4 h-4 mr-2" />
                        Visualizar
                      </DropdownMenuItem>
                      {canEdit && (
                        <>
                          <DropdownMenuItem onClick={() => handleEditTraining(training)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleExportTrainings}>
                            <Download className="w-4 h-4 mr-2" />
                            Exportar
                          </DropdownMenuItem>
                        </>
                      )}
                      {training.materials.length > 0 && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <FileText className="w-4 h-4 mr-2" />
                            Materiais ({training.materials.length})
                          </DropdownMenuItem>
                          {/* Start Training Button - only for enrolled users */}
                          {training.participants.includes(user?.id || '') && (
                            <DropdownMenuItem
                              onClick={() => handleStartTraining(training)}
                              className="text-green-600 font-medium"
                            >
                              <PlayCircle className="w-4 h-4 mr-2" />
                              Iniciar Treinamento
                            </DropdownMenuItem>
                          )}
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredTrainings.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhum treinamento encontrado
          </h3>
          <p className="text-gray-600 mb-4">
            {searchTerm || statusFilter !== 'all' || categoryFilter !== 'all'
              ? 'Tente ajustar os filtros de busca'
              : 'Comece criando programas de capacitação para sua equipe'
            }
          </p>
          {canCreate && (searchTerm === '' && statusFilter === 'all' && categoryFilter === 'all') && (
            <Button onClick={handleCreateTraining}>
              <Plus className="w-4 h-4 mr-2" />
              Criar Primeiro Treinamento
            </Button>
          )}
        </div>
      )}

      {/* View Training Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center">
              {selectedTraining && getFormatIcon(selectedTraining.format)}
              <span className="ml-2">{selectedTraining?.title}</span>
            </DialogTitle>
            <DialogDescription>
              {selectedTraining?.instructor && `Instrutor: ${selectedTraining.instructor}`}
            </DialogDescription>
          </DialogHeader>
          
          {selectedTraining && (
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                {getCategoryBadge(selectedTraining.category)}
                {getStatusBadge(selectedTraining.status)}
                <Badge variant="outline">{selectedTraining.duration}</Badge>
                <Badge variant="outline">
                  {selectedTraining.participants.length} participantes
                </Badge>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Descrição</h4>
                <p className="text-gray-700">{selectedTraining.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Informações</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Formato:</span>
                      <span className="capitalize">
                        {selectedTraining.format === 'online' ? 'Online' : 
                         selectedTraining.format === 'presencial' ? 'Presencial' : 'Híbrido'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Início:</span>
                      <span>{format(new Date(selectedTraining.startDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
                    </div>
                    {selectedTraining.endDate && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Término:</span>
                        <span>{format(new Date(selectedTraining.endDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2 flex items-center">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Trilha de Aprendizado ({selectedTraining.materials.length} aulas)
                  </h4>
                  {selectedTraining.materials.length > 0 ? (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {selectedTraining.materials.map((material, index) => {
                        const userMaterialProgress = userProgress[selectedTraining.id]?.find(p => p.materialId === material.id);
                        const isCompleted = userMaterialProgress?.completed || false;

                        return (
                          <div key={material.id} className={`flex items-center justify-between p-3 rounded-lg border transition-all ${isCompleted ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                            <div className="flex items-center space-x-3">
                              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${isCompleted ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'}`}>
                                {index + 1}
                              </div>
                              <div>
                                <div className="flex items-center space-x-2">
                                  {material.type === 'video' && <Video className="w-4 h-4 text-blue-600" />}
                                  {material.type === 'pdf' && <FileText className="w-4 h-4 text-red-600" />}
                                  {material.type === 'presentation' && <Presentation className="w-4 h-4 text-orange-600" />}
                                  <span className="text-sm font-medium">{material.name}</span>
                                  {isCompleted && <CheckCircle className="w-4 h-4 text-green-500" />}
                                </div>
                                {material.duration && (
                                  <div className="text-xs text-gray-500 mt-1">
                                    Duração: {material.duration}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              {material.type === 'video' && (
                                <Badge variant="secondary" className="text-xs">
                                  Vídeo
                                </Badge>
                              )}
                              <Button size="sm" variant="ghost">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">Nenhum material disponível</p>
                  )}
                </div>
              </div>

              {user?.role === 'employee' && !selectedTraining.participants.includes(user.id) && (
                <div className="flex justify-end">
                  <Button 
                    onClick={() => handleJoinTraining(selectedTraining.id)}
                    className="bg-gradient-to-r from-purple-600 to-blue-600"
                  >
                    Inscrever-se neste Treinamento
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Training Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Novo Treinamento</DialogTitle>
            <DialogDescription>
              Crie um programa de capacitação para sua equipe
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="training-title">Título do Treinamento</Label>
                <Input
                  id="training-title"
                  value={trainingForm.title || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, title: e.target.value})}
                  placeholder="Ex: Liderança Eficaz"
                />
              </div>
              <div>
                <Label htmlFor="training-category">Categoria</Label>
                <Select 
                  value={trainingForm.category || ''} 
                  onValueChange={(value) => setTrainingForm({...trainingForm, category: value as Training['category']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Técnico</SelectItem>
                    <SelectItem value="soft_skills">Soft Skills</SelectItem>
                    <SelectItem value="compliance">Compliance</SelectItem>
                    <SelectItem value="leadership">Liderança</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="training-format">Formato</Label>
                <Select 
                  value={trainingForm.format || ''} 
                  onValueChange={(value) => setTrainingForm({...trainingForm, format: value as Training['format']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Formato" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="presencial">Presencial</SelectItem>
                    <SelectItem value="hybrid">Híbrido</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="training-duration">Duração</Label>
                <Input
                  id="training-duration"
                  value={trainingForm.duration || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, duration: e.target.value})}
                  placeholder="Ex: 20 horas"
                />
              </div>
              <div>
                <Label htmlFor="training-instructor">Instrutor (opcional)</Label>
                <Input
                  id="training-instructor"
                  value={trainingForm.instructor || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, instructor: e.target.value})}
                  placeholder="Nome do instrutor"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="training-description">Descrição</Label>
              <Textarea
                id="training-description"
                value={trainingForm.description || ''}
                onChange={(e) => setTrainingForm({...trainingForm, description: e.target.value})}
                placeholder="Descreva o conte��do, objetivos e metodologia do treinamento..."
                rows={4}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="training-start">Data de Início</Label>
                <Input
                  id="training-start"
                  type="date"
                  value={trainingForm.startDate || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, startDate: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="training-end">Data de Término (opcional)</Label>
                <Input
                  id="training-end"
                  type="date"
                  value={trainingForm.endDate || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, endDate: e.target.value})}
                />
              </div>
            </div>

            {/* Materials Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">Materiais do Treinamento</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsMaterialDialogOpen(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Material
                </Button>
              </div>

              {trainingMaterials.length > 0 ? (
                <div className="grid grid-cols-1 gap-3">
                  {trainingMaterials.map((material) => (
                    <div key={material.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        {getMaterialIcon(material.type)}
                        <div>
                          <p className="font-medium text-sm">{material.name}</p>
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            <span className="capitalize">{material.type}</span>
                            {material.duration && (
                              <>
                                <span>•</span>
                                <span>{material.duration}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveMaterial(material.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                  <Paperclip className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-500">Nenhum material anexado</p>
                  <p className="text-xs text-gray-400">Clique em "Adicionar Material" para incluir conteúdo</p>
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSaveTraining}>
                Criar Treinamento
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Material Dialog */}
      <Dialog open={isMaterialDialogOpen} onOpenChange={setIsMaterialDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Adicionar Material</DialogTitle>
            <DialogDescription>
              Anexe documentos, vídeos e outros materiais ao treinamento
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="material-name">Nome do Material</Label>
              <Input
                id="material-name"
                value={materialForm.name}
                onChange={(e) => setMaterialForm({...materialForm, name: e.target.value})}
                placeholder="Ex: Apostila de React"
              />
            </div>

            <div>
              <Label htmlFor="material-type">Tipo de Material</Label>
              <Select
                value={materialForm.type}
                onValueChange={(value) => setMaterialForm({...materialForm, type: value as any})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">
                    <div className="flex items-center">
                      <FileText className="w-4 h-4 mr-2 text-blue-600" />
                      PDF / Documento
                    </div>
                  </SelectItem>
                  <SelectItem value="video">
                    <div className="flex items-center">
                      <Video className="w-4 h-4 mr-2 text-red-600" />
                      Vídeo
                    </div>
                  </SelectItem>
                  <SelectItem value="presentation">
                    <div className="flex items-center">
                      <Presentation className="w-4 h-4 mr-2 text-purple-600" />
                      Apresentação
                    </div>
                  </SelectItem>
                  <SelectItem value="quiz">
                    <div className="flex items-center">
                      <BookOpenCheck className="w-4 h-4 mr-2 text-green-600" />
                      Quiz / Exercício
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* File Upload or URL */}
            <div className="space-y-3">
              <Label>Arquivo ou Link</Label>

              {/* File Upload Section */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                <input
                  type="file"
                  id="file-upload"
                  accept=".pdf,.doc,.docx,.mp4,.avi,.mov,.ppt,.pptx,.png,.jpg,.jpeg"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setMaterialForm({...materialForm, file, url: ''});
                    }
                  }}
                  className="hidden"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600">
                    Clique para carregar arquivo ou arraste aqui
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    PDF, DOC, MP4, AVI, PPT, PNG, JPG (máx. 50MB)
                  </p>
                </label>

                {materialForm.file && (
                  <div className="mt-3 p-2 bg-green-50 rounded border border-green-200">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <File className="w-4 h-4 text-green-600 mr-2" />
                        <span className="text-sm text-green-700">{materialForm.file.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setMaterialForm({...materialForm, file: null})}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              <div className="text-center text-sm text-gray-500">ou</div>

              {/* URL Input */}
              <div>
                <Input
                  type="url"
                  value={materialForm.url}
                  onChange={(e) => setMaterialForm({...materialForm, url: e.target.value, file: null})}
                  placeholder="Cole um link externo (YouTube, Google Drive, etc.)"
                />
              </div>
            </div>

            {(materialForm.type === 'video' || materialForm.type === 'presentation') && (
              <div>
                <Label htmlFor="material-duration">Duração (opcional)</Label>
                <Input
                  id="material-duration"
                  value={materialForm.duration}
                  onChange={(e) => setMaterialForm({...materialForm, duration: e.target.value})}
                  placeholder="Ex: 45 min, 2h 30min"
                />
              </div>
            )}

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsMaterialDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleAddMaterial} disabled={isUploading}>
                {isUploading ? (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2 animate-spin" />
                    Fazendo Upload...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Material
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Training Player Dialog */}
      <Dialog open={isTrainingPlayerOpen} onOpenChange={setIsTrainingPlayerOpen}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] overflow-hidden p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>Player de Treinamento</DialogTitle>
          </DialogHeader>

          {selectedTraining && (
            <div className="h-[95vh] overflow-auto">
              <TrainingPlayer
                training={{
                  id: selectedTraining.id,
                  title: selectedTraining.title,
                  description: selectedTraining.description,
                  materials: selectedTraining.materials || [],
                  instructor: selectedTraining.instructor,
                  duration: selectedTraining.duration ? parseInt(selectedTraining.duration) * 60 : undefined
                }}
                userProgress={userProgress[selectedTraining.id] || []}
                onUpdateProgress={handleUpdateProgress}
                onComplete={handleCompleteTraining}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Training Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Edit className="w-5 h-5 mr-2" />
              Editar Treinamento
            </DialogTitle>
            <DialogDescription>
              Atualize as informações do treinamento selecionado
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-title">Título *</Label>
                <Input
                  id="edit-title"
                  value={trainingForm.title || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, title: e.target.value})}
                  placeholder="Ex: Curso de React Avançado"
                />
              </div>
              <div>
                <Label htmlFor="edit-category">Categoria *</Label>
                <Select
                  value={trainingForm.category || ''}
                  onValueChange={(value) => setTrainingForm({...trainingForm, category: value as Training['category']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Técnico</SelectItem>
                    <SelectItem value="soft_skills">Soft Skills</SelectItem>
                    <SelectItem value="compliance">Compliance</SelectItem>
                    <SelectItem value="leadership">Liderança</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="edit-description">Descrição *</Label>
              <Textarea
                id="edit-description"
                value={trainingForm.description || ''}
                onChange={(e) => setTrainingForm({...trainingForm, description: e.target.value})}
                placeholder="Descreva o conteúdo e objetivos do treinamento"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="edit-format">Formato</Label>
                <Select
                  value={trainingForm.format || ''}
                  onValueChange={(value) => setTrainingForm({...trainingForm, format: value as Training['format']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Formato" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="presencial">Presencial</SelectItem>
                    <SelectItem value="hybrid">Híbrido</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="edit-duration">Duração</Label>
                <Input
                  id="edit-duration"
                  value={trainingForm.duration || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, duration: e.target.value})}
                  placeholder="Ex: 8 horas, 3 dias"
                />
              </div>
              <div>
                <Label htmlFor="edit-instructor">Instrutor</Label>
                <Input
                  id="edit-instructor"
                  value={trainingForm.instructor || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, instructor: e.target.value})}
                  placeholder="Nome do instrutor"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-start-date">Data de Início</Label>
                <Input
                  id="edit-start-date"
                  type="date"
                  value={trainingForm.startDate || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, startDate: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit-end-date">Data de Término</Label>
                <Input
                  id="edit-end-date"
                  type="date"
                  value={trainingForm.endDate || ''}
                  onChange={(e) => setTrainingForm({...trainingForm, endDate: e.target.value})}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="edit-status">Status</Label>
              <Select
                value={trainingForm.status || ''}
                onValueChange={(value) => setTrainingForm({...trainingForm, status: value as Training['status']})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Status do treinamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_started">Não Iniciado</SelectItem>
                  <SelectItem value="in_progress">Em Andamento</SelectItem>
                  <SelectItem value="completed">Concluído</SelectItem>
                  <SelectItem value="expired">Expirado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleUpdateTraining}>
                <Edit className="w-4 h-4 mr-2" />
                Atualizar Treinamento
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
