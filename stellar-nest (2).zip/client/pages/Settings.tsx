import { useState, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { database } from '@/lib/database';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  Settings as SettingsIcon, Users, Shield, Briefcase, FileText,
  Plus, Edit, Trash2, Save, MoreHorizontal, UserCheck,
  Key, Lock, Eye, EyeOff, CheckCircle, AlertTriangle,
  ArrowRight, ArrowLeft, Calendar, Clock, Star,
  Database, Globe, Mail, Bell, Palette, Zap, Cloud,
  Link, ExternalLink, Wifi, Smartphone
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface UserRole {
  id: string;
  name: string;
  displayName: string;
  permissions: string[];
  description: string;
}

interface SelectionStage {
  id: string;
  name: string;
  description: string;
  order: number;
  isRequired: boolean;
  estimatedDays: number;
  color: string;
}

interface SystemConfig {
  companyName: string;
  companyEmail: string;
  timezone: string;
  language: string;
  dateFormat: string;
  enableNotifications: boolean;
  enableEmailAlerts: boolean;
  retentionPolicy: number;
  maxFileSize: number;
}

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: any;
  isEnabled: boolean;
  requiredPermissions: string[];
  settings?: Record<string, any>;
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: string;
}

const availablePermissions = [
  { id: 'view_all_employees', name: 'Visualizar Todos os Colaboradores', category: 'employees' },
  { id: 'create_employee', name: 'Criar Colaborador', category: 'employees' },
  { id: 'edit_employee', name: 'Editar Colaborador', category: 'employees' },
  { id: 'delete_employee', name: 'Excluir Colaborador', category: 'employees' },
  { id: 'view_team_employees', name: 'Visualizar Equipe', category: 'employees' },
  { id: 'view_all_jobs', name: 'Visualizar Todas as Vagas', category: 'jobs' },
  { id: 'create_job', name: 'Criar Vaga', category: 'jobs' },
  { id: 'edit_job', name: 'Editar Vaga', category: 'jobs' },
  { id: 'delete_job', name: 'Excluir Vaga', category: 'jobs' },
  { id: 'view_public_jobs', name: 'Visualizar Vagas Públicas', category: 'jobs' },
  { id: 'apply_to_jobs', name: 'Candidatar-se a Vagas', category: 'jobs' },
  { id: 'view_all_evaluations', name: 'Visualizar Todas as Avaliações', category: 'evaluations' },
  { id: 'create_evaluation', name: 'Criar Avaliação', category: 'evaluations' },
  { id: 'edit_evaluation', name: 'Editar Avaliação', category: 'evaluations' },
  { id: 'view_team_evaluations', name: 'Visualizar Avaliações da Equipe', category: 'evaluations' },
  { id: 'view_own_evaluations', name: 'Visualizar Próprias Avaliações', category: 'evaluations' },
  { id: 'create_self_evaluation', name: 'Criar Auto-avaliação', category: 'evaluations' },
  { id: 'view_all_trainings', name: 'Visualizar Todos os Treinamentos', category: 'trainings' },
  { id: 'create_training', name: 'Criar Treinamento', category: 'trainings' },
  { id: 'edit_training', name: 'Editar Treinamento', category: 'trainings' },
  { id: 'view_trainings', name: 'Visualizar Treinamentos', category: 'trainings' },
  { id: 'join_training', name: 'Participar de Treinamento', category: 'trainings' },
  { id: 'view_reports', name: 'Visualizar Relatórios', category: 'reports' },
  { id: 'export_data', name: 'Exportar Dados', category: 'reports' },
  { id: 'view_own_profile', name: 'Visualizar Próprio Perfil', category: 'profile' },
  { id: 'edit_own_profile', name: 'Editar Próprio Perfil', category: 'profile' },
  { id: 'view_feedback', name: 'Visualizar Feedback', category: 'feedback' },
  { id: 'view_application_status', name: 'Visualizar Status da Candidatura', category: 'applications' },
  { id: 'manage_users', name: 'Gerenciar Usuários', category: 'system' },
  { id: 'system_config', name: 'Configurações do Sistema', category: 'system' }
];

export default function Settings() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('system');
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false);
  const [isStageDialogOpen, setIsStageDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [selectedStage, setSelectedStage] = useState<SelectionStage | null>(null);
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [isEditRoleDialogOpen, setIsEditRoleDialogOpen] = useState(false);

  // System Configuration State
  const [systemConfig, setSystemConfig] = useState<SystemConfig>({
    companyName: 'Integre RH',
    companyEmail: 'contato@integrehr.com',
    timezone: 'America/Sao_Paulo',
    language: 'pt-BR',
    dateFormat: 'dd/MM/yyyy',
    enableNotifications: true,
    enableEmailAlerts: true,
    retentionPolicy: 365,
    maxFileSize: 10
  });

  // User Roles Configuration
  const [userRoles, setUserRoles] = useState<UserRole[]>([
    {
      id: 'rh_admin',
      name: 'rh_admin',
      displayName: 'Administrador RH',
      description: 'Acesso completo ao sistema',
      permissions: [
        'view_all_employees', 'create_employee', 'edit_employee', 'delete_employee',
        'view_all_jobs', 'create_job', 'edit_job', 'delete_job',
        'view_all_evaluations', 'create_evaluation', 'edit_evaluation',
        'view_all_trainings', 'create_training', 'edit_training',
        'view_reports', 'export_data', 'manage_users', 'system_config'
      ]
    },
    {
      id: 'manager',
      name: 'manager',
      displayName: 'Gestor',
      description: 'Gestão da equipe e processos',
      permissions: [
        'view_team_employees', 'create_employee', 'edit_employee',
        'view_all_jobs', 'create_job', 'edit_job',
        'view_team_evaluations', 'create_evaluation', 'edit_evaluation',
        'view_all_trainings', 'create_training',
        'view_reports', 'export_data'
      ]
    },
    {
      id: 'employee',
      name: 'employee',
      displayName: 'Colaborador',
      description: 'Acesso básico para colaboradores',
      permissions: [
        'view_own_profile', 'edit_own_profile',
        'view_own_evaluations', 'create_self_evaluation',
        'view_trainings', 'join_training',
        'view_feedback'
      ]
    },
    {
      id: 'candidate',
      name: 'candidate',
      displayName: 'Candidato',
      description: 'Acesso para candidatos externos',
      permissions: [
        'view_public_jobs', 'apply_to_jobs', 'view_application_status'
      ]
    }
  ]);

  // Selection Process Stages
  const [selectionStages, setSelectionStages] = useState<SelectionStage[]>([
    {
      id: 'application',
      name: 'Aplicação Recebida',
      description: 'Candidato aplicou para a vaga',
      order: 0,
      isRequired: true,
      estimatedDays: 1,
      color: 'bg-gray-100'
    },
    {
      id: 'screening',
      name: 'Triagem de Currículo',
      description: 'Análise inicial do currículo e requisitos',
      order: 1,
      isRequired: true,
      estimatedDays: 2,
      color: 'bg-blue-100'
    },
    {
      id: 'phone_interview',
      name: 'Entrevista por Telefone',
      description: 'Primeira conversa com o candidato',
      order: 2,
      isRequired: false,
      estimatedDays: 3,
      color: 'bg-yellow-100'
    },
    {
      id: 'technical_test',
      name: 'Teste Técnico',
      description: 'Avaliação das competências técnicas',
      order: 3,
      isRequired: false,
      estimatedDays: 5,
      color: 'bg-purple-100'
    },
    {
      id: 'final_interview',
      name: 'Entrevista Final',
      description: 'Entrevista presencial com gestores',
      order: 4,
      isRequired: true,
      estimatedDays: 3,
      color: 'bg-orange-100'
    },
    {
      id: 'approved',
      name: 'Aprovado',
      description: 'Candidato aprovado no processo',
      order: 5,
      isRequired: true,
      estimatedDays: 1,
      color: 'bg-green-100'
    },
    {
      id: 'rejected',
      name: 'Rejeitado',
      description: 'Candidato não aprovado',
      order: 6,
      isRequired: true,
      estimatedDays: 1,
      color: 'bg-red-100'
    }
  ]);

  // Integrations Configuration
  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: 'slack',
      name: 'Slack',
      description: 'Integração com Slack para notificações e comunicação',
      icon: Zap,
      isEnabled: false,
      requiredPermissions: ['view_all_employees', 'manage_users'],
      status: 'disconnected',
      settings: {
        webhookUrl: '',
        channelName: '#rh-notifications'
      }
    },
    {
      id: 'email',
      name: 'Email SMTP',
      description: 'Configuração de servidor SMTP para envio de emails',
      icon: Mail,
      isEnabled: true,
      requiredPermissions: ['system_config'],
      status: 'connected',
      lastSync: new Date().toISOString(),
      settings: {
        smtpHost: 'smtp.gmail.com',
        smtpPort: 587,
        username: 'rh@empresa.com'
      }
    },
    {
      id: 'google_workspace',
      name: 'Google Workspace',
      description: 'Sincronização com Google Calendar e Drive',
      icon: Cloud,
      isEnabled: false,
      requiredPermissions: ['view_all_employees', 'create_employee'],
      status: 'disconnected',
      settings: {
        clientId: '',
        domain: ''
      }
    },
    {
      id: 'whatsapp',
      name: 'WhatsApp Business',
      description: 'Envio de notificações via WhatsApp',
      icon: Smartphone,
      isEnabled: false,
      requiredPermissions: ['view_all_employees'],
      status: 'error',
      settings: {
        apiKey: '',
        phoneNumber: ''
      }
    }
  ]);

  // Load saved configurations
  useEffect(() => {
    const savedConfig = localStorage.getItem('integrerh_system_config');
    if (savedConfig) {
      setSystemConfig(JSON.parse(savedConfig));
    }

    const savedRoles = localStorage.getItem('integrerh_user_roles');
    if (savedRoles) {
      setUserRoles(JSON.parse(savedRoles));
    }

    const savedStages = localStorage.getItem('integrerh_selection_stages');
    if (savedStages) {
      setSelectionStages(JSON.parse(savedStages));
    }

    const savedIntegrations = localStorage.getItem('integrerh_integrations');
    if (savedIntegrations) {
      setIntegrations(JSON.parse(savedIntegrations));
    }
  }, []);

  const canManageSystem = hasPermission(user?.role || 'employee', ['rh_admin']);

  const handleSaveSystemConfig = () => {
    // Save to localStorage or send to API
    localStorage.setItem('integrerh_system_config', JSON.stringify(systemConfig));
    alert('Configurações do sistema salvas com sucesso!');
  };

  const handleSaveUserRoles = () => {
    localStorage.setItem('integrerh_user_roles', JSON.stringify(userRoles));

    // Also save to database for integration
    database.set('user_roles', userRoles);

    alert('Permissões de usuário salvas com sucesso!');
  };

  const handleEditRole = (role: UserRole) => {
    setSelectedRole({ ...role });
    setIsEditRoleDialogOpen(true);
  };

  const handleSaveRole = () => {
    if (!selectedRole) return;

    setUserRoles(roles =>
      roles.map(role => role.id === selectedRole.id ? selectedRole : role)
    );

    setIsEditRoleDialogOpen(false);
    setSelectedRole(null);
  };

  const handleTogglePermission = (permissionId: string) => {
    if (!selectedRole) return;

    const hasPermission = selectedRole.permissions.includes(permissionId);
    let updatedPermissions;

    if (hasPermission) {
      updatedPermissions = selectedRole.permissions.filter(p => p !== permissionId);
    } else {
      updatedPermissions = [...selectedRole.permissions, permissionId];
    }

    setSelectedRole({
      ...selectedRole,
      permissions: updatedPermissions
    });
  };

  const handleToggleIntegration = (integrationId: string) => {
    setIntegrations(integrations =>
      integrations.map(integration =>
        integration.id === integrationId
          ? { ...integration, isEnabled: !integration.isEnabled }
          : integration
      )
    );
  };

  const handleSaveIntegrations = () => {
    localStorage.setItem('integrerh_integrations', JSON.stringify(integrations));

    // Also save to database
    database.set('integrations', integrations);

    alert('Configurações de integrações salvas com sucesso!');
  };

  const handleSaveSelectionStages = () => {
    localStorage.setItem('integrerh_selection_stages', JSON.stringify(selectionStages));
    alert('Fases do processo seletivo salvas com sucesso!');
  };

  const handleAddStage = () => {
    const newStage: SelectionStage = {
      id: `stage_${Date.now()}`,
      name: '',
      description: '',
      order: selectionStages.length,
      isRequired: false,
      estimatedDays: 1,
      color: 'bg-gray-100'
    };
    setSelectedStage(newStage);
    setIsStageDialogOpen(true);
  };

  const handleEditStage = (stage: SelectionStage) => {
    setSelectedStage(stage);
    setIsStageDialogOpen(true);
  };

  const handleSaveStage = () => {
    if (!selectedStage) return;
    
    if (selectedStage.id.startsWith('stage_')) {
      // New stage
      setSelectionStages([...selectionStages, selectedStage]);
    } else {
      // Edit existing stage
      setSelectionStages(stages => 
        stages.map(s => s.id === selectedStage.id ? selectedStage : s)
      );
    }
    setIsStageDialogOpen(false);
    setSelectedStage(null);
  };

  const handleDeleteStage = (stageId: string) => {
    if (confirm('Tem certeza que deseja excluir esta fase?')) {
      setSelectionStages(stages => stages.filter(s => s.id !== stageId));
    }
  };

  if (!canManageSystem) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <Shield className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Acesso Restrito
          </h3>
          <p className="text-gray-600">
            Você não tem permissão para acessar as configurações do sistema
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <SettingsIcon className="w-8 h-8 mr-3 text-purple-600" />
            Configurações do Sistema
          </h1>
          <p className="text-gray-600 mt-1">
            Gerencie configurações, permissões e processos
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="system">Configurações Gerais</TabsTrigger>
          <TabsTrigger value="permissions">Permissões</TabsTrigger>
          <TabsTrigger value="integrations">Integrações</TabsTrigger>
          <TabsTrigger value="selection">Processo Seletivo</TabsTrigger>
        </TabsList>

        {/* System Configuration Tab */}
        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2" />
                Configurações Gerais do Sistema
              </CardTitle>
              <CardDescription>
                Configure informações básicas da empresa e preferências do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="company-name">Nome da Empresa</Label>
                    <Input
                      id="company-name"
                      value={systemConfig.companyName}
                      onChange={(e) => setSystemConfig({...systemConfig, companyName: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="company-email">Email da Empresa</Label>
                    <Input
                      id="company-email"
                      type="email"
                      value={systemConfig.companyEmail}
                      onChange={(e) => setSystemConfig({...systemConfig, companyEmail: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="timezone">Fuso Horário</Label>
                    <Select 
                      value={systemConfig.timezone} 
                      onValueChange={(value) => setSystemConfig({...systemConfig, timezone: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="America/Sao_Paulo">São Paulo (UTC-3)</SelectItem>
                        <SelectItem value="America/New_York">Nova York (UTC-5)</SelectItem>
                        <SelectItem value="Europe/London">Londres (UTC+0)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="language">Idioma</Label>
                    <Select 
                      value={systemConfig.language} 
                      onValueChange={(value) => setSystemConfig({...systemConfig, language: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="es-ES">Español</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="date-format">Formato de Data</Label>
                    <Select 
                      value={systemConfig.dateFormat} 
                      onValueChange={(value) => setSystemConfig({...systemConfig, dateFormat: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dd/MM/yyyy">DD/MM/AAAA</SelectItem>
                        <SelectItem value="MM/dd/yyyy">MM/DD/AAAA</SelectItem>
                        <SelectItem value="yyyy-MM-dd">AAAA-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="max-file-size">Tamanho Máximo de Arquivo (MB)</Label>
                    <Input
                      id="max-file-size"
                      type="number"
                      value={systemConfig.maxFileSize}
                      onChange={(e) => setSystemConfig({...systemConfig, maxFileSize: Number(e.target.value)})}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Notificações</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Notificações Push</Label>
                      <p className="text-sm text-gray-600">Receber notificações no navegador</p>
                    </div>
                    <Switch
                      checked={systemConfig.enableNotifications}
                      onCheckedChange={(checked) => setSystemConfig({...systemConfig, enableNotifications: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Alertas por Email</Label>
                      <p className="text-sm text-gray-600">Enviar alertas importantes por email</p>
                    </div>
                    <Switch
                      checked={systemConfig.enableEmailAlerts}
                      onCheckedChange={(checked) => setSystemConfig({...systemConfig, enableEmailAlerts: checked})}
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSaveSystemConfig}>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Permissions Tab */}
        <TabsContent value="permissions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Permissões de Usuários
              </CardTitle>
              <CardDescription>
                Configure as permissões para cada tipo de usuário no sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userRoles.map((role) => (
                  <Card key={role.id} className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium">{role.displayName}</h4>
                        <p className="text-sm text-gray-600">{role.description}</p>
                      </div>
                      <Badge variant="outline">{role.permissions.length} permissões</Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                      {role.permissions.slice(0, 6).map((permission) => {
                        const permissionInfo = availablePermissions.find(p => p.id === permission);
                        return (
                          <div key={permission} className="flex items-center space-x-2 text-sm">
                            <CheckCircle className="w-3 h-3 text-green-500" />
                            <span className="text-gray-700">
                              {permissionInfo?.name || permission.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </span>
                          </div>
                        );
                      })}
                      {role.permissions.length > 6 && (
                        <div className="text-sm text-gray-500">
                          +{role.permissions.length - 6} mais permissões
                        </div>
                      )}
                    </div>

                    <div className="mt-4 flex justify-end">
                      <Button variant="outline" size="sm" onClick={() => handleEditRole(role)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Editar Permissões
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="flex justify-end mt-6">
                <Button onClick={handleSaveUserRoles}>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Permissões
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Link className="w-5 h-5 mr-2" />
                Integrações do Sistema
              </CardTitle>
              <CardDescription>
                Configure integrações externas e controle o acesso baseado em permissões
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {integrations.map((integration) => {
                  const IconComponent = integration.icon;
                  const hasRequiredPermissions = integration.requiredPermissions.every(permission =>
                    user && hasPermission(user.role || 'employee', [permission])
                  );

                  return (
                    <Card key={integration.id} className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                            <IconComponent className="w-6 h-6 text-gray-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <h4 className="font-medium">{integration.name}</h4>
                              <Badge
                                className={
                                  integration.status === 'connected' ? 'bg-green-100 text-green-700' :
                                  integration.status === 'error' ? 'bg-red-100 text-red-700' :
                                  'bg-gray-100 text-gray-700'
                                }
                              >
                                {integration.status === 'connected' ? 'Conectado' :
                                 integration.status === 'error' ? 'Erro' : 'Desconectado'}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">{integration.description}</p>

                            {integration.requiredPermissions.length > 0 && (
                              <div className="mt-2">
                                <p className="text-xs text-gray-500">Permissões necessárias:</p>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {integration.requiredPermissions.map(permission => {
                                    const permissionInfo = availablePermissions.find(p => p.id === permission);
                                    const hasPermission = user && hasPermission(user.role || 'employee', [permission]);
                                    return (
                                      <Badge
                                        key={permission}
                                        variant="outline"
                                        className={`text-xs ${
                                          hasPermission ? 'border-green-200 text-green-700' : 'border-red-200 text-red-700'
                                        }`}
                                      >
                                        {permissionInfo?.name || permission}
                                      </Badge>
                                    );
                                  })}
                                </div>
                              </div>
                            )}

                            {integration.lastSync && (
                              <p className="text-xs text-gray-500 mt-2">
                                Última sincronização: {format(new Date(integration.lastSync), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center space-x-3">
                          <Switch
                            checked={integration.isEnabled}
                            onCheckedChange={() => handleToggleIntegration(integration.id)}
                            disabled={!hasRequiredPermissions}
                          />
                          {hasRequiredPermissions ? (
                            <Button variant="outline" size="sm">
                              <Settings as any className="w-4 h-4 mr-2" />
                              Configurar
                            </Button>
                          ) : (
                            <Button variant="outline" size="sm" disabled>
                              <Lock className="w-4 h-4 mr-2" />
                              Sem Acesso
                            </Button>
                          )}
                        </div>
                      </div>

                      {!hasRequiredPermissions && (
                        <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                          <div className="flex items-start space-x-2">
                            <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5" />
                            <div>
                              <p className="text-sm text-yellow-800">
                                Você não possui as permissões necessárias para configurar esta integração.
                              </p>
                              <p className="text-xs text-yellow-700 mt-1">
                                Entre em contato com um administrador do sistema.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>

              <div className="flex justify-end mt-6">
                <Button onClick={handleSaveIntegrations}>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Integrações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Selection Process Tab */}
        <TabsContent value="selection" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <Briefcase className="w-5 h-5 mr-2" />
                  Fases do Processo Seletivo
                </div>
                <Button onClick={handleAddStage}>
                  <Plus className="w-4 h-4 mr-2" />
                  Nova Fase
                </Button>
              </CardTitle>
              <CardDescription>
                Configure as etapas do processo seletivo que os candidatos devem passar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {selectionStages
                  .sort((a, b) => a.order - b.order)
                  .map((stage) => (
                  <Card key={stage.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`w-8 h-8 ${stage.color} rounded-full flex items-center justify-center text-sm font-medium`}>
                          {stage.order + 1}
                        </div>
                        <div>
                          <h4 className="font-medium">{stage.name}</h4>
                          <p className="text-sm text-gray-600">{stage.description}</p>
                          <div className="flex items-center space-x-4 mt-1">
                            <span className="text-xs text-gray-500">
                              {stage.estimatedDays} dia(s) estimado(s)
                            </span>
                            {stage.isRequired && (
                              <Badge variant="outline" className="text-xs">Obrigatória</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleEditStage(stage)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        {!stage.isRequired && (
                          <Button variant="ghost" size="sm" onClick={() => handleDeleteStage(stage.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="flex justify-end mt-6">
                <Button onClick={handleSaveSelectionStages}>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Stage Dialog */}
      <Dialog open={isStageDialogOpen} onOpenChange={setIsStageDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedStage?.id.startsWith('stage_') ? 'Nova Fase' : 'Editar Fase'}
            </DialogTitle>
            <DialogDescription>
              Configure os detalhes da fase do processo seletivo
            </DialogDescription>
          </DialogHeader>

          {selectedStage && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="stage-name">Nome da Fase</Label>
                <Input
                  id="stage-name"
                  value={selectedStage.name}
                  onChange={(e) => setSelectedStage({...selectedStage, name: e.target.value})}
                  placeholder="Ex: Entrevista Técnica"
                />
              </div>
              <div>
                <Label htmlFor="stage-description">Descrição</Label>
                <Textarea
                  id="stage-description"
                  value={selectedStage.description}
                  onChange={(e) => setSelectedStage({...selectedStage, description: e.target.value})}
                  placeholder="Descreva o que acontece nesta fase"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="stage-days">Dias Estimados</Label>
                  <Input
                    id="stage-days"
                    type="number"
                    value={selectedStage.estimatedDays}
                    onChange={(e) => setSelectedStage({...selectedStage, estimatedDays: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <Label htmlFor="stage-color">Cor</Label>
                  <Select 
                    value={selectedStage.color} 
                    onValueChange={(value) => setSelectedStage({...selectedStage, color: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bg-gray-100">Cinza</SelectItem>
                      <SelectItem value="bg-blue-100">Azul</SelectItem>
                      <SelectItem value="bg-green-100">Verde</SelectItem>
                      <SelectItem value="bg-yellow-100">Amarelo</SelectItem>
                      <SelectItem value="bg-purple-100">Roxo</SelectItem>
                      <SelectItem value="bg-orange-100">Laranja</SelectItem>
                      <SelectItem value="bg-red-100">Vermelho</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={selectedStage.isRequired}
                  onCheckedChange={(checked) => setSelectedStage({...selectedStage, isRequired: checked})}
                />
                <Label>Fase obrigatória</Label>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsStageDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleSaveStage}>
                  Salvar Fase
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Role Permissions Dialog */}
      <Dialog open={isEditRoleDialogOpen} onOpenChange={setIsEditRoleDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Editar Permissões - {selectedRole?.displayName}
            </DialogTitle>
            <DialogDescription>
              Configure as permissões específicas para este tipo de usuário
            </DialogDescription>
          </DialogHeader>

          {selectedRole && (
            <div className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">{selectedRole.displayName}</h4>
                <p className="text-sm text-blue-700">{selectedRole.description}</p>
                <p className="text-xs text-blue-600 mt-2">
                  {selectedRole.permissions.length} permissões selecionadas
                </p>
              </div>

              {Object.entries(
                availablePermissions.reduce((acc, permission) => {
                  if (!acc[permission.category]) {
                    acc[permission.category] = [];
                  }
                  acc[permission.category].push(permission);
                  return acc;
                }, {} as Record<string, typeof availablePermissions>)
              ).map(([category, permissions]) => (
                <div key={category} className="space-y-3">
                  <h3 className="text-lg font-medium text-gray-900 capitalize">
                    {category === 'employees' ? 'Colaboradores' :
                     category === 'jobs' ? 'Vagas' :
                     category === 'evaluations' ? 'Avaliações' :
                     category === 'trainings' ? 'Treinamentos' :
                     category === 'reports' ? 'Relatórios' :
                     category === 'profile' ? 'Perfil' :
                     category === 'feedback' ? 'Feedback' :
                     category === 'applications' ? 'Candidaturas' :
                     category === 'system' ? 'Sistema' : category}
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {permissions.map((permission) => {
                      const isSelected = selectedRole.permissions.includes(permission.id);
                      return (
                        <div
                          key={permission.id}
                          className={`flex items-center space-x-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                            isSelected ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                          }`}
                          onClick={() => handleTogglePermission(permission.id)}
                        >
                          <div className={`w-4 h-4 border-2 rounded flex items-center justify-center ${
                            isSelected ? 'bg-blue-600 border-blue-600' : 'border-gray-300'
                          }`}>
                            {isSelected && (
                              <CheckCircle className="w-3 h-3 text-white" />
                            )}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">
                              {permission.name}
                            </p>
                            <p className="text-xs text-gray-600">
                              ID: {permission.id}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div className="flex justify-end space-x-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsEditRoleDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleSaveRole}>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Permissões
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
