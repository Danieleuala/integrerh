import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Award, CheckCircle, Clock, User, Star, Send, ArrowLeft,
  Target, BookOpen, MessageSquare
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface EvaluationCompetency {
  name: string;
  description: string;
  maxScore: number;
  weight: number;
}

interface EvaluationResponse {
  competencyName: string;
  score: number;
  comments: string;
}

interface EvaluationLink {
  id: string;
  evaluationId: string;
  employeeId: string;
  employeeName: string;
  position: string;
  department: string;
  evaluatorRole: string;
  type: string;
  period: string;
  dueDate: string;
  competencies: EvaluationCompetency[];
  instructions: string;
  isCompleted: boolean;
  responses: EvaluationResponse[];
}

export default function PublicEvaluation() {
  const { linkId } = useParams<{ linkId: string }>();
  const navigate = useNavigate();
  const [evaluationLink, setEvaluationLink] = useState<EvaluationLink | null>(null);
  const [responses, setResponses] = useState<EvaluationResponse[]>([]);
  const [currentCompetencyIndex, setCurrentCompetencyIndex] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [evaluatorInfo, setEvaluatorInfo] = useState({
    name: '',
    email: '',
    relationship: ''
  });

  useEffect(() => {
    if (linkId) {
      loadEvaluationLink();
    }
  }, [linkId]);

  const loadEvaluationLink = () => {
    try {
      const savedLinks = localStorage.getItem('evaluationLinks');
      if (savedLinks) {
        const links = JSON.parse(savedLinks);
        const link = links.find((l: EvaluationLink) => l.id === linkId);
        
        if (link) {
          setEvaluationLink(link);
          setIsCompleted(link.isCompleted);
          
          // Initialize responses
          const initialResponses = link.competencies.map(comp => ({
            competencyName: comp.name,
            score: 5,
            comments: ''
          }));
          setResponses(initialResponses);
        } else {
          console.error('Link de avaliação não encontrado');
        }
      }
    } catch (error) {
      console.error('Erro ao carregar link de avaliação:', error);
    }
  };

  const updateResponse = (competencyName: string, field: 'score' | 'comments', value: number | string) => {
    setResponses(prev => prev.map(response =>
      response.competencyName === competencyName
        ? { ...response, [field]: value }
        : response
    ));
  };

  const handleSubmit = async () => {
    // Validate evaluator info
    if (!evaluatorInfo.name || !evaluatorInfo.email) {
      alert('Por favor, preencha seu nome e email.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Update evaluation link with responses
      const updatedLink = {
        ...evaluationLink,
        isCompleted: true,
        responses,
        evaluatorName: evaluatorInfo.name,
        evaluatorId: evaluatorInfo.email,
        completedDate: new Date().toISOString()
      };

      // Save to localStorage
      const savedLinks = localStorage.getItem('evaluationLinks');
      if (savedLinks) {
        const links = JSON.parse(savedLinks);
        const updatedLinks = links.map((l: EvaluationLink) =>
          l.id === linkId ? updatedLink : l
        );
        localStorage.setItem('evaluationLinks', JSON.stringify(updatedLinks));
      }

      setIsCompleted(true);
      
    } catch (error) {
      console.error('Erro ao enviar avaliação:', error);
      alert('Erro ao enviar avaliação. Tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getScoreLabel = (score: number) => {
    if (score >= 9) return 'Excelente';
    if (score >= 7) return 'Muito Bom';
    if (score >= 5) return 'Bom';
    if (score >= 3) return 'Regular';
    return 'Precisa Melhorar';
  };

  const getScoreColor = (score: number) => {
    if (score >= 9) return 'text-green-600';
    if (score >= 7) return 'text-blue-600';
    if (score >= 5) return 'text-yellow-600';
    if (score >= 3) return 'text-orange-600';
    return 'text-red-600';
  };

  const progress = evaluationLink ? ((currentCompetencyIndex + 1) / evaluationLink.competencies.length) * 100 : 0;

  if (!evaluationLink) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <Award className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Avaliação não encontrada
            </h3>
            <p className="text-gray-600 mb-4">
              O link de avaliação pode estar expirado ou inválido.
            </p>
            <Button onClick={() => navigate('/')}>
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-2xl">
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 mx-auto text-green-600 mb-6" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Avaliação Enviada com Sucesso!
            </h2>
            <p className="text-gray-600 mb-6">
              Obrigado por dedicar seu tempo para avaliar <strong>{evaluationLink.employeeName}</strong>.
              Sua avaliação é muito importante para o desenvolvimento profissional.
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-blue-800 text-sm">
                ✅ Suas respostas foram registradas com sucesso e enviadas para análise.
              </p>
              <p className="text-blue-700 text-xs mt-2">
                📋 Os resultados serão analisados pela equipe de RH e gestores responsáveis.
              </p>
            </div>
            <Button onClick={() => navigate('/')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentCompetency = evaluationLink.competencies[currentCompetencyIndex];
  const currentResponse = responses.find(r => r.competencyName === currentCompetency?.name);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center">
                <Award className="w-8 h-8 mr-3 text-blue-600" />
                Avaliação de Desempenho
              </h1>
              <p className="text-gray-600 mt-1">
                {evaluationLink.type} - {evaluationLink.period}
              </p>
            </div>
            <Badge variant="outline" className="border-blue-200 text-blue-700">
              <Clock className="w-4 h-4 mr-1" />
              Válido até {format(new Date(evaluationLink.dueDate), 'dd/MM/yyyy', { locale: ptBR })}
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Progress */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                Progresso da Avaliação
              </span>
              <span className="text-sm text-gray-500">
                {currentCompetencyIndex + 1} de {evaluationLink.competencies.length}
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>

        {/* Employee Info */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <Avatar className="w-16 h-16">
                <AvatarFallback className="bg-blue-100 text-blue-600 text-lg">
                  {evaluationLink.employeeName.split(' ').map(n => n[0]).join('').toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{evaluationLink.employeeName}</h3>
                <p className="text-gray-600">{evaluationLink.position}</p>
                <p className="text-sm text-gray-500">{evaluationLink.department}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Evaluator Info */}
        {currentCompetencyIndex === 0 && !evaluatorInfo.name && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2" />
                Suas Informações
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="evaluatorName">Nome Completo *</Label>
                <Input
                  id="evaluatorName"
                  value={evaluatorInfo.name}
                  onChange={(e) => setEvaluatorInfo(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Digite seu nome completo"
                />
              </div>
              <div>
                <Label htmlFor="evaluatorEmail">Email *</Label>
                <Input
                  id="evaluatorEmail"
                  type="email"
                  value={evaluatorInfo.email}
                  onChange={(e) => setEvaluatorInfo(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Digite seu email"
                />
              </div>
              <div>
                <Label htmlFor="relationship">Relacionamento Profissional</Label>
                <Input
                  id="relationship"
                  value={evaluatorInfo.relationship}
                  onChange={(e) => setEvaluatorInfo(prev => ({ ...prev, relationship: e.target.value }))}
                  placeholder="Ex: Colega de equipe, Supervisor, Cliente interno..."
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Competency Evaluation */}
        {evaluatorInfo.name && currentCompetency && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <Target className="w-5 h-5 mr-2" />
                  {currentCompetency.name}
                </div>
                <Badge variant="secondary">
                  {currentCompetencyIndex + 1}/{evaluationLink.competencies.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-600">{currentCompetency.description}</p>
              
              <div>
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-base font-medium">Avaliação</Label>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-blue-600">
                      {currentResponse?.score}/10
                    </div>
                    <div className={`text-sm font-medium ${getScoreColor(currentResponse?.score || 5)}`}>
                      {getScoreLabel(currentResponse?.score || 5)}
                    </div>
                  </div>
                </div>
                
                <Slider
                  value={[currentResponse?.score || 5]}
                  onValueChange={([value]) => updateResponse(currentCompetency.name, 'score', value)}
                  max={10}
                  min={1}
                  step={1}
                  className="w-full"
                />
                
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span>1 - Muito Baixo</span>
                  <span>5 - Médio</span>
                  <span>10 - Excelente</span>
                </div>
              </div>

              <div>
                <Label htmlFor="comments" className="text-base font-medium">
                  Comentários e Sugestões
                </Label>
                <Textarea
                  id="comments"
                  value={currentResponse?.comments || ''}
                  onChange={(e) => updateResponse(currentCompetency.name, 'comments', e.target.value)}
                  placeholder="Compartilhe observações específicas, exemplos ou sugestões de melhoria..."
                  className="mt-2 min-h-[100px]"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Navigation */}
        {evaluatorInfo.name && (
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentCompetencyIndex(Math.max(0, currentCompetencyIndex - 1))}
              disabled={currentCompetencyIndex === 0}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Anterior
            </Button>

            {currentCompetencyIndex === evaluationLink.competencies.length - 1 ? (
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="bg-green-600 hover:bg-green-700"
              >
                {isSubmitting ? (
                  <>Enviando...</>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Enviar Avaliação
                  </>
                )}
              </Button>
            ) : (
              <Button
                onClick={() => setCurrentCompetencyIndex(currentCompetencyIndex + 1)}
              >
                Próximo
                <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
