import { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { EnhancedDataStore, Test, TestQuestion, TestAnswer, TestResult } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { 
  Clock, CheckCircle, AlertCircle, FileText, User, Mail,
  Timer, Award, Target, Heart, ChevronRight, ChevronLeft,
  Send, XCircle, RotateCcw, Play, BookOpen
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface CandidateInfo {
  name: string;
  email: string;
  phone?: string;
}

export default function PublicTest() {
  const { testId } = useParams();
  const navigate = useNavigate();
  
  // State management
  const [test, setTest] = useState<Test | null>(null);
  const [candidateInfo, setCandidateInfo] = useState<CandidateInfo>({
    name: '',
    email: '',
    phone: ''
  });
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, TestAnswer>>({});
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [testStatus, setTestStatus] = useState<'info' | 'started' | 'completed' | 'submitted'>('info');
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);

  // Load test data
  useEffect(() => {
    if (testId) {
      const testData = EnhancedDataStore.getTestById(testId);
      if (testData && testData.isActive) {
        setTest(testData);
        setTimeLeft(testData.timeLimit * 60); // Convert to seconds
      } else {
        // Test not found or inactive
        navigate('/');
      }
    }
  }, [testId, navigate]);

  // Timer effect
  useEffect(() => {
    if (testStatus === 'started' && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleSubmitTest(true); // Auto-submit when time runs out
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [testStatus, timeLeft]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = useMemo(() => {
    if (!test) return 0;
    const answeredQuestions = test.questions.filter(q => answers[q.id]).length;
    return (answeredQuestions / test.questions.length) * 100;
  }, [test, answers]);

  const handleStartTest = () => {
    if (!candidateInfo.name || !candidateInfo.email) {
      alert('Por favor, preencha seu nome e e-mail para continuar.');
      return;
    }

    setTestStatus('started');
    setStartTime(new Date());
  };

  const handleAnswerChange = (questionId: string, answer: string | number) => {
    const question = test?.questions.find(q => q.id === questionId);
    if (!question) return;

    const testAnswer: TestAnswer = {
      questionId,
      answer,
      points: 0 // Will be calculated on submission
    };

    setAnswers(prev => ({ ...prev, [questionId]: testAnswer }));
  };

  const calculateScore = (): TestResult => {
    if (!test || !startTime) {
      throw new Error('Test or start time not available');
    }

    let totalScore = 0;
    let totalPoints = 0;
    const gradedAnswers: TestAnswer[] = [];

    test.questions.forEach(question => {
      const answer = answers[question.id];
      totalPoints += question.weight;

      if (answer) {
        let points = 0;
        let isCorrect = false;

        if (question.type === 'multiple_choice' && 
            typeof answer.answer === 'number' && 
            answer.answer === question.correctAnswer) {
          points = question.weight;
          isCorrect = true;
        }
        // For essay questions, points would be manually graded later

        gradedAnswers.push({
          ...answer,
          points,
          isCorrect
        });

        totalScore += points;
      }
    });

    const percentage = totalPoints > 0 ? (totalScore / totalPoints) * 100 : 0;
    const passed = percentage >= test.passingScore;

    const result: TestResult = {
      id: `result_${Date.now()}`,
      testId: test.id,
      candidateId: '', // Will be set when candidate is created
      answers: gradedAnswers,
      score: totalScore,
      percentage,
      passed,
      startedAt: startTime.toISOString(),
      completedAt: new Date().toISOString(),
      timeSpent: Math.floor((Date.now() - startTime.getTime()) / 1000 / 60) // minutes
    };

    return result;
  };

  const handleSubmitTest = (autoSubmit = false) => {
    if (!autoSubmit && testStatus !== 'started') return;

    try {
      const result = calculateScore();
      
      // Create or update candidate
      const existingCandidates = EnhancedDataStore.getCandidates();
      let candidate = existingCandidates.find(c => c.email === candidateInfo.email);
      
      if (!candidate) {
        candidate = EnhancedDataStore.addCandidate({
          name: candidateInfo.name,
          email: candidateInfo.email,
          phone: candidateInfo.phone || '',
          skills: [],
          experience: '',
          education: '',
          location: '',
          applications: [],
          testResults: [],
          interviewHistory: [],
          tags: [],
          source: 'website'
        });
      }

      // Update result with candidate ID
      result.candidateId = candidate.id;

      // Update candidate with test result
      const updatedTestResults = [...candidate.testResults, result];
      EnhancedDataStore.updateCandidate(candidate.id, {
        testResults: updatedTestResults
      });

      setTestResult(result);
      setTestStatus('completed');
      
    } catch (error) {
      console.error('Error submitting test:', error);
      alert('Erro ao enviar a prova. Tente novamente.');
    }
  };

  const currentQuestion = test?.questions[currentQuestionIndex];
  const canGoNext = currentQuestionIndex < (test?.questions.length || 0) - 1;
  const canGoPrevious = currentQuestionIndex > 0;

  if (!test) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Prova não encontrada
            </h2>
            <p className="text-gray-600 mb-4">
              A prova solicitada não está disponível ou foi desativada.
            </p>
            <Button onClick={() => navigate('/')}>
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-10 h-10 bg-integre-gradient rounded-xl flex items-center justify-center shadow-lg">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                    Integre RH
                  </span>
                  <p className="text-xs text-gray-500 -mt-1">Sistema de Avaliação</p>
                </div>
              </div>
            </div>
            {testStatus === 'started' && (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-sm">
                  <Clock className="w-4 h-4 text-purple-600" />
                  <span className={`font-mono ${timeLeft < 300 ? 'text-red-600' : 'text-gray-600'}`}>
                    {formatTime(timeLeft)}
                  </span>
                </div>
                <Progress value={(1 - timeLeft / (test.timeLimit * 60)) * 100} className="w-24" />
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Test Information Screen */}
        {testStatus === 'info' && (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-purple-600" />
              </div>
              <CardTitle className="text-2xl">{test.name}</CardTitle>
              <CardDescription className="text-lg">
                {test.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Test Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="text-center">
                  <Clock className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                  <div className="text-sm text-gray-600">Tempo Limite</div>
                  <div className="font-semibold">{test.timeLimit} minutos</div>
                </div>
                <div className="text-center">
                  <FileText className="w-6 h-6 text-green-500 mx-auto mb-2" />
                  <div className="text-sm text-gray-600">Questões</div>
                  <div className="font-semibold">{test.questions.length}</div>
                </div>
                <div className="text-center">
                  <Target className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                  <div className="text-sm text-gray-600">Nota Mínima</div>
                  <div className="font-semibold">{test.passingScore}%</div>
                </div>
              </div>

              {/* Candidate Information Form */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium text-gray-900">Suas Informações</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input
                      id="name"
                      value={candidateInfo.name}
                      onChange={(e) => setCandidateInfo(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Digite seu nome completo"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">E-mail *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={candidateInfo.email}
                      onChange={(e) => setCandidateInfo(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="seu.email@exemplo.com"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label htmlFor="phone">Telefone (opcional)</Label>
                    <Input
                      id="phone"
                      value={candidateInfo.phone}
                      onChange={(e) => setCandidateInfo(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="(00) 00000-0000"
                    />
                  </div>
                </div>
              </div>

              {/* Instructions */}
              <Alert>
                <BookOpen className="w-4 h-4" />
                <AlertDescription className="space-y-2">
                  <p className="font-medium">Instruções importantes:</p>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Leia cada questão com atenção antes de responder</li>
                    <li>Você pode navegar entre as questões e alterar suas respostas</li>
                    <li>O tempo é limitado - gerencie bem seu tempo</li>
                    <li>Certifique-se de responder todas as questões antes de enviar</li>
                    <li>Após enviar, não será possível alterar as respostas</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <Button 
                onClick={handleStartTest}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                size="lg"
              >
                <Play className="w-5 h-5 mr-2" />
                Iniciar Prova
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Test Taking Screen */}
        {testStatus === 'started' && currentQuestion && (
          <div className="space-y-6">
            {/* Progress Header */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">
                    Questão {currentQuestionIndex + 1} de {test.questions.length}
                  </span>
                  <span className="text-sm text-gray-600">
                    {Math.round(progress)}% concluído
                  </span>
                </div>
                <Progress value={progress} />
              </CardContent>
            </Card>

            {/* Question Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">
                      Questão {currentQuestionIndex + 1}
                    </Badge>
                    {currentQuestion.type === 'multiple_choice' ? (
                      <Badge className="bg-blue-100 text-blue-700">Múltipla Escolha</Badge>
                    ) : (
                      <Badge className="bg-green-100 text-green-700">Dissertativa</Badge>
                    )}
                    <Badge variant="secondary">{currentQuestion.weight} ponto(s)</Badge>
                  </div>
                  {currentQuestion.category && (
                    <Badge variant="outline">{currentQuestion.category}</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4 leading-relaxed">
                    {currentQuestion.text}
                  </h3>
                </div>

                {/* Multiple Choice Answer */}
                {currentQuestion.type === 'multiple_choice' && currentQuestion.options && (
                  <RadioGroup
                    value={answers[currentQuestion.id]?.answer?.toString() || ''}
                    onValueChange={(value) => handleAnswerChange(currentQuestion.id, parseInt(value))}
                  >
                    <div className="space-y-3">
                      {currentQuestion.options.map((option, index) => (
                        <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                          <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                          <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                            <span className="font-medium text-gray-700 mr-2">
                              {String.fromCharCode(65 + index)})
                            </span>
                            {option}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </RadioGroup>
                )}

                {/* Essay Answer */}
                {currentQuestion.type === 'essay' && (
                  <div>
                    <Label htmlFor="essay-answer">Sua Resposta:</Label>
                    <Textarea
                      id="essay-answer"
                      value={answers[currentQuestion.id]?.answer?.toString() || ''}
                      onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                      placeholder="Digite sua resposta aqui..."
                      rows={8}
                      className="mt-2"
                    />
                    <p className="text-sm text-gray-500 mt-2">
                      Seja claro e objetivo em sua resposta. Esta questão será avaliada manualmente.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex justify-between items-center">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                disabled={!canGoPrevious}
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Anterior
              </Button>

              <div className="flex space-x-3">
                {canGoNext ? (
                  <Button
                    onClick={() => setCurrentQuestionIndex(prev => Math.min(test.questions.length - 1, prev + 1))}
                  >
                    Próxima
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button
                    onClick={() => setShowSubmitDialog(true)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Finalizar Prova
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Test Completed Screen */}
        {testStatus === 'completed' && testResult && (
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8 text-center">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${
                testResult.passed ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {testResult.passed ? (
                  <CheckCircle className="w-10 h-10 text-green-600" />
                ) : (
                  <XCircle className="w-10 h-10 text-red-600" />
                )}
              </div>
              
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                Prova Concluída!
              </h2>
              
              <p className="text-gray-600 mb-6">
                Sua prova foi finalizada e enviada com sucesso para análise.
              </p>

              {/* Simple completion info */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-2">
                    Prova Concluída
                  </div>
                  <p className="text-blue-800 text-sm">
                    Realizada em {format(new Date(testResult.completedAt), 'dd/MM/yyyy \'às\' HH:mm', { locale: ptBR })}
                  </p>
                  <p className="text-blue-700 text-xs mt-2">
                    Tempo utilizado: {testResult.timeSpent} minutos
                  </p>
                </div>
              </div>

              <Alert className="border-blue-200 bg-blue-50">
                <AlertDescription className="text-blue-700">
                  📋 Seus resultados foram registrados e enviados para análise pela equipe de RH.
                  <br />
                  📞 Você será contatado sobre as próximas etapas do processo seletivo.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Submit Confirmation Dialog */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Finalizar Prova</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja finalizar a prova? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Questões respondidas:</span>
                  <span className="font-medium ml-2">
                    {test?.questions.filter(q => answers[q.id]).length || 0} de {test?.questions.length || 0}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Tempo restante:</span>
                  <span className="font-medium ml-2">{formatTime(timeLeft)}</span>
                </div>
              </div>
            </div>

            {test && test.questions.filter(q => !answers[q.id]).length > 0 && (
              <Alert>
                <AlertCircle className="w-4 h-4" />
                <AlertDescription>
                  Você ainda tem {test.questions.filter(q => !answers[q.id]).length} questão(ões) sem resposta.
                  Deseja mesmo finalizar?
                </AlertDescription>
              </Alert>
            )}

            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
                Continuar Prova
              </Button>
              <Button onClick={() => {
                setShowSubmitDialog(false);
                handleSubmitTest();
              }}>
                Finalizar Prova
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
