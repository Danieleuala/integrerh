import { useState, useMemo, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { useLocation, useSearchParams } from 'react-router-dom';
import { IntegratedDataStore, Document as DocType, Employee } from '@/lib/mockData';
import { database } from '@/lib/database';
import { DocumentUpload } from '@/components/DocumentUpload';
import { DocumentViewer } from '@/components/DocumentViewer';
import DocumentStorage from '@/components/DocumentStorage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  FileText, Plus, Search, Download, Eye, Edit, MoreHorizontal,
  Users, Upload, Folder, Archive, Share, Lock, Clock,
  CheckCircle, AlertTriangle, File, FileImage, Award,
  Shield, Star, Tag, Filter, Calendar, HardDrive,
  Trash2, Copy, ExternalLink, Database, FolderOpen
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DocumentCategory {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: any;
  requiredFor?: string[];
}

interface DocumentTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  template?: string;
  fields?: string[];
}

interface CompanyDocument {
  id: string;
  name: string;
  type: 'policy' | 'procedure' | 'contract_template' | 'manual' | 'form';
  category: string;
  content?: string;
  uploadDate: string;
  lastModified: string;
  version: string;
  author: string;
  status: 'draft' | 'active' | 'archived';
  tags?: string[];
  accessLevel: 'public' | 'restricted' | 'confidential';
  departments?: string[];
}

export default function Documents() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const [employees, setEmployees] = useState(IntegratedDataStore.getEmployees());
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Load employees from database on component mount
  useEffect(() => {
    const dbEmployees = database.getEmployees();
    if (dbEmployees.length > 0) {
      setEmployees(dbEmployees);
    }
  }, [refreshTrigger]);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<DocType | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isEmployeeDocsDialogOpen, setIsEmployeeDocsDialogOpen] = useState(false);
  const [newDocumentType, setNewDocumentType] = useState<string>('');
  const [newDocumentDescription, setNewDocumentDescription] = useState('');

  const canViewAll = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canManage = hasPermission(user?.role || 'employee', ['rh_admin']);

  // Detectar employeeId da URL e abrir dialog de upload automaticamente
  useEffect(() => {
    const employeeId = searchParams.get('employeeId');
    if (employeeId) {
      const employee = employees.find(emp => emp.id === employeeId);
      if (employee) {
        setSelectedEmployee(employee);
        setIsUploadDialogOpen(true);
      }
    }
  }, [searchParams, employees]);

  // Categorias de documentos
  const documentCategories: DocumentCategory[] = [
    {
      id: 'documentos_pessoais',
      name: 'Documentos Pessoais',
      description: 'RG, CPF, CNH, Carteira de Trabalho, Certidões',
      color: 'bg-blue-500',
      icon: FileText,
      requiredFor: ['admissao', 'atualizacao_cadastral']
    },
    {
      id: 'contratos',
      name: 'Contratos',
      description: 'Contratos de trabalho, termos aditivos, rescisões',
      color: 'bg-green-500',
      icon: FileText,
      requiredFor: ['admissao', 'promocao']
    },
    {
      id: 'atestados',
      name: 'Atestados',
      description: 'Atestados médicos, odontológicos e de saúde ocupacional',
      color: 'bg-red-500',
      icon: FileText,
      requiredFor: ['afastamentos', 'controle_medico']
    },
    {
      id: 'documentos_admissionais',
      name: 'Documentos Admissionais',
      description: 'Exames admissionais, declarações, formulários de admissão',
      color: 'bg-orange-500',
      icon: FileText,
      requiredFor: ['processo_admissional']
    },
    {
      id: 'comunicados_internos',
      name: 'Comunicados Internos',
      description: 'Comunicados, memorandos, circulares internas',
      color: 'bg-purple-500',
      icon: FileText,
      requiredFor: ['comunicacao_interna']
    },
    {
      id: 'outros',
      name: 'Outros',
      description: 'Documentos diversos não categorizados',
      color: 'bg-gray-500',
      icon: FolderOpen,
      requiredFor: ['arquivo_geral']
    }
  ];

  // Documentos da empresa (mock)
  const [companyDocuments] = useState<CompanyDocument[]>([
    {
      id: 'cd1',
      name: 'Política de Home Office',
      type: 'policy',
      category: 'company',
      uploadDate: '2024-01-15',
      lastModified: '2024-01-20',
      version: '2.1',
      author: 'Ana Silva',
      status: 'active',
      tags: ['home office', 'política', 'trabalho remoto'],
      accessLevel: 'public',
      departments: ['Todos']
    },
    {
      id: 'cd2',
      name: 'Manual do Colaborador',
      type: 'manual',
      category: 'company',
      uploadDate: '2024-01-10',
      lastModified: '2024-01-15',
      version: '3.0',
      author: 'Ana Silva',
      status: 'active',
      tags: ['manual', 'orientações', 'colaborador'],
      accessLevel: 'public',
      departments: ['Todos']
    },
    {
      id: 'cd3',
      name: 'Procedimento de Segurança da Informação',
      type: 'procedure',
      category: 'company',
      uploadDate: '2024-01-08',
      lastModified: '2024-01-12',
      version: '1.5',
      author: 'Carlos Mendes',
      status: 'active',
      tags: ['segurança', 'informação', 'procedimento'],
      accessLevel: 'restricted',
      departments: ['Tecnologia', 'Recursos Humanos']
    }
  ]);

  // Templates de documentos
  const documentTemplates: DocumentTemplate[] = [
    {
      id: 'temp1',
      name: 'Solicitação de Férias',
      description: 'Formulário para solicitação de período de férias',
      category: 'form',
      fields: ['periodo_inicio', 'periodo_fim', 'justificativa']
    },
    {
      id: 'temp2',
      name: 'Declaração de Dependentes',
      description: 'Formulário para declaração de dependentes',
      category: 'form',
      fields: ['nome_dependente', 'parentesco', 'data_nascimento']
    },
    {
      id: 'temp3',
      name: 'Termo de Responsabilidade - Equipamentos',
      description: 'Termo de responsabilidade para uso de equipamentos',
      category: 'contract_template',
      fields: ['equipamento', 'numero_serie', 'data_entrega']
    }
  ];

  // Todos os documentos dos colaboradores
  const allEmployeeDocuments = useMemo(() => {
    return employees.flatMap(emp => 
      emp.documents.map(doc => ({ ...doc, employeeId: emp.id, employeeName: emp.name }))
    );
  }, [employees]);

  const filteredDocuments = useMemo(() => {
    return allEmployeeDocuments.filter(doc => {
      const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           doc.employeeName.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesType = typeFilter === 'all' || doc.type === typeFilter;
      const matchesCategory = categoryFilter === 'all' || doc.type === categoryFilter;

      return matchesSearch && matchesType && matchesCategory;
    });
  }, [allEmployeeDocuments, searchTerm, typeFilter, categoryFilter]);

  const getDocumentIcon = (type: DocType['type']) => {
    switch (type) {
      case 'contract':
        return <FileText className="w-5 h-5 text-green-600" />;
      case 'id':
        return <FileText className="w-5 h-5 text-blue-600" />;
      case 'certificate':
        return <Star className="w-5 h-5 text-purple-600" />;
      case 'atestados':
        return <FileText className="w-5 h-5 text-red-600" />;
      case 'documentos_admissionais':
        return <FileText className="w-5 h-5 text-orange-600" />;
      case 'comunicados_internos':
        return <FileText className="w-5 h-5 text-purple-600" />;
      default:
        return <File className="w-5 h-5 text-gray-600" />;
    }
  };

  const getCategoryBadge = (type: DocType['type']) => {
    const typeToCategory: Record<string, { name: string; color: string }> = {
      'contract': { name: 'Contratos', color: 'bg-green-100 text-green-700' },
      'id': { name: 'Docs. Pessoais', color: 'bg-blue-100 text-blue-700' },
      'certificate': { name: 'Docs. Admissionais', color: 'bg-orange-100 text-orange-700' },
      'atestados': { name: 'Atestados', color: 'bg-red-100 text-red-700' },
      'comunicados_internos': { name: 'Comunicados', color: 'bg-purple-100 text-purple-700' },
      'other': { name: 'Outros', color: 'bg-gray-100 text-gray-700' }
    };

    const category = typeToCategory[type] || typeToCategory['other'];
    return <Badge className={category.color}>{category.name}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-700">Ativo</Badge>;
      case 'draft':
        return <Badge className="bg-yellow-100 text-yellow-700">Rascunho</Badge>;
      case 'archived':
        return <Badge className="bg-gray-100 text-gray-700">Arquivado</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getAccessLevelBadge = (level: string) => {
    switch (level) {
      case 'public':
        return <Badge variant="outline" className="border-green-200 text-green-700">Público</Badge>;
      case 'restricted':
        return <Badge variant="outline" className="border-yellow-200 text-yellow-700">Restrito</Badge>;
      case 'confidential':
        return <Badge variant="outline" className="border-red-200 text-red-700">Confidencial</Badge>;
      default:
        return <Badge variant="secondary">Normal</Badge>;
    }
  };

  const handleViewDocument = (document: DocType) => {
    setSelectedDocument(document);
    setIsViewDialogOpen(true);
  };

  const handleViewEmployeeDocuments = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsEmployeeDocsDialogOpen(true);
  };

  const handleExportDocuments = () => {
    const data = {
      employeeDocuments: canViewAll ? filteredDocuments : 
        filteredDocuments.filter(doc => doc.employeeId === user?.id),
      companyDocuments: companyDocuments.filter(doc => 
        doc.accessLevel === 'public' || canViewAll
      ),
      exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `documentos_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleDocumentUpload = (files: FileList | null) => {
    if (files && user && newDocumentType) {
      let uploadSuccess = true;

      Array.from(files).forEach(file => {
        const newDocument: Omit<DocType, 'id'> = {
          name: file.name,
          type: newDocumentType as DocType['type'],
          uploadDate: new Date().toISOString(),
          size: `${(file.size / 1024).toFixed(0)} KB`,
          url: URL.createObjectURL(file), // Add URL for viewing
          ...(newDocumentType === 'outros' && newDocumentDescription && {
            description: newDocumentDescription
          })
        };

        const targetEmployeeId = selectedEmployee?.id || user.id;

        // Save to database with proper integration
        const success = database.addDocument(targetEmployeeId, newDocument);

        if (!success) {
          uploadSuccess = false;
          return;
        }

        // Also save to IntegratedDataStore for compatibility
        IntegratedDataStore.addDocument(targetEmployeeId, newDocument);
      });

      if (!uploadSuccess) {
        alert('Erro ao enviar documento. Tente novamente.');
        return;
      }

      // Reset form
      setNewDocumentType('');
      setNewDocumentDescription('');
      setIsUploadDialogOpen(false);
      setSelectedEmployee(null);

      // Trigger refresh
      setRefreshTrigger(prev => prev + 1);

      alert('✅ Documentos enviados com sucesso!');
    } else if (!newDocumentType) {
      alert('⚠️ Por favor, selecione o tipo de documento antes de fazer o upload.');
    }
  };

  const handleDeleteDocument = (documentId: string, employeeId: string) => {
    if (confirm('Tem certeza que deseja excluir este documento? Esta ação não pode ser desfeita.')) {
      // Get current employee data
      const employee = database.getEmployee(employeeId);
      if (employee && employee.documents) {
        // Remove document from employee's documents array
        const updatedDocuments = employee.documents.filter(doc => doc.id !== documentId);

        // Update employee with new documents array
        const success = database.updateEmployee(employeeId, {
          documents: updatedDocuments
        });

        if (success) {
          // Also update IntegratedDataStore for compatibility
          IntegratedDataStore.deleteDocument(employeeId, documentId);

          // Trigger refresh
          setRefreshTrigger(prev => prev + 1);

          alert('✅ Documento excluído com sucesso!');
        } else {
          alert('❌ Erro ao excluir documento. Tente novamente.');
        }
      } else {
        alert('❌ Erro ao localizar o colaborador. Tente novamente.');
      }
    }
  };

  // Cálculo de estatísticas
  const documentStats = useMemo(() => {
    const userDocs = canViewAll ? allEmployeeDocuments : 
      allEmployeeDocuments.filter(doc => doc.employeeId === user?.id);
    
    const totalSize = userDocs.reduce((acc, doc) => {
      const sizeInKB = parseInt(doc.size.replace(' KB', ''));
      return acc + sizeInKB;
    }, 0);

    const byType = userDocs.reduce((acc, doc) => {
      acc[doc.type] = (acc[doc.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const completeness = employees.map(emp => {
      const requiredDocs = ['contract', 'id'];
      const hasDocs = requiredDocs.filter(type => 
        emp.documents.some(doc => doc.type === type)
      );
      return (hasDocs.length / requiredDocs.length) * 100;
    });

    const avgCompleteness = completeness.reduce((a, b) => a + b, 0) / completeness.length;

    return {
      total: userDocs.length,
      totalSize: totalSize > 1024 ? `${(totalSize / 1024).toFixed(1)} MB` : `${totalSize} KB`,
      byType,
      avgCompleteness: avgCompleteness || 0,
      employeesWithIncomplete: employees.filter(emp => {
        const required = ['contract', 'id'];
        return required.some(type => !emp.documents.some(doc => doc.type === type));
      }).length
    };
  }, [allEmployeeDocuments, employees, canViewAll, user?.id]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <FileText className="w-8 h-8 mr-3 text-purple-600" />
            Gestão de Documentos
          </h1>
          <p className="text-gray-600 mt-1">
            Central de documentos, contratos e arquivos corporativos
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={handleExportDocuments}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          <Button variant="outline" size="sm" onClick={() => setIsUploadDialogOpen(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Upload
          </Button>
          {canManage && (
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Novo Documento
            </Button>
          )}
        </div>
      </div>

      {/* Statistics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Documentos</p>
                <p className="text-3xl font-bold text-gray-900">{documentStats.total}</p>
                <p className="text-xs text-gray-500">{documentStats.totalSize}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completude Média</p>
                <p className="text-3xl font-bold text-green-600">{documentStats.avgCompleteness.toFixed(1)}%</p>
                <p className="text-xs text-gray-500">dos colaboradores</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Docs. Pendentes</p>
                <p className="text-3xl font-bold text-orange-600">{documentStats.employeesWithIncomplete}</p>
                <p className="text-xs text-gray-500">colaboradores</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Docs. Empresa</p>
                <p className="text-3xl font-bold text-purple-600">{companyDocuments.length}</p>
                <p className="text-xs text-gray-500">ativos</p>
              </div>
              <Database className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Document Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Categorias de Documentos</CardTitle>
          <CardDescription>
            Organize seus documentos por categoria
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documentCategories.map((category) => {
              const categoryCount = allEmployeeDocuments.filter(doc => {
                // Mapear tipos para categorias
                const typeToCategory: Record<string, string> = {
                  'contract': 'contratos',
                  'id': 'documentos_pessoais',
                  'certificate': 'documentos_admissionais',
                  'other': 'outros',
                  'atestados': 'atestados',
                  'comunicados_internos': 'comunicados_internos'
                };
                return typeToCategory[doc.type] === category.id;
              }).length;

              return (
                <Card key={category.id} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 ${category.color} rounded-lg flex items-center justify-center`}>
                        <category.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{category.name}</h3>
                        <p className="text-sm text-gray-600">{category.description}</p>
                        <p className="text-xs text-gray-500 mt-1">{categoryCount} documento(s)</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs defaultValue="employee-docs" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="employee-docs" className="flex items-center">
            <Users className="w-4 h-4 mr-2" />
            Docs. Colaboradores
          </TabsTrigger>
          <TabsTrigger value="company-docs" className="flex items-center">
            <FolderOpen className="w-4 h-4 mr-2" />
            Docs. Empresa
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center">
            <FileText className="w-4 h-4 mr-2" />
            Templates
          </TabsTrigger>
        </TabsList>

        {/* Employee Documents Tab */}
        <TabsContent value="employee-docs" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
                <div className="flex flex-1 items-center space-x-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar documentos ou colaboradores..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas Categorias</SelectItem>
                      <SelectItem value="documentos_pessoais">Documentos Pessoais</SelectItem>
                      <SelectItem value="contratos">Contratos</SelectItem>
                      <SelectItem value="atestados">Atestados</SelectItem>
                      <SelectItem value="documentos_admissionais">Documentos Admissionais</SelectItem>
                      <SelectItem value="comunicados_internos">Comunicados Internos</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="contract">Contratos</SelectItem>
                      <SelectItem value="id">Identidade</SelectItem>
                      <SelectItem value="certificate">Certificados</SelectItem>
                      <SelectItem value="other">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="text-sm text-gray-600">
                  {filteredDocuments.length} de {allEmployeeDocuments.length} documento(s)
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Employee Documents by Employee */}
          {canViewAll && (
            <Card>
              <CardHeader>
                <CardTitle>Documentos por Colaborador</CardTitle>
                <CardDescription>
                  Visualize os documentos de cada colaborador
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {employees.map((employee) => {
                    const docCount = employee.documents.length;
                    const requiredDocs = ['contract', 'id'];
                    const completedRequired = requiredDocs.filter(type => 
                      employee.documents.some(doc => doc.type === type)
                    ).length;
                    const completeness = (completedRequired / requiredDocs.length) * 100;

                    return (
                      <Card key={employee.id} className="hover:shadow-md transition-shadow cursor-pointer"
                            onClick={() => handleViewEmployeeDocuments(employee)}>
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3 mb-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={employee.avatar} alt={employee.name} />
                              <AvatarFallback className="bg-purple-100 text-purple-600">
                                {employee.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <h3 className="font-medium text-gray-900">{employee.name}</h3>
                              <p className="text-sm text-gray-600">{employee.position}</p>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Documentos</span>
                              <span className="text-sm font-medium">{docCount}</span>
                            </div>
                            <div className="space-y-1">
                              <div className="flex justify-between items-center">
                                <span className="text-xs text-gray-500">Completude</span>
                                <span className="text-xs font-medium">{completeness.toFixed(0)}%</span>
                              </div>
                              <Progress value={completeness} className="h-2" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Documents Table */}
          <Card>
            <CardHeader>
              <CardTitle>Lista de Documentos</CardTitle>
              <CardDescription>
                {canViewAll ? 'Todos os documentos dos colaboradores' : 'Seus documentos pessoais'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredDocuments
                  .filter(doc => canViewAll || doc.employeeId === user?.id)
                  .map((document) => {
                    // Convert document format to match DocumentViewer expectations
                    const documentForViewer = {
                      id: document.id,
                      name: document.name,
                      type: document.type,
                      size: parseInt(document.size.replace(' KB', '')) * 1024, // Convert to bytes
                      extension: document.name.split('.').pop() || 'unknown',
                      uploadDate: document.uploadDate,
                      url: document.url // Add URL if available
                    };

                    return (
                      <div key={document.id} className="space-y-2">
                        {canViewAll && (
                          <div className="text-sm text-gray-600 font-medium">
                            Colaborador: {document.employeeName}
                          </div>
                        )}
                        <div className="flex items-center justify-between p-4 border rounded-lg border-l-4 border-l-purple-500 bg-gray-50">
                          <div className="flex-1">
                            <DocumentViewer
                              document={documentForViewer}
                              className=""
                            />
                          </div>
                          {(canManage || document.employeeId === user?.id) && (
                            <div className="flex items-center space-x-2 ml-4">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleViewDocument(document)}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteDocument(document.id, document.employeeId)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>

              {filteredDocuments.filter(doc => canViewAll || doc.employeeId === user?.id).length === 0 && (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Nenhum documento encontrado
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {searchTerm || typeFilter !== 'all'
                      ? 'Tente ajustar os filtros de busca'
                      : 'Faça upload dos seus primeiros documentos'
                    }
                  </p>
                  <Button onClick={() => setIsUploadDialogOpen(true)}>
                    <Upload className="w-4 h-4 mr-2" />
                    Fazer Upload
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Company Documents Tab */}
        <TabsContent value="company-docs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Documentos da Empresa</CardTitle>
              <CardDescription>
                Políticas, manuais, procedimentos e formulários
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {companyDocuments
                  .filter(doc => doc.accessLevel === 'public' || canViewAll)
                  .map((document) => (
                  <Card key={document.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <FileText className="w-5 h-5 text-purple-600" />
                            <h3 className="text-lg font-semibold text-gray-900">{document.name}</h3>
                            {getStatusBadge(document.status)}
                            {getAccessLevelBadge(document.accessLevel)}
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                            <span>Versão {document.version}</span>
                            <span>Por: {document.author}</span>
                            <span>Modificado: {format(new Date(document.lastModified), 'dd/MM/yyyy', { locale: ptBR })}</span>
                          </div>
                          
                          {document.tags && (
                            <div className="flex flex-wrap gap-2 mb-3">
                              {document.tags.map((tag, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                          
                          <div className="flex items-center space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-2" />
                              Visualizar
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="w-4 h-4 mr-2" />
                              Download
                            </Button>
                            {document.accessLevel !== 'confidential' && (
                              <Button variant="outline" size="sm">
                                <Share className="w-4 h-4 mr-2" />
                                Compartilhar
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {companyDocuments.filter(doc => doc.accessLevel === 'public' || canViewAll).length === 0 && (
                  <div className="text-center py-8">
                    <FolderOpen className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">Nenhum documento da empresa disponível</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Templates de Documentos</CardTitle>
              <CardDescription>
                Modelos padronizados para criação de documentos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {documentTemplates.map((template) => (
                  <Card key={template.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <FileText className="w-8 h-8 text-blue-600 mt-1" />
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900 mb-2">{template.name}</h3>
                          <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                          
                          {template.fields && (
                            <div className="mb-4">
                              <p className="text-xs text-gray-500 mb-1">Campos:</p>
                              <div className="flex flex-wrap gap-1">
                                {template.fields.slice(0, 3).map((field, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {field.replace('_', ' ')}
                                  </Badge>
                                ))}
                                {template.fields.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{template.fields.length - 3} mais
                                  </Badge>
                                )}
                              </div>
                            </div>
                          )}
                          
                          <Button size="sm" className="w-full">
                            <Copy className="w-4 h-4 mr-2" />
                            Usar Template
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Upload Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Upload de Documentos</DialogTitle>
            <DialogDescription>
              {selectedEmployee
                ? `Enviando documento para ${selectedEmployee.name}`
                : 'Envie seus documentos para o sistema'
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="document-type">Tipo de Documento *</Label>
                <Select value={newDocumentType} onValueChange={setNewDocumentType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo de documento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="documentos_pessoais">Documentos Pessoais</SelectItem>
                    <SelectItem value="contratos">Contratos</SelectItem>
                    <SelectItem value="atestados">Atestados</SelectItem>
                    <SelectItem value="documentos_admissionais">Documentos Admissionais</SelectItem>
                    <SelectItem value="comunicados_internos">Comunicados Internos</SelectItem>
                    <SelectItem value="outros">Outros</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {newDocumentType === 'outros' && (
                <div>
                  <Label htmlFor="document-description">Descrição *</Label>
                  <Input
                    id="document-description"
                    value={newDocumentDescription}
                    onChange={(e) => setNewDocumentDescription(e.target.value)}
                    placeholder="Descreva o tipo de documento"
                  />
                </div>
              )}

              {/* Document Type Description */}
              {newDocumentType && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">
                    {documentCategories.find(cat => cat.id === newDocumentType)?.name}
                  </h4>
                  <p className="text-sm text-blue-700">
                    {documentCategories.find(cat => cat.id === newDocumentType)?.description}
                  </p>
                </div>
              )}
            </div>

            {newDocumentType ? (
              <DocumentStorage
                employeeId={selectedEmployee?.id || user?.id || ''}
                documentType={newDocumentType}
                description={newDocumentDescription}
                onUploadComplete={(success, documents) => {
                  if (success) {
                    // Reset form
                    setNewDocumentType('');
                    setNewDocumentDescription('');
                    setIsUploadDialogOpen(false);
                    setSelectedEmployee(null);

                    // Trigger refresh
                    setRefreshTrigger(prev => prev + 1);

                    alert(`✅ ${documents.length} documento(s) enviado(s) com sucesso!`);
                  } else {
                    alert('❌ Erro ao enviar alguns documentos. Verifique os detalhes.');
                  }
                }}
                maxFiles={5}
                maxSizePerFile={10240} // 10MB
              />
            ) : (
              <div className="border-2 border-dashed border-yellow-300 rounded-lg p-6 text-center bg-yellow-50">
                <Upload className="w-12 h-12 mx-auto text-yellow-500 mb-4" />
                <h3 className="text-lg font-medium text-yellow-800 mb-2">
                  Selecione o tipo de documento primeiro
                </h3>
                <p className="text-sm text-yellow-700">
                  Escolha uma categoria de documento acima antes de fazer o upload
                </p>
              </div>
            )}

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Formatos aceitos: PDF, DOC, DOCX, JPG, PNG
              </p>
              <p className="text-xs text-gray-500">
                Tamanho máximo: 10MB por arquivo
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Document Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedDocument?.name}</DialogTitle>
            <DialogDescription>
              Detalhes do documento
            </DialogDescription>
          </DialogHeader>
          
          {selectedDocument && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Categoria:</span>
                  <div className="mt-1">
                    {getCategoryBadge(selectedDocument.type)}
                  </div>
                </div>
                <div>
                  <span className="text-gray-600">Tamanho:</span>
                  <p className="font-medium">{selectedDocument.size}</p>
                </div>
                <div>
                  <span className="text-gray-600">Data de Upload:</span>
                  <p className="font-medium">
                    {format(new Date(selectedDocument.uploadDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </p>
                </div>
                <div>
                  <span className="text-gray-600">URL:</span>
                  <p className="font-medium text-blue-600">
                    {selectedDocument.url || 'Não disponível'}
                  </p>
                </div>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button variant="outline">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Abrir
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Employee Documents Dialog */}
      <Dialog open={isEmployeeDocsDialogOpen} onOpenChange={setIsEmployeeDocsDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>
              Documentos de {selectedEmployee?.name}
            </DialogTitle>
            <DialogDescription>
              {selectedEmployee?.position} - {selectedEmployee?.department}
            </DialogDescription>
          </DialogHeader>
          
          {selectedEmployee && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedEmployee.documents.map((document) => (
                  <Card key={document.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        {getDocumentIcon(document.type)}
                        <div className="flex-1">
                          <p className="font-medium text-sm">{document.name}</p>
                          <p className="text-xs text-gray-600">{document.size}</p>
                          <p className="text-xs text-gray-500">
                            {format(new Date(document.uploadDate), 'dd/MM/yyyy', { locale: ptBR })}
                          </p>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {selectedEmployee.documents.length === 0 && (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600">Nenhum documento encontrado</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
