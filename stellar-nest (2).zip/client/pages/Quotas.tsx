import React, { useState, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  Shield, Users, AlertTriangle, TrendingUp, Edit, 
  Plus, Search, CheckCircle, XCircle, BarChart3
} from 'lucide-react';

interface CompanyQuota {
  id: string;
  companyName: string;
  plan: 'starter' | 'professional' | 'enterprise';
  employeeLimit: number;
  currentEmployees: number;
  status: 'active' | 'blocked' | 'cancelled';
  utilizationPercent: number;
  isNearLimit: boolean;
  lastUpdated: string;
  contractStartDate: string;
  notes?: string;
}

// Mock data
const mockQuotas: CompanyQuota[] = [
  {
    id: '1',
    companyName: 'Tech Solutions Ltda',
    plan: 'professional',
    employeeLimit: 50,
    currentEmployees: 35,
    status: 'active',
    utilizationPercent: 70,
    isNearLimit: false,
    lastUpdated: '2024-02-01',
    contractStartDate: '2024-01-15'
  },
  {
    id: '2',
    companyName: 'Inovação Digital S.A.',
    plan: 'enterprise',
    employeeLimit: 200,
    currentEmployees: 150,
    status: 'active',
    utilizationPercent: 75,
    isNearLimit: false,
    lastUpdated: '2024-02-01',
    contractStartDate: '2023-06-10'
  },
  {
    id: '3',
    companyName: 'StartUp Criativa',
    plan: 'starter',
    employeeLimit: 15,
    currentEmployees: 14,
    status: 'active',
    utilizationPercent: 93,
    isNearLimit: true,
    lastUpdated: '2024-02-01',
    contractStartDate: '2024-03-01',
    notes: 'Próximo do limite - considerar upgrade'
  },
  {
    id: '4',
    companyName: 'Consultoria Pro',
    plan: 'professional',
    employeeLimit: 50,
    currentEmployees: 48,
    status: 'active',
    utilizationPercent: 96,
    isNearLimit: true,
    lastUpdated: '2024-02-01',
    contractStartDate: '2023-08-20'
  },
  {
    id: '5',
    companyName: 'Empresa Bloqueada',
    plan: 'starter',
    employeeLimit: 15,
    currentEmployees: 10,
    status: 'blocked',
    utilizationPercent: 67,
    isNearLimit: false,
    lastUpdated: '2024-01-15',
    contractStartDate: '2023-12-01'
  }
];

export default function Quotas() {
  const { user } = useAuth();
  const [quotas, setQuotas] = useState<CompanyQuota[]>(mockQuotas);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [isEditQuotaDialogOpen, setIsEditQuotaDialogOpen] = useState(false);
  const [selectedQuota, setSelectedQuota] = useState<CompanyQuota | null>(null);

  // Filtros
  const filteredQuotas = useMemo(() => {
    return quotas.filter(quota => {
      const matchesSearch = quota.companyName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesPlan = selectedPlan === 'all' || quota.plan === selectedPlan;
      const matchesStatus = selectedStatus === 'all' || quota.status === selectedStatus;
      
      return matchesSearch && matchesPlan && matchesStatus;
    });
  }, [quotas, searchTerm, selectedPlan, selectedStatus]);

  // Estatísticas
  const stats = useMemo(() => {
    const total = quotas.length;
    const active = quotas.filter(q => q.status === 'active').length;
    const nearLimit = quotas.filter(q => q.isNearLimit && q.status === 'active').length;
    const totalEmployees = quotas.reduce((sum, q) => sum + q.currentEmployees, 0);
    const totalLimit = quotas.reduce((sum, q) => sum + q.employeeLimit, 0);
    const avgUtilization = quotas.length > 0 
      ? quotas.reduce((sum, q) => sum + q.utilizationPercent, 0) / quotas.length 
      : 0;
    
    return { 
      total, active, nearLimit, totalEmployees, totalLimit, avgUtilization 
    };
  }, [quotas]);

  const getUtilizationColor = (percent: number) => {
    if (percent >= 90) return 'text-red-600';
    if (percent >= 80) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getUtilizationBgColor = (percent: number) => {
    if (percent >= 90) return 'bg-red-500';
    if (percent >= 80) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getPlanInfo = (plan: string) => {
    switch (plan) {
      case 'starter':
        return { name: 'Starter', limit: '15 funcionários', color: 'bg-gray-100 text-gray-800' };
      case 'professional':
        return { name: 'Professional', limit: '50 funcionários', color: 'bg-blue-100 text-blue-800' };
      case 'enterprise':
        return { name: 'Enterprise', limit: '200 funcionários', color: 'bg-purple-100 text-purple-800' };
      default:
        return { name: plan, limit: '', color: 'bg-gray-100 text-gray-800' };
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Ativo</Badge>;
      case 'blocked':
        return <Badge className="bg-red-100 text-red-800">Bloqueado</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-100 text-gray-800">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const editQuota = (quota: CompanyQuota) => {
    setSelectedQuota(quota);
    setIsEditQuotaDialogOpen(true);
  };

  const saveQuotaChanges = () => {
    if (selectedQuota) {
      // Lógica para salvar mudanças
      console.log('Saving quota changes for:', selectedQuota.companyName);
      setIsEditQuotaDialogOpen(false);
      setSelectedQuota(null);
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="text-center py-8">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Acesso Restrito</h2>
        <p className="text-gray-600">Esta área é exclusiva para administradores do sistema.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Limites e Quotas</h1>
          <p className="text-gray-600 mt-1">Controle de colaboradores por empresa e utilização de planos</p>
        </div>
        
        <Button className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Ajustar Limites
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Empresas Ativas</CardTitle>
            <CheckCircle className="w-4 h-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.active}</div>
            <p className="text-xs text-muted-foreground">de {stats.total} empresas total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Próximos do Limite</CardTitle>
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.nearLimit}</div>
            <p className="text-xs text-muted-foreground">empresas acima de 90%</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Funcionários</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">de {stats.totalLimit} vagas disponíveis</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Utilização Média</CardTitle>
            <BarChart3 className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getUtilizationColor(stats.avgUtilization)}`}>
              {stats.avgUtilization.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">média geral do sistema</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por nome da empresa..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="w-full md:w-48">
              <Select value={selectedPlan} onValueChange={setSelectedPlan}>
                <SelectTrigger>
                  <SelectValue placeholder="Plano" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Planos</SelectItem>
                  <SelectItem value="starter">Starter</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full md:w-48">
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Status</SelectItem>
                  <SelectItem value="active">Ativo</SelectItem>
                  <SelectItem value="blocked">Bloqueado</SelectItem>
                  <SelectItem value="cancelled">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quotas Table */}
      <Card>
        <CardHeader>
          <CardTitle>Controle de Quotas</CardTitle>
          <CardDescription>
            {filteredQuotas.length} empresa(s) encontrada(s)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Empresa</TableHead>
                <TableHead>Plano</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Utilização</TableHead>
                <TableHead>Funcionários</TableHead>
                <TableHead>Última Atualização</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredQuotas.map((quota) => {
                const planInfo = getPlanInfo(quota.plan);
                return (
                  <TableRow key={quota.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{quota.companyName}</div>
                        {quota.notes && (
                          <div className="text-sm text-gray-500">{quota.notes}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={planInfo.color}>
                        {planInfo.name}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(quota.status)}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className={`text-sm font-medium ${getUtilizationColor(quota.utilizationPercent)}`}>
                            {quota.utilizationPercent}%
                          </span>
                          {quota.isNearLimit && (
                            <AlertTriangle className="w-4 h-4 text-yellow-500" />
                          )}
                        </div>
                        <Progress 
                          value={quota.utilizationPercent} 
                          className="h-2"
                          style={{
                            background: quota.utilizationPercent >= 90 ? '#fef2f2' : 
                                       quota.utilizationPercent >= 80 ? '#fffbeb' : '#f0fdf4'
                          }}
                        />
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-gray-400" />
                        <span className="font-medium">
                          {quota.currentEmployees}/{quota.employeeLimit}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-gray-500">
                        {new Date(quota.lastUpdated).toLocaleDateString('pt-BR')}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => editQuota(quota)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Quota Dialog */}
      <Dialog open={isEditQuotaDialogOpen} onOpenChange={setIsEditQuotaDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajustar Limites de Funcionários</DialogTitle>
            <DialogDescription>
              {selectedQuota && `Alterar limites para ${selectedQuota.companyName}`}
            </DialogDescription>
          </DialogHeader>
          
          {selectedQuota && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="current-limit">Limite Atual</Label>
                <Input 
                  id="current-limit" 
                  value={selectedQuota.employeeLimit}
                  type="number"
                  min="1"
                  max="1000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-plan">Plano</Label>
                <Select defaultValue={selectedQuota.plan}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="starter">Starter (15 funcionários)</SelectItem>
                    <SelectItem value="professional">Professional (50 funcionários)</SelectItem>
                    <SelectItem value="enterprise">Enterprise (200 funcionários)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2 space-y-2">
                <Label htmlFor="quota-notes">Observações</Label>
                <Input 
                  id="quota-notes" 
                  value={selectedQuota.notes || ''}
                  placeholder="Observações sobre o limite..."
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditQuotaDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={saveQuotaChanges} className="bg-purple-600 hover:bg-purple-700">
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
