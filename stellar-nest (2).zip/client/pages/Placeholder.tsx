import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Construction, Zap } from "lucide-react";
import { Link } from "react-router-dom";

interface PlaceholderProps {
  title: string;
  description: string;
}

export default function Placeholder({ title, description }: PlaceholderProps) {
  return (
    <div className="space-y-6">
      <Card className="text-center">
        <CardHeader className="pb-8">
          <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Construction className="w-10 h-10 text-purple-600" />
          </div>
          <CardTitle className="text-3xl font-bold text-gray-900 mb-4">
            {title}
          </CardTitle>
          <CardDescription className="text-lg text-gray-600 max-w-2xl mx-auto">
            {description}
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-8">
          <p className="text-gray-500 mb-8">
            Esta funcionalidade está sendo desenvolvida com base nas especificações completas.
            Enquanto isso, explore os módulos já funcionais ou veja nossa demonstração completa.
          </p>
          <div className="flex justify-center space-x-4">
            <Link to="/dashboard">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao Dashboard
              </Button>
            </Link>
            <Link to="/demo">
              <Button variant="outline" className="border-purple-200 text-purple-600 hover:bg-purple-50">
                <Zap className="w-4 h-4 mr-2" />
                Ver Demonstração
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
