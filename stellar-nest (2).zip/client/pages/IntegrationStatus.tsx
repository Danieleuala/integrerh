// Integre RH - Painel de Status das Integrações
// Dashboard mostrando status de todas as integrações e serviços

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  CheckCircle2, XCircle, AlertTriangle, RefreshCw, Database, Mail,
  Cloud, MessageSquare, BarChart3, Shield, Zap, Settings,
  Activity, Server, HardDrive
} from 'lucide-react';

interface ServiceStatus {
  name: string;
  status: 'active' | 'inactive' | 'error' | 'testing';
  icon: React.ComponentType<any>;
  description: string;
  configured: boolean;
  lastChecked?: Date;
  error?: string;
}

export default function IntegrationStatus() {
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const refreshStatus = async () => {
    setIsRefreshing(true);
    // Simular carregamento
    setTimeout(() => {
      setIsRefreshing(false);
      setLastUpdate(new Date());
    }, 2000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'testing':
        return <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active':
        return 'default';
      case 'error':
        return 'destructive';
      case 'testing':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Ativo';
      case 'error':
        return 'Erro';
      case 'testing':
        return 'Testando';
      default:
        return 'Inativo';
    }
  };

  // Status dos serviços
  const services: ServiceStatus[] = [
    {
      name: 'Banco de Dados',
      status: 'active',
      icon: Database,
      description: 'Supabase PostgreSQL Database',
      configured: Boolean(import.meta.env.VITE_SUPABASE_URL),
      lastChecked: new Date()
    },
    {
      name: 'Serviço de Email',
      status: Boolean(import.meta.env.VITE_RESEND_API_KEY) ? 'active' : 'inactive',
      icon: Mail,
      description: 'Resend Email Service',
      configured: Boolean(import.meta.env.VITE_RESEND_API_KEY)
    },
    {
      name: 'Armazenamento',
      status: Boolean(import.meta.env.VITE_SUPABASE_URL) ? 'active' : 'inactive',
      icon: Cloud,
      description: 'Supabase Storage',
      configured: Boolean(import.meta.env.VITE_SUPABASE_URL)
    },
    {
      name: 'WhatsApp Business',
      status: Boolean(import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN) ? 'active' : 'inactive',
      icon: MessageSquare,
      description: 'Meta WhatsApp Business API',
      configured: Boolean(import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN)
    },
    {
      name: 'Analytics',
      status: Boolean(import.meta.env.VITE_GOOGLE_ANALYTICS_ID) ? 'active' : 'inactive',
      icon: BarChart3,
      description: 'Google Analytics 4',
      configured: Boolean(import.meta.env.VITE_GOOGLE_ANALYTICS_ID)
    },
    {
      name: 'Notificações em Tempo Real',
      status: Boolean(import.meta.env.VITE_ENABLE_REAL_TIME_UPDATES) ? 'active' : 'inactive',
      icon: Zap,
      description: 'Supabase Realtime',
      configured: Boolean(import.meta.env.VITE_ENABLE_REAL_TIME_UPDATES)
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-600" />
          <p className="text-gray-600">Carregando status das integrações...</p>
        </div>
      </div>
    );
  }

  const activeServices = services.filter(s => s.status === 'active').length;
  const errorServices = services.filter(s => s.status === 'error').length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Status das Integrações</h1>
          <p className="text-gray-600">Monitor de serviços e integrações do Integre RH</p>
        </div>
        <Button
          onClick={refreshStatus}
          disabled={isRefreshing}
          className="flex items-center space-x-2"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          <span>{isRefreshing ? 'Atualizando...' : 'Atualizar'}</span>
        </Button>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Serviços Ativos</p>
                <p className="text-3xl font-bold text-green-600">{activeServices}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Com Problemas</p>
                <p className="text-3xl font-bold text-red-600">{errorServices}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Serviços</p>
                <p className="text-3xl font-bold text-gray-900">{services.length}</p>
              </div>
              <Server className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service, index) => {
          const IconComponent = service.icon;
          return (
            <Card key={index}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <IconComponent className="w-6 h-6 text-purple-600" />
                    <CardTitle className="text-lg">{service.name}</CardTitle>
                  </div>
                  {getStatusIcon(service.status)}
                </div>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge variant={getStatusBadgeVariant(service.status)}>
                      {getStatusText(service.status)}
                    </Badge>
                    <Badge variant={service.configured ? 'outline' : 'secondary'}>
                      {service.configured ? 'Configurado' : 'Não configurado'}
                    </Badge>
                  </div>
                  
                  {service.error && (
                    <Alert>
                      <AlertTriangle className="w-4 h-4" />
                      <AlertDescription className="text-sm">
                        {service.error}
                      </AlertDescription>
                    </Alert>
                  )}

                  {service.lastChecked && (
                    <p className="text-xs text-gray-500">
                      Última verificação: {service.lastChecked.toLocaleString()}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Configuration Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Configurações de Ambiente</span>
          </CardTitle>
          <CardDescription>
            Status das variáveis de ambiente necessárias para as integrações
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: 'VITE_SUPABASE_URL', status: Boolean(import.meta.env.VITE_SUPABASE_URL) },
              { key: 'VITE_SUPABASE_ANON_KEY', status: Boolean(import.meta.env.VITE_SUPABASE_ANON_KEY) },
              { key: 'VITE_RESEND_API_KEY', status: Boolean(import.meta.env.VITE_RESEND_API_KEY) },
              { key: 'VITE_WHATSAPP_ACCESS_TOKEN', status: Boolean(import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN) },
              { key: 'VITE_GOOGLE_ANALYTICS_ID', status: Boolean(import.meta.env.VITE_GOOGLE_ANALYTICS_ID) },
              { key: 'VITE_ENABLE_REAL_TIME_UPDATES', status: Boolean(import.meta.env.VITE_ENABLE_REAL_TIME_UPDATES) }
            ].map((config, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <span className="text-sm font-mono">{config.key}</span>
                <Badge variant={config.status ? 'default' : 'secondary'}>
                  {config.status ? 'Configurado' : 'Não configurado'}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* MCP Integration Suggestion */}
      <Card className="border-purple-200 bg-purple-50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-purple-900">
            <Zap className="w-5 h-5" />
            <span>Integrações MCP Disponíveis</span>
          </CardTitle>
          <CardDescription className="text-purple-700">
            Conecte-se a serviços externos para potencializar sua plataforma de RH
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <p className="text-sm text-purple-800">
              Para conectar integrações adicionais como Neon (banco de dados), Linear (gestão de projetos), 
              Sentry (monitoramento), e outros serviços MCP, clique no botão abaixo:
            </p>
            <Button variant="outline" className="border-purple-300 text-purple-700 hover:bg-purple-100">
              <span>Abrir MCP Integra��ões</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Last Update Info */}
      <div className="text-center text-sm text-gray-500">
        Última atualização: {lastUpdate.toLocaleString()}
      </div>
    </div>
  );
}
