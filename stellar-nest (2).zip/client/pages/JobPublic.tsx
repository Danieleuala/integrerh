import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { IntegratedDataStore, Job, JobApplication } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { 
  Briefcase, MapPin, Calendar, DollarSign, Clock, 
  Users, CheckCircle, Upload, FileText, Send,
  ArrowLeft, Building2, Star, Target, Gift
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function JobPublic() {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [applicationForm, setApplicationForm] = useState({
    candidateName: '',
    candidateEmail: '',
    phone: '',
    linkedin: '',
    experience: '',
    motivation: '',
    salary_expectation: '',
    availability: '',
    resume: null as File | null
  });

  useEffect(() => {
    if (jobId) {
      const foundJob = IntegratedDataStore.getJob(jobId);
      setJob(foundJob || null);
      setLoading(false);
    }
  }, [jobId]);

  const handleResumeUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Verificar se é PDF ou DOC
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (allowedTypes.includes(file.type)) {
        setApplicationForm({ ...applicationForm, resume: file });
      } else {
        alert('Por favor, envie apenas arquivos PDF, DOC ou DOCX.');
      }
    }
  };

  const handleSubmitApplication = async () => {
    if (!job) return;

    // Validar campos obrigatórios
    if (!applicationForm.candidateName || !applicationForm.candidateEmail || !applicationForm.phone || !applicationForm.experience || !applicationForm.motivation) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(applicationForm.candidateEmail)) {
      alert('Por favor, insira um email válido.');
      return;
    }

    setSubmitting(true);

    try {
      // Simular upload de currículo
      let resumeUrl = '';
      if (applicationForm.resume) {
        // Em um sistema real, aqui faria upload para o servidor
        resumeUrl = `uploads/resumes/${Date.now()}_${applicationForm.resume.name}`;
      }

      // Criar candidatura
      const newApplication: Omit<JobApplication, 'id'> = {
        jobId: job.id,
        candidateName: applicationForm.candidateName,
        candidateEmail: applicationForm.candidateEmail,
        resumeUrl: resumeUrl,
        status: 'pending',
        appliedDate: new Date().toISOString(),
        notes: `Phone: ${applicationForm.phone}\nLinkedIn: ${applicationForm.linkedin}\nExperience: ${applicationForm.experience}\nMotivation: ${applicationForm.motivation}\nSalary Expectation: ${applicationForm.salary_expectation}\nAvailability: ${applicationForm.availability}`
      };

      // Adicionar candidatura usando o sistema integrado
      const updatedJob = IntegratedDataStore.getJob(job.id);
      if (updatedJob) {
        const applicationWithId: JobApplication = {
          ...newApplication,
          id: `app_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        };
        
        updatedJob.applications.push(applicationWithId);
        IntegratedDataStore.updateJob(job.id, updatedJob);
        
        setSubmitted(true);
        
        // Emitir evento para notificar o sistema
        // O banco integrado vai criar notificações automaticamente
      }

    } catch (error) {
      alert('Erro ao enviar candidatura. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando vaga...</p>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Vaga não encontrada</h1>
          <p className="text-gray-600 mb-4">A vaga solicitada não existe ou foi removida.</p>
          <Button onClick={() => navigate('/')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <div className="max-w-md w-full mx-4">
          <Card>
            <CardContent className="text-center p-8">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Candidatura Enviada!</h1>
              <p className="text-gray-600 mb-6">
                Sua candidatura para a vaga de <strong>{job.title}</strong> foi enviada com sucesso. 
                Nossa equipe analisará seu perfil e entrará em contato em breve.
              </p>
              <div className="space-y-2 text-sm text-gray-500">
                <p>✓ Candidatura registrada</p>
                <p>✓ Email de confirmação enviado</p>
                <p>✓ Currículo anexado</p>
              </div>
              <Button className="mt-6" onClick={() => navigate('/')}>
                Voltar ao Início
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-white border-b border-purple-100 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-integre-gradient rounded-xl flex items-center justify-center shadow-lg">
                <Briefcase className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                  Integre RH
                </h1>
                <p className="text-sm text-gray-500">Conectando talentos e oportunidades</p>
              </div>
            </div>
            <Button variant="outline" onClick={() => navigate('/')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Job Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-2xl text-gray-900">{job.title}</CardTitle>
                    <CardDescription className="flex items-center mt-2">
                      <Building2 className="w-4 h-4 mr-2" />
                      {job.department}
                    </CardDescription>
                  </div>
                  <Badge 
                    className={job.status === 'open' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}
                  >
                    {job.status === 'open' ? 'Vaga Aberta' : 'Vaga Fechada'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Job Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mr-2" />
                    <span className="capitalize">{job.type.replace('_', ' ')}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="w-4 h-4 mr-2" />
                    {format(new Date(job.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </div>
                  {job.salary && (
                    <div className="flex items-center text-sm text-gray-600">
                      <DollarSign className="w-4 h-4 mr-2" />
                      {job.salary}
                    </div>
                  )}
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="w-4 h-4 mr-2" />
                    {job.applications.length} candidatura(s)
                  </div>
                </div>

                <Separator />

                {/* Description */}
                <div>
                  <h3 className="font-semibold mb-2">Descrição da Vaga</h3>
                  <p className="text-gray-700 whitespace-pre-wrap">{job.description}</p>
                </div>

                {/* Requirements */}
                {job.requirements.length > 0 && (
                  <div>
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Target className="w-4 h-4 mr-2" />
                      Requisitos
                    </h3>
                    <ul className="space-y-1">
                      {job.requirements.map((req, index) => (
                        <li key={index} className="flex items-center text-gray-700">
                          <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Benefits */}
                {job.benefits.length > 0 && (
                  <div>
                    <h3 className="font-semibold mb-2 flex items-center">
                      <Gift className="w-4 h-4 mr-2" />
                      Benefícios
                    </h3>
                    <ul className="space-y-1">
                      {job.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-center text-gray-700">
                          <Star className="w-4 h-4 mr-2 text-purple-600" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Application Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Candidatar-se</CardTitle>
                <CardDescription>
                  Preencha o formulário para enviar sua candidatura
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome Completo *</Label>
                  <Input
                    id="name"
                    value={applicationForm.candidateName}
                    onChange={(e) => setApplicationForm({...applicationForm, candidateName: e.target.value})}
                    placeholder="Seu nome completo"
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={applicationForm.candidateEmail}
                    onChange={(e) => setApplicationForm({...applicationForm, candidateEmail: e.target.value})}
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Telefone *</Label>
                  <Input
                    id="phone"
                    value={applicationForm.phone}
                    onChange={(e) => setApplicationForm({...applicationForm, phone: e.target.value})}
                    placeholder="(11) 99999-9999"
                  />
                </div>

                <div>
                  <Label htmlFor="linkedin">LinkedIn (opcional)</Label>
                  <Input
                    id="linkedin"
                    value={applicationForm.linkedin}
                    onChange={(e) => setApplicationForm({...applicationForm, linkedin: e.target.value})}
                    placeholder="linkedin.com/in/seuperfil"
                  />
                </div>

                <div>
                  <Label htmlFor="experience">Experiência Relevante *</Label>
                  <Textarea
                    id="experience"
                    value={applicationForm.experience}
                    onChange={(e) => setApplicationForm({...applicationForm, experience: e.target.value})}
                    placeholder="Descreva sua experiência relevante para esta vaga..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="motivation">Por que deseja esta vaga? *</Label>
                  <Textarea
                    id="motivation"
                    value={applicationForm.motivation}
                    onChange={(e) => setApplicationForm({...applicationForm, motivation: e.target.value})}
                    placeholder="Conte-nos o que te motiva a se candidatar..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="salary">Pretensão Salarial (opcional)</Label>
                  <Input
                    id="salary"
                    value={applicationForm.salary_expectation}
                    onChange={(e) => setApplicationForm({...applicationForm, salary_expectation: e.target.value})}
                    placeholder="Ex: R$ 5.000 - R$ 7.000"
                  />
                </div>

                <div>
                  <Label htmlFor="availability">Disponibilidade (opcional)</Label>
                  <Input
                    id="availability"
                    value={applicationForm.availability}
                    onChange={(e) => setApplicationForm({...applicationForm, availability: e.target.value})}
                    placeholder="Ex: Imediata, 30 dias"
                  />
                </div>

                <div>
                  <Label htmlFor="resume">Currículo (PDF, DOC, DOCX)</Label>
                  <div className="mt-1">
                    <input
                      id="resume"
                      type="file"
                      accept=".pdf,.doc,.docx"
                      onChange={handleResumeUpload}
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      onClick={() => document.getElementById('resume')?.click()}
                      className="w-full"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {applicationForm.resume ? applicationForm.resume.name : 'Escolher arquivo'}
                    </Button>
                  </div>
                  {applicationForm.resume && (
                    <div className="flex items-center mt-2 text-sm text-gray-600">
                      <FileText className="w-4 h-4 mr-1" />
                      <span>{applicationForm.resume.name}</span>
                    </div>
                  )}
                </div>

                <Button 
                  onClick={handleSubmitApplication} 
                  disabled={submitting || job.status !== 'open'}
                  className="w-full"
                >
                  {submitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Enviar Candidatura
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  Ao enviar sua candidatura, você aceita nossos termos e política de privacidade.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
