import { useState, useMemo, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { 
  EnhancedDataStore, 
  Competency, 
  EvaluationTemplate, 
  EvaluationInstance,
  EvaluationResults
} from '@/lib/enhancedData';
import { IntegratedDataStore, Employee } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  Award, Plus, Search, Eye, Edit, MoreHorizontal, 
  Users, Clock, Calendar, Target, TrendingUp,
  CheckCircle, XCircle, AlertCircle, Star, Download,
  BarChart3, User, UserCheck, Settings, Copy, Link,
  FileText, MessageSquare, Brain, Zap, Heart,
  PieChart, LineChart, Activity, Sparkles, Send,
  Mail, ExternalLink, Trash2, Filter, Tag
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

export default function EnhancedEvaluations() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // State management
  const [competencies, setCompetencies] = useState<Competency[]>([]);
  const [evaluationTemplates, setEvaluationTemplates] = useState<EvaluationTemplate[]>([]);
  const [evaluationInstances, setEvaluationInstances] = useState<EvaluationInstance[]>([]);
  const [employees] = useState<Employee[]>(IntegratedDataStore.getEmployees());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  
  // Dialog states
  const [isCompetencyDialogOpen, setIsCompetencyDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [isEvaluationDialogOpen, setIsEvaluationDialogOpen] = useState(false);
  const [isResultsDialogOpen, setIsResultsDialogOpen] = useState(false);
  
  // Selected items
  const [selectedTemplate, setSelectedTemplate] = useState<EvaluationTemplate | null>(null);
  const [selectedEvaluation, setSelectedEvaluation] = useState<EvaluationInstance | null>(null);
  
  // Form states
  const [competencyForm, setCompetencyForm] = useState<Partial<Competency>>({
    name: '',
    description: '',
    category: 'behavioral',
    scale: { min: 1, max: 5, labels: ['Insuficiente', 'Básico', 'Bom', 'Muito Bom', 'Excelente'] },
    questions: [],
    isActive: true
  });
  
  const [templateForm, setTemplateForm] = useState<Partial<EvaluationTemplate>>({
    name: '',
    description: '',
    type: 'performance',
    competencies: [],
    evaluatorTypes: ['manager'],
    frequency: 'one_time',
    isActive: true,
    allowAnonymous: false
  });

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);

  // Load data on component mount
  useEffect(() => {
    setCompetencies(EnhancedDataStore.getCompetencies());
    setEvaluationTemplates(EnhancedDataStore.getEvaluationTemplates());
    setEvaluationInstances(EnhancedDataStore.getEvaluationInstances());
  }, []);

  const filteredTemplates = useMemo(() => {
    return evaluationTemplates.filter(template => {
      const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           template.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = typeFilter === 'all' || template.type === typeFilter;
      
      return matchesSearch && matchesType;
    });
  }, [evaluationTemplates, searchTerm, typeFilter]);

  const filteredInstances = useMemo(() => {
    return evaluationInstances.filter(instance => {
      const template = evaluationTemplates.find(t => t.id === instance.templateId);
      const employee = employees.find(e => e.id === instance.evalueeId);
      
      const matchesSearch = employee?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           template?.name.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || instance.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [evaluationInstances, evaluationTemplates, employees, searchTerm, statusFilter]);

  const evaluationStats = useMemo(() => {
    const totalTemplates = evaluationTemplates.length;
    const activeTemplates = evaluationTemplates.filter(t => t.isActive).length;
    const totalInstances = evaluationInstances.length;
    const completedInstances = evaluationInstances.filter(i => i.status === 'completed').length;
    const pendingInstances = evaluationInstances.filter(i => i.status === 'pending').length;
    const avgScore = completedInstances > 0 
      ? evaluationInstances
          .filter(i => i.status === 'completed')
          .reduce((acc, i) => acc + i.overallScore, 0) / completedInstances
      : 0;

    return {
      totalTemplates,
      activeTemplates,
      totalInstances,
      completedInstances,
      pendingInstances,
      avgScore
    };
  }, [evaluationTemplates, evaluationInstances]);

  const getTypeBadge = (type: EvaluationTemplate['type']) => {
    const typeMap = {
      performance: { label: 'Performance', color: 'bg-blue-100 text-blue-700' },
      technical: { label: 'Técnica', color: 'bg-green-100 text-green-700' },
      '360_feedback': { label: '360°', color: 'bg-purple-100 text-purple-700' },
      probation: { label: 'Probatório', color: 'bg-orange-100 text-orange-700' },
      custom: { label: 'Personalizada', color: 'bg-gray-100 text-gray-700' }
    };

    const typeInfo = typeMap[type] || typeMap.custom;
    return <Badge className={typeInfo.color}>{typeInfo.label}</Badge>;
  };

  const getStatusBadge = (status: EvaluationInstance['status']) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="border-yellow-200 text-yellow-700">Pendente</Badge>;
      case 'in_progress':
        return <Badge className="bg-blue-100 text-blue-700">Em Andamento</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-700">Concluída</Badge>;
      case 'expired':
        return <Badge className="bg-red-100 text-red-700">Expirada</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getCategoryBadge = (category: Competency['category']) => {
    const categoryMap = {
      technical: { label: 'Técnica', color: 'bg-blue-100 text-blue-700' },
      behavioral: { label: 'Comportamental', color: 'bg-green-100 text-green-700' },
      leadership: { label: 'Liderança', color: 'bg-purple-100 text-purple-700' },
      communication: { label: 'Comunicação', color: 'bg-orange-100 text-orange-700' },
      custom: { label: 'Personalizada', color: 'bg-gray-100 text-gray-700' }
    };

    const categoryInfo = categoryMap[category] || categoryMap.custom;
    return <Badge className={categoryInfo.color}>{categoryInfo.label}</Badge>;
  };

  const handleCreateCompetency = () => {
    if (!competencyForm.name || !competencyForm.description) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    const newCompetency = EnhancedDataStore.addCompetency({
      ...competencyForm as Omit<Competency, 'id' | 'createdDate'>,
      createdBy: user?.id || 'current_user'
    });

    setCompetencies(EnhancedDataStore.getCompetencies());
    setIsCompetencyDialogOpen(false);
    setCompetencyForm({
      name: '',
      description: '',
      category: 'behavioral',
      scale: { min: 1, max: 5, labels: ['Insuficiente', 'Básico', 'Bom', 'Muito Bom', 'Excelente'] },
      questions: [],
      isActive: true
    });

    toast({
      title: "Sucesso",
      description: "Competência criada com sucesso!",
    });
  };

  const handleCreateTemplate = () => {
    if (!templateForm.name || !templateForm.description || !templateForm.competencies?.length) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios e selecione pelo menos uma competência",
        variant: "destructive"
      });
      return;
    }

    const newTemplate = EnhancedDataStore.addEvaluationTemplate({
      ...templateForm as Omit<EvaluationTemplate, 'id' | 'createdDate'>,
      shareableLink: `${window.location.origin}/evaluation/public/${Date.now()}`,
      createdBy: user?.id || 'current_user'
    });

    setEvaluationTemplates(EnhancedDataStore.getEvaluationTemplates());
    setIsTemplateDialogOpen(false);
    setTemplateForm({
      name: '',
      description: '',
      type: 'performance',
      competencies: [],
      evaluatorTypes: ['manager'],
      frequency: 'one_time',
      isActive: true,
      allowAnonymous: false
    });

    toast({
      title: "Sucesso",
      description: "Template de avaliação criado com sucesso!",
    });
  };

  const generateEvaluationLink = (template: EvaluationTemplate) => {
    return template.shareableLink || `${window.location.origin}/evaluation/public/${template.id}`;
  };

  const copyEvaluationLink = (template: EvaluationTemplate) => {
    const link = generateEvaluationLink(template);
    navigator.clipboard.writeText(link);
    toast({
      title: "Link copiado!",
      description: "O link da avaliação foi copiado para a área de transferência.",
    });
  };

  const addCompetencyToTemplate = (competencyId: string) => {
    if (!templateForm.competencies?.includes(competencyId)) {
      setTemplateForm(prev => ({
        ...prev,
        competencies: [...(prev.competencies || []), competencyId]
      }));
    }
  };

  const removeCompetencyFromTemplate = (competencyId: string) => {
    setTemplateForm(prev => ({
      ...prev,
      competencies: prev.competencies?.filter(id => id !== competencyId) || []
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Award className="w-8 h-8 mr-3 text-purple-600" />
            Sistema de Avaliações
          </h1>
          <p className="text-gray-600 mt-1">
            Avaliações personalizadas com competências customizáveis
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={() => setIsCompetencyDialogOpen(true)}>
            <Brain className="w-4 h-4 mr-2" />
            Gerenciar Competências
          </Button>
          {canCreate && (
            <Button 
              className="bg-gradient-to-r from-purple-600 to-blue-600"
              onClick={() => setIsTemplateDialogOpen(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Avaliação
            </Button>
          )}
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Templates Ativos</p>
                <p className="text-3xl font-bold text-blue-600">{evaluationStats.activeTemplates}</p>
                <p className="text-xs text-gray-500">de {evaluationStats.totalTemplates} total</p>
              </div>
              <FileText className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avaliações Pendentes</p>
                <p className="text-3xl font-bold text-orange-600">{evaluationStats.pendingInstances}</p>
                <p className="text-xs text-gray-500">aguardando resposta</p>
              </div>
              <Clock className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Concluídas</p>
                <p className="text-3xl font-bold text-green-600">{evaluationStats.completedInstances}</p>
                <p className="text-xs text-gray-500">de {evaluationStats.totalInstances} total</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Nota Média</p>
                <p className="text-3xl font-bold text-purple-600">{evaluationStats.avgScore.toFixed(1)}</p>
                <p className="text-xs text-gray-500">pontuação geral</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="templates" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="templates" className="flex items-center">
            <FileText className="w-4 h-4 mr-2" />
            Templates
          </TabsTrigger>
          <TabsTrigger value="instances" className="flex items-center">
            <Users className="w-4 h-4 mr-2" />
            Avaliações
          </TabsTrigger>
          <TabsTrigger value="competencies" className="flex items-center">
            <Brain className="w-4 h-4 mr-2" />
            Competências
          </TabsTrigger>
          <TabsTrigger value="results" className="flex items-center">
            <BarChart3 className="w-4 h-4 mr-2" />
            Resultados
          </TabsTrigger>
        </TabsList>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
                <div className="flex flex-1 items-center space-x-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar templates..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Tipos</SelectItem>
                      <SelectItem value="performance">Performance</SelectItem>
                      <SelectItem value="technical">Técnica</SelectItem>
                      <SelectItem value="360_feedback">360°</SelectItem>
                      <SelectItem value="probation">Probatório</SelectItem>
                      <SelectItem value="custom">Personalizada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="text-sm text-gray-600">
                  {filteredTemplates.length} de {evaluationTemplates.length} template(s)
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Templates List */}
          <div className="grid grid-cols-1 gap-6">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <h3 className="text-xl font-semibold text-gray-900">{template.name}</h3>
                        {getTypeBadge(template.type)}
                        <Badge className={template.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                          {template.isActive ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </div>
                      
                      <p className="text-gray-600 mb-4">{template.description}</p>
                      
                      <div className="flex items-center space-x-6 text-sm text-gray-600 mb-3">
                        <div className="flex items-center">
                          <Brain className="w-4 h-4 mr-2" />
                          {template.competencies.length} competência(s)
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-2" />
                          {template.evaluatorTypes.join(', ')}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {format(new Date(template.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {template.competencies.slice(0, 3).map(competencyId => {
                          const competency = competencies.find(c => c.id === competencyId);
                          return competency ? (
                            <Badge key={competencyId} variant="outline" className="text-xs">
                              {competency.name}
                            </Badge>
                          ) : null;
                        })}
                        {template.competencies.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{template.competencies.length - 3} mais
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => copyEvaluationLink(template)}
                      >
                        <Link className="w-4 h-4 mr-2" />
                        Copiar Link
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => {
                            setSelectedTemplate(template);
                            setIsEvaluationDialogOpen(true);
                          }}>
                            <Eye className="w-4 h-4 mr-2" />
                            Visualizar
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Send className="w-4 h-4 mr-2" />
                            Aplicar Avaliação
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyEvaluationLink(template)}>
                            <Copy className="w-4 h-4 mr-2" />
                            Copiar Link
                          </DropdownMenuItem>
                          {canEdit && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="w-4 h-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredTemplates.length === 0 && (
              <Card>
                <CardContent className="p-12 text-center">
                  <FileText className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Nenhum template encontrado
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {searchTerm || typeFilter !== 'all'
                      ? 'Tente ajustar os filtros de busca'
                      : 'Crie seu primeiro template de avaliação'
                    }
                  </p>
                  {canCreate && (
                    <Button onClick={() => setIsTemplateDialogOpen(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Criar Primeiro Template
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Instances Tab */}
        <TabsContent value="instances" className="space-y-6">
          <div className="text-center py-8 text-gray-500">
            <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Avaliações em Andamento
            </h3>
            <p className="text-gray-600">
              As avaliações aplicadas aparecerão aqui
            </p>
          </div>
        </TabsContent>

        {/* Competencies Tab */}
        <TabsContent value="competencies" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {competencies.map((competency) => (
              <Card key={competency.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{competency.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">{competency.description}</p>
                    </div>
                    {getCategoryBadge(competency.category)}
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Escala:</span>
                      <span>{competency.scale.min} - {competency.scale.max}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Questões:</span>
                      <span>{competency.questions.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Status:</span>
                      <Badge className={competency.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                        {competency.isActive ? 'Ativa' : 'Inativa'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="results" className="space-y-6">
          <div className="text-center py-8 text-gray-500">
            <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Dashboard de Resultados
            </h3>
            <p className="text-gray-600">
              Relatórios e análises das avaliações aparecerão aqui
            </p>
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Competency Dialog */}
      <Dialog open={isCompetencyDialogOpen} onOpenChange={setIsCompetencyDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Competências</DialogTitle>
            <DialogDescription>
              Crie e configure competências personalizadas
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="comp-name">Nome da Competência *</Label>
                <Input
                  id="comp-name"
                  value={competencyForm.name || ''}
                  onChange={(e) => setCompetencyForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Ex: Comunicação"
                />
              </div>
              <div>
                <Label htmlFor="comp-category">Categoria</Label>
                <Select
                  value={competencyForm.category || 'behavioral'}
                  onValueChange={(value) => setCompetencyForm(prev => ({ 
                    ...prev, 
                    category: value as Competency['category']
                  }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="behavioral">Comportamental</SelectItem>
                    <SelectItem value="technical">Técnica</SelectItem>
                    <SelectItem value="leadership">Liderança</SelectItem>
                    <SelectItem value="communication">Comunicação</SelectItem>
                    <SelectItem value="custom">Personalizada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="comp-description">Descrição *</Label>
              <Textarea
                id="comp-description"
                value={competencyForm.description || ''}
                onChange={(e) => setCompetencyForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Descreva o que esta competência avalia..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Escala Mínima</Label>
                <Input
                  type="number"
                  value={competencyForm.scale?.min || 1}
                  onChange={(e) => setCompetencyForm(prev => ({
                    ...prev,
                    scale: { ...prev.scale!, min: parseInt(e.target.value) }
                  }))}
                  min="1"
                  max="10"
                />
              </div>
              <div>
                <Label>Escala Máxima</Label>
                <Input
                  type="number"
                  value={competencyForm.scale?.max || 5}
                  onChange={(e) => setCompetencyForm(prev => ({
                    ...prev,
                    scale: { ...prev.scale!, max: parseInt(e.target.value) }
                  }))}
                  min="2"
                  max="10"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={competencyForm.isActive}
                onCheckedChange={(checked) => setCompetencyForm(prev => ({ ...prev, isActive: checked }))}
              />
              <Label>Competência ativa</Label>
            </div>

            <div className="flex justify-end space-x-3 pt-6 border-t">
              <Button variant="outline" onClick={() => setIsCompetencyDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreateCompetency}>
                Criar Competência
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Template Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Criar Template de Avaliação</DialogTitle>
            <DialogDescription>
              Configure um novo template de avaliação
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="h-[75vh] pr-4">
            <Tabs defaultValue="basic" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
              <TabsTrigger value="competencies">Competências ({templateForm.competencies?.length || 0})</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="template-name">Nome da Avaliação *</Label>
                  <Input
                    id="template-name"
                    value={templateForm.name || ''}
                    onChange={(e) => setTemplateForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Ex: Avaliação de Performance Q1"
                  />
                </div>
                <div>
                  <Label htmlFor="template-type">Tipo da Avaliação</Label>
                  <Select
                    value={templateForm.type || 'performance'}
                    onValueChange={(value) => setTemplateForm(prev => ({ 
                      ...prev, 
                      type: value as EvaluationTemplate['type']
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="performance">Avaliação de Performance</SelectItem>
                      <SelectItem value="technical">Avaliaç��o Técnica</SelectItem>
                      <SelectItem value="360_feedback">Feedback 360°</SelectItem>
                      <SelectItem value="probation">Avaliação Probatória</SelectItem>
                      <SelectItem value="custom">Personalizada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="template-description">Descrição *</Label>
                <Textarea
                  id="template-description"
                  value={templateForm.description || ''}
                  onChange={(e) => setTemplateForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Descreva o objetivo desta avaliação..."
                  rows={3}
                />
              </div>

              <div>
                <Label>Tipos de Avaliadores</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  {[
                    { value: 'self', label: 'Autoavaliação' },
                    { value: 'manager', label: 'Gestor' },
                    { value: 'peer', label: 'Pares' },
                    { value: 'subordinate', label: 'Subordinados' },
                    { value: 'client', label: 'Clientes' }
                  ].map(evaluatorType => (
                    <div key={evaluatorType.value} className="flex items-center space-x-2">
                      <Checkbox
                        checked={templateForm.evaluatorTypes?.includes(evaluatorType.value as any) || false}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setTemplateForm(prev => ({
                              ...prev,
                              evaluatorTypes: [...(prev.evaluatorTypes || []), evaluatorType.value as any]
                            }));
                          } else {
                            setTemplateForm(prev => ({
                              ...prev,
                              evaluatorTypes: prev.evaluatorTypes?.filter(type => type !== evaluatorType.value) || []
                            }));
                          }
                        }}
                      />
                      <Label className="text-sm">{evaluatorType.label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="template-frequency">Frequência</Label>
                  <Select
                    value={templateForm.frequency || 'one_time'}
                    onValueChange={(value) => setTemplateForm(prev => ({ 
                      ...prev, 
                      frequency: value as EvaluationTemplate['frequency']
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="one_time">Uma vez</SelectItem>
                      <SelectItem value="monthly">Mensal</SelectItem>
                      <SelectItem value="quarterly">Trimestral</SelectItem>
                      <SelectItem value="semi_annual">Semestral</SelectItem>
                      <SelectItem value="annual">Anual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-4 pt-6">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={templateForm.isActive}
                      onCheckedChange={(checked) => setTemplateForm(prev => ({ ...prev, isActive: checked }))}
                    />
                    <Label className="text-sm">Ativo</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={templateForm.allowAnonymous}
                      onCheckedChange={(checked) => setTemplateForm(prev => ({ ...prev, allowAnonymous: checked }))}
                    />
                    <Label className="text-sm">Permitir Anônimo</Label>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Competencies Tab */}
            <TabsContent value="competencies" className="space-y-6">
              <div>
                <Label>Competências Disponíveis</Label>
                <p className="text-sm text-gray-600 mb-4">
                  Selecione as competências que serão avaliadas neste template
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-64 overflow-y-auto">
                  {competencies.filter(c => c.isActive).map((competency) => (
                    <div 
                      key={competency.id} 
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        templateForm.competencies?.includes(competency.id)
                          ? 'border-purple-300 bg-purple-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => {
                        if (templateForm.competencies?.includes(competency.id)) {
                          removeCompetencyFromTemplate(competency.id);
                        } else {
                          addCompetencyToTemplate(competency.id);
                        }
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-sm">{competency.name}</h4>
                          <p className="text-xs text-gray-600">{competency.description}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          {getCategoryBadge(competency.category)}
                          {templateForm.competencies?.includes(competency.id) && (
                            <CheckCircle className="w-4 h-4 text-purple-600" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {templateForm.competencies && templateForm.competencies.length > 0 && (
                <div>
                  <Label>Competências Selecionadas ({templateForm.competencies.length})</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {templateForm.competencies.map(competencyId => {
                      const competency = competencies.find(c => c.id === competencyId);
                      return competency ? (
                        <Badge 
                          key={competencyId} 
                          variant="secondary" 
                          className="flex items-center gap-2"
                        >
                          {competency.name}
                          <button
                            type="button"
                            onClick={() => removeCompetencyFromTemplate(competencyId)}
                            className="text-gray-500 hover:text-red-500"
                          >
                            ×
                          </button>
                        </Badge>
                      ) : null;
                    })}
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button variant="outline" onClick={() => setIsTemplateDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateTemplate}>
              Criar Template
            </Button>
          </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
