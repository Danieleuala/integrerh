import { useState, useEffect, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Job } from "@/lib/mockData";
import { DataAdapter } from "@/lib/dataAdapter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Briefcase,
  Search,
  MapPin,
  DollarSign,
  Calendar,
  Users,
  Building2,
  Clock,
  ExternalLink,
  Heart,
  ArrowLeft,
  Filter,
  CheckCircle,
  Star,
  Target,
  Zap,
  Eye,
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Company {
  id: string;
  name: string;
  trade_name?: string;
  slug: string;
  logo_url?: string;
  industry?: string;
  city?: string;
  state?: string;
  description?: string;
}

export default function PublicJobs() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [companies, setCompanies] = useState<Company[]>([
    {
      id: '1',
      name: 'TechCorp Solutions',
      trade_name: 'TechCorp',
      slug: 'techcorp',
      industry: 'Tecnologia',
      city: 'São Paulo',
      state: 'SP'
    }
  ]);
  const [searchTerm, setSearchTerm] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [locationFilter, setLocationFilter] = useState<string>("all");
  const [companyFilter, setCompanyFilter] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Default fallback jobs to prevent undefined errors
  const defaultJobs: Job[] = [
    {
      id: '1',
      title: 'Desenvolvedor Full Stack',
      department: 'Tecnologia',
      description: 'Vaga para desenvolvedor experiente com React e Node.js',
      requirements: ['React', 'Node.js', 'TypeScript'],
      benefits: ['Vale refeição', 'Plano de saúde', 'Home office'],
      salary: 'R$ 8.000 - R$ 12.000',
      type: 'full_time',
      status: 'open',
      createdDate: '2024-01-15',
      applications: []
    },
    {
      id: '2',
      title: 'Designer UX/UI',
      department: 'Design',
      description: 'Profissional criativo para desenvolver interfaces incríveis',
      requirements: ['Figma', 'Photoshop', 'Prototipagem'],
      benefits: ['Vale refeição', 'Plano de saúde', 'Horário flexível'],
      salary: 'R$ 5.000 - R$ 8.000',
      type: 'full_time',
      status: 'open',
      createdDate: '2024-01-20',
      applications: []
    }
  ];

  // Load jobs and companies
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        // Initialize with default data first
        setJobs(defaultJobs);

        console.log("About to call DataAdapter.getJobs()");
        const allJobs = await DataAdapter.getJobs();
        console.log("DataAdapter.getJobs() returned:", allJobs);

        // Only show open jobs to public - ensure we have valid data
        if (allJobs && Array.isArray(allJobs) && allJobs.length > 0) {
          const openJobs = allJobs.filter((job: Job) => job.status === "open");
          if (openJobs.length > 0) {
            setJobs(openJobs);
            console.log(`Loaded ${openJobs.length} open jobs from database`);
          } else {
            console.warn("No open jobs found in database, using default jobs");
          }
        } else {
          console.warn("No jobs data from database, using default jobs (this is normal if Supabase is not configured)");
        }

        // Mock companies data - in real implementation, fetch from API
        const mockCompanies: Company[] = [
          {
            id: '1',
            name: 'TechCorp Solutions',
            trade_name: 'TechCorp',
            slug: 'techcorp',
            logo_url: 'https://images.unsplash.com/photo-1560472355-536de3962603?w=100&h=100&fit=crop&crop=center',
            industry: 'Tecnologia',
            city: 'São Paulo',
            state: 'SP',
            description: 'Empresa líder em soluções tecnológicas'
          },
          {
            id: '2',
            name: 'Marketing Plus',
            trade_name: 'Marketing Plus',
            slug: 'marketing-plus',
            industry: 'Marketing',
            city: 'Rio de Janeiro',
            state: 'RJ',
            description: 'Agência de marketing digital'
          }
        ];
        // Always ensure we have company data
        setCompanies(mockCompanies.length > 0 ? mockCompanies : [{
          id: '1',
          name: 'Empresas Parceiras',
          slug: 'parceiras',
          industry: 'Geral'
        }]);
      } catch (err) {
        console.error("Error loading jobs - raw error:", err);
        console.error("Error type:", typeof err);
        console.error("Error constructor:", err?.constructor?.name);

        let errorMessage = "Erro desconhecido";
        if (err instanceof Error) {
          errorMessage = err.message;
          console.error("Error stack:", err.stack);
        } else if (typeof err === "string") {
          errorMessage = err;
        } else if (err && typeof err === "object") {
          try {
            errorMessage = JSON.stringify(
              err,
              Object.getOwnPropertyNames(err),
              2,
            );
          } catch (stringifyError) {
            errorMessage = String(err);
          }
        } else {
          errorMessage = String(err);
        }

        console.error("Final error message:", errorMessage);
        console.warn(`Database error, using fallback data: ${errorMessage}`);
        setJobs(defaultJobs);
        setError(null); // Clear error since we have fallback data
      } finally {
        setLoading(false);
        // Ensure we always have valid job data
        if (!jobs || jobs.length === 0) {
          setJobs(defaultJobs);
        }
      }
    };

    loadData();
  }, []);

  // Filter jobs based on search and filters
  const filteredJobs = useMemo(() => {
    if (!jobs || !Array.isArray(jobs)) {
      return defaultJobs;
    }

    return jobs.filter((job) => {
      if (!job) return false;

      const matchesSearch =
        (job.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (job.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (job.department || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchesDepartment =
        departmentFilter === "all" || job.department === departmentFilter;

      const matchesCompany =
        companyFilter === "all" || (job as any).company_id === companyFilter;

      return matchesSearch && matchesDepartment && matchesCompany;
    });
  }, [jobs, searchTerm, departmentFilter, companyFilter, defaultJobs]);

  // Get unique departments for filters
  const departments = useMemo(() => {
    if (!jobs || !Array.isArray(jobs)) {
      return ['Tecnologia', 'Design'];
    }
    const depts = [...new Set(jobs.map((job) => job?.department).filter(Boolean))];
    return depts.sort();
  }, [jobs]);

  const getJobTypeBadge = (type: string) => {
    const variants = {
      full_time: {
        variant: "default" as const,
        label: "Tempo Integral",
        className: "bg-green-100 text-green-700",
      },
      part_time: {
        variant: "secondary" as const,
        label: "Meio Período",
        className: "bg-blue-100 text-blue-700",
      },
      contract: {
        variant: "outline" as const,
        label: "Contrato",
        className: "bg-purple-100 text-purple-700",
      },
    };

    const config =
      variants[type as keyof typeof variants] || variants["full_time"];
    return (
      <Badge variant={config.variant} className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const getUrgencyBadge = (urgency: string) => {
    switch (urgency) {
      case "high":
        return (
          <Badge variant="destructive" className="bg-red-100 text-red-700">
            Urgente
          </Badge>
        );
      case "medium":
        return (
          <Badge
            variant="outline"
            className="border-orange-200 text-orange-700"
          >
            Moderada
          </Badge>
        );
      case "low":
        return (
          <Badge variant="secondary" className="bg-gray-100 text-gray-700">
            Baixa
          </Badge>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="text-center">
          <Briefcase className="w-12 h-12 mx-auto text-purple-600 mb-4 animate-pulse" />
          <p className="text-gray-600">Carregando vagas...</p>
        </div>
      </div>
    );
  }

  // Removed error display as we now fallback to mock data

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 bg-integre-gradient rounded-xl flex items-center justify-center shadow-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                  Integre RH
                </span>
                <p className="text-xs text-gray-500 -mt-1">Área do Candidato</p>
              </div>
            </Link>

            <div className="flex items-center space-x-3">
              <Link to="/candidate-status">
                <Button
                  variant="outline"
                  className="border-purple-200 text-purple-700 hover:bg-purple-50"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Status das Candidaturas
                </Button>
              </Link>
              <Link to="/">
                <Button variant="ghost" className="hover:bg-purple-50">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar ao Site
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Vagas Disponíveis
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Encontre sua próxima oportunidade profissional. Todas as vagas estão
            abertas para candidaturas.
          </p>
        </div>

        {/* Companies Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building2 className="w-5 h-5 mr-2" />
              Empresas Parceiras
            </CardTitle>
            <CardDescription>
              Conheça as empresas que estão contratando e veja suas oportunidades
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {companies?.map((company) => (
                <Link
                  key={company.id}
                  to={`/company/${company.slug}/jobs`}
                  className="block"
                >
                  <Card className="hover:shadow-lg transition-shadow duration-300 cursor-pointer border-2 hover:border-blue-200">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                          {company.logo_url ? (
                            <img
                              src={company.logo_url}
                              alt={company.name}
                              className="w-10 h-10 rounded-lg object-cover"
                            />
                          ) : (
                            <Building2 className="w-6 h-6 text-white" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">
                            {company.trade_name || company.name}
                          </h3>
                          <div className="flex items-center text-sm text-gray-600 mt-1">
                            {company.industry && (
                              <Badge variant="outline" className="mr-2 text-xs">
                                {company.industry}
                              </Badge>
                            )}
                            {company.city && company.state && (
                              <div className="flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {company.city}, {company.state}
                              </div>
                            )}
                          </div>
                        </div>
                        <ExternalLink className="w-4 h-4 text-gray-400" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar vagas por título, descrição ou departamento..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select
                value={departmentFilter}
                onValueChange={setDepartmentFilter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todos os departamentos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os departamentos</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={companyFilter}
                onValueChange={setCompanyFilter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todas as empresas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as empresas</SelectItem>
                  {companies?.map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.trade_name || company.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Jobs Grid */}
        {filteredJobs.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Briefcase className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Nenhuma vaga encontrada
              </h3>
              <p className="text-gray-600 mb-4">
                Não encontramos vagas que correspondam aos seus critérios de
                busca.
              </p>
              <Button
                onClick={() => {
                  setSearchTerm("");
                  setDepartmentFilter("all");
                  setCompanyFilter("all");
                }}
              >
                Limpar Filtros
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredJobs.map((job) => (
              <Card
                key={job.id}
                className="hover:shadow-lg transition-all duration-300 border-purple-100 hover:border-purple-300"
              >
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <CardTitle className="text-xl text-purple-700 mb-2">
                        {job.title}
                      </CardTitle>
                      <div className="space-y-2">
                        <CardDescription className="flex items-center text-base">
                          <Building2 className="w-4 h-4 mr-2" />
                          {job.department}
                        </CardDescription>
                        {/* Company info - mock for now */}
                        {(job as any).company_id && (
                          <div className="flex items-center text-sm text-gray-600">
                            <div className="w-6 h-6 bg-blue-100 rounded mr-2 flex items-center justify-center">
                              <Building2 className="w-3 h-3 text-blue-600" />
                            </div>
                            <span>TechCorp Solutions</span>
                            <Badge variant="outline" className="ml-2 text-xs">
                              Tecnologia
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-2">
                      {getJobTypeBadge(job.type)}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Job Info */}
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      Publicada em{" "}
                      {format(new Date(job.createdDate), "dd/MM/yyyy", {
                        locale: ptBR,
                      })}
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2" />
                      {job.applications?.length || 0} candidatura(s)
                    </div>
                  </div>

                  {/* Salary */}
                  {job.salary && (
                    <div className="flex items-center text-green-600 font-medium">
                      <DollarSign className="w-4 h-4 mr-2" />
                      {job.salary}
                    </div>
                  )}

                  {/* Description Preview */}
                  <p className="text-gray-700 line-clamp-3">
                    {job.description?.length > 150
                      ? `${job.description.substring(0, 150)}...`
                      : job.description}
                  </p>

                  {/* Requirements Preview */}
                  {job.requirements?.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Principais Requisitos:
                      </h4>
                      <div className="space-y-1">
                        {job.requirements?.slice(0, 3).map((req, index) => (
                          <div key={index} className="flex items-start text-sm">
                            <CheckCircle className="w-3 h-3 text-green-500 mr-2 mt-1 flex-shrink-0" />
                            <span className="text-gray-600">{req}</span>
                          </div>
                        ))}
                        {job.requirements?.length > 3 && (
                          <p className="text-sm text-gray-500">
                            +{(job.requirements?.length || 0) - 3} requisitos adicionais
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Benefits Preview */}
                  {job.benefits?.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Benefícios:
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {job.benefits?.slice(0, 4).map((benefit, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            <Star className="w-3 h-3 mr-1" />
                            {benefit?.length > 20
                              ? `${benefit.substring(0, 20)}...`
                              : benefit}
                          </Badge>
                        ))}
                        {job.benefits?.length > 4 && (
                          <Badge variant="secondary" className="text-xs">
                            +{(job.benefits?.length || 0) - 4} mais
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Additional Job Info */}
                  <div className="text-sm text-gray-600">
                    <p>Processo seletivo com múltiplas etapas. Candidature-se para mais detalhes!</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-4 border-t border-gray-100 space-y-2">
                    <Link to={`/company/techcorp/jobs`}>
                      <Button variant="outline" className="w-full border-purple-200 text-purple-600 hover:bg-purple-50">
                        <Building2 className="w-4 h-4 mr-2" />
                        Ver Vagas da Empresa
                      </Button>
                    </Link>
                    <Link to={`/candidate-apply/${job.id}`}>
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Candidatar-se a esta Vaga
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Footer Info */}
        <Card className="mt-12 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardContent className="p-8 text-center">
            <div className="flex items-center justify-center mb-4">
              <Target className="w-8 h-8 text-purple-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">
                Sua próxima oportunidade está aqui!
              </h3>
            </div>
            <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
              Todas as vagas listadas estão abertas para candidaturas. O
              processo é simples: clique na vaga desejada, preencha seus dados e
              pronto! Nossa equipe analisará seu perfil e entrará em contato.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
              <div className="flex items-center justify-center p-4">
                <Zap className="w-6 h-6 text-purple-600 mr-3" />
                <div className="text-left">
                  <h4 className="font-medium text-gray-900">Processo Ágil</h4>
                  <p className="text-sm text-gray-600">
                    Candidatura rápida e simples
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-center p-4">
                <Users className="w-6 h-6 text-blue-600 mr-3" />
                <div className="text-left">
                  <h4 className="font-medium text-gray-900">Acompanhamento</h4>
                  <p className="text-sm text-gray-600">
                    Retorno sobre sua candidatura
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-center p-4">
                <Heart className="w-6 h-6 text-purple-600 mr-3" />
                <div className="text-left">
                  <h4 className="font-medium text-gray-900">Oportunidades</h4>
                  <p className="text-sm text-gray-600">
                    Vagas em empresas selecionadas
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
