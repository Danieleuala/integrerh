import { useState, useMemo, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore, Announcement, Employee } from '@/lib/mockData';
import { database } from '@/lib/database';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  MessageSquare, Plus, Search, Send, Eye, Edit, MoreHorizontal, 
  Users, Calendar, Bell, Megaphone, Pin, Filter, Download,
  AlertCircle, CheckCircle, Clock, Mail, Phone, Video,
  FileText, Image as ImageIcon, Paperclip, Star
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Message {
  id: string;
  fromId: string;
  toId: string[];
  subject: string;
  content: string;
  date: string;
  isRead: boolean;
  attachments?: string[];
  type: 'message' | 'announcement' | 'notification';
  priority: 'low' | 'medium' | 'high';
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  date: string;
  isRead: boolean;
  userId: string;
  actionUrl?: string;
}

export default function Communications() {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState(IntegratedDataStore.getAnnouncements());
  const [employees] = useState(IntegratedDataStore.getEmployees());
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false);
  const [announcementForm, setAnnouncementForm] = useState<Partial<Announcement>>({});
  const [messageForm, setMessageForm] = useState({
    toId: [] as string[],
    subject: '',
    content: '',
    priority: 'medium' as 'low' | 'medium' | 'high'
  });
  const [userMessages, setUserMessages] = useState<{ inbox: Message[], sent: Message[] }>({ inbox: [], sent: [] });
  const [activeMessageTab, setActiveMessageTab] = useState<'inbox' | 'sent'>('inbox');

  // Load user messages from database
  useEffect(() => {
    if (user?.id) {
      const messages = database.getUserMessages(user.id);
      setUserMessages(messages);
    }
  }, [user?.id]);

  const [notifications] = useState<Notification[]>([
    {
      id: 'n1',
      title: 'Nova avaliação disponível',
      message: 'Sua avaliação trimestral está disponível para preenchimento.',
      type: 'info',
      date: '2024-01-25T09:00:00Z',
      isRead: false,
      userId: user?.id || '3',
      actionUrl: '/evaluations'
    },
    {
      id: 'n2',
      title: 'Treinamento concluído',
      message: 'Parabéns! Você concluiu o treinamento de Segurança da Informação.',
      type: 'success',
      date: '2024-01-24T16:45:00Z',
      isRead: true,
      userId: user?.id || '3',
      actionUrl: '/trainings'
    },
    {
      id: 'n3',
      title: 'Documento pendente',
      message: 'Você tem documentos pendentes para upload.',
      type: 'warning',
      date: '2024-01-23T11:30:00Z',
      isRead: false,
      userId: user?.id || '3',
      actionUrl: '/documents'
    }
  ]);

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);

  const filteredAnnouncements = useMemo(() => {
    return announcements.filter(announcement => {
      const matchesSearch = announcement.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           announcement.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           announcement.author.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesPriority = priorityFilter === 'all' || announcement.priority === priorityFilter;
      
      return matchesSearch && matchesPriority;
    });
  }, [announcements, searchTerm, priorityFilter]);

  const getPriorityBadge = (priority: Announcement['priority']) => {
    switch (priority) {
      case 'high':
        return <Badge className="bg-red-100 text-red-700">Alta</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-100 text-yellow-700">Média</Badge>;
      case 'low':
        return <Badge className="bg-green-100 text-green-700">Baixa</Badge>;
      default:
        return <Badge variant="secondary">Normal</Badge>;
    }
  };

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Bell className="w-4 h-4 text-blue-600" />;
    }
  };

  const handleViewAnnouncement = (announcement: Announcement) => {
    setSelectedAnnouncement(announcement);
    setIsViewDialogOpen(true);
  };

  const handleCreateAnnouncement = () => {
    setAnnouncementForm({
      title: '',
      content: '',
      author: user?.name || '',
      date: new Date().toISOString(),
      priority: 'medium',
      departments: ['Todos']
    });
    setIsCreateDialogOpen(true);
  };

  const handleSaveAnnouncement = () => {
    if (announcementForm.title && announcementForm.content && announcementForm.priority) {
      const newAnnouncement = IntegratedDataStore.addAnnouncement(announcementForm as Omit<Announcement, 'id'>);
      setAnnouncements(IntegratedDataStore.getAnnouncements());
      setIsCreateDialogOpen(false);
      setAnnouncementForm({});
      alert('Comunicado publicado com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos obrigatórios: Título, Conteúdo e Prioridade.');
    }
  };

  const handleSendMessage = () => {
    if (messageForm.toId.length > 0 && messageForm.subject && messageForm.content && user?.id) {
      // Save message to database
      const newMessage = database.addMessage({
        fromId: user.id,
        toId: messageForm.toId,
        subject: messageForm.subject,
        content: messageForm.content,
        date: new Date().toISOString(),
        isRead: false,
        type: 'message',
        priority: messageForm.priority
      });

      // Update local state
      const updatedMessages = database.getUserMessages(user.id);
      setUserMessages(updatedMessages);

      setIsMessageDialogOpen(false);
      setMessageForm({
        toId: [],
        subject: '',
        content: '',
        priority: 'medium'
      });
      alert('Mensagem enviada com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos obrigatórios: Destinatário, Assunto e Mensagem.');
    }
  };

  const handleExportCommunications = () => {
    const data = {
      announcements: filteredAnnouncements,
      messages: userMessages,
      notifications: notifications.filter(notif => notif.userId === user?.id),
      exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `comunicacoes_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const unreadNotifications = notifications.filter(notif => !notif.isRead && notif.userId === user?.id);
  const unreadMessages = userMessages.inbox.filter(msg => !msg.isRead);

  const handleMarkAsRead = (messageId: string) => {
    if (user?.id) {
      database.markMessageAsRead(messageId, user.id);
      const updatedMessages = database.getUserMessages(user.id);
      setUserMessages(updatedMessages);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <MessageSquare className="w-8 h-8 mr-3 text-purple-600" />
            Comunicações Internas
          </h1>
          <p className="text-gray-600 mt-1">
            Central de comunicações, avisos, mensagens e notificações
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={handleExportCommunications}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          <Button variant="outline" size="sm" onClick={() => setIsMessageDialogOpen(true)}>
            <Send className="w-4 h-4 mr-2" />
            Nova Mensagem
          </Button>
          {canCreate && (
            <Button onClick={handleCreateAnnouncement} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Novo Comunicado
            </Button>
          )}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Comunicados Ativos</p>
                <p className="text-3xl font-bold text-gray-900">{announcements.length}</p>
              </div>
              <Megaphone className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Notificações</p>
                <p className="text-3xl font-bold text-orange-600">{unreadNotifications.length}</p>
                <p className="text-xs text-gray-500">não lidas</p>
              </div>
              <Bell className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Mensagens</p>
                <p className="text-3xl font-bold text-purple-600">{unreadMessages.length}</p>
                <p className="text-xs text-gray-500">não lidas</p>
              </div>
              <Mail className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Colaboradores Online</p>
                <p className="text-3xl font-bold text-green-600">{employees.filter(emp => emp.status === 'active').length}</p>
              </div>
              <Users className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="announcements" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="announcements" className="flex items-center">
            <Megaphone className="w-4 h-4 mr-2" />
            Comunicados
          </TabsTrigger>
          <TabsTrigger value="messages" className="flex items-center">
            <Mail className="w-4 h-4 mr-2" />
            Mensagens ({unreadMessages.length})
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center">
            <Bell className="w-4 h-4 mr-2" />
            Notificações ({unreadNotifications.length})
          </TabsTrigger>
        </TabsList>

        {/* Announcements Tab */}
        <TabsContent value="announcements" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
                <div className="flex flex-1 items-center space-x-4">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar comunicados..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Prioridade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      <SelectItem value="high">Alta</SelectItem>
                      <SelectItem value="medium">Média</SelectItem>
                      <SelectItem value="low">Baixa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="text-sm text-gray-600">
                  {filteredAnnouncements.length} de {announcements.length} comunicado(s)
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Announcements List */}
          <div className="grid grid-cols-1 gap-6">
            {filteredAnnouncements.map((announcement) => (
              <Card key={announcement.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <Pin className="w-5 h-5 text-purple-600" />
                        <h3 className="text-lg font-semibold text-gray-900">{announcement.title}</h3>
                        {getPriorityBadge(announcement.priority)}
                      </div>
                      
                      <p className="text-gray-700 mb-4 line-clamp-3">{announcement.content}</p>
                      
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-4">
                          <span>Por: {announcement.author}</span>
                          <span>{format(new Date(announcement.date), 'dd/MM/yyyy', { locale: ptBR })}</span>
                          <span>Departamentos: {announcement.departments?.join(', ')}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleViewAnnouncement(announcement)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Ver Completo
                          </Button>
                          {canEdit && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <Edit className="w-4 h-4 mr-2" />
                                  Editar
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Pin className="w-4 h-4 mr-2" />
                                  Fixar
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredAnnouncements.length === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <Megaphone className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Nenhum comunicado encontrado
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {searchTerm || priorityFilter !== 'all'
                      ? 'Tente ajustar os filtros de busca'
                      : 'Não há comunicados publicados no momento'
                    }
                  </p>
                  {canCreate && (searchTerm === '' && priorityFilter === 'all') && (
                    <Button onClick={handleCreateAnnouncement}>
                      <Plus className="w-4 h-4 mr-2" />
                      Criar Primeiro Comunicado
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Messages Tab */}
        <TabsContent value="messages" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Caixa de Mensagens</CardTitle>
              <CardDescription>
                Suas mensagens e conversas internas
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Message Tabs */}
              <Tabs value={activeMessageTab} onValueChange={(value) => setActiveMessageTab(value as 'inbox' | 'sent')} className="space-y-4">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="inbox" className="flex items-center">
                    <Mail className="w-4 h-4 mr-2" />
                    Caixa de Entrada ({userMessages.inbox.length})
                  </TabsTrigger>
                  <TabsTrigger value="sent" className="flex items-center">
                    <Send className="w-4 h-4 mr-2" />
                    Enviadas ({userMessages.sent.length})
                  </TabsTrigger>
                </TabsList>

                {/* Inbox Messages */}
                <TabsContent value="inbox" className="space-y-4">
                  {userMessages.inbox.map((message) => {
                    const sender = employees.find(emp => emp.id === message.fromId);

                    return (
                      <div key={message.id} className={`p-4 rounded-lg border ${!message.isRead ? 'bg-blue-50 border-blue-200' : 'bg-white'}`}>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-8 h-8">
                              <AvatarImage src={sender?.avatar} alt={sender?.name} />
                              <AvatarFallback className="bg-purple-100 text-purple-600">
                                {sender?.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium text-gray-900">{sender?.name}</p>
                              <p className="text-sm text-gray-500">
                                {formatDistanceToNow(new Date(message.date), { addSuffix: true, locale: ptBR })}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {getPriorityBadge(message.priority)}
                            {!message.isRead && (
                              <Badge className="bg-blue-100 text-blue-700">Nova</Badge>
                            )}
                          </div>
                        </div>
                        <div className="mt-3">
                          <h4 className="font-medium text-gray-900 mb-1">{message.subject}</h4>
                          <p className="text-gray-700 text-sm">{message.content}</p>
                          {!message.isRead && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-2"
                              onClick={() => handleMarkAsRead(message.id)}
                            >
                              Marcar como lida
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}

                  {userMessages.inbox.length === 0 && (
                    <div className="text-center py-8">
                      <Mail className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                      <p className="text-gray-600">Nenhuma mensagem na caixa de entrada</p>
                    </div>
                  )}
                </TabsContent>

                {/* Sent Messages */}
                <TabsContent value="sent" className="space-y-4">
                  {userMessages.sent.map((message) => {
                    const recipients = message.toId.map(id => employees.find(emp => emp.id === id)).filter(Boolean);

                    return (
                      <div key={message.id} className="p-4 rounded-lg border bg-green-50 border-green-200">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                              <Send className="w-4 h-4 text-green-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">
                                Para: {recipients.map(r => r?.name).join(', ')}
                              </p>
                              <p className="text-sm text-gray-500">
                                {formatDistanceToNow(new Date(message.date), { addSuffix: true, locale: ptBR })}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {getPriorityBadge(message.priority)}
                            <Badge className="bg-green-100 text-green-700">Enviada</Badge>
                          </div>
                        </div>
                        <div className="mt-3">
                          <h4 className="font-medium text-gray-900 mb-1">{message.subject}</h4>
                          <p className="text-gray-700 text-sm">{message.content}</p>
                        </div>
                      </div>
                    );
                  })}

                  {userMessages.sent.length === 0 && (
                    <div className="text-center py-8">
                      <Send className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                      <p className="text-gray-600">Nenhuma mensagem enviada</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Central de Notificações</CardTitle>
              <CardDescription>
                Alertas, lembretes e atualizações do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.filter(notif => notif.userId === user?.id).map((notification) => (
                  <div key={notification.id} className={`p-4 rounded-lg border ${!notification.isRead ? 'bg-yellow-50 border-yellow-200' : 'bg-white'}`}>
                    <div className="flex items-start space-x-3">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-gray-900">{notification.title}</h4>
                          <span className="text-sm text-gray-500">
                            {formatDistanceToNow(new Date(notification.date), { addSuffix: true, locale: ptBR })}
                          </span>
                        </div>
                        <p className="text-gray-700 text-sm mt-1">{notification.message}</p>
                        {notification.actionUrl && (
                          <Button variant="link" size="sm" className="p-0 mt-2">
                            Ver detalhes
                          </Button>
                        )}
                      </div>
                      {!notification.isRead && (
                        <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      )}
                    </div>
                  </div>
                ))}

                {notifications.filter(notif => notif.userId === user?.id).length === 0 && (
                  <div className="text-center py-8">
                    <Bell className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">Nenhuma notificação encontrada</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* View Announcement Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedAnnouncement?.title}</DialogTitle>
            <DialogDescription>
              Publicado por {selectedAnnouncement?.author} em {' '}
              {selectedAnnouncement && format(new Date(selectedAnnouncement.date), 'dd/MM/yyyy', { locale: ptBR })}
            </DialogDescription>
          </DialogHeader>
          
          {selectedAnnouncement && (
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                {getPriorityBadge(selectedAnnouncement.priority)}
                <Badge variant="outline">
                  Departamentos: {selectedAnnouncement.departments?.join(', ')}
                </Badge>
              </div>
              
              <div className="prose max-w-none">
                <p className="text-gray-700 whitespace-pre-wrap">{selectedAnnouncement.content}</p>
              </div>
              
              {selectedAnnouncement.attachments && selectedAnnouncement.attachments.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Anexos:</h4>
                  <div className="space-y-2">
                    {selectedAnnouncement.attachments.map((attachment, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        <Paperclip className="w-4 h-4" />
                        <span>{attachment.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Announcement Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Novo Comunicado</DialogTitle>
            <DialogDescription>
              Crie um novo comunicado para a empresa
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="ann-title">Título</Label>
              <Input
                id="ann-title"
                value={announcementForm.title || ''}
                onChange={(e) => setAnnouncementForm({...announcementForm, title: e.target.value})}
                placeholder="Título do comunicado"
              />
            </div>

            <div>
              <Label htmlFor="ann-priority">Prioridade</Label>
              <Select 
                value={announcementForm.priority || ''} 
                onValueChange={(value) => setAnnouncementForm({...announcementForm, priority: value as 'low' | 'medium' | 'high'})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a prioridade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baixa</SelectItem>
                  <SelectItem value="medium">Média</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="ann-content">Conteúdo</Label>
              <Textarea
                id="ann-content"
                value={announcementForm.content || ''}
                onChange={(e) => setAnnouncementForm({...announcementForm, content: e.target.value})}
                placeholder="Escreva o conteúdo do comunicado..."
                rows={6}
              />
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSaveAnnouncement}>
                Publicar Comunicado
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Send Message Dialog */}
      <Dialog open={isMessageDialogOpen} onOpenChange={setIsMessageDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Nova Mensagem</DialogTitle>
            <DialogDescription>
              Envie uma mensagem para outros colaboradores
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="msg-to">Para</Label>
              <Select 
                value={messageForm.toId[0] || ''} 
                onValueChange={(value) => setMessageForm({...messageForm, toId: [value]})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o destinatário" />
                </SelectTrigger>
                <SelectContent>
                  {employees.filter(emp => emp.id !== user?.id).map(employee => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.name} - {employee.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="msg-subject">Assunto</Label>
              <Input
                id="msg-subject"
                value={messageForm.subject}
                onChange={(e) => setMessageForm({...messageForm, subject: e.target.value})}
                placeholder="Assunto da mensagem"
              />
            </div>

            <div>
              <Label htmlFor="msg-priority">Prioridade</Label>
              <Select 
                value={messageForm.priority} 
                onValueChange={(value) => setMessageForm({...messageForm, priority: value as 'low' | 'medium' | 'high'})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baixa</SelectItem>
                  <SelectItem value="medium">Média</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="msg-content">Mensagem</Label>
              <Textarea
                id="msg-content"
                value={messageForm.content}
                onChange={(e) => setMessageForm({...messageForm, content: e.target.value})}
                placeholder="Escreva sua mensagem..."
                rows={6}
              />
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsMessageDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSendMessage}>
                <Send className="w-4 h-4 mr-2" />
                Enviar Mensagem
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
