import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { IntegratedDataStore } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import {
  CheckCircle, XCircle, AlertTriangle, TestTube, 
  PlayCircle, RefreshCw, FileText, Users, Briefcase,
  BookOpen, Award, MessageSquare, Database, Settings
} from 'lucide-react';

interface TestResult {
  name: string;
  status: 'passed' | 'failed' | 'warning' | 'pending';
  message: string;
  details?: string;
}

interface ModuleTest {
  module: string;
  tests: TestResult[];
  icon: React.ComponentType<any>;
}

export default function SystemTest() {
  const { user } = useAuth();
  const [testResults, setTestResults] = useState<ModuleTest[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const runSystemTests = async () => {
    setIsRunning(true);
    setProgress(0);
    const results: ModuleTest[] = [];

    // Test 1: Dashboard Module
    setProgress(10);
    const dashboardTests: TestResult[] = [];
    
    try {
      // Test data loading
      const employees = IntegratedDataStore.getEmployees();
      const jobs = IntegratedDataStore.getJobs();
      const trainings = IntegratedDataStore.getTrainings();
      const evaluations = IntegratedDataStore.getEvaluations();

      dashboardTests.push({
        name: 'Data Loading',
        status: employees.length > 0 ? 'passed' : 'failed',
        message: `Loaded ${employees.length} employees, ${jobs.length} jobs, ${trainings.length} trainings, ${evaluations.length} evaluations`,
      });

      // Test stats calculation
      const activeEmployees = employees.filter(emp => emp.status === 'active').length;
      dashboardTests.push({
        name: 'Statistics Calculation',
        status: activeEmployees >= 0 ? 'passed' : 'failed',
        message: `Active employees: ${activeEmployees}`,
      });

    } catch (error) {
      dashboardTests.push({
        name: 'Dashboard Module',
        status: 'failed',
        message: 'Failed to load dashboard data',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    results.push({
      module: 'Dashboard',
      tests: dashboardTests,
      icon: Database
    });

    // Test 2: Employees Module
    setProgress(20);
    const employeeTests: TestResult[] = [];
    
    try {
      const employees = IntegratedDataStore.getEmployees();
      employeeTests.push({
        name: 'Employee Data Structure',
        status: employees.every(emp => emp.name && emp.email && emp.id) ? 'passed' : 'failed',
        message: `All ${employees.length} employees have required fields`,
      });

      // Test employee operations
      const testEmployee = {
        name: 'Test Employee',
        email: 'test@test.com',
        phone: '123456789',
        cpf: '123.456.789-00',
        rg: '12.345.678-9',
        position: 'Test Position',
        department: 'Test Department',
        address: 'Test Address',
        joinDate: new Date().toISOString(),
        status: 'active' as const,
        documents: [],
        evaluations: [],
        trainings: [],
        history: []
      };

      const addResult = IntegratedDataStore.addEmployee(testEmployee);
      if (addResult) {
        IntegratedDataStore.deleteEmployee(addResult.id);
      }

      employeeTests.push({
        name: 'CRUD Operations',
        status: addResult ? 'passed' : 'failed',
        message: addResult ? 'Add/Delete operations working' : 'CRUD operations failed',
      });

    } catch (error) {
      employeeTests.push({
        name: 'Employees Module',
        status: 'failed',
        message: 'Failed to test employee operations',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    results.push({
      module: 'Employees',
      tests: employeeTests,
      icon: Users
    });

    // Test 3: Jobs Module
    setProgress(40);
    const jobTests: TestResult[] = [];
    
    try {
      const jobs = IntegratedDataStore.getJobs();
      jobTests.push({
        name: 'Job Data Loading',
        status: jobs.length >= 0 ? 'passed' : 'failed',
        message: `Loaded ${jobs.length} job listings`,
      });

      // Test job filtering
      const openJobs = jobs.filter(job => job.status === 'open');
      jobTests.push({
        name: 'Job Filtering',
        status: 'passed',
        message: `${openJobs.length} open jobs found`,
      });

    } catch (error) {
      jobTests.push({
        name: 'Jobs Module',
        status: 'failed',
        message: 'Failed to test jobs module',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    results.push({
      module: 'Jobs',
      tests: jobTests,
      icon: Briefcase
    });

    // Test 4: Documents Module
    setProgress(60);
    const documentTests: TestResult[] = [];
    
    try {
      const employees = IntegratedDataStore.getEmployees();
      const totalDocs = employees.reduce((sum, emp) => sum + emp.documents.length, 0);
      
      documentTests.push({
        name: 'Document Storage',
        status: totalDocs >= 0 ? 'passed' : 'failed',
        message: `${totalDocs} documents found across all employees`,
      });

      // Test document upload simulation
      if (employees.length > 0) {
        const testDoc = {
          name: 'test-document.pdf',
          type: 'contract' as const,
          uploadDate: new Date().toISOString(),
          size: '100 KB',
          url: 'test-url'
        };

        const uploadResult = IntegratedDataStore.addDocument(employees[0].id, testDoc);
        if (uploadResult) {
          // Clean up test document
          const employee = IntegratedDataStore.getEmployee(employees[0].id);
          if (employee) {
            const docToDelete = employee.documents.find(doc => doc.name === 'test-document.pdf');
            if (docToDelete) {
              IntegratedDataStore.deleteDocument(employees[0].id, docToDelete.id);
            }
          }
        }

        documentTests.push({
          name: 'Document Operations',
          status: uploadResult ? 'passed' : 'failed',
          message: uploadResult ? 'Upload/Delete operations working' : 'Document operations failed',
        });
      }

    } catch (error) {
      documentTests.push({
        name: 'Documents Module',
        status: 'failed',
        message: 'Failed to test documents module',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    results.push({
      module: 'Documents',
      tests: documentTests,
      icon: FileText
    });

    // Test 5: Trainings Module
    setProgress(80);
    const trainingTests: TestResult[] = [];
    
    try {
      const trainings = IntegratedDataStore.getTrainings();
      trainingTests.push({
        name: 'Training Data',
        status: trainings.length >= 0 ? 'passed' : 'failed',
        message: `${trainings.length} training programs loaded`,
      });

      // Test training materials
      const trainingsWithMaterials = trainings.filter(training => training.materials && training.materials.length > 0);
      trainingTests.push({
        name: 'Training Materials',
        status: trainingsWithMaterials.length > 0 ? 'passed' : 'warning',
        message: `${trainingsWithMaterials.length} trainings have materials`,
      });

    } catch (error) {
      trainingTests.push({
        name: 'Trainings Module',
        status: 'failed',
        message: 'Failed to test trainings module',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    results.push({
      module: 'Trainings',
      tests: trainingTests,
      icon: BookOpen
    });

    // Test 6: Public Pages
    setProgress(90);
    const publicTests: TestResult[] = [];
    
    try {
      // Test local storage data for public pages
      const publicJobsData = localStorage.getItem('enhancedJobs');
      publicTests.push({
        name: 'Public Jobs Data',
        status: publicJobsData ? 'passed' : 'warning',
        message: publicJobsData ? 'Job data available for public page' : 'No job data in localStorage',
      });

      // Test evaluation links
      const evaluationLinks = localStorage.getItem('evaluationLinks');
      publicTests.push({
        name: 'Evaluation Links',
        status: 'passed',
        message: evaluationLinks ? 'Evaluation links storage working' : 'No evaluation links found',
      });

    } catch (error) {
      publicTests.push({
        name: 'Public Pages',
        status: 'failed',
        message: 'Failed to test public pages',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }

    results.push({
      module: 'Public Pages',
      tests: publicTests,
      icon: TestTube
    });

    setProgress(100);
    setTestResults(results);
    setIsRunning(false);
  };

  const getStatusIcon = (status: TestResult['status']) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      default:
        return <RefreshCw className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: TestResult['status']) => {
    switch (status) {
      case 'passed':
        return <Badge className="bg-green-100 text-green-700">Passou</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-700">Falhou</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-700">Aviso</Badge>;
      default:
        return <Badge variant="secondary">Pendente</Badge>;
    }
  };

  const totalTests = testResults.reduce((sum, module) => sum + module.tests.length, 0);
  const passedTests = testResults.reduce((sum, module) => 
    sum + module.tests.filter(test => test.status === 'passed').length, 0
  );
  const failedTests = testResults.reduce((sum, module) => 
    sum + module.tests.filter(test => test.status === 'failed').length, 0
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <TestTube className="w-8 h-8 mr-3 text-blue-600" />
            Teste do Sistema
          </h1>
          <p className="text-gray-600 mt-1">
            Verificação completa de funcionalidades do sistema
          </p>
        </div>
        <Button 
          onClick={runSystemTests} 
          disabled={isRunning}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              Testando...
            </>
          ) : (
            <>
              <PlayCircle className="w-4 h-4 mr-2" />
              Executar Testes
            </>
          )}
        </Button>
      </div>

      {/* Progress Bar */}
      {isRunning && (
        <Card>
          <CardContent className="p-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progresso dos Testes</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Test Results Summary */}
      {testResults.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Testes Executados</p>
                  <p className="text-3xl font-bold text-blue-600">{totalTests}</p>
                </div>
                <TestTube className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Testes Aprovados</p>
                  <p className="text-3xl font-bold text-green-600">{passedTests}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Testes Falharam</p>
                  <p className="text-3xl font-bold text-red-600">{failedTests}</p>
                </div>
                <XCircle className="w-8 h-8 text-red-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Test Results by Module */}
      {testResults.length > 0 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">Resultados por Módulo</h2>
          
          {testResults.map((moduleResult, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <moduleResult.icon className="w-6 h-6 mr-3 text-blue-600" />
                  {moduleResult.module}
                  <div className="ml-auto flex space-x-2">
                    {moduleResult.tests.map((test, testIndex) => (
                      <div key={testIndex} className="flex items-center space-x-1">
                        {getStatusIcon(test.status)}
                      </div>
                    ))}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {moduleResult.tests.map((test, testIndex) => (
                    <div key={testIndex} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">{test.name}</h4>
                        {getStatusBadge(test.status)}
                      </div>
                      <p className="text-sm text-gray-600">{test.message}</p>
                      {test.details && (
                        <Alert className="mt-2 border-red-200 bg-red-50">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription className="text-red-800">
                            {test.details}
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Instructions */}
      {testResults.length === 0 && !isRunning && (
        <Card>
          <CardContent className="p-6 text-center">
            <TestTube className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Sistema Pronto para Teste
            </h3>
            <p className="text-gray-600 mb-4">
              Execute os testes para verificar se todas as funcionalidades estão funcionando corretamente.
            </p>
            <Button onClick={runSystemTests}>
              <PlayCircle className="w-4 h-4 mr-2" />
              Iniciar Testes
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
