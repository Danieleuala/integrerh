import { useState, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore, Feedback as FeedbackType, Employee } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  MessageSquare, Plus, Search, Eye, Edit, MoreHorizontal, 
  Users, Clock, Calendar, Target, ThumbsUp, ThumbsDown,
  CheckCircle, XCircle, AlertCircle, Star, Download,
  Heart, TrendingUp, Send, Reply
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Feedback() {
  const { user } = useAuth();
  const [feedbacks, setFeedbacks] = useState(IntegratedDataStore.getFeedbacks());
  const [employees] = useState(IntegratedDataStore.getEmployees());
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [recipientFilter, setRecipientFilter] = useState<string>('all');
  const [selectedFeedback, setSelectedFeedback] = useState<FeedbackType | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [feedbackForm, setFeedbackForm] = useState<Partial<FeedbackType>>({});

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin', 'manager', 'employee']);
  const canView = hasPermission(user?.role || 'employee', ['rh_admin', 'manager', 'employee']);

  const filteredFeedbacks = useMemo(() => {
    return feedbacks.filter(feedback => {
      const fromEmployee = employees.find(emp => emp.id === feedback.fromId);
      const toEmployee = employees.find(emp => emp.id === feedback.toId);
      
      const matchesSearch = fromEmployee?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           toEmployee?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           feedback.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           feedback.competency?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = typeFilter === 'all' || feedback.type === typeFilter;
      const matchesRecipient = recipientFilter === 'all' || feedback.toId === recipientFilter;
      
      // Show only non-private feedbacks or feedbacks involving the current user, or user is RH/manager
      const canSee = !feedback.isPrivate ||
                     feedback.fromId === user?.id ||
                     feedback.toId === user?.id ||
                     user?.role === 'rh_admin' ||
                     user?.role === 'manager';
      
      return matchesSearch && matchesType && matchesRecipient && canSee;
    });
  }, [feedbacks, employees, searchTerm, typeFilter, recipientFilter, user]);

  const getTypeBadge = (type: FeedbackType['type']) => {
    switch (type) {
      case 'positive':
        return <Badge className="bg-green-100 text-green-700"><ThumbsUp className="w-3 h-3 mr-1" />Positivo</Badge>;
      case 'constructive':
        return <Badge className="bg-orange-100 text-orange-700"><Target className="w-3 h-3 mr-1" />Construtivo</Badge>;
      case 'goal':
        return <Badge className="bg-blue-100 text-blue-700"><Star className="w-3 h-3 mr-1" />Meta</Badge>;
      default:
        return <Badge variant="secondary">Outros</Badge>;
    }
  };

  const handleViewFeedback = (feedback: FeedbackType) => {
    setSelectedFeedback(feedback);
    setIsViewDialogOpen(true);
  };

  const handleCreateFeedback = () => {
    setFeedbackForm({
      fromId: user?.id || '',
      toId: '',
      message: '',
      type: 'positive',
      competency: '',
      date: new Date().toISOString(),
      isPrivate: false
    });
    setIsCreateDialogOpen(true);
  };

  const handleSaveFeedback = () => {
    if (feedbackForm.toId && feedbackForm.message && feedbackForm.type) {
      // Check if user is not sending feedback to themselves
      if (feedbackForm.toId === user?.id) {
        alert('Você não pode enviar feedback para si mesmo!');
        return;
      }

      const newFeedback = IntegratedDataStore.addFeedback(feedbackForm as Omit<FeedbackType, 'id'>);
      setFeedbacks(IntegratedDataStore.getFeedbacks());
      setIsCreateDialogOpen(false);
      setFeedbackForm({});
      alert('Feedback enviado com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos obrigatórios: Destinatário, Mensagem e Tipo.');
    }
  };

  const handleExportFeedbacks = () => {
    const dataStr = JSON.stringify(filteredFeedbacks, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `feedbacks_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const stats = useMemo(() => {
    const userFeedbacks = {
      received: feedbacks.filter(feedback => feedback.toId === user?.id),
      sent: feedbacks.filter(feedback => feedback.fromId === user?.id)
    };
    
    return {
      total: feedbacks.length,
      positive: feedbacks.filter(feedback => feedback.type === 'positive').length,
      constructive: feedbacks.filter(feedback => feedback.type === 'constructive').length,
      goal: feedbacks.filter(feedback => feedback.type === 'goal').length,
      userReceived: userFeedbacks.received.length,
      userSent: userFeedbacks.sent.length,
      thisWeek: feedbacks.filter(feedback => {
        const feedbackDate = new Date(feedback.date);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return feedbackDate >= weekAgo;
      }).length
    };
  }, [feedbacks, user]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <MessageSquare className="w-8 h-8 mr-3 text-purple-600" />
            Feedback Contínuo
          </h1>
          <p className="text-gray-600 mt-1">
            Sistema de comunicação e desenvolvimento em tempo real
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={handleExportFeedbacks}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          {canCreate && (
            <Button onClick={handleCreateFeedback} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Novo Feedback
            </Button>
          )}
        </div>
      </div>

      {/* Personal Feedback Summary */}
      {user?.role === 'employee' && (
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Heart className="w-5 h-5 mr-2" />
              Meus Feedbacks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{stats.userReceived}</div>
                <p className="text-sm text-gray-600">Recebidos</p>
                <p className="text-xs text-gray-500">Total</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">{stats.userSent}</div>
                <p className="text-sm text-gray-600">Enviados</p>
                <p className="text-xs text-gray-500">Por mim</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">{stats.thisWeek}</div>
                <p className="text-sm text-gray-600">Esta Semana</p>
                <p className="text-xs text-gray-500">Atividade recente</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600">
                  {stats.userReceived > 0 ? Math.round((stats.positive / stats.userReceived) * 100) : 0}%
                </div>
                <p className="text-sm text-gray-600">Positivos</p>
                <p className="text-xs text-gray-500">Taxa de satisfação</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <MessageSquare className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Positivos</p>
                <p className="text-3xl font-bold text-green-600">{stats.positive}</p>
              </div>
              <ThumbsUp className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Construtivos</p>
                <p className="text-3xl font-bold text-orange-600">{stats.constructive}</p>
              </div>
              <Target className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Esta Semana</p>
                <p className="text-3xl font-bold text-purple-600">{stats.thisWeek}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por pessoa, mensagem..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="positive">Positivos</SelectItem>
                  <SelectItem value="constructive">Construtivos</SelectItem>
                  <SelectItem value="goal">Metas</SelectItem>
                </SelectContent>
              </Select>

              <Select value={recipientFilter} onValueChange={setRecipientFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Destinatário" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {employees.map(employee => (
                    <SelectItem key={employee.id} value={employee.id}>
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredFeedbacks.length} de {feedbacks.length} feedback(s)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Feedbacks Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Timeline de Feedbacks</CardTitle>
          <CardDescription>
            Histórico de comunicações e desenvolvimento da equipe
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {filteredFeedbacks.map((feedback) => {
              const fromEmployee = employees.find(emp => emp.id === feedback.fromId);
              const toEmployee = employees.find(emp => emp.id === feedback.toId);
              
              return (
                <div key={feedback.id} className="flex space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <Avatar className="w-10 h-10 flex-shrink-0">
                    <AvatarImage src={fromEmployee?.avatar} alt={fromEmployee?.name} />
                    <AvatarFallback className="bg-purple-100 text-purple-600">
                      {fromEmployee?.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <p className="font-medium text-gray-900">
                          {fromEmployee?.name}
                        </p>
                        <span className="text-gray-500">→</span>
                        <p className="font-medium text-gray-700">
                          {toEmployee?.name}
                        </p>
                        {getTypeBadge(feedback.type)}
                        {feedback.isPrivate && (
                          <Badge variant="outline" className="border-red-200 text-red-700">
                            Privado
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-500">
                          {format(new Date(feedback.date), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                        </span>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewFeedback(feedback)}>
                              <Eye className="w-4 h-4 mr-2" />
                              Ver Detalhes
                            </DropdownMenuItem>
                            {(feedback.fromId === user?.id || user?.role === 'rh_admin') && (
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Editar
                              </DropdownMenuItem>
                            )}
                            {feedback.toId === user?.id && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Reply className="w-4 h-4 mr-2" />
                                  Responder
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    
                    <p className="text-gray-700 mb-2 line-clamp-2">
                      {feedback.message}
                    </p>
                    
                    {feedback.competency && (
                      <div className="flex items-center space-x-2">
                        <Target className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          Competência: {feedback.competency}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {filteredFeedbacks.length === 0 && (
            <div className="text-center py-12">
              <MessageSquare className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum feedback encontrado
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || typeFilter !== 'all' || recipientFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Comece a cultura de feedback contínuo na sua equipe'
                }
              </p>
              {canCreate && (searchTerm === '' && typeFilter === 'all' && recipientFilter === 'all') && (
                <Button onClick={handleCreateFeedback}>
                  <Plus className="w-4 h-4 mr-2" />
                  Enviar Primeiro Feedback
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Feedback Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalhes do Feedback</DialogTitle>
          </DialogHeader>
          
          {selectedFeedback && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={employees.find(emp => emp.id === selectedFeedback.fromId)?.avatar} />
                    <AvatarFallback className="bg-purple-100 text-purple-600">
                      {employees.find(emp => emp.id === selectedFeedback.fromId)?.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">
                      {employees.find(emp => emp.id === selectedFeedback.fromId)?.name}
                    </p>
                    <p className="text-sm text-gray-600">
                      para {employees.find(emp => emp.id === selectedFeedback.toId)?.name}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {getTypeBadge(selectedFeedback.type)}
                  {selectedFeedback.isPrivate && (
                    <Badge variant="outline" className="border-red-200 text-red-700">
                      Privado
                    </Badge>
                  )}
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Mensagem</h4>
                <p className="text-gray-700 whitespace-pre-wrap">{selectedFeedback.message}</p>
              </div>

              {selectedFeedback.competency && (
                <div>
                  <h4 className="font-medium mb-2">Competência Relacionada</h4>
                  <Badge variant="outline" className="border-blue-200 text-blue-700">
                    {selectedFeedback.competency}
                  </Badge>
                </div>
              )}

              <div className="text-sm text-gray-600">
                <p>
                  Enviado em {format(new Date(selectedFeedback.date), 'dd/MM/yyyy às HH:mm', { locale: ptBR })}
                </p>
              </div>

              {selectedFeedback.toId === user?.id && (
                <div className="flex justify-end">
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
                    <Reply className="w-4 h-4 mr-2" />
                    Responder Feedback
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Feedback Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Novo Feedback</DialogTitle>
            <DialogDescription>
              Envie um feedback construtivo para um colega
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="feedback-recipient">Destinatário</Label>
                <Select 
                  value={feedbackForm.toId || ''} 
                  onValueChange={(value) => setFeedbackForm({...feedbackForm, toId: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a pessoa" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.filter(emp => emp.id !== user?.id).map(employee => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} - {employee.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="feedback-type">Tipo de Feedback</Label>
                <Select 
                  value={feedbackForm.type || ''} 
                  onValueChange={(value) => setFeedbackForm({...feedbackForm, type: value as FeedbackType['type']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="positive">Positivo</SelectItem>
                    <SelectItem value="constructive">Construtivo</SelectItem>
                    <SelectItem value="goal">Meta/Objetivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="feedback-competency">Competência (opcional)</Label>
              <Input
                id="feedback-competency"
                value={feedbackForm.competency || ''}
                onChange={(e) => setFeedbackForm({...feedbackForm, competency: e.target.value})}
                placeholder="Ex: Comunicação, Liderança, Trabalho em Equipe"
              />
            </div>

            <div>
              <Label htmlFor="feedback-message">Mensagem</Label>
              <Textarea
                id="feedback-message"
                value={feedbackForm.message || ''}
                onChange={(e) => setFeedbackForm({...feedbackForm, message: e.target.value})}
                placeholder="Escreva seu feedback de forma construtiva e específica..."
                rows={6}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="feedback-private"
                checked={feedbackForm.isPrivate || false}
                onCheckedChange={(checked) => setFeedbackForm({...feedbackForm, isPrivate: checked})}
              />
              <Label htmlFor="feedback-private" className="text-sm">
                Feedback privado (visível apenas para RH e as pessoas envolvidas)
              </Label>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSaveFeedback}>
                <Send className="w-4 h-4 mr-2" />
                Enviar Feedback
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
