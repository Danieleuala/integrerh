import { useAuth, getRoleDisplayName, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore } from '@/lib/mockData';
import { ActivityFeed } from '@/components/ActivityFeed';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Users, TrendingUp, Calendar, Award, Clock, Briefcase, 
  MessageSquare, BookOpen, BarChart3, Bell, Settings,
  ChevronRight, Plus, Eye
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useMemo } from 'react';

export default function Dashboard() {
  const { user } = useAuth();
  
  const stats = useMemo(() => {
    // Use integrated cross-module stats
    const crossModuleStats = IntegratedDataStore.getCrossModuleStats();
    const employees = IntegratedDataStore.getEmployees();
    const jobs = IntegratedDataStore.getJobs();
    const trainings = IntegratedDataStore.getTrainings();
    const evaluations = IntegratedDataStore.getEvaluations();
    
    return {
      totalEmployees: employees.length,
      activeEmployees: employees.filter(emp => emp.status === 'active').length,
      openJobs: jobs.filter(job => job.status === 'open').length,
      trainingsInProgress: trainings.filter(training => training.status === 'in_progress').length,
      completedEvaluations: evaluations.filter(evaluation => evaluation.status === 'completed').length,
      avgPerformance: evaluations.length > 0
        ? (evaluations.reduce((acc, evaluation) => acc + evaluation.overallScore, 0) / evaluations.length).toFixed(1)
        : '0.0'
    };
  }, []);

  const recentActivities = [
    {
      id: '1',
      type: 'new_employee',
      message: 'Maria Santos foi contratada para Analista de Vendas',
      time: '2 horas atrás',
      icon: Users,
      color: 'bg-green-100 text-green-600'
    },
    {
      id: '2',
      type: 'evaluation',
      message: 'Avaliação 360° de Carlos Mendes foi concluída',
      time: '4 horas atrás',
      icon: Award,
      color: 'bg-purple-100 text-purple-600'
    },
    {
      id: '3',
      type: 'training',
      message: 'Treinamento de Liderança iniciado por 5 colaboradores',
      time: '1 dia atrás',
      icon: BookOpen,
      color: 'bg-blue-100 text-blue-600'
    },
    {
      id: '4',
      type: 'job_application',
      message: 'Nova candidatura para Desenvolvedor Full Stack',
      time: '2 dias atrás',
      icon: Briefcase,
      color: 'bg-orange-100 text-orange-600'
    }
  ];

  const quickActions = [
    {
      title: 'Novo Colaborador',
      description: 'Cadastrar novo funcionário',
      icon: Users,
      color: 'bg-green-500',
      href: '/employees',
      permission: ['rh_admin', 'manager']
    },
    {
      title: 'Criar Vaga',
      description: 'Publicar nova oportunidade',
      icon: Briefcase,
      color: 'bg-blue-500',
      href: '/jobs',
      permission: ['rh_admin', 'manager']
    },
    {
      title: 'Nova Avaliação',
      description: 'Iniciar processo de avaliação',
      icon: Award,
      color: 'bg-purple-500',
      href: '/evaluations',
      permission: ['rh_admin', 'manager']
    },
    {
      title: 'Criar Treinamento',
      description: 'Desenvolver programa de capacitação',
      icon: BookOpen,
      color: 'bg-orange-500',
      href: '/trainings',
      permission: ['rh_admin']
    }
  ];

  const modules = [
    {
      title: 'Gestão de Colaboradores',
      description: `${stats.activeEmployees} ativos de ${stats.totalEmployees} total`,
      icon: Users,
      color: 'border-green-200 hover:border-green-400',
      href: '/employees',
      permission: ['rh_admin', 'manager']
    },
    {
      title: 'Vagas e Recrutamento',
      description: `${stats.openJobs} vagas abertas`,
      icon: Briefcase,
      color: 'border-blue-200 hover:border-blue-400',
      href: '/jobs',
      permission: ['rh_admin', 'manager', 'candidate']
    },
    {
      title: 'Avaliações de Performance',
      description: `${stats.completedEvaluations} avaliações concluídas`,
      icon: Award,
      color: 'border-purple-200 hover:border-purple-400',
      href: '/evaluations',
      permission: ['rh_admin', 'manager', 'employee']
    },
    {
      title: 'Treinamentos',
      description: `${stats.trainingsInProgress} em andamento`,
      icon: BookOpen,
      color: 'border-orange-200 hover:border-orange-400',
      href: '/trainings',
      permission: ['rh_admin', 'manager', 'employee']
    },
    {
      title: 'Feedback Contínuo',
      description: 'Sistema de feedback em tempo real',
      icon: MessageSquare,
      color: 'border-pink-200 hover:border-pink-400',
      href: '/feedback',
      permission: ['rh_admin', 'manager', 'employee']
    },
    {
      title: 'Relatórios e Analytics',
      description: 'Dashboards e métricas de RH',
      icon: BarChart3,
      color: 'border-indigo-200 hover:border-indigo-400',
      href: '/reports',
      permission: ['rh_admin', 'manager']
    }
  ];

  if (!user) return null;

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Bem-vindo, {user.name}! 👋
          </h1>
          <p className="text-gray-600 mt-1">
            {getRoleDisplayName(user.role)} - {user.department || 'Sistema'}
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Badge variant="secondary" className="bg-purple-100 text-purple-700">
            {getRoleDisplayName(user.role)}
          </Badge>
          <Link to="/profile">
            <Button variant="outline" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Perfil
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Colaboradores Ativos</p>
                <p className="text-3xl font-bold">{stats.activeEmployees}</p>
                <p className="text-green-200 text-xs">de {stats.totalEmployees} total</p>
              </div>
              <Users className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">Vagas Abertas</p>
                <p className="text-3xl font-bold">{stats.openJobs}</p>
                <p className="text-blue-200 text-xs">Recrutamento ativo</p>
              </div>
              <Briefcase className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">Performance Média</p>
                <p className="text-3xl font-bold">{stats.avgPerformance}</p>
                <p className="text-purple-200 text-xs">de 10.0 pontos</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm">Treinamentos</p>
                <p className="text-3xl font-bold">{stats.trainingsInProgress}</p>
                <p className="text-orange-200 text-xs">Em andamento</p>
              </div>
              <BookOpen className="w-8 h-8 text-orange-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      {hasPermission(user.role, ['rh_admin', 'manager']) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="w-5 h-5 mr-2" />
              Ações Rápidas
            </CardTitle>
            <CardDescription>
              Acesso direto às principais funcionalidades
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {quickActions
                .filter(action => hasPermission(user.role, action.permission as any))
                .map((action, index) => (
                <Link key={index} to={action.href}>
                  <Card className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4 text-center">
                      <div className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                        <action.icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="font-medium text-gray-900 mb-1">{action.title}</h3>
                      <p className="text-sm text-gray-600">{action.description}</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Modules Grid */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Módulos da Plataforma</CardTitle>
              <CardDescription>
                Acesse as principais funcionalidades do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {modules
                  .filter(module => hasPermission(user.role, module.permission as any))
                  .map((module, index) => (
                  <Link key={index} to={module.href}>
                    <Card className={`${module.color} hover:shadow-md transition-all cursor-pointer`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <module.icon className="w-5 h-5 mr-2 text-gray-600" />
                              <h3 className="font-medium text-gray-900">{module.title}</h3>
                            </div>
                            <p className="text-sm text-gray-600">{module.description}</p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-gray-400 ml-2" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Integrated Activity Feed */}
        <div>
          <ActivityFeed limit={10} showHeader={true} />
        </div>
      </div>
    </div>
  );
}
