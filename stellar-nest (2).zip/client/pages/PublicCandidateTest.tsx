import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { EnhancedDataStore, Test } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import CandidateTestArea from '@/components/CandidateTestArea';
import { Brain, User, Mail, Phone, ArrowRight, Briefcase } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CandidateInfo {
  name: string;
  email: string;
  phone: string;
}

export default function PublicCandidateTest() {
  const { testId } = useParams<{ testId: string }>();
  const { toast } = useToast();
  
  const [test, setTest] = useState<Test | null>(null);
  const [candidateInfo, setCandidateInfo] = useState<CandidateInfo>({
    name: '',
    email: '',
    phone: ''
  });
  const [candidateId, setCandidateId] = useState<string | null>(null);
  const [step, setStep] = useState<'info' | 'test'>('info');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (testId) {
      // Load specific test
      const foundTest = EnhancedDataStore.getTests().find(t => t.id === testId);
      setTest(foundTest || null);
    }
    setLoading(false);
  }, [testId]);

  const handleStartTest = () => {
    if (!candidateInfo.name || !candidateInfo.email) {
      toast({
        title: "Informações obrigatórias",
        description: "Por favor, preencha seu nome e email para continuar",
        variant: "destructive"
      });
      return;
    }

    // Create or find candidate
    let candidates = EnhancedDataStore.getCandidates();
    let candidate = candidates.find(c => c.email === candidateInfo.email);
    
    if (!candidate) {
      candidate = {
        id: `candidate_${Date.now()}`,
        name: candidateInfo.name,
        email: candidateInfo.email,
        phone: candidateInfo.phone,
        testResults: [],
        applications: []
      };
      
      // This would need to be implemented in your data store
      // EnhancedDataStore.addCandidate(candidate);
    }

    setCandidateId(candidate.id);
    setStep('test');

    toast({
      title: "Bem-vindo!",
      description: `Boa sorte em sua prova, ${candidateInfo.name}!`,
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Brain className="w-12 h-12 mx-auto text-purple-600 mb-4 animate-pulse" />
          <p className="text-gray-600">Carregando prova...</p>
        </div>
      </div>
    );
  }

  if (!test) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Brain className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Prova não encontrada
            </h2>
            <p className="text-gray-600 mb-4">
              A prova que você está tentando acessar não existe ou foi removida.
            </p>
            <Button onClick={() => window.location.href = '/'}>
              <Briefcase className="w-4 h-4 mr-2" />
              Ver Vagas Disponíveis
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!test.isActive) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Brain className="w-12 h-12 mx-auto text-orange-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Prova indisponível
            </h2>
            <p className="text-gray-600 mb-4">
              Esta prova não está ativa no momento. Tente novamente mais tarde ou entre em contato com o RH.
            </p>
            <Button onClick={() => window.location.href = '/'}>
              <Briefcase className="w-4 h-4 mr-2" />
              Ver Vagas Disponíveis
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'test' && candidateId) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <CandidateTestArea 
            candidateId={candidateId}
            onClose={() => {
              setStep('info');
              setCandidateId(null);
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Avaliação Técnica
          </h1>
          <p className="text-gray-600">
            Processo Seletivo - Integre RH
          </p>
        </div>

        {/* Test Info Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-center text-xl">
              {test.name}
            </CardTitle>
            <CardDescription className="text-center">
              {test.description}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600 mb-1">
                  {test.questions.length}
                </div>
                <div className="text-sm text-gray-600">Questões</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 mb-1">
                  {test.timeLimit}
                </div>
                <div className="text-sm text-gray-600">Minutos</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600 mb-1">
                  {test.passingScore}%
                </div>
                <div className="text-sm text-gray-600">Nota Mínima</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Candidate Info Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Suas Informações</span>
            </CardTitle>
            <CardDescription>
              Preencha seus dados para iniciar a avaliação
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Nome Completo *</Label>
              <Input
                id="name"
                value={candidateInfo.name}
                onChange={(e) => setCandidateInfo(prev => ({
                  ...prev,
                  name: e.target.value
                }))}
                placeholder="Digite seu nome completo"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={candidateInfo.email}
                onChange={(e) => setCandidateInfo(prev => ({
                  ...prev,
                  email: e.target.value
                }))}
                placeholder="seu.email@exemplo.com"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={candidateInfo.phone}
                onChange={(e) => setCandidateInfo(prev => ({
                  ...prev,
                  phone: e.target.value
                }))}
                placeholder="(11) 99999-9999"
                className="mt-1"
              />
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Instruções Importantes:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Você terá {test.timeLimit} minutos para completar a prova</li>
                <li>• É necessário obter pelo menos {test.passingScore}% para aprovação</li>
                <li>• Não feche a janela durante a realização da prova</li>
                <li>• Certifique-se de ter uma conexão estável com a internet</li>
                <li>• Seus resultados serão registrados automaticamente</li>
              </ul>
            </div>

            <Button 
              onClick={handleStartTest}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              size="lg"
            >
              <Brain className="w-5 h-5 mr-2" />
              Iniciar Avaliação
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>

            <p className="text-xs text-gray-500 text-center">
              Ao continuar, você concorda em fornecer informações precisas e realizar a prova de forma íntegra
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>Powered by Integre RH - Sistema de Recrutamento e Seleção</p>
        </div>
      </div>
    </div>
  );
}
