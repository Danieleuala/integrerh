import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useRealAuth } from '@/hooks/useRealAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Eye, EyeOff, LogIn, Users, UserCheck, Crown, Briefcase } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<string>('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login, isAuthenticated } = useRealAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnTo = searchParams.get('returnTo') || '/dashboard';

  useEffect(() => {
    if (isAuthenticated) {
      navigate(returnTo);
    }
  }, [isAuthenticated, navigate, returnTo]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!email || !password) {
      setError('Por favor, preencha todos os campos');
      setIsLoading(false);
      return;
    }

    const result = await login(email, password, role);
    
    if (result.success) {
      navigate(returnTo);
    } else {
      setError(result.message);
    }
    
    setIsLoading(false);
  };

  const roleOptions = [
    { value: 'admin', label: 'Administrador', icon: Crown, description: 'Gestão de empresas clientes' },
    { value: 'hr', label: 'RH', icon: Users, description: 'Gestão de recursos humanos' },
    { value: 'manager', label: 'Gestor', icon: UserCheck, description: 'Gerenciamento de equipe' },
    { value: 'employee', label: 'Funcionário', icon: Briefcase, description: 'Acesso de colaborador' },
    { value: 'candidate', label: 'Candidato', icon: LogIn, description: 'Portal do candidato' }
  ];

  const quickAccess = [
    { email: 'admin@integrerh.com', password: 'admin123', role: 'admin', label: 'Admin Demo' },
    { email: 'rh@integrerh.com', password: 'rh123', role: 'hr', label: 'RH Demo' },
    { email: 'gestor@integrerh.com', password: 'gestor123', role: 'manager', label: 'Gestor Demo' },
    { email: 'funcionario@integrerh.com', password: 'func123', role: 'employee', label: 'Funcionário Demo' },
    { email: 'candidato@integrerh.com', password: 'cand123', role: 'candidate', label: 'Candidato Demo' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left side - Branding */}
        <div className="hidden lg:flex flex-col justify-center space-y-8 px-8">
          <div>
            <h1 className="text-4xl font-bold text-purple-700 mb-4">Integre RH</h1>
            <p className="text-xl text-gray-600 mb-8">
              Plataforma completa de gestão de recursos humanos
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Gestão de Pessoas</h3>
                  <p className="text-gray-600">Controle completo do quadro de funcionários</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Recrutamento</h3>
                  <p className="text-gray-600">Portal de vagas e gestão de candidatos</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <UserCheck className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Avaliações</h3>
                  <p className="text-gray-600">Sistema completo de avaliação de desempenho</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login form */}
        <div className="flex flex-col justify-center space-y-6">
          <Card className="border-0 shadow-2xl">
            <CardHeader className="text-center space-y-2">
              <CardTitle className="text-3xl font-bold text-gray-900">Entrar</CardTitle>
              <CardDescription className="text-gray-600">
                Acesse sua conta na plataforma Integre RH
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Tipo de Acesso</Label>
                  <Select value={role} onValueChange={setRole}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione seu tipo de acesso" />
                    </SelectTrigger>
                    <SelectContent>
                      {roleOptions.map((option) => {
                        const IconComponent = option.icon;
                        return (
                          <SelectItem key={option.value} value={option.value}>
                            <div className="flex items-center space-x-2">
                              <IconComponent className="w-4 h-4" />
                              <div>
                                <div className="font-medium">{option.label}</div>
                                <div className="text-xs text-gray-500">{option.description}</div>
                              </div>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu.email@empresa.com"
                    className="h-12"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Senha</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Sua senha"
                      className="h-12 pr-12"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-12 w-12 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-500" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-500" />
                      )}
                    </Button>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 bg-purple-600 hover:bg-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Entrando...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <LogIn className="w-4 h-4" />
                      <span>Entrar</span>
                    </div>
                  )}
                </Button>
              </form>

              <div className="flex items-center justify-between text-sm">
                <Link 
                  to="/forgot-password" 
                  className="text-purple-600 hover:text-purple-700 hover:underline"
                >
                  Esqueci minha senha
                </Link>
                <Link 
                  to="/register" 
                  className="text-purple-600 hover:text-purple-700 hover:underline"
                >
                  Criar conta
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Quick Access Demo */}
          <Card className="border border-gray-200">
            <CardHeader>
              <CardTitle className="text-lg">Acesso Rápido - Demo</CardTitle>
              <CardDescription>
                Use essas credenciais para testar diferentes perfis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-2">
                {quickAccess.map((access, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="text-xs h-auto py-3 px-4 justify-start"
                    onClick={() => {
                      setEmail(access.email);
                      setPassword(access.password);
                      setRole(access.role);
                    }}
                  >
                    <div className="text-left">
                      <div className="font-medium">{access.label}</div>
                      <div className="text-xs text-gray-500">{access.email}</div>
                    </div>
                  </Button>
                ))}
              </div>
              
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="text-center text-green-800">
                  <p className="text-xs">
                    <strong>Credenciais para teste:</strong><br/>
                    Use qualquer email acima + senha respectiva ou clique nos botões para preencher automaticamente.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
