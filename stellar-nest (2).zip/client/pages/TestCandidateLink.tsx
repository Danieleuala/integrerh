import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { EnhancedJob } from '@/lib/enhancedData';
import { ExternalLink, Copy } from 'lucide-react';

export default function TestCandidateLink() {
  const [jobs, setJobs] = useState<EnhancedJob[]>([]);
  const [testJobId, setTestJobId] = useState('');

  useEffect(() => {
    const savedJobs = localStorage.getItem('enhancedJobs');
    if (savedJobs) {
      const jobsData = JSON.parse(savedJobs);
      setJobs(jobsData);
      if (jobsData.length > 0) {
        setTestJobId(jobsData[0].id);
      }
    }
  }, []);

  const testLink = (jobId: string) => {
    const link = `${window.location.origin}/candidate-apply/${jobId}`;
    window.open(link, '_blank');
  };

  const copyLink = (jobId: string) => {
    const link = `${window.location.origin}/candidate-apply/${jobId}`;
    navigator.clipboard.writeText(link);
    alert('Link copiado!');
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Teste de Links de Candidatura</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Testar Job ID específico:</label>
            <div className="flex space-x-2">
              <Input
                value={testJobId}
                onChange={(e) => setTestJobId(e.target.value)}
                placeholder="ID da vaga"
              />
              <Button onClick={() => testLink(testJobId)}>
                <ExternalLink className="w-4 h-4 mr-2" />
                Testar
              </Button>
              <Button variant="outline" onClick={() => copyLink(testJobId)}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium">Vagas disponíveis:</h3>
            {jobs.map((job) => (
              <div key={job.id} className="p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{job.title}</h4>
                    <p className="text-sm text-gray-600">{job.department}</p>
                    <p className="text-xs text-gray-500">ID: {job.id}</p>
                  </div>
                  <div className="space-x-2">
                    <Button size="sm" onClick={() => testLink(job.id)}>
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Testar Link
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => copyLink(job.id)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="mt-2">
                  <p className="text-xs text-gray-500 break-all">
                    {job.shareableLink || `${window.location.origin}/candidate-apply/${job.id}`}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {jobs.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              Nenhuma vaga encontrada. Crie uma vaga primeiro.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
