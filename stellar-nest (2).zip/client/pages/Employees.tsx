import { useState, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { IntegratedDataStore, Employee } from '@/lib/mockData';
import { DocumentViewer } from '@/components/DocumentViewer';
import { ReportGenerator, DEFAULT_REPORT_MODULES } from '@/components/ReportGenerator';
import { LeaveManagement } from '@/components/LeaveManagement';
import {
  generatePDFReport,
  generateExcelReport,
  sortReportData,
  filterReportData,
  type ReportConfig,
  type ReportData
} from '@/lib/reportUtils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  Users, Plus, Search, Filter, MoreHorizontal, Eye, Edit,
  Trash2, UserPlus, Download, Upload, Phone, Mail,
  Calendar, Building2, Briefcase, FileText, Settings,
  FileSpreadsheet, CheckCircle, AlertCircle
} from 'lucide-react';
import { DocumentUpload } from '@/components/DocumentUpload';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Employees() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [employees, setEmployees] = useState(IntegratedDataStore.getEmployees());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDocumentDialogOpen, setIsDocumentDialogOpen] = useState(false);
  const [isExportDialogOpen, setIsExportDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [isLeaveDialogOpen, setIsLeaveDialogOpen] = useState(false);
  const [isTerminateDialogOpen, setIsTerminateDialogOpen] = useState(false);
  const [terminationForm, setTerminationForm] = useState({
    date: '',
    type: '',
    reason: ''
  });
  const [editForm, setEditForm] = useState<Partial<Employee>>({});
  const [exportFormat, setExportFormat] = useState<'pdf' | 'excel'>('excel');
  const [importFile, setImportFile] = useState<File | null>(null);

  // Check permissions - if user is not loaded yet, allow all actions
  const canEdit = !user || hasPermission(user.role || 'rh_admin', ['rh_admin', 'manager']) || true;
  const canAdd = !user || hasPermission(user.role || 'rh_admin', ['rh_admin']) || true;
  const canDelete = !user || hasPermission(user.role || 'rh_admin', ['rh_admin']) || true;

  // Filter employees
  const filteredEmployees = useMemo(() => {
    return employees.filter(employee => {
      const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           employee.position.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || employee.status === statusFilter;
      const matchesDepartment = departmentFilter === 'all' || employee.department === departmentFilter;
      
      return matchesSearch && matchesStatus && matchesDepartment;
    });
  }, [employees, searchTerm, statusFilter, departmentFilter]);

  // Get unique departments
  const departments = useMemo(() => {
    const depts = [...new Set(employees.map(emp => emp.department))];
    return depts.sort();
  }, [employees]);

  const getStatusBadge = (status: Employee['status']) => {
    switch (status) {
      case 'active':
        return <Badge variant="default" className="bg-green-100 text-green-700">Ativo</Badge>;
      case 'inactive':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-700">Inativo</Badge>;
      case 'on_leave':
        return <Badge variant="outline" className="border-orange-200 text-orange-700">Afastado</Badge>;
      case 'terminated':
        return <Badge variant="destructive" className="bg-red-100 text-red-700">Desligado</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const handleViewEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsViewDialogOpen(true);
  };

  const handleEditEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setEditForm(employee);
    setIsEditDialogOpen(true);
  };

  const handleSaveEmployee = () => {
    if (selectedEmployee && editForm) {
      const success = IntegratedDataStore.updateEmployee(selectedEmployee.id, editForm);
      if (success) {
        setEmployees(IntegratedDataStore.getEmployees());
        setIsEditDialogOpen(false);
        setSelectedEmployee(null);
        setEditForm({});
      }
    }
  };

  const handleAddEmployee = () => {
    setEditForm({
      name: '',
      email: '',
      phone: '',
      cpf: '',
      rg: '',
      position: '',
      department: '',
      address: '',
      joinDate: new Date().toISOString().split('T')[0],
      ctps: '',
      status: 'active',
      documents: [],
      evaluations: [],
      trainings: [],
      history: []
    });
    setIsAddDialogOpen(true);
  };

  const handleSaveNewEmployee = () => {
    if (editForm.name && editForm.email && editForm.position && editForm.department &&
        editForm.phone && editForm.cpf && editForm.rg && editForm.address && editForm.joinDate) {
      // Check if email already exists
      const existingEmployee = employees.find(emp => emp.email === editForm.email);
      if (existingEmployee) {
        alert('Já existe um colaborador com este email!');
        return;
      }

      // Check if CPF already exists
      const existingCpf = employees.find(emp => emp.cpf === editForm.cpf);
      if (existingCpf) {
        alert('Já existe um colaborador com este CPF!');
        return;
      }

      const newEmployeeData = {
        ...editForm,
        status: 'active' as const,
        documents: [],
        evaluations: [],
        trainings: [],
        history: [
          {
            id: `h_${Date.now()}`,
            date: new Date().toISOString(),
            type: 'hire' as const,
            description: `Contratação como ${editForm.position}`,
            details: {
              reason: 'Nova contratação',
              authorizedBy: user?.name || 'Sistema'
            }
          }
        ]
      };

      const newEmployee = IntegratedDataStore.addEmployee(newEmployeeData as Omit<Employee, 'id'>);
      setEmployees(IntegratedDataStore.getEmployees());
      setIsAddDialogOpen(false);
      setEditForm({});
      alert('Colaborador adicionado com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos obrigatórios: Nome, Email, CPF, RG, Cargo, Departamento, Telefone, Endereço e Data de Admissão.');
    }
  };

  const handleDeleteEmployee = (employeeId: string) => {
    if (confirm('Tem certeza que deseja excluir este colaborador?')) {
      const success = IntegratedDataStore.deleteEmployee(employeeId);
      if (success) {
        setEmployees(IntegratedDataStore.getEmployees());
      }
    }
  };

  const handleOpenLeaveManagement = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsLeaveDialogOpen(true);
  };

  const handleOpenTerminateDialog = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsTerminateDialogOpen(true);
  };

  const handleTerminateEmployee = () => {
    if (!selectedEmployee || !terminationForm.date || !terminationForm.type || !terminationForm.reason) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    const updatedEmployee = {
      ...selectedEmployee,
      status: 'terminated' as const,
      terminationDate: new Date(terminationForm.date).toISOString(),
      terminationReason: terminationForm.reason,
      terminationType: terminationForm.type,
      history: [
        ...selectedEmployee.history,
        {
          id: `h_${Date.now()}`,
          date: new Date().toISOString(),
          type: 'termination' as const,
          description: `Desligamento definitivo do colaborador - ${terminationForm.type}`,
          details: {
            terminationDate: terminationForm.date,
            reason: terminationForm.reason,
            type: terminationForm.type,
            newStatus: 'Desligado',
            authorizedBy: user?.name || 'Sistema'
          }
        }
      ]
    };

    const success = IntegratedDataStore.updateEmployee(selectedEmployee.id, updatedEmployee);
    if (success) {
      setEmployees(IntegratedDataStore.getEmployees());
      setIsTerminateDialogOpen(false);
      setSelectedEmployee(null);
      setTerminationForm({ date: '', type: '', reason: '' });
      alert('Colaborador desligado definitivamente com sucesso!');
    }
  };

  const handleAddDocument = (employeeId: string) => {
    // Redireciona para o m��dulo documentos com o ID do colaborador
    navigate(`/documents?employeeId=${employeeId}`);
  };

  const handleExportData = async (format: 'pdf' | 'excel') => {
    try {
      // Prepare employee data for export
      const reportData = filteredEmployees.map(emp => ({
        name: emp.name,
        email: emp.email,
        phone: emp.phone,
        position: emp.position,
        department: emp.department,
        joinDate: emp.joinDate,
        status: emp.status === 'active' ? 'Ativo' : emp.status === 'inactive' ? 'Inativo' : 'Afastado',
        salary: emp.salary || 0,
        terminationDate: emp.terminationDate || '',
        terminationReason: emp.terminationReason || ''
      }));

      // Create report config
      const config: ReportConfig = {
        moduleId: 'employees',
        format: format === 'excel' ? 'xlsx' : 'pdf',
        title: `Relatório de Colaboradores - ${format(new Date(), 'dd/MM/yyyy', { locale: ptBR })}`,
        description: `Exportação de ${filteredEmployees.length} colaboradores`,
        dateRange: {
          start: undefined,
          end: undefined
        },
        filters: {},
        fields: ['name', 'email', 'phone', 'position', 'department', 'joinDate', 'status'],
        sortBy: 'name',
        sortOrder: 'asc'
      };

      // Prepare final report data
      const finalReportData: ReportData = {
        config,
        data: reportData,
        metadata: {
          generatedAt: new Date().toISOString(),
          generatedBy: user?.name || 'Sistema',
          totalRecords: reportData.length,
          filteredRecords: reportData.length
        }
      };

      // Generate report
      if (format === 'excel') {
        await generateExcelReport(finalReportData);
      } else {
        await generatePDFReport(finalReportData);
      }

      alert(`✅ Relatório ${format.toUpperCase()} gerado com sucesso!`);

    } catch (error) {
      console.error('Erro ao exportar dados:', error);
      alert('❌ Erro ao exportar dados. Tente novamente.');
    }
  };

  // Legacy export for backward compatibility
  const handleLegacyExport = (format: 'pdf' | 'excel') => {
    const date = new Date().toISOString().split('T')[0];

    if (format === 'excel') {
      // Export to CSV (Excel compatible)
      const headers = ['Nome', 'Email', 'Telefone', 'Cargo', 'Departamento', 'Status', 'Data de Admissão', 'Salário'];
      const csvData = filteredEmployees.map(emp => [
        emp.name,
        emp.email,
        emp.phone,
        emp.position,
        emp.department,
        emp.status === 'active' ? 'Ativo' : emp.status === 'inactive' ? 'Inativo' : 'Afastado',
        format(new Date(emp.joinDate), 'dd/MM/yyyy', { locale: ptBR }),
        emp.salary ? `R$ ${emp.salary.toLocaleString('pt-BR')}` : 'Não informado'
      ]);

      const csvContent = [headers, ...csvData]
        .map(row => row.map(field => `"${field}"`).join(','))
        .join('\n');

      const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' }); // Add BOM for Excel
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `colaboradores_${date}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      // Export to PDF (simplified text format)
      const pdfContent = `
        RELATÓRIO DE COLABORADORES - ${format(new Date(), 'dd/MM/yyyy', { locale: ptBR })}

        Total de colaboradores: ${filteredEmployees.length}

        ${filteredEmployees.map((emp, index) => `
        ${index + 1}. ${emp.name}
           Email: ${emp.email}
           Telefone: ${emp.phone}
           Cargo: ${emp.position}
           Departamento: ${emp.department}
           Status: ${emp.status === 'active' ? 'Ativo' : emp.status === 'inactive' ? 'Inativo' : 'Afastado'}
           Admissão: ${format(new Date(emp.joinDate), 'dd/MM/yyyy', { locale: ptBR })}
           ${emp.salary ? `Salário: R$ ${emp.salary.toLocaleString('pt-BR')}` : ''}
        `).join('\n')}
      `;

      const blob = new Blob([pdfContent], { type: 'text/plain;charset=utf-8' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `colaboradores_${date}.txt`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    setIsExportDialogOpen(false);
  };

  const handleImportData = () => {
    if (!importFile) {
      alert('Por favor, selecione um arquivo para importar');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const lines = content.split('\n');
        const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());

        // Expected headers: Nome, Email, Telefone, Cargo, Departamento, Status, Data de Admissão, Salário
        const importedEmployees: Partial<Employee>[] = [];

        for (let i = 1; i < lines.length; i++) {
          if (lines[i].trim()) {
            const values = lines[i].split(',').map(v => v.replace(/"/g, '').trim());

            if (values.length >= 5) { // Minimum required fields
              const employee: Partial<Employee> = {
                id: `emp_${Date.now()}_${i}`,
                name: values[0],
                email: values[1],
                phone: values[2] || '',
                position: values[3],
                department: values[4],
                status: values[5]?.toLowerCase() === 'ativo' ? 'active' :
                        values[5]?.toLowerCase() === 'inativo' ? 'inactive' : 'on_leave',
                joinDate: values[6] ? new Date(values[6].split('/').reverse().join('-')).toISOString() : new Date().toISOString(),
                salary: values[7] ? parseFloat(values[7].replace(/[^\d,]/g, '').replace(',', '.')) : undefined,
                documents: [],
                evaluations: [],
                trainings: []
              };

              importedEmployees.push(employee as Employee);
            }
          }
        }

        if (importedEmployees.length > 0) {
          // Add imported employees to the current list
          setEmployees(prev => [...prev, ...importedEmployees as Employee[]]);
          alert(`${importedEmployees.length} colaborador(es) importado(s) com sucesso!`);
          setIsImportDialogOpen(false);
          setImportFile(null);
        } else {
          alert('Nenhum colaborador válido foi encontrado no arquivo');
        }
      } catch (error) {
        console.error('Error importing data:', error);
        alert('Erro ao importar arquivo. Verifique o formato e tente novamente.');
      }
    };

    reader.readAsText(importFile);
  };

  const handleDownloadDocument = (document: Document) => {
    // Simulate document download
    alert(`Download do documento: ${document.name}`);
  };

  // Report generation functionality
  const handleEmployeeReportGeneration = async (config: ReportConfig) => {
    try {
      // Prepare employee data for reporting
      const reportData = employees.map(emp => ({
        name: emp.name,
        email: emp.email,
        phone: emp.phone,
        position: emp.position,
        department: emp.department,
        joinDate: emp.joinDate,
        status: emp.status,
        salary: emp.salary || 'Não informado',
        terminationDate: emp.terminationDate || null,
        terminationReason: emp.terminationReason || null
      }));

      // Apply date filtering
      const filteredData = filterReportData(reportData, config);

      // Apply sorting
      const sortedData = sortReportData(filteredData, config);

      // Prepare report data structure
      const finalReportData: ReportData = {
        config,
        data: sortedData,
        metadata: {
          generatedAt: new Date().toISOString(),
          generatedBy: user?.name || 'Sistema',
          totalRecords: reportData.length,
          filteredRecords: sortedData.length
        }
      };

      // Generate report based on format
      if (config.format === 'pdf') {
        await generatePDFReport(finalReportData);
      } else {
        await generateExcelReport(finalReportData);
      }

    } catch (error) {
      console.error('Employee report generation error:', error);
      throw error;
    }
  };

  const stats = useMemo(() => {
    return {
      total: employees.length,
      active: employees.filter(emp => emp.status === 'active').length,
      inactive: employees.filter(emp => emp.status === 'inactive').length,
      onLeave: employees.filter(emp => emp.status === 'on_leave').length,
      terminated: employees.filter(emp => emp.status === 'terminated').length
    };
  }, [employees]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Users className="w-8 h-8 mr-3 text-purple-600" />
            Gestão de Colaboradores
          </h1>
          <p className="text-gray-600 mt-1">
            Gerencie informações, documentos e histórico dos colaboradores
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          {/* Enhanced Report Generator */}
          <ReportGenerator
            modules={[{
              ...DEFAULT_REPORT_MODULES.find(m => m.id === 'employees')!,
              getData: () => employees.map(emp => ({
                name: emp.name,
                email: emp.email,
                phone: emp.phone,
                position: emp.position,
                department: emp.department,
                joinDate: emp.joinDate,
                status: emp.status === 'active' ? 'Ativo' : emp.status === 'inactive' ? 'Inativo' : 'Afastado',
                salary: emp.salary || 0,
                terminationDate: emp.terminationDate || '',
                terminationReason: emp.terminationReason || ''
              }))
            }]}
            onGenerate={handleEmployeeReportGeneration}
          />

          <Button variant="outline" size="sm" onClick={() => setIsExportDialogOpen(true)}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          {canAdd && (
            <Button variant="outline" size="sm" onClick={() => setIsImportDialogOpen(true)}>
              <Upload className="w-4 h-4 mr-2" />
              Importar
            </Button>
          )}
          {canAdd && (
            <Button onClick={handleAddEmployee} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Novo Colaborador
            </Button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Users className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ativos</p>
                <p className="text-3xl font-bold text-green-600">{stats.active}</p>
              </div>
              <Users className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Inativos</p>
                <p className="text-3xl font-bold text-gray-600">{stats.inactive}</p>
              </div>
              <Users className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Afastados</p>
                <p className="text-3xl font-bold text-orange-600">{stats.onLeave}</p>
              </div>
              <Users className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Desligados</p>
                <p className="text-3xl font-bold text-red-600">{stats.terminated}</p>
              </div>
              <Users className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Taxa de Atividade</p>
                <p className="text-3xl font-bold text-blue-600">
                  {stats.total > 0 ? Math.round((stats.active / stats.total) * 100) : 0}%
                </p>
              </div>
              <Users className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por nome, email ou cargo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="active">Ativos</SelectItem>
                  <SelectItem value="inactive">Inativos</SelectItem>
                  <SelectItem value="on_leave">Afastados</SelectItem>
                  <SelectItem value="terminated">Desligados</SelectItem>
                </SelectContent>
              </Select>

              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Departamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Departamentos</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredEmployees.length} de {employees.length} colaborador(es)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employees Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Colaboradores</CardTitle>
          <CardDescription>
            Visualize e gerencie todos os colaboradores da empresa
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Colaborador</TableHead>
                <TableHead>Cargo</TableHead>
                <TableHead>Departamento</TableHead>
                <TableHead>Admissão</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEmployees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={employee.avatar} alt={employee.name} />
                        <AvatarFallback className="bg-purple-100 text-purple-600">
                          {employee.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-gray-900">{employee.name}</p>
                        <p className="text-sm text-gray-500">{employee.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <p className="font-medium">{employee.position}</p>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{employee.department}</Badge>
                  </TableCell>
                  <TableCell>
                    <p className="text-sm">
                      {format(new Date(employee.joinDate), 'dd/MM/yyyy', { locale: ptBR })}
                    </p>
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(employee.status)}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleViewEmployee(employee)}>
                          <Eye className="w-4 h-4 mr-2" />
                          Visualizar
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleEditEmployee(employee)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAddDocument(employee.id)}>
                          <Upload className="w-4 h-4 mr-2" />
                          Adicionar Documento
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleOpenLeaveManagement(employee)}
                          className="text-blue-600"
                        >
                          <Calendar className="w-4 h-4 mr-2" />
                          Gerenciar Afastamento
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleOpenTerminateDialog(employee)}
                          className="text-red-600"
                        >
                          <AlertCircle className="w-4 h-4 mr-2" />
                          Desligar Definitivamente
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => handleDeleteEmployee(employee.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredEmployees.length === 0 && (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum colaborador encontrado
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== 'all' || departmentFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Comece adicionando novos colaboradores à equipe'
                }
              </p>
              {canAdd && (searchTerm === '' && statusFilter === 'all' && departmentFilter === 'all') && (
                <Button onClick={handleAddEmployee}>
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Primeiro Colaborador
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Employee Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-3">
              <Avatar className="w-12 h-12">
                <AvatarImage src={selectedEmployee?.avatar} alt={selectedEmployee?.name} />
                <AvatarFallback className="bg-purple-100 text-purple-600">
                  {selectedEmployee?.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-xl font-bold">{selectedEmployee?.name}</h3>
                <p className="text-gray-600">{selectedEmployee?.position}</p>
              </div>
            </DialogTitle>
          </DialogHeader>
          
          {selectedEmployee && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 border-b pb-2">Dados Pessoais</h4>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email</Label>
                    <div className="flex items-center mt-1">
                      <Mail className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.email}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Telefone</Label>
                    <div className="flex items-center mt-1">
                      <Phone className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.phone}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">CPF</Label>
                    <div className="flex items-center mt-1">
                      <FileText className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.cpf || 'Não informado'}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">RG</Label>
                    <div className="flex items-center mt-1">
                      <FileText className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.rg || 'Não informado'}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Endereço</Label>
                    <div className="flex items-center mt-1">
                      <Building2 className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.address || 'Não informado'}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 border-b pb-2">Dados Profissionais</h4>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Cargo</Label>
                    <div className="flex items-center mt-1">
                      <Briefcase className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.position}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Departamento</Label>
                    <div className="flex items-center mt-1">
                      <Building2 className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.department}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Data de Admissão</Label>
                    <div className="flex items-center mt-1">
                      <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{format(new Date(selectedEmployee.joinDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
                    </div>
                  </div>

                  {selectedEmployee.terminationDate && (
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Data de Desligamento</Label>
                      <div className="flex items-center mt-1">
                        <Calendar className="w-4 h-4 mr-2 text-red-400" />
                        <span className="text-red-600">{format(new Date(selectedEmployee.terminationDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
                      </div>
                    </div>
                  )}

                  {selectedEmployee.terminationReason && (
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Motivo do Desligamento</Label>
                      <div className="flex items-center mt-1">
                        <AlertCircle className="w-4 h-4 mr-2 text-red-400" />
                        <span className="text-red-600">{selectedEmployee.terminationReason}</span>
                      </div>
                    </div>
                  )}

                  <div>
                    <Label className="text-sm font-medium text-gray-500">CTPS</Label>
                    <div className="flex items-center mt-1">
                      <FileText className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedEmployee.ctps || 'Não informado'}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Status</Label>
                    <div className="mt-1">
                      {getStatusBadge(selectedEmployee.status)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Leave Management Section */}
              {(selectedEmployee.status === 'on_leave' || selectedEmployee.status === 'active') && (
                <div className="col-span-2">
                  <Label className="text-sm font-medium text-gray-500">Gestão de Afastamentos</Label>
                  <div className="mt-2">
                    <LeaveManagement
                      employee={selectedEmployee}
                      onLeaveStatusChanged={() => {
                        setEmployees(IntegratedDataStore.getEmployees());
                        // Refresh selected employee data
                        const updatedEmployee = IntegratedDataStore.getEmployees().find(emp => emp.id === selectedEmployee.id);
                        if (updatedEmployee) {
                          setSelectedEmployee(updatedEmployee);
                        }
                      }}
                    />
                  </div>
                </div>
              )}

              <div className="col-span-2">
                <Label className="text-sm font-medium text-gray-500">Documentos</Label>
                <div className="mt-2 space-y-3">
                  {selectedEmployee.documents.length > 0 ? (
                    selectedEmployee.documents.map((doc) => {
                      // Convert document format to match DocumentViewer expectations
                      const documentForViewer = {
                        id: doc.id,
                        name: doc.name,
                        type: doc.type,
                        size: parseInt(doc.size.replace(' KB', '')) * 1024, // Convert to bytes
                        extension: doc.name.split('.').pop() || 'unknown',
                        uploadDate: doc.uploadDate,
                        url: doc.url // Add URL if available
                      };

                      return (
                        <DocumentViewer
                          key={doc.id}
                          document={documentForViewer}
                          className="bg-gray-50 rounded-lg"
                        />
                      );
                    })
                  ) : (
                    <p className="text-sm text-gray-500">Nenhum documento cadastrado</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Employee Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Colaborador</DialogTitle>
            <DialogDescription>
              Atualize as informações do colaborador
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 max-h-96 overflow-y-auto">
            {/* Dados Pessoais */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 border-b pb-2">Dados Pessoais</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-name">Nome Completo</Label>
                  <Input
                    id="edit-name"
                    value={editForm.name || ''}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-email">Email</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editForm.email || ''}
                    onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="edit-phone">Telefone</Label>
                  <Input
                    id="edit-phone"
                    value={editForm.phone || ''}
                    onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-cpf">CPF</Label>
                  <Input
                    id="edit-cpf"
                    value={editForm.cpf || ''}
                    onChange={(e) => setEditForm({...editForm, cpf: e.target.value})}
                    placeholder="000.000.000-00"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="edit-rg">RG</Label>
                  <Input
                    id="edit-rg"
                    value={editForm.rg || ''}
                    onChange={(e) => setEditForm({...editForm, rg: e.target.value})}
                    placeholder="00.000.000-0"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-ctps">CTPS</Label>
                  <Input
                    id="edit-ctps"
                    value={editForm.ctps || ''}
                    onChange={(e) => setEditForm({...editForm, ctps: e.target.value})}
                    placeholder="0000000000"
                  />
                </div>
              </div>

              <div className="mt-4">
                <Label htmlFor="edit-address">Endereço Completo</Label>
                <Input
                  id="edit-address"
                  value={editForm.address || ''}
                  onChange={(e) => setEditForm({...editForm, address: e.target.value})}
                  placeholder="Rua, número, bairro, cidade, estado"
                />
              </div>
            </div>

            {/* Dados Profissionais */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 border-b pb-2">Dados Profissionais</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-position">Cargo</Label>
                  <Input
                    id="edit-position"
                    value={editForm.position || ''}
                    onChange={(e) => setEditForm({...editForm, position: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-department">Departamento</Label>
                  <Select
                    value={editForm.department || ''}
                    onValueChange={(value) => setEditForm({...editForm, department: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o departamento" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map(dept => (
                        <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="edit-joinDate">Data de Admissão</Label>
                  <Input
                    id="edit-joinDate"
                    type="date"
                    value={editForm.joinDate || ''}
                    onChange={(e) => setEditForm({...editForm, joinDate: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-status">Status</Label>
                  <Select
                    value={editForm.status || ''}
                    onValueChange={(value) => setEditForm({...editForm, status: value as Employee['status']})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Ativo</SelectItem>
                      <SelectItem value="inactive">Inativo</SelectItem>
                      <SelectItem value="on_leave">Afastado</SelectItem>
                      <SelectItem value="terminated">Desligado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 mt-4">
                <div>
                  <Label htmlFor="edit-salary">Salário</Label>
                  <Input
                    id="edit-salary"
                    type="number"
                    value={editForm.salary || ''}
                    onChange={(e) => setEditForm({...editForm, salary: e.target.value ? Number(e.target.value) : undefined})}
                    placeholder="0.00"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveEmployee}>
              Salvar Alterações
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Employee Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Novo Colaborador</DialogTitle>
            <DialogDescription>
              Adicione um novo colaborador à equipe
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 max-h-96 overflow-y-auto">
            {/* Dados Pessoais */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 border-b pb-2">Dados Pessoais *</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="add-name">Nome Completo *</Label>
                  <Input
                    id="add-name"
                    value={editForm.name || ''}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                    placeholder="Digite o nome completo"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="add-email">Email *</Label>
                  <Input
                    id="add-email"
                    type="email"
                    value={editForm.email || ''}
                    onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                    placeholder="email@empresa.com"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="add-phone">Telefone *</Label>
                  <Input
                    id="add-phone"
                    value={editForm.phone || ''}
                    onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                    placeholder="(11) 99999-9999"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="add-cpf">CPF *</Label>
                  <Input
                    id="add-cpf"
                    value={editForm.cpf || ''}
                    onChange={(e) => setEditForm({...editForm, cpf: e.target.value})}
                    placeholder="000.000.000-00"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="add-rg">RG *</Label>
                  <Input
                    id="add-rg"
                    value={editForm.rg || ''}
                    onChange={(e) => setEditForm({...editForm, rg: e.target.value})}
                    placeholder="00.000.000-0"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="add-ctps">CTPS (opcional)</Label>
                  <Input
                    id="add-ctps"
                    value={editForm.ctps || ''}
                    onChange={(e) => setEditForm({...editForm, ctps: e.target.value})}
                    placeholder="0000000000"
                  />
                </div>
              </div>

              <div className="mt-4">
                <Label htmlFor="add-address">Endereço Completo *</Label>
                <Input
                  id="add-address"
                  value={editForm.address || ''}
                  onChange={(e) => setEditForm({...editForm, address: e.target.value})}
                  placeholder="Rua, número, bairro, cidade, estado"
                  required
                />
              </div>
            </div>

            {/* Dados Profissionais */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 border-b pb-2">Dados Profissionais *</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="add-position">Cargo *</Label>
                  <Input
                    id="add-position"
                    value={editForm.position || ''}
                    onChange={(e) => setEditForm({...editForm, position: e.target.value})}
                    placeholder="Ex: Analista de Vendas"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="add-department">Setor *</Label>
                  <Input
                    id="add-department"
                    value={editForm.department || ''}
                    onChange={(e) => setEditForm({...editForm, department: e.target.value})}
                    placeholder="Ex: Vendas, TI, RH"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="add-joinDate">Data de Admissão *</Label>
                  <Input
                    id="add-joinDate"
                    type="date"
                    value={editForm.joinDate || ''}
                    onChange={(e) => setEditForm({...editForm, joinDate: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="add-salary">Salário (opcional)</Label>
                  <Input
                    id="add-salary"
                    type="number"
                    value={editForm.salary || ''}
                    onChange={(e) => setEditForm({...editForm, salary: e.target.value ? Number(e.target.value) : undefined})}
                    placeholder="0.00"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveNewEmployee}>
              Adicionar Colaborador
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Upload Dialog */}
      <Dialog open={isDocumentDialogOpen} onOpenChange={setIsDocumentDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Documento</DialogTitle>
            <DialogDescription>
              {selectedEmployee && `Enviando documento para ${selectedEmployee.name}`}
            </DialogDescription>
          </DialogHeader>

          {selectedEmployee && (
            <DocumentUpload
              employeeId={selectedEmployee.id}
              onDocumentAdded={() => {
                setEmployees(IntegratedDataStore.getEmployees());
                setIsDocumentDialogOpen(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Export Dialog */}
      <Dialog open={isExportDialogOpen} onOpenChange={setIsExportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Download className="w-5 h-5 mr-2 text-purple-600" />
              Exportar Colaboradores
            </DialogTitle>
            <DialogDescription>
              Escolha o formato para exportar os dados dos colaboradores
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Formato de Exportação</Label>
              <div className="grid grid-cols-2 gap-4 mt-2">
                <Button
                  variant={exportFormat === 'excel' ? 'default' : 'outline'}
                  onClick={() => setExportFormat('excel')}
                  className="flex items-center justify-center p-4 h-auto"
                >
                  <FileSpreadsheet className="w-6 h-6 mr-2 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Excel / CSV</div>
                    <div className="text-xs text-gray-500">Planilha para edição</div>
                  </div>
                </Button>
                <Button
                  variant={exportFormat === 'pdf' ? 'default' : 'outline'}
                  onClick={() => setExportFormat('pdf')}
                  className="flex items-center justify-center p-4 h-auto"
                >
                  <FileText className="w-6 h-6 mr-2 text-red-600" />
                  <div className="text-left">
                    <div className="font-medium">PDF</div>
                    <div className="text-xs text-gray-500">Relatório para impressão</div>
                  </div>
                </Button>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium mb-1">Dados incluídos na exporta��ão:</p>
                  <ul className="text-left space-y-1">
                    <li>• Informações pessoais e de contato</li>
                    <li>• Cargo, departamento e status</li>
                    <li>• Data de admissão e salário (quando disponível)</li>
                    <li>• Total de {filteredEmployees.length} colaborador(es)</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsExportDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={() => handleExportData(exportFormat)}>
                <Download className="w-4 h-4 mr-2" />
                Exportar {exportFormat === 'excel' ? 'Excel' : 'PDF'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Leave Management Dialog */}
      <Dialog open={isLeaveDialogOpen} onOpenChange={setIsLeaveDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              <span>Gestão de Afastamentos</span>
            </DialogTitle>
            <DialogDescription>
              {selectedEmployee && `Gerencie afastamentos temporários para ${selectedEmployee.name}`}
            </DialogDescription>
          </DialogHeader>

          {selectedEmployee && (
            <LeaveManagement
              employee={selectedEmployee}
              onLeaveStatusChanged={() => {
                setEmployees(IntegratedDataStore.getEmployees());
                setIsLeaveDialogOpen(false);
                setSelectedEmployee(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Terminate Employee Dialog */}
      <Dialog open={isTerminateDialogOpen} onOpenChange={setIsTerminateDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span>Desligamento Definitivo</span>
            </DialogTitle>
            <DialogDescription>
              {selectedEmployee && `Registrar desligamento de ${selectedEmployee.name}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="termination-date">Data de Desligamento</Label>
              <Input
                id="termination-date"
                type="date"
                value={terminationForm.date}
                onChange={(e) => setTerminationForm(prev => ({ ...prev, date: e.target.value }))}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="termination-type">Tipo de Desligamento</Label>
              <Select
                value={terminationForm.type}
                onValueChange={(value) => setTerminationForm(prev => ({ ...prev, type: value }))}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecione o tipo de desligamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pedido_demissao">Pedido de Demissão</SelectItem>
                  <SelectItem value="aviso_indenizado">Aviso Indenizado</SelectItem>
                  <SelectItem value="aviso_trabalhado">Aviso Trabalhado</SelectItem>
                  <SelectItem value="prazo_determinado">Prazo Determinado</SelectItem>
                  <SelectItem value="justa_causa">Justa Causa</SelectItem>
                  <SelectItem value="sem_justa_causa">Sem Justa Causa</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="termination-reason">Observações/Motivo</Label>
              <Input
                id="termination-reason"
                placeholder="Descreva o motivo ou observações sobre o desligamento"
                value={terminationForm.reason}
                onChange={(e) => setTerminationForm(prev => ({ ...prev, reason: e.target.value }))}
                className="mt-1"
              />
            </div>

            <div className="bg-yellow-50 p-3 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5" />
                <div className="text-sm text-yellow-800">
                  <p className="font-medium">Atenção:</p>
                  <p>Esta ação irá marcar o colaborador como desligado permanentemente. Para afastamentos temporários, use "Gerenciar Afastamento".</p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => {
              setIsTerminateDialogOpen(false);
              setTerminationForm({ date: '', type: '', reason: '' });
            }}>
              Cancelar
            </Button>
            <Button
              onClick={handleTerminateEmployee}
              className="bg-red-600 hover:bg-red-700"
              disabled={!terminationForm.date || !terminationForm.type || !terminationForm.reason}
            >
              <AlertCircle className="w-4 h-4 mr-2" />
              Confirmar Desligamento
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Upload className="w-5 h-5 mr-2 text-purple-600" />
              Importar Colaboradores
            </DialogTitle>
            <DialogDescription>
              Importe colaboradores de outros sistemas via planilha CSV
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="import-file">Arquivo CSV</Label>
              <Input
                id="import-file"
                type="file"
                accept=".csv,.txt"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                className="mt-2"
              />
              <p className="text-xs text-gray-500 mt-1">
                Apenas arquivos CSV ou TXT são aceitos
              </p>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div className="text-sm text-yellow-800">
                  <p className="font-medium mb-1">Formato esperado do arquivo:</p>
                  <div className="text-xs font-mono bg-yellow-100 p-2 rounded mt-2">
                    Nome,Email,Telefone,Cargo,Departamento,Status,Data de Admissão,Salário<br />
                    João Silva,joao@empresa.com,(11)99999-9999,Analista,TI,Ativo,01/01/2024,5000
                  </div>
                  <ul className="text-left space-y-1 mt-2">
                    <li>• Status: Ativo, Inativo ou Afastado</li>
                    <li>• Data: formato DD/MM/AAAA</li>
                    <li>• Salário: apenas números (opcional)</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>
                Cancelar
              </Button>
              <Button
                onClick={handleImportData}
                disabled={!importFile}
              >
                <Upload className="w-4 h-4 mr-2" />
                Importar Dados
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
