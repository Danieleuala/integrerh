import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Job, JobApplication } from '@/lib/mockData';
import { DataAdapter } from '@/lib/dataAdapter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Briefcase, MapPin, DollarSign, Clock, Users, Star,
  CheckCircle, Send, Building2, Calendar, TestTube,
  FileText, User, Mail, Phone, Upload, ArrowRight
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface CandidateForm {
  name: string;
  email: string;
  phone: string;
  resume: string;
  coverLetter: string;
  experience: string;
}

export default function CandidateApply() {
  const { jobId } = useParams<{ jobId: string }>();
  const { toast } = useToast();

  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [candidateForm, setCandidateForm] = useState<CandidateForm>({
    name: '',
    email: '',
    phone: '',
    resume: '',
    coverLetter: '',
    experience: ''
  });

  useEffect(() => {
    const loadJob = async () => {
      if (jobId) {
        try {
          setLoading(true);
          setError(null);
          const foundJob = await DataAdapter.getJob(jobId);
          setJob(foundJob || null);

          if (!foundJob) {
            setError('Vaga não encontrada');
          }
        } catch (err) {
          console.error('Error loading job:', err);
          setError('Erro ao carregar vaga. Tente novamente mais tarde.');
        } finally {
          setLoading(false);
        }
      }
    };

    loadJob();
  }, [jobId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!job || !candidateForm.name || !candidateForm.email) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha pelo menos nome e email",
        variant: "destructive"
      });
      return;
    }

    setSubmitting(true);

    try {
      // Create application
      const application: Omit<JobApplication, 'id' | 'jobId'> = {
        candidateName: candidateForm.name,
        candidateEmail: candidateForm.email,
        phone: candidateForm.phone,
        status: 'pending',
        appliedDate: new Date().toISOString().split('T')[0],
        currentStage: 0,
        notes: `Carta de apresentação: ${candidateForm.coverLetter}\n\nExperiência: ${candidateForm.experience}`,
        stageHistory: [{
          stage: 'Aplicação Recebida',
          date: new Date().toISOString(),
          notes: 'Candidato aplicou para a vaga'
        }]
      };

      // Add application to job using DataAdapter
      const success = await DataAdapter.addApplicationToJob(jobId!, application);

      if (!success) {
        throw new Error('Erro ao enviar candidatura');
      }

      // Add candidate to talent bank automatically
      const talentProfile = {
        id: `talent_${Date.now()}`,
        name: form.name,
        email: form.email,
        phone: form.phone,
        location: 'Não informado',
        experience: 'A definir',
        skills: [],
        education: 'Não informado',
        summary: form.coverLetter || '',
        rating: 0,
        status: 'available' as const,
        availability: 'negotiable' as const,
        addedDate: new Date().toISOString(),
        documents: {
          cv: form.resume || undefined
        },
        source: 'job_application',
        appliedJobs: [jobId!]
      };

      // Save to talent bank (localStorage for now)
      const existingTalents = JSON.parse(localStorage.getItem('talentBank') || '[]');
      const existingTalent = existingTalents.find((t: any) => t.email === form.email);

      if (!existingTalent) {
        existingTalents.push(talentProfile);
        localStorage.setItem('talentBank', JSON.stringify(existingTalents));
      } else {
        // Update existing talent with new job application
        existingTalent.appliedJobs = [...(existingTalent.appliedJobs || []), jobId!];
        existingTalent.lastContact = new Date().toISOString();
        localStorage.setItem('talentBank', JSON.stringify(existingTalents));
      }

      setSubmitted(true);
      toast({
        title: "Candidatura enviada!",
        description: "Sua candidatura foi registrada com sucesso. Entraremos em contato em breve.",
      });

    } catch (error) {
      toast({
        title: "Erro ao enviar candidatura",
        description: "Ocorreu um erro. Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Briefcase className="w-12 h-12 mx-auto text-purple-600 mb-4 animate-pulse" />
          <p className="text-gray-600">Carregando vaga...</p>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Vaga não encontrada
            </h2>
            <p className="text-gray-600 mb-4">
              A vaga que você está tentando acessar não existe ou foi removida.
            </p>
            <Button onClick={() => window.location.href = '/'}>
              Ver Outras Vagas
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (job.status !== 'open') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Briefcase className="w-12 h-12 mx-auto text-orange-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Vaga não disponível
            </h2>
            <p className="text-gray-600 mb-4">
              Esta vaga não está mais recebendo candidaturas.
            </p>
            <Button onClick={() => window.location.href = '/'}>
              Ver Vagas Abertas
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 mx-auto text-green-600 mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Candidatura Enviada!
            </h2>
            <p className="text-gray-600 mb-6">
              Obrigado por se candidatar à vaga de <strong>{job.title}</strong>. 
              Nossa equipe analisará seu perfil e entrará em contato em breve.
            </p>
            <div className="space-y-2 text-sm text-gray-500">
              <p>✓ Candidatura registrada</p>
              <p>✓ Email de confirmação enviado</p>
              <p>✓ Processo seletivo iniciado</p>
            </div>
            <Button 
              onClick={() => window.location.href = '/'} 
              className="mt-6"
            >
              Ver Outras Vagas
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Briefcase className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Candidatar-se à Vaga
          </h1>
          <p className="text-gray-600">
            Integre RH - Sistema de Recrutamento
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Job Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">{job.title}</CardTitle>
              <CardDescription className="flex items-center space-x-4 text-base">
                <div className="flex items-center">
                  <Building2 className="w-4 h-4 mr-2" />
                  {job.department}
                </div>
                {job.salary && (
                  <div className="flex items-center">
                    <DollarSign className="w-4 h-4 mr-2" />
                    {job.salary}
                  </div>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Job Info */}
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Publicada em {format(new Date(job.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-2" />
                  {job.applications.length} candidatura(s)
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="font-semibold mb-2">Descrição da Vaga</h4>
                <p className="text-gray-700 whitespace-pre-wrap">{job.description}</p>
              </div>

              {/* Requirements */}
              {job.requirements.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Requisitos</h4>
                  <ul className="space-y-1">
                    {job.requirements.map((req, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Benefits */}
              {job.benefits.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Benefícios</h4>
                  <ul className="space-y-1">
                    {job.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start">
                        <Star className="w-4 h-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Process Stages */}
              <div>
                <h4 className="font-semibold mb-3">Processo Seletivo</h4>
                <div className="space-y-2">
                  {job.stages.map((stage, index) => (
                    <div key={stage.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-center w-8 h-8 bg-purple-100 text-purple-600 rounded-full text-sm font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{stage.name}</span>
                          {stage.hasTest && <TestTube className="w-4 h-4 text-blue-500" />}
                          {stage.isRequired && <Star className="w-4 h-4 text-orange-500" />}
                        </div>
                        {stage.description && (
                          <p className="text-sm text-gray-600 mt-1">{stage.description}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Application Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5" />
                <span>Formulário de Candidatura</span>
              </CardTitle>
              <CardDescription>
                Preencha seus dados para se candidatar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome Completo *</Label>
                  <Input
                    id="name"
                    value={candidateForm.name}
                    onChange={(e) => setCandidateForm(prev => ({
                      ...prev,
                      name: e.target.value
                    }))}
                    placeholder="Seu nome completo"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={candidateForm.email}
                    onChange={(e) => setCandidateForm(prev => ({
                      ...prev,
                      email: e.target.value
                    }))}
                    placeholder="seu.email@exemplo.com"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Telefone</Label>
                  <Input
                    id="phone"
                    value={candidateForm.phone}
                    onChange={(e) => setCandidateForm(prev => ({
                      ...prev,
                      phone: e.target.value
                    }))}
                    placeholder="(11) 99999-9999"
                  />
                </div>

                <div>
                  <Label htmlFor="experience">Experiência Relevante</Label>
                  <Textarea
                    id="experience"
                    value={candidateForm.experience}
                    onChange={(e) => setCandidateForm(prev => ({
                      ...prev,
                      experience: e.target.value
                    }))}
                    placeholder="Descreva sua experiência relacionada à vaga..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="resume">Currículo (URL ou texto)</Label>
                  <Textarea
                    id="resume"
                    value={candidateForm.resume}
                    onChange={(e) => setCandidateForm(prev => ({
                      ...prev,
                      resume: e.target.value
                    }))}
                    placeholder="Cole o link do seu currículo ou descreva seu histórico profissional..."
                    rows={4}
                  />
                </div>

                <div>
                  <Label htmlFor="coverLetter">Carta de Apresentação</Label>
                  <Textarea
                    id="coverLetter"
                    value={candidateForm.coverLetter}
                    onChange={(e) => setCandidateForm(prev => ({
                      ...prev,
                      coverLetter: e.target.value
                    }))}
                    placeholder="Por que você é o candidato ideal para esta vaga?"
                    rows={4}
                  />
                </div>

                <Separator />

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Próximos Passos:</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>✓ Análise do currículo pela equipe de RH</li>
                    <li>✓ Contato para agendamento de entrevista</li>
                    {job.stages.some(s => s.hasTest) && (
                      <li>✓ Realização de testes técnicos</li>
                    )}
                    <li>✓ Processo seletivo conforme etapas descritas</li>
                  </ul>
                </div>

                <Button 
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  size="lg"
                >
                  {submitting ? (
                    <>
                      <Clock className="w-5 h-5 mr-2 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Enviar Candidatura
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  Ao enviar sua candidatura, você concorda que seus dados sejam utilizados para este processo seletivo
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
