import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  ArrowLeft, QrCode, Copy, CheckCircle, Clock, 
  CreditCard, Smartphone, AlertCircle, Shield, Check
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PaymentState {
  plan: string;
  price: number;
  period: string;
  planId: string;
}

interface CompanyInfo {
  name: string;
  cnpj: string;
  email: string;
  phone: string;
}

export default function Pagamento() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const paymentData = location.state as PaymentState;
  
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'card'>('pix');
  const [pixCode, setPixCode] = useState('');
  const [qrCodeImage, setQrCodeImage] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'processing' | 'confirmed' | 'failed'>('pending');
  const [timeRemaining, setTimeRemaining] = useState(900); // 15 minutes
  
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo>({
    name: '',
    cnpj: '',
    email: '',
    phone: ''
  });

  useEffect(() => {
    if (!paymentData) {
      navigate('/planos');
      return;
    }
    
    // Generate PIX code (in a real app, this would come from a payment API)
    generatePixPayment();
  }, [paymentData, navigate]);

  useEffect(() => {
    // Countdown timer
    if (timeRemaining > 0 && paymentStatus === 'pending') {
      const timer = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [timeRemaining, paymentStatus]);

  const generatePixPayment = async () => {
    // Simulate PIX code generation
    // In production, this would integrate with a real payment API like Gerencianet, PagSeguro, etc.
    const mockPixCode = `00020126580014BR.GOV.BCB.PIX0136123e4567-e12b-12d1-a456-426614174000520400005303986540${paymentData.price.toFixed(2)}5802BR5925INTEGRE RH SOLUCOES LTDA6009SAO_PAULO62070503***6304`;
    
    setPixCode(mockPixCode);
    
    // Generate QR Code (in production, use a proper QR code library)
    const qrCodeData = `data:image/svg+xml;base64,${btoa(`
      <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="white"/>
        <text x="100" y="100" text-anchor="middle" font-size="12" fill="black">QR Code PIX</text>
        <text x="100" y="120" text-anchor="middle" font-size="10" fill="gray">R$ ${paymentData.price.toFixed(2)}</text>
      </svg>
    `)}`;
    setQrCodeImage(qrCodeData);
  };

  const copyPixCode = () => {
    navigator.clipboard.writeText(pixCode);
    toast({
      title: "Código copiado!",
      description: "O código PIX foi copiado para a área de transferência.",
    });
  };

  const simulatePaymentConfirmation = () => {
    setPaymentStatus('processing');
    
    // Simulate payment processing
    setTimeout(() => {
      setPaymentStatus('confirmed');
      toast({
        title: "Pagamento confirmado!",
        description: "Seu plano foi ativado com sucesso.",
      });
      
      // Redirect to success page after 3 seconds
      setTimeout(() => {
        navigate('/pagamento-sucesso', { 
          state: { 
            plan: paymentData.plan,
            company: companyInfo.name || 'Sua Empresa'
          } 
        });
      }, 3000);
    }, 3000);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  if (!paymentData) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/planos')}
            className="text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar aos planos
          </Button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column - Company Info */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informações da Empresa</CardTitle>
                <CardDescription>
                  Preencha os dados para ativação do plano
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="company-name">Nome da Empresa *</Label>
                  <Input
                    id="company-name"
                    value={companyInfo.name}
                    onChange={(e) => setCompanyInfo(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Sua Empresa Ltda"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="cnpj">CNPJ *</Label>
                  <Input
                    id="cnpj"
                    value={companyInfo.cnpj}
                    onChange={(e) => setCompanyInfo(prev => ({ ...prev, cnpj: e.target.value }))}
                    placeholder="00.000.000/0000-00"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="email">Email para Faturamento *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={companyInfo.email}
                    onChange={(e) => setCompanyInfo(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="financeiro@empresa.com"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="phone">Telefone de Contato *</Label>
                  <Input
                    id="phone"
                    value={companyInfo.phone}
                    onChange={(e) => setCompanyInfo(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="(11) 99999-9999"
                    required
                  />
                </div>
              </CardContent>
            </Card>

            {/* Plan Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Plano {paymentData.plan}</span>
                    <Badge>{paymentData.period}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Período:</span>
                    <span className="capitalize">{paymentData.period}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Total:</span>
                    <span>R$ {paymentData.price.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Payment */}
          <div className="space-y-6">
            {/* Payment Status */}
            {paymentStatus !== 'pending' && (
              <Alert className={
                paymentStatus === 'confirmed' ? 'border-green-300 bg-green-50' :
                paymentStatus === 'processing' ? 'border-yellow-300 bg-yellow-50' :
                'border-red-300 bg-red-50'
              }>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {paymentStatus === 'confirmed' && 'Pagamento confirmado! Redirecionando...'}
                  {paymentStatus === 'processing' && 'Processando pagamento...'}
                  {paymentStatus === 'failed' && 'Pagamento falhou. Tente novamente.'}
                </AlertDescription>
              </Alert>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <QrCode className="w-5 h-5 text-purple-600" />
                  <span>Pagamento via PIX</span>
                </CardTitle>
                <CardDescription>
                  Método rápido e seguro
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {paymentStatus === 'pending' && (
                  <div className="flex items-center justify-center space-x-2 text-orange-600">
                    <Clock className="w-4 h-4" />
                    <span className="font-medium">
                      Expira em {formatTime(timeRemaining)}
                    </span>
                  </div>
                )}

                {/* QR Code */}
                <div className="text-center">
                  <div className="inline-block p-4 bg-white rounded-lg shadow-sm border">
                    <img 
                      src={qrCodeImage} 
                      alt="QR Code PIX" 
                      className="w-48 h-48 mx-auto"
                    />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    Escaneie o QR Code com seu banco
                  </p>
                </div>

                <Separator />

                {/* PIX Code */}
                <div>
                  <Label className="text-base font-medium">Código PIX (Copia e Cola)</Label>
                  <div className="flex mt-2">
                    <Input
                      value={pixCode}
                      readOnly
                      className="rounded-r-none font-mono text-xs"
                    />
                    <Button
                      onClick={copyPixCode}
                      className="rounded-l-none"
                      variant="outline"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Cole este código no seu aplicativo bancário
                  </p>
                </div>

                {/* Instructions */}
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Como pagar:</h4>
                  <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                    <li>Abra o aplicativo do seu banco</li>
                    <li>Escolha a opção PIX</li>
                    <li>Escaneie o QR Code ou cole o código</li>
                    <li>Confirme o pagamento</li>
                  </ol>
                </div>

                {/* Security Info */}
                <div className="flex items-center space-x-2 text-green-600 text-sm">
                  <Shield className="w-4 h-4" />
                  <span>Pagamento 100% seguro e criptografado</span>
                </div>

                {/* Demo Button */}
                <div className="pt-4 border-t">
                  <p className="text-sm text-gray-600 mb-3">
                    Para demonstração, você pode simular o pagamento:
                  </p>
                  <Button 
                    onClick={simulatePaymentConfirmation}
                    disabled={paymentStatus !== 'pending'}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Simular Pagamento (Demo)
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Support */}
            <Card className="border-purple-200">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Precisa de ajuda?</h4>
                <p className="text-sm text-gray-600 mb-3">
                  Nossa equipe está disponível para auxiliar com seu pagamento
                </p>
                <Button 
                  variant="outline" 
                  className="w-full border-purple-300 text-purple-700"
                  onClick={() => {
                    const message = encodeURIComponent(`Olá! Estou com dificuldades no pagamento do plano ${paymentData.plan}. Podem me ajudar?`);
                    window.open(`https://wa.me/5587981389271?text=${message}`, '_blank');
                  }}
                >
                  <Smartphone className="w-4 h-4 mr-2" />
                  Falar no WhatsApp
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
