import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, ArrowLeft, Users, Heart } from "lucide-react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-10 h-10 bg-integre-gradient rounded-xl flex items-center justify-center shadow-lg">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                    Integre RH
                  </span>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <div className="mb-8">
            <h1 className="text-9xl font-bold text-purple-600 mb-4">404</h1>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Página não encontrada
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              A página que você está procurando não existe ou pode ter sido movida. 
              Verifique o endereço ou volte ao dashboard principal.
            </p>
          </div>

          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center justify-center">
                <Home className="w-5 h-5 mr-2" />
                Onde você gostaria de ir?
              </CardTitle>
              <CardDescription>
                Navegue para uma das principais seções da plataforma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Link to="/" className="block">
                <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                  <Home className="w-4 h-4 mr-2" />
                  Página Inicial
                </Button>
              </Link>
              <Link to="/login" className="block">
                <Button variant="outline" className="w-full border-purple-200 text-purple-600 hover:bg-purple-50">
                  <Users className="w-4 h-4 mr-2" />
                  Fazer Login
                </Button>
              </Link>
              <Link to="/register" className="block">
                <Button variant="outline" className="w-full border-purple-200 text-purple-600 hover:bg-purple-50">
                  Criar Conta
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
