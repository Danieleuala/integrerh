import { useState, useEffect, useMemo } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Job } from "@/lib/mockData";
import { DataAdapter } from "@/lib/dataAdapter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Briefcase,
  Search,
  MapPin,
  DollarSign,
  Calendar,
  Users,
  Building2,
  Clock,
  ExternalLink,
  Heart,
  ArrowLeft,
  Filter,
  CheckCircle,
  Star,
  Target,
  Zap,
  Eye,
  Globe,
  Mail,
  Phone,
  Share2,
  Copy,
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Company {
  id: string;
  name: string;
  trade_name?: string;
  email: string;
  phone?: string;
  website?: string;
  logo_url?: string;
  description?: string;
  industry?: string;
  city?: string;
  state?: string;
}

export default function CompanyJobs() {
  const { companySlug } = useParams<{ companySlug: string }>();
  const navigate = useNavigate();
  const [company, setCompany] = useState<Company | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  useEffect(() => {
    loadCompanyAndJobs();
  }, [companySlug]);

  const loadCompanyAndJobs = async () => {
    setLoading(true);
    setNotFound(false);
    
    try {
      // Mock company data - na implementação real, buscar pelo slug/id
      const mockCompany: Company = {
        id: '1',
        name: 'TechCorp Solutions',
        trade_name: 'TechCorp',
        email: 'carreiras@techcorp.com',
        phone: '(11) 99999-1111',
        website: 'https://techcorp.com',
        logo_url: 'https://images.unsplash.com/photo-1560472355-536de3962603?w=100&h=100&fit=crop&crop=center',
        description: 'Somos uma empresa líder em soluções tecnológicas, sempre em busca dos melhores talentos para compor nossa equipe. Oferecemos um ambiente inovador, desafios estimulantes e oportunidades reais de crescimento profissional.',
        industry: 'Tecnologia',
        city: 'São Paulo',
        state: 'SP'
      };

      // Mock jobs data - na implementação real, buscar vagas da empresa
      const mockJobs: Job[] = [
        {
          id: '1',
          title: 'Desenvolvedor Full Stack Sênior',
          department: 'Tecnologia',
          description: 'Buscamos um desenvolvedor experiente para atuar no desenvolvimento de aplicações web modernas utilizando React, Node.js e tecnologias cloud.',
          requirements: ['React', 'Node.js', 'TypeScript', 'AWS', '5+ anos de experiência'],
          benefits: ['Vale refeição R$ 35/dia', 'Plano de saúde completo', 'Home office flexível', 'Plano de carreira estruturado', 'Cursos e certificações'],
          salary: 'R$ 12.000 - R$ 18.000',
          type: 'full_time',
          status: 'open',
          created_date: '2024-01-15',
          applications_count: 45,
          company_id: '1'
        },
        {
          id: '2',
          title: 'Product Manager',
          department: 'Produto',
          description: 'Lidere o desenvolvimento de produtos digitais inovadores, trabalhando diretamente com equipes de engenharia, design e negócios.',
          requirements: ['Experiência em gestão de produto', 'Metodologias ágeis', 'Análise de dados', 'Visão estratégica'],
          benefits: ['Vale refeição R$ 35/dia', 'Plano de saúde completo', 'Participação nos lucros', 'Stock options'],
          salary: 'R$ 15.000 - R$ 22.000',
          type: 'full_time',
          status: 'open',
          created_date: '2024-01-20',
          applications_count: 23,
          company_id: '1'
        },
        {
          id: '3',
          title: 'UX/UI Designer',
          department: 'Design',
          description: 'Crie experiências digitais incríveis para nossos produtos, desde a pesquisa com usu��rios até a entrega final dos designs.',
          requirements: ['Figma', 'Design System', 'Pesquisa UX', 'Prototipagem', 'Portfolio sólido'],
          benefits: ['Vale refeição R$ 35/dia', 'Plano de saúde completo', 'Auxílio home office R$ 500', 'Cursos de design'],
          salary: 'R$ 8.000 - R$ 12.000',
          type: 'full_time',
          status: 'open',
          created_date: '2024-01-18',
          applications_count: 67,
          company_id: '1'
        }
      ];

      if (companySlug === 'techcorp') {
        setCompany(mockCompany);
        setJobs(mockJobs);
      } else {
        setNotFound(true);
      }
    } catch (error) {
      console.error('Erro ao carregar dados da empresa:', error);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.requirements.some(req => req.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesDepartment = departmentFilter === 'all' || job.department === departmentFilter;
      const matchesType = typeFilter === 'all' || job.type === typeFilter;
      
      return matchesSearch && matchesDepartment && matchesType;
    });
  }, [jobs, searchTerm, departmentFilter, typeFilter]);

  const departments = Array.from(new Set(jobs.map(job => job.department)));

  const getJobTypeBadge = (type: string) => {
    const types = {
      full_time: { label: 'Tempo Integral', color: 'bg-green-100 text-green-800' },
      part_time: { label: 'Meio Período', color: 'bg-blue-100 text-blue-800' },
      contract: { label: 'Contrato', color: 'bg-orange-100 text-orange-800' }
    };
    const config = types[type as keyof typeof types] || types.full_time;
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  const handleShareCompany = async () => {
    const currentUrl = window.location.href;
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 3000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = currentUrl;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 3000);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando oportunidades...</p>
          </div>
        </div>
      </div>
    );
  }

  if (notFound || !company) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center">
            <Building2 className="mx-auto h-24 w-24 text-gray-400 mb-6" />
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Empresa não encontrada</h1>
            <p className="text-xl text-gray-600 mb-8">
              A empresa que você está procurando não foi encontrada ou não possui vagas ativas no momento.
            </p>
            <div className="space-x-4">
              <Button onClick={() => navigate('/public-jobs')}>
                Ver Todas as Vagas
              </Button>
              <Button variant="outline" onClick={() => navigate('/')}>
                Voltar ao Início
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-6">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/public-jobs')}
              className="text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Ver Todas as Vagas
            </Button>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={handleShareCompany}
                className={copySuccess ? 'bg-green-50 border-green-300' : ''}
              >
                {copySuccess ? (
                  <>
                    <Copy className="w-4 h-4 mr-2 text-green-600" />
                    Link Copiado!
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartilhar Vagas
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={() => navigate('/')}>
                Área do Candidato
              </Button>
            </div>
          </div>

          {/* Company Info */}
          <div className="flex items-start space-x-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              {company.logo_url ? (
                <img src={company.logo_url} alt={company.name} className="w-16 h-16 rounded-lg object-cover" />
              ) : (
                <Building2 className="w-10 h-10 text-white" />
              )}
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {company.trade_name || company.name}
              </h1>
              {company.trade_name && company.name !== company.trade_name && (
                <p className="text-gray-600 mb-2">{company.name}</p>
              )}
              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                {company.industry && (
                  <Badge variant="outline">{company.industry}</Badge>
                )}
                {company.city && company.state && (
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {company.city}, {company.state}
                  </div>
                )}
                {company.website && (
                  <a 
                    href={company.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center hover:text-blue-600"
                  >
                    <Globe className="w-4 h-4 mr-1" />
                    Website
                  </a>
                )}
              </div>
              {company.description && (
                <p className="text-gray-700 leading-relaxed max-w-4xl">
                  {company.description}
                </p>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por cargo, tecnologia ou palavra-chave..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-48 bg-white">
                  <SelectValue placeholder="Departamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Departamentos</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-48 bg-white">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Tipos</SelectItem>
                  <SelectItem value="full_time">Tempo Integral</SelectItem>
                  <SelectItem value="part_time">Meio Período</SelectItem>
                  <SelectItem value="contract">Contrato</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Jobs Grid */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">
              Oportunidades Disponíveis
            </h2>
            <p className="text-gray-600">
              {filteredJobs.length} vaga{filteredJobs.length !== 1 ? 's' : ''} encontrada{filteredJobs.length !== 1 ? 's' : ''}
            </p>
          </div>

          {filteredJobs.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Briefcase className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Nenhuma vaga encontrada
                </h3>
                <p className="text-gray-600 mb-6">
                  Não encontramos vagas que correspondam aos seus critérios de busca.
                </p>
                <Button onClick={() => {
                  setSearchTerm('');
                  setDepartmentFilter('all');
                  setTypeFilter('all');
                }}>
                  Limpar Filtros
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredJobs.map((job) => (
                <Card key={job.id} className="hover:shadow-lg transition-shadow duration-300 bg-white">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2 text-gray-900">
                          {job.title}
                        </CardTitle>
                        <div className="flex flex-wrap items-center gap-2 mb-3">
                          <Badge variant="outline">{job.department}</Badge>
                          {getJobTypeBadge(job.type)}
                        </div>
                      </div>
                    </div>
                    
                    <CardDescription className="text-gray-700 leading-relaxed">
                      {job.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    {/* Requirements */}
                    {job.requirements && job.requirements.length > 0 && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                          <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                          Requisitos
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {job.requirements.slice(0, 4).map((req, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {req}
                            </Badge>
                          ))}
                          {job.requirements.length > 4 && (
                            <Badge variant="secondary" className="text-xs">
                              +{job.requirements.length - 4} mais
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Benefits */}
                    {job.benefits && job.benefits.length > 0 && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                          <Star className="w-4 h-4 mr-2 text-yellow-600" />
                          Benefícios
                        </h4>
                        <div className="text-sm text-gray-600">
                          {job.benefits.slice(0, 3).map((benefit, index) => (
                            <div key={index} className="flex items-center mb-1">
                              <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mr-2"></div>
                              {benefit}
                            </div>
                          ))}
                          {job.benefits.length > 3 && (
                            <div className="text-xs text-gray-500 mt-1">
                              +{job.benefits.length - 3} benefícios adicionais
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Job Info */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      {job.salary && (
                        <div className="flex items-center text-gray-600">
                          <DollarSign className="w-4 h-4 mr-2 text-green-600" />
                          <span className="font-medium">{job.salary}</span>
                        </div>
                      )}
                      <div className="flex items-center text-gray-600">
                        <Calendar className="w-4 h-4 mr-2 text-blue-600" />
                        <span>
                          {format(new Date(job.created_date), 'dd/MM/yyyy', { locale: ptBR })}
                        </span>
                      </div>
                      {job.applications_count !== undefined && (
                        <div className="flex items-center text-gray-600">
                          <Users className="w-4 h-4 mr-2 text-purple-600" />
                          <span>{job.applications_count} candidatos</span>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        asChild 
                        className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        <Link to={`/candidate-apply/${job.id}`}>
                          Candidatar-se
                        </Link>
                      </Button>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Contact Section */}
        <Card className="mt-12 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Não encontrou a vaga ideal?
            </h3>
            <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
              Envie seu currículo para nós! Estamos sempre em busca de talentos excepcionais 
              e entraremos em contato quando surgir uma oportunidade que combine com seu perfil.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild>
                <a href={`mailto:${company.email}?subject=Candidatura Espontânea`}>
                  <Mail className="w-4 h-4 mr-2" />
                  Enviar Currículo
                </a>
              </Button>
              {company.phone && (
                <Button variant="outline" asChild>
                  <a href={`tel:${company.phone}`}>
                    <Phone className="w-4 h-4 mr-2" />
                    Entrar em Contato
                  </a>
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
