import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import {
  Building2, User, Mail, Phone, MapPin, CreditCard, Copy,
  CheckCircle, AlertCircle, Crown, Shield, Heart, MessageCircle
} from 'lucide-react';

interface ClientRegistration {
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  cnpj: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  employeesCount: string;
  selectedPlan: 'basic' | 'professional' | 'enterprise';
  message?: string;
}

export default function ClientRegister() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const planFromUrl = searchParams.get('plan') as 'basic' | 'professional' | 'enterprise' || 'basic';

  const [formData, setFormData] = useState<ClientRegistration>({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    cnpj: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    employeesCount: '',
    selectedPlan: planFromUrl,
    message: ''
  });
  
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [pixCopied, setPixCopied] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const plans = {
    basic: {
      name: 'Básico',
      price: 29,
      features: ['Gestão de colaboradores', 'Controle de documentos', 'Relatórios básicos', 'Suporte por email'],
      maxEmployees: 50,
      color: 'blue'
    },
    professional: {
      name: 'Profissional',
      price: 79,
      features: ['Tudo do plano Básico', 'Recrutamento e seleção', 'Avaliações de performance', 'Treinamentos online', 'Suporte prioritário'],
      maxEmployees: 200,
      color: 'purple'
    },
    enterprise: {
      name: 'Enterprise',
      price: 0,
      features: ['Consulta gratuita', 'Análise personalizada', 'Atendimento especializado'],
      maxEmployees: 'Ilimitado',
      color: 'green',
      isConsultation: true
    }
  };

  const pixKey = '08178831422';
  const whatsappNumber = '5587981389271';

  const handleInputChange = (field: keyof ClientRegistration, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateForm = () => {
    const required = ['companyName', 'contactName', 'email', 'phone', 'cnpj', 'address', 'city', 'state'];
    return required.every(field => formData[field as keyof ClientRegistration].trim() !== '');
  };

  const formatCNPJ = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 10) {
      return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    } else {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      alert('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    if (formData.selectedPlan === 'enterprise') {
      // Redirect to WhatsApp for Enterprise plan (consultation)
      const message = `Olá! Gostaria de uma consulta sobre o plano Enterprise do Integre RH.

*Dados da Empresa:*
• Empresa: ${formData.companyName}
• Contato: ${formData.contactName}
• Email: ${formData.email}
• Telefone: ${formData.phone}
• CNPJ: ${formData.cnpj}
• Funcionários: ${formData.employeesCount}

${formData.message ? `*Mensagem:* ${formData.message}` : ''}

Aguardo retorno para agendarmos uma reunião!`;

      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
      return;
    }

    setIsLoading(true);
    
    try {
      // Simulate saving to database
      const clientData = {
        ...formData,
        id: `client_${Date.now()}`,
        createdAt: new Date().toISOString(),
        status: 'pending_payment',
        planPrice: plans[formData.selectedPlan].price
      };

      // Save to localStorage (in production, this would be an API call)
      const existingClients = JSON.parse(localStorage.getItem('registeredClients') || '[]');
      existingClients.push(clientData);
      localStorage.setItem('registeredClients', JSON.stringify(existingClients));

      setIsPaymentDialogOpen(true);
    } catch (error) {
      alert('Erro ao processar cadastro. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const copyPixKey = async () => {
    try {
      await navigator.clipboard.writeText(pixKey);
      setPixCopied(true);
      setTimeout(() => setPixCopied(false), 3000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = pixKey;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setPixCopied(true);
      setTimeout(() => setPixCopied(false), 3000);
    }
  };

  const selectedPlan = plans[formData.selectedPlan];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                    Integre RH
                  </span>
                  <p className="text-xs text-gray-500 -mt-1">Conectando gestão e performance</p>
                </div>
              </div>
            </div>
            <Button variant="ghost" onClick={() => navigate('/')}>
              Voltar
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Cadastro de Cliente
          </h1>
          <p className="text-gray-600">
            Preencha os dados para contratar o plano {selectedPlan.name}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building2 className="w-5 h-5 mr-2 text-purple-600" />
                  Dados da Empresa
                </CardTitle>
                <CardDescription>
                  Informações básicas da sua empresa
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="companyName">Nome da Empresa *</Label>
                    <Input
                      id="companyName"
                      value={formData.companyName}
                      onChange={(e) => handleInputChange('companyName', e.target.value)}
                      placeholder="Ex: Tech Solutions Ltda"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cnpj">CNPJ *</Label>
                    <Input
                      id="cnpj"
                      value={formData.cnpj}
                      onChange={(e) => handleInputChange('cnpj', formatCNPJ(e.target.value))}
                      placeholder="00.000.000/0000-00"
                      maxLength={18}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="contactName">Nome do Responsável *</Label>
                    <Input
                      id="contactName"
                      value={formData.contactName}
                      onChange={(e) => handleInputChange('contactName', e.target.value)}
                      placeholder="Ex: João Silva"
                    />
                  </div>
                  <div>
                    <Label htmlFor="employeesCount">Número de Funcionários</Label>
                    <Select onValueChange={(value) => handleInputChange('employeesCount', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1-10">1 a 10 funcionários</SelectItem>
                        <SelectItem value="11-50">11 a 50 funcionários</SelectItem>
                        <SelectItem value="51-100">51 a 100 funcionários</SelectItem>
                        <SelectItem value="101-200">101 a 200 funcionários</SelectItem>
                        <SelectItem value="201+">Mais de 200 funcionários</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="contato@empresa.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Telefone *</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', formatPhone(e.target.value))}
                      placeholder="(11) 99999-9999"
                      maxLength={15}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address">Endereço Completo *</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    placeholder="Rua, número, bairro"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="city">Cidade *</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      placeholder="São Paulo"
                    />
                  </div>
                  <div>
                    <Label htmlFor="state">Estado *</Label>
                    <Select onValueChange={(value) => handleInputChange('state', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="UF" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="AC">Acre</SelectItem>
                        <SelectItem value="AL">Alagoas</SelectItem>
                        <SelectItem value="AP">Amapá</SelectItem>
                        <SelectItem value="AM">Amazonas</SelectItem>
                        <SelectItem value="BA">Bahia</SelectItem>
                        <SelectItem value="CE">Ceará</SelectItem>
                        <SelectItem value="DF">Distrito Federal</SelectItem>
                        <SelectItem value="ES">Espírito Santo</SelectItem>
                        <SelectItem value="GO">Goiás</SelectItem>
                        <SelectItem value="MA">Maranhão</SelectItem>
                        <SelectItem value="MT">Mato Grosso</SelectItem>
                        <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                        <SelectItem value="MG">Minas Gerais</SelectItem>
                        <SelectItem value="PA">Pará</SelectItem>
                        <SelectItem value="PB">Paraíba</SelectItem>
                        <SelectItem value="PR">Paraná</SelectItem>
                        <SelectItem value="PE">Pernambuco</SelectItem>
                        <SelectItem value="PI">Piauí</SelectItem>
                        <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                        <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                        <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                        <SelectItem value="RO">Rondônia</SelectItem>
                        <SelectItem value="RR">Roraima</SelectItem>
                        <SelectItem value="SC">Santa Catarina</SelectItem>
                        <SelectItem value="SP">São Paulo</SelectItem>
                        <SelectItem value="SE">Sergipe</SelectItem>
                        <SelectItem value="TO">Tocantins</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="zipCode">CEP</Label>
                    <Input
                      id="zipCode"
                      value={formData.zipCode}
                      onChange={(e) => handleInputChange('zipCode', e.target.value.replace(/\D/g, '').replace(/(\d{5})(\d{3})/, '$1-$2'))}
                      placeholder="00000-000"
                      maxLength={9}
                    />
                  </div>
                </div>

                {formData.selectedPlan === 'enterprise' && (
                  <div>
                    <Label htmlFor="message">Mensagem (Opcional)</Label>
                    <Textarea
                      id="message"
                      value={formData.message || ''}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      placeholder="Conte-nos mais sobre suas necessidades..."
                      rows={3}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Plan Summary */}
          <div>
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Plano Selecionado</span>
                  {selectedPlan.color === 'purple' && (
                    <Badge className="bg-purple-600 text-white">
                      <Crown className="w-3 h-3 mr-1" />
                      Popular
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    selectedPlan.color === 'blue' ? 'bg-blue-100' :
                    selectedPlan.color === 'purple' ? 'bg-purple-100' : 'bg-green-100'
                  }`}>
                    {selectedPlan.color === 'blue' && <Building2 className="w-8 h-8 text-blue-600" />}
                    {selectedPlan.color === 'purple' && <Crown className="w-8 h-8 text-purple-600" />}
                    {selectedPlan.color === 'green' && <Shield className="w-8 h-8 text-green-600" />}
                  </div>
                  <h3 className="text-xl font-bold">{selectedPlan.name}</h3>
                  <div className="mt-2">
                    {selectedPlan.isConsultation ? (
                      <div>
                        <span className="text-2xl font-bold text-green-600">Consulta Gratuita</span>
                        <p className="text-sm text-gray-500">Atendimento especializado</p>
                      </div>
                    ) : (
                      <div>
                        <span className="text-3xl font-bold">R$ {selectedPlan.price}</span>
                        <span className="text-gray-500">/mês</span>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Inclui:</h4>
                  <ul className="space-y-2 text-sm">
                    {selectedPlan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between text-sm">
                    <span>Funcionários:</span>
                    <span className="font-semibold">Até {selectedPlan.maxEmployees}</span>
                  </div>
                </div>

                <Button 
                  className="w-full" 
                  onClick={handleSubmit}
                  disabled={isLoading}
                >
                  {isLoading ? 'Processando...' : 
                   selectedPlan.isConsultation ? 'Solicitar Consulta' : 'Finalizar Cadastro'}
                  {selectedPlan.isConsultation && <MessageCircle className="w-4 h-4 ml-2" />}
                </Button>

                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => navigate('/')}
                >
                  Escolher Outro Plano
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CreditCard className="w-5 h-5 mr-2 text-green-600" />
              Pagamento via PIX
            </DialogTitle>
            <DialogDescription>
              Realize o pagamento para ativar sua conta
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Cadastro realizado com sucesso! Realize o pagamento via PIX para ativar sua conta.
              </AlertDescription>
            </Alert>

            <div className="text-center">
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h3 className="font-semibold mb-2">Valor a Pagar</h3>
                <div className="text-3xl font-bold text-green-600">
                  R$ {selectedPlan.price},00
                </div>
                <p className="text-sm text-gray-500">Plano {selectedPlan.name} - Mensal</p>
              </div>

              <div className="bg-blue-50 rounded-lg p-4">
                <h4 className="font-semibold mb-2">Chave PIX</h4>
                <div className="flex items-center justify-center space-x-2">
                  <code className="bg-white px-3 py-2 rounded border text-lg font-mono">
                    {pixKey}
                  </code>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={copyPixKey}
                    className={pixCopied ? 'bg-green-100 border-green-300' : ''}
                  >
                    {pixCopied ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-1 text-green-600" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-1" />
                        Copiar
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Após o pagamento, enviaremos o login e senha por email em até 24 horas.
              </AlertDescription>
            </Alert>

            <div className="text-center">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  setIsPaymentDialogOpen(false);
                  navigate('/');
                }}
              >
                Voltar ao Início
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
