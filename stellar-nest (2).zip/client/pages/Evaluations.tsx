import { useState, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore, Evaluation, Employee } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Slider } from '@/components/ui/slider';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  Award, Plus, Search, Eye, Edit, MoreHorizontal,
  Users, Clock, Calendar, Target, TrendingUp,
  CheckCircle, XCircle, AlertCircle, Star, Download,
  BarChart3, User, UserCheck, LinkIcon, Phone, Mail, MessageSquare
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

export default function Evaluations() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [evaluations, setEvaluations] = useState(IntegratedDataStore.getEvaluations());
  const [employees] = useState(IntegratedDataStore.getEmployees());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedEvaluation, setSelectedEvaluation] = useState<Evaluation | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [evaluationForm, setEvaluationForm] = useState<Partial<Evaluation>>({});
  const [customCompetencies, setCustomCompetencies] = useState<string[]>([]);
  const [newCompetency, setNewCompetency] = useState('');
  const [evaluationProgress, setEvaluationProgress] = useState(0);
  const [isCompetencyDialogOpen, setIsCompetencyDialogOpen] = useState(false);

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canView = hasPermission(user?.role || 'employee', ['rh_admin', 'manager', 'employee']);

  // Default competencies
  const defaultCompetencies = [
    'Comunicação', 'Trabalho em Equipe', 'Liderança', 'Proatividade',
    'Conhecimento Técnico', 'Resoluç��o de Problemas', 'Criatividade',
    'Adaptabilidade', 'Orientação a Resultados', 'Gestão de Tempo'
  ];

  // All available competencies (default + custom)
  const allCompetencies = [...defaultCompetencies, ...customCompetencies];

  // Add custom competency
  const handleAddCompetency = () => {
    if (newCompetency.trim() && !allCompetencies.includes(newCompetency.trim())) {
      setCustomCompetencies([...customCompetencies, newCompetency.trim()]);
      setNewCompetency('');
    }
  };

  // Calculate evaluation progress based on filled competencies
  const calculateProgress = (competencies: any[]) => {
    const totalFields = competencies.length + 2; // +2 for feedback and overall assessment
    const filledFields = competencies.filter(comp => comp.score > 0).length +
                        (evaluationForm.feedback ? 1 : 0) +
                        (evaluationForm.overallScore ? 1 : 0);
    return Math.round((filledFields / totalFields) * 100);
  };

  const filteredEvaluations = useMemo(() => {
    return evaluations.filter(evaluation => {
      const employee = employees.find(emp => emp.id === evaluation.employeeId);
      const evaluator = employees.find(emp => emp.id === evaluation.evaluatorId);
      
      const matchesSearch = employee?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           evaluator?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           evaluation.period.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || evaluation.status === statusFilter;
      const matchesType = typeFilter === 'all' || evaluation.type === typeFilter;
      
      return matchesSearch && matchesStatus && matchesType;
    });
  }, [evaluations, employees, searchTerm, statusFilter, typeFilter]);

  const getStatusBadge = (status: Evaluation['status']) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="border-yellow-200 text-yellow-700">Pendente</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-700">Concluída</Badge>;
      case 'approved':
        return <Badge className="bg-blue-100 text-blue-700">Aprovada</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getTypeBadge = (type: Evaluation['type']) => {
    switch (type) {
      case '360':
        return <Badge variant="outline" className="border-purple-200 text-purple-700">360°</Badge>;
      case 'self':
        return <Badge variant="outline" className="border-blue-200 text-blue-700">Autoavaliação</Badge>;
      case 'manager':
        return <Badge variant="outline" className="border-green-200 text-green-700">Gestor</Badge>;
      default:
        return <Badge variant="secondary">Outros</Badge>;
    }
  };

  const getScoreColor = (score: number, maxScore: number) => {
    const percentage = (score / maxScore) * 100;
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const handleViewEvaluation = (evaluation: Evaluation) => {
    setSelectedEvaluation(evaluation);
    setIsViewDialogOpen(true);
  };

  const handleCreateEvaluation = () => {
    setEvaluationForm({
      employeeId: '',
      evaluatorId: user?.id || '',
      type: 'manager',
      period: new Date().getFullYear().toString(),
      competencies: [
        { name: 'Comunicação', score: 5, maxScore: 10 },
        { name: 'Trabalho em Equipe', score: 5, maxScore: 10 },
        { name: 'Proatividade', score: 5, maxScore: 10 },
        { name: 'Conhecimento Técnico', score: 5, maxScore: 10 },
        { name: 'Liderança', score: 5, maxScore: 10 }
      ],
      overallScore: 5.0,
      feedback: '',
      date: new Date().toISOString(),
      status: 'pending'
    });
    setIsCreateDialogOpen(true);
  };

  const handleSaveEvaluation = () => {
    if (evaluationForm.employeeId && evaluationForm.competencies && evaluationForm.type && evaluationForm.period) {
      // Calculate overall score
      const totalScore = evaluationForm.competencies.reduce((acc, comp) => acc + comp.score, 0);
      const maxTotalScore = evaluationForm.competencies.reduce((acc, comp) => acc + comp.maxScore, 0);
      const overallScore = (totalScore / maxTotalScore) * 10;

      const newEvaluation = IntegratedDataStore.addEvaluation({
        ...evaluationForm,
        overallScore: Number(overallScore.toFixed(1))
      } as Omit<Evaluation, 'id'>);

      setEvaluations(IntegratedDataStore.getEvaluations());
      setIsCreateDialogOpen(false);
      setEvaluationForm({});

      // Show success message
      alert('Avaliação criada com sucesso!');
    } else {
      alert('Por favor, preencha todos os campos obrigatórios.');
    }
  };

  const generateEvaluationLink = async (evaluation: Evaluation, evaluatorType: string = 'peer') => {
    const employee = employees.find(emp => emp.id === evaluation.employeeId);
    if (!employee) return;

    const linkId = `eval_link_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 14); // 14 days from now

    const evaluationLink = {
      id: linkId,
      evaluationId: evaluation.id,
      employeeId: evaluation.employeeId,
      employeeName: employee.name,
      position: employee.position,
      department: employee.department,
      evaluatorId: '',
      evaluatorName: '',
      evaluatorRole: evaluatorType,
      type: evaluation.type,
      period: evaluation.period,
      dueDate: dueDate.toISOString(),
      competencies: evaluation.competencies.map(comp => ({
        name: comp.name,
        description: getCompetencyDescription(comp.name),
        maxScore: comp.maxScore,
        weight: 1
      })),
      instructions: getEvaluationInstructions(evaluation.type),
      isCompleted: false,
      createdDate: new Date().toISOString(),
      responses: []
    };

    // Save evaluation link
    const savedLinks = localStorage.getItem('evaluationLinks');
    const links = savedLinks ? JSON.parse(savedLinks) : [];
    links.push(evaluationLink);
    localStorage.setItem('evaluationLinks', JSON.stringify(links));

    // Generate the public URL
    const publicUrl = `${window.location.origin}/evaluation/${linkId}`;

    // Copy to clipboard with enhanced fallback
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(publicUrl);
      } else {
        // Enhanced fallback method
        const textArea = document.createElement('textarea');
        textArea.value = publicUrl;
        textArea.style.position = 'absolute';
        textArea.style.left = '-9999px';
        textArea.style.top = '0';
        textArea.setAttribute('readonly', '');
        document.body.appendChild(textArea);
        textArea.select();
        textArea.setSelectionRange(0, 99999);
        const successful = document.execCommand('copy');
        document.body.removeChild(textArea);

        if (!successful) {
          throw new Error('Fallback copy failed');
        }
      }

      // Simple success message
      toast({
        title: "✅ Link copiado!",
        description: "Link de avaliação copiado com sucesso!",
      });
    } catch (err) {
      console.error('Failed to copy evaluation link:', err);

      // Show link for manual copy
      toast({
        title: "⚠️ Copie manualmente",
        description: publicUrl,
        variant: "destructive"
      });

      // Fallback prompt
      if (window.prompt) {
        window.prompt('Copie o link de avaliação:', publicUrl);
      }
    }

    return publicUrl;
  };

  const getCompetencyDescription = (competencyName: string): string => {
    const descriptions: Record<string, string> = {
      'Comunicação': 'Capacidade de se expressar claramente e ouvir ativamente',
      'Trabalho em Equipe': 'Colaboração efetiva e construtiva com colegas',
      'Liderança': 'Inspirar e guiar outros para alcançar objetivos comuns',
      'Proatividade': 'Iniciativa e antecipação às necessidades do trabalho',
      'Conhecimento Técnico': 'Domínio das competências técnicas necessárias para a função',
      'Resolução de Problemas': 'Identificar e solucionar problemas de forma eficaz',
      'Criatividade': 'Capacidade de gerar ideias inovadoras e soluções originais',
      'Adaptabilidade': 'Flexibilidade para se ajustar a mudanças e novos desafios',
      'Orientação a Resultados': 'Foco em alcançar e superar metas estabelecidas',
      'Gestão de Tempo': 'Organização e priorização eficiente das atividades'
    };
    return descriptions[competencyName] || 'Competência importante para o desempenho profissional';
  };

  const getEvaluationInstructions = (type: string): string => {
    switch (type) {
      case '360':
        return 'Esta é uma avaliação 360°. Considere todas as interações que teve com o colaborador durante o período avaliado. Seja objetivo e construtivo em seus comentários.';
      case 'self':
        return 'Esta é uma autoavaliação. Reflita honestamente sobre seu desempenho durante o período. Considere seus pontos fortes e áreas de melhoria.';
      case 'manager':
        return 'Como gestor, avalie o desempenho do colaborador considerando metas, comportamentos e contribuições para a equipe.';
      default:
        return 'Avalie o desempenho do colaborador de forma justa e construtiva, baseando-se em observações concretas durante o período.';
    }
  };

  const shareEvaluationLink = (evaluation: Evaluation, method: 'whatsapp' | 'email') => {
    const employee = employees.find(emp => emp.id === evaluation.employeeId);
    if (!employee) return;

    const publicUrl = generateEvaluationLink(evaluation);

    if (method === 'whatsapp') {
      const message = `🎯 *Avaliação de Desempenho*\n\nVocê foi convidado(a) para avaliar:\n👤 *${employee.name}*\n🏢 ${employee.position} - ${employee.department}\n📅 Período: ${evaluation.period}\n\n📝 Acesse: ${publicUrl}\n\n⏰ Prazo: 14 dias\n\nSua participação é muito importante! 🙏`;
      window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
    } else if (method === 'email') {
      const subject = `Convite para Avaliação de Desempenho - ${employee.name}`;
      const body = `Prezado(a),

Você foi convidado(a) para participar da avaliação de desempenho de ${employee.name} (${employee.position} - ${employee.department}).

📋 Período de Avaliação: ${evaluation.period}
🎯 Tipo: ${evaluation.type === '360' ? 'Avaliação 360°' : evaluation.type === 'self' ? 'Autoavaliação' : 'Avaliação de Gestor'}

Para acessar a avaliação, clique no link abaixo:
${publicUrl}

⏰ Prazo para conclusão: 14 dias a partir de hoje

Instruç��es:
- A avaliação leva aproximadamente 10-15 minutos
- Seja objetivo e construtivo em seus comentários
- Todas as respostas são confidenciais

Sua participação é fundamental para o desenvolvimento profissional do colaborador.

Atenciosamente,
Equipe Integre RH`;

      window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
    }
  };

  const handleExportEvaluations = () => {
    const dataStr = JSON.stringify(filteredEvaluations, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `avaliacoes_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const updateCompetencyScore = (index: number, score: number) => {
    if (evaluationForm.competencies) {
      const updatedCompetencies = [...evaluationForm.competencies];
      updatedCompetencies[index] = { ...updatedCompetencies[index], score };
      setEvaluationForm({ ...evaluationForm, competencies: updatedCompetencies });
    }
  };

  const stats = useMemo(() => {
    const userEvaluations = user?.role === 'employee'
      ? evaluations.filter(evaluation => evaluation.employeeId === user.id)
      : evaluations;
      
    return {
      total: userEvaluations.length,
      pending: userEvaluations.filter(evaluation => evaluation.status === 'pending').length,
      completed: userEvaluations.filter(evaluation => evaluation.status === 'completed').length,
      approved: userEvaluations.filter(evaluation => evaluation.status === 'approved').length,
      avgScore: userEvaluations.length > 0 
        ? (userEvaluations.reduce((acc, evaluation) => acc + evaluation.overallScore, 0) / userEvaluations.length).toFixed(1)
        : '0.0'
    };
  }, [evaluations, user]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Award className="w-8 h-8 mr-3 text-purple-600" />
            Avaliações de Performance
          </h1>
          <p className="text-gray-600 mt-1">
            Sistema completo de avalia��ão 360° e feedback contínuo
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={handleExportEvaluations}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          {canCreate && (
            <Button onClick={handleCreateEvaluation} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Nova Avaliação
            </Button>
          )}
        </div>
      </div>

      {/* Personal Score Card for Employees */}
      {user?.role === 'employee' && (
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="w-5 h-5 mr-2" />
              Minha Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-purple-600">{stats.avgScore}</div>
                <p className="text-sm text-gray-600">Pontuação Média</p>
                <p className="text-xs text-gray-500">de 10.0 pontos</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
                <p className="text-sm text-gray-600">Avaliações</p>
                <p className="text-xs text-gray-500">Realizadas</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{stats.completed}</div>
                <p className="text-sm text-gray-600">Concluídas</p>
                <p className="text-xs text-gray-500">Este período</p>
              </div>
              <div className="text-center">
                <div className="relative">
                  <Progress 
                    value={(stats.completed / (stats.total || 1)) * 100} 
                    className="h-3 mb-2"
                  />
                  <div className="text-lg font-bold text-orange-600">
                    {Math.round((stats.completed / (stats.total || 1)) * 100)}%
                  </div>
                </div>
                <p className="text-sm text-gray-600">Taxa de Conclusão</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Award className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pendentes</p>
                <p className="text-3xl font-bold text-yellow-600">{stats.pending}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Concluídas</p>
                <p className="text-3xl font-bold text-green-600">{stats.completed}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Média Geral</p>
                <p className="text-3xl font-bold text-purple-600">{stats.avgScore}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por colaborador, período..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pending">Pendentes</SelectItem>
                  <SelectItem value="completed">Concluídas</SelectItem>
                  <SelectItem value="approved">Aprovadas</SelectItem>
                </SelectContent>
              </Select>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Tipos</SelectItem>
                  <SelectItem value="360">Avaliação 360°</SelectItem>
                  <SelectItem value="self">Autoavaliação</SelectItem>
                  <SelectItem value="manager">Avaliação Gestor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredEvaluations.length} de {evaluations.length} avaliação(ões)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Evaluations Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Avaliações</CardTitle>
          <CardDescription>
            Acompanhe o progresso das avaliações de performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Colaborador</TableHead>
                <TableHead>Avaliador</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Período</TableHead>
                <TableHead>Pontuação</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEvaluations.map((evaluation) => {
                const employee = employees.find(emp => emp.id === evaluation.employeeId);
                const evaluator = employees.find(emp => emp.id === evaluation.evaluatorId);
                
                return (
                  <TableRow key={evaluation.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={employee?.avatar} alt={employee?.name} />
                          <AvatarFallback className="bg-purple-100 text-purple-600">
                            {employee?.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-gray-900">{employee?.name}</p>
                          <p className="text-sm text-gray-500">{employee?.position}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <p className="font-medium">{evaluator?.name}</p>
                      <p className="text-sm text-gray-500">{evaluator?.position}</p>
                    </TableCell>
                    <TableCell>
                      {getTypeBadge(evaluation.type)}
                    </TableCell>
                    <TableCell>
                      <p className="font-medium">{evaluation.period}</p>
                      <p className="text-sm text-gray-500">
                        {format(new Date(evaluation.date), 'dd/MM/yyyy', { locale: ptBR })}
                      </p>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <span className={`text-lg font-bold ${getScoreColor(evaluation.overallScore, 10)}`}>
                          {evaluation.overallScore.toFixed(1)}
                        </span>
                        <span className="text-sm text-gray-500">/10</span>
                      </div>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-3 h-3 ${i < Math.round(evaluation.overallScore / 2) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(evaluation.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {canView && (
                            <DropdownMenuItem onClick={() => handleViewEvaluation(evaluation)}>
                              <Eye className="w-4 h-4 mr-2" />
                              Visualizar Resultados
                            </DropdownMenuItem>
                          )}
                          {canEdit && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => generateEvaluationLink(evaluation, 'peer')}>
                                <LinkIcon className="w-4 h-4 mr-2" />
                                Gerar Link de Avaliação
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => shareEvaluationLink(evaluation, 'whatsapp')}>
                                <Phone className="w-4 h-4 mr-2" />
                                Compartilhar via WhatsApp
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => shareEvaluationLink(evaluation, 'email')}>
                                <Mail className="w-4 h-4 mr-2" />
                                Enviar por Email
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Editar Avaliação
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="w-4 h-4 mr-2" />
                                Exportar PDF
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>

          {filteredEvaluations.length === 0 && (
            <div className="text-center py-12">
              <Award className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma avaliação encontrada
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== 'all' || typeFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Comece criando as primeiras avaliações de performance'
                }
              </p>
              {canCreate && (searchTerm === '' && statusFilter === 'all' && typeFilter === 'all') && (
                <Button onClick={handleCreateEvaluation}>
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeira Avaliação
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Evaluation Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Avaliação de Performance</DialogTitle>
            <DialogDescription>
              {selectedEvaluation && (
                <>
                  {employees.find(emp => emp.id === selectedEvaluation.employeeId)?.name} - {selectedEvaluation.period}
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          
          {selectedEvaluation && (
            <div className="space-y-6">
              {/* Header with badges and overall score */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {getTypeBadge(selectedEvaluation.type)}
                  {getStatusBadge(selectedEvaluation.status)}
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-purple-600">
                    {selectedEvaluation.overallScore.toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-600">de 10.0 pontos</div>
                  <div className="flex justify-center mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${i < Math.round(selectedEvaluation.overallScore / 2) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Summary cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {selectedEvaluation.competencies.length}
                    </div>
                    <div className="text-sm text-gray-600">Competências</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {selectedEvaluation.competencies.filter(c => (c.score / c.maxScore) >= 0.8).length}
                    </div>
                    <div className="text-sm text-gray-600">Excelentes</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-yellow-600">
                      {selectedEvaluation.competencies.filter(c => (c.score / c.maxScore) >= 0.6 && (c.score / c.maxScore) < 0.8).length}
                    </div>
                    <div className="text-sm text-gray-600">Adequadas</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {selectedEvaluation.competencies.filter(c => (c.score / c.maxScore) < 0.6).length}
                    </div>
                    <div className="text-sm text-gray-600">A Melhorar</div>
                  </CardContent>
                </Card>
              </div>

              {/* Competencies detail */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center">
                  <Target className="w-5 h-5 mr-2" />
                  Competências Avaliadas
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedEvaluation.competencies.map((competency, index) => {
                    const percentage = (competency.score / competency.maxScore) * 100;
                    const level = percentage >= 80 ? 'excellent' : percentage >= 60 ? 'good' : 'needs_improvement';

                    return (
                      <Card key={index} className="p-4">
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{competency.name}</span>
                            <div className="flex items-center space-x-2">
                              <span className={`text-lg font-bold ${
                                level === 'excellent' ? 'text-green-600' :
                                level === 'good' ? 'text-yellow-600' : 'text-red-600'
                              }`}>
                                {competency.score}/{competency.maxScore}
                              </span>
                              <Badge variant="outline" className={
                                level === 'excellent' ? 'border-green-200 text-green-700' :
                                level === 'good' ? 'border-yellow-200 text-yellow-700' : 'border-red-200 text-red-700'
                              }>
                                {level === 'excellent' ? 'Excelente' :
                                 level === 'good' ? 'Adequado' : 'Melhorar'}
                              </Badge>
                            </div>
                          </div>
                          <Progress
                            value={percentage}
                            className="h-3"
                          />
                          <div className="text-xs text-gray-600">
                            {percentage.toFixed(1)}% de aproveitamento
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>

              {/* Employee and evaluation info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <User className="w-5 h-5 mr-2" />
                      Informações do Colaborador
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Nome:</span>
                      <span className="font-medium">{employees.find(emp => emp.id === selectedEvaluation.employeeId)?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Cargo:</span>
                      <span>{employees.find(emp => emp.id === selectedEvaluation.employeeId)?.position}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Departamento:</span>
                      <span>{employees.find(emp => emp.id === selectedEvaluation.employeeId)?.department}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Calendar className="w-5 h-5 mr-2" />
                      Detalhes da Avaliação
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Avaliador:</span>
                      <span className="font-medium">{employees.find(emp => emp.id === selectedEvaluation.evaluatorId)?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Data:</span>
                      <span>{format(new Date(selectedEvaluation.date), 'dd/MM/yyyy', { locale: ptBR })}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Período:</span>
                      <span>{selectedEvaluation.period}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tipo:</span>
                      <span>{selectedEvaluation.type === '360' ? 'Avaliação 360°' :
                             selectedEvaluation.type === 'self' ? 'Autoavaliação' :
                             'Avaliação de Gestor'}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Feedback section */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <MessageSquare className="w-5 h-5 mr-2" />
                    Feedback e Comentários
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg border border-purple-200">
                    <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                      {selectedEvaluation.feedback || 'Nenhum comentário adicional foi fornecido.'}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Action buttons */}
              <div className="flex justify-between pt-4 border-t">
                <div className="space-x-3">
                  <Button variant="outline" onClick={() => generateEvaluationLink(selectedEvaluation, 'peer')}>
                    <LinkIcon className="w-4 h-4 mr-2" />
                    Gerar Link
                  </Button>
                  <Button variant="outline" onClick={() => shareEvaluationLink(selectedEvaluation, 'whatsapp')}>
                    <Phone className="w-4 h-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>
                <Button onClick={() => setIsViewDialogOpen(false)}>
                  Fechar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Evaluation Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Nova Avaliação de Performance</DialogTitle>
            <DialogDescription>
              Crie uma nova avaliação para um colaborador
            </DialogDescription>
          </DialogHeader>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progresso da Avaliação</span>
              <span>{evaluationProgress}% completo</span>
            </div>
            <Progress value={evaluationProgress} className="h-2" />
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="eval-employee">Colaborador</Label>
                <Select 
                  value={evaluationForm.employeeId || ''} 
                  onValueChange={(value) => setEvaluationForm({...evaluationForm, employeeId: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o colaborador" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map(employee => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} - {employee.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="eval-type">Tipo de Avaliação</Label>
                <Select 
                  value={evaluationForm.type || ''} 
                  onValueChange={(value) => setEvaluationForm({...evaluationForm, type: value as Evaluation['type']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manager">Avaliação do Gestor</SelectItem>
                    <SelectItem value="self">Autoavaliação</SelectItem>
                    <SelectItem value="360">Avaliação 360°</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="eval-period">Período</Label>
              <Input
                id="eval-period"
                value={evaluationForm.period || ''}
                onChange={(e) => setEvaluationForm({...evaluationForm, period: e.target.value})}
                placeholder="Ex: 2024 - Q1"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-semibold">Competências</h4>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsCompetencyDialogOpen(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Gerenciar Competências
                </Button>
              </div>

              {!evaluationForm.competencies || evaluationForm.competencies.length === 0 ? (
                <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                  <Target className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Nenhuma competência selecionada
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Clique em "Gerenciar Competências" para adicionar competências à avaliação
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => setIsCompetencyDialogOpen(true)}
                  >
                    Adicionar Competências
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {evaluationForm.competencies.map((competency, index) => (
                    <div key={index} className="space-y-2 p-4 border rounded-lg bg-gray-50">
                      <div className="flex justify-between items-center">
                        <Label className="font-medium">{competency.name}</Label>
                        <span className="text-sm text-gray-600 bg-white px-2 py-1 rounded">
                          {competency.score}/{competency.maxScore}
                        </span>
                      </div>
                      <Slider
                        value={[competency.score]}
                        onValueChange={(value) => {
                          const updatedCompetencies = [...(evaluationForm.competencies || [])];
                          updatedCompetencies[index].score = value[0];
                          setEvaluationForm({...evaluationForm, competencies: updatedCompetencies});
                          setEvaluationProgress(calculateProgress(updatedCompetencies));
                        }}
                        max={competency.maxScore}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Insatisfatório</span>
                        <span>Excelente</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="eval-feedback">Feedback e Comentários</Label>
              <Textarea
                id="eval-feedback"
                value={evaluationForm.feedback || ''}
                onChange={(e) => setEvaluationForm({...evaluationForm, feedback: e.target.value})}
                placeholder="Escreva seu feedback detalhado sobre a performance do colaborador..."
                rows={6}
              />
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSaveEvaluation}>
                Salvar Avaliação
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Competencies Management Dialog */}
      <Dialog open={isCompetencyDialogOpen} onOpenChange={setIsCompetencyDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Gerenciar Competências</DialogTitle>
            <DialogDescription>
              Selecione ou adicione competências para esta avaliação
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Add New Competency */}
            <div className="space-y-2">
              <Label>Criar Nova Competência</Label>
              <div className="flex space-x-2">
                <Input
                  placeholder="Nome da competência..."
                  value={newCompetency}
                  onChange={(e) => setNewCompetency(e.target.value)}
                />
                <Button onClick={handleAddCompetency}>
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar
                </Button>
              </div>
            </div>

            {/* Available Competencies */}
            <div className="space-y-3">
              <Label>Competências Disponíveis</Label>
              <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                {allCompetencies.map((competency, index) => {
                  const isSelected = evaluationForm.competencies?.some(c => c.name === competency);
                  return (
                    <div
                      key={index}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-purple-100 border-purple-300 text-purple-700'
                          : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                      }`}
                      onClick={() => {
                        const currentCompetencies = evaluationForm.competencies || [];
                        if (isSelected) {
                          // Remove competency
                          const filtered = currentCompetencies.filter(c => c.name !== competency);
                          setEvaluationForm({...evaluationForm, competencies: filtered});
                        } else {
                          // Add competency
                          const newComp = {
                            name: competency,
                            score: 0,
                            maxScore: 10
                          };
                          setEvaluationForm({
                            ...evaluationForm,
                            competencies: [...currentCompetencies, newComp]
                          });
                        }
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{competency}</span>
                        {isSelected && <CheckCircle className="w-4 h-4" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Selected Count */}
            <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
              <span className="font-medium">
                {evaluationForm.competencies?.length || 0} competência(s) selecionada(s)
              </span>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsCompetencyDialogOpen(false)}>
                Fechar
              </Button>
              <Button onClick={() => {
                setIsCompetencyDialogOpen(false);
                setEvaluationProgress(calculateProgress(evaluationForm.competencies || []));
              }}>
                Aplicar Seleção
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
