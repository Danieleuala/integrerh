import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Heart, Mail, ArrowLeft, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { PasswordRecoveryService } from '@/lib/passwordRecoveryService';

export default function PasswordRecovery() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email) {
      setError('Por favor, digite seu e-mail');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Por favor, digite um e-mail válido');
      return;
    }

    setIsLoading(true);

    try {
      const result = await PasswordRecoveryService.sendRecoveryEmail(email);
      
      if (result.success) {
        setSuccess(true);
      } else {
        setError(result.message);
      }
    } catch (error) {
      setError('Erro inesperado. Tente novamente em alguns minutos.');
      console.error('Password recovery error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const contactInfo = PasswordRecoveryService.getContactInfo();

  if (success) {
    return (
      <div className="min-h-screen bg-integre-gradient flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Heart className="w-10 h-10 text-purple-600" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Integre RH</h1>
            <p className="text-white/80">Conectando gestão e performance</p>
          </div>

          {/* Success Card */}
          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                E-mail Enviado!
              </h2>
              
              <p className="text-gray-600 mb-6">
                Enviamos um link de recuperação para <strong>{email}</strong>. 
                Verifique sua caixa de entrada e pasta de spam.
              </p>

              <div className="bg-blue-50 p-4 rounded-lg mb-6">
                <div className="flex items-start space-x-3">
                  <Mail className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium mb-1">Não recebeu o e-mail?</p>
                    <ul className="text-left space-y-1">
                      <li>• Verifique a pasta de spam ou lixo eletrônico</li>
                      <li>• O link expira em 1 hora</li>
                      <li>• Você pode solicitar um novo link a qualquer momento</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Button 
                  onClick={() => {
                    setSuccess(false);
                    setEmail('');
                  }}
                  variant="outline" 
                  className="w-full"
                >
                  Enviar Novo Link
                </Button>
                
                <Link to="/login">
                  <Button variant="ghost" className="w-full">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Voltar ao Login
                  </Button>
                </Link>
              </div>

              <div className="mt-6 pt-6 border-t">
                <p className="text-sm text-gray-600 mb-2">Precisa de ajuda?</p>
                <div className="text-sm text-gray-500 space-y-1">
                  <p>📞 {contactInfo.phone}</p>
                  <p>📧 {contactInfo.email}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-integre-gradient flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Heart className="w-10 h-10 text-purple-600" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Integre RH</h1>
          <p className="text-white/80">Conectando gestão e performance</p>
        </div>

        {/* Recovery Card */}
        <Card className="border-0 shadow-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-gray-900">Recuperar Senha</CardTitle>
            <CardDescription>
              Digite seu e-mail para receber um link de recuperação
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-gray-700">
                  E-mail cadastrado
                </label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu.email@empresa.com"
                  className="h-11"
                  disabled={isLoading}
                />
                <p className="text-xs text-gray-500">
                  Digite o e-mail que você usa para acessar a plataforma
                </p>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4 mr-2" />
                    Enviar Link de Recuperação
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-medium mb-1">Importante:</p>
                    <ul className="space-y-1">
                      <li>• O link de recuperação expira em 1 hora</li>
                      <li>• Verifique sua pasta de spam</li>
                      <li>• Apenas o último link enviado será válido</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 text-center">
              <Link 
                to="/login" 
                className="text-sm text-purple-600 hover:text-purple-500 font-medium inline-flex items-center"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Voltar ao Login
              </Link>
            </div>

            <div className="mt-6 pt-6 border-t text-center">
              <p className="text-sm text-gray-600 mb-2">Precisa de ajuda?</p>
              <div className="text-sm text-gray-500 space-y-1">
                <p>📞 {contactInfo.phone}</p>
                <p>📧 {contactInfo.email}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <p className="text-white/60 text-sm">
            © 2024 Integre RH. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </div>
  );
}
