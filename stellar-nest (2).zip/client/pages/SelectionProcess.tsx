import { useState, useEffect, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore, Job, JobApplication } from '@/lib/mockData';
import { EnhancedDataStore, EnhancedJob, EnhancedJobApplication } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  UserCheck, Plus, Search, Filter, MoreHorizontal, Eye, Edit,
  ArrowRight, ArrowLeft, CheckCircle, XCircle, AlertTriangle,
  Clock, Calendar, Phone, Video, FileText, MessageSquare,
  Target, Users, Briefcase, Star, ThumbsUp, ThumbsDown,
  Save, Send, Bell, GitBranch, TrendingUp, Award
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface SelectionStage {
  id: string;
  name: string;
  description: string;
  order: number;
  estimatedDays: number;
  color: string;
}

interface StageAction {
  id: string;
  applicationId: string;
  fromStage: string;
  toStage: string;
  notes?: string;
  evaluator: string;
  date: string;
  rating?: number;
}

export default function SelectionProcess() {
  const { user } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [selectedApplication, setSelectedApplication] = useState<JobApplication | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [jobFilter, setJobFilter] = useState<string>('all');
  const [isActionDialogOpen, setIsActionDialogOpen] = useState(false);
  const [isNotesDialogOpen, setIsNotesDialogOpen] = useState(false);
  const [actionType, setActionType] = useState<'advance' | 'reject' | 'approve'>('advance');
  const [actionNotes, setActionNotes] = useState('');
  const [actionRating, setActionRating] = useState<number>(0);
  const [view, setView] = useState<'board' | 'list'>('board');

  // Get selection stages from localStorage (configured in Settings)
  const [selectionStages, setSelectionStages] = useState<SelectionStage[]>([]);

  const canManage = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);

  useEffect(() => {
    const loadJobs = () => {
      // Load all open jobs (including those without applications yet)
      const allJobs = IntegratedDataStore.getJobs().filter(job => job.status === 'open');
      setJobs(allJobs);
    };

    loadJobs();

    // Auto-refresh every 5 seconds to catch new jobs
    const interval = setInterval(loadJobs, 5000);

    return () => clearInterval(interval);

    // Load selection stages from Settings
    const savedStages = localStorage.getItem('integrerh_selection_stages');
    if (savedStages) {
      setSelectionStages(JSON.parse(savedStages));
    } else {
      // Default stages if none configured
      setSelectionStages([
        { id: 'application', name: 'Aplicação', description: 'Candidato aplicou', order: 0, estimatedDays: 1, color: 'bg-gray-100' },
        { id: 'screening', name: 'Triagem', description: 'Análise de currículo', order: 1, estimatedDays: 2, color: 'bg-blue-100' },
        { id: 'phone_interview', name: 'Entrevista Telefônica', description: 'Primeira conversa', order: 2, estimatedDays: 3, color: 'bg-yellow-100' },
        { id: 'technical_test', name: 'Teste Técnico', description: 'Avaliação técnica', order: 3, estimatedDays: 5, color: 'bg-purple-100' },
        { id: 'final_interview', name: 'Entrevista Final', description: 'Última etapa', order: 4, estimatedDays: 3, color: 'bg-orange-100' },
        { id: 'approved', name: 'Aprovado', description: 'Candidato aprovado', order: 5, estimatedDays: 1, color: 'bg-green-100' },
        { id: 'rejected', name: 'Rejeitado', description: 'Candidato rejeitado', order: 6, estimatedDays: 1, color: 'bg-red-100' }
      ]);
    }
  }, []);

  // Get all applications across all jobs
  const allApplications = useMemo(() => {
    return jobs.flatMap(job => 
      job.applications.map(app => ({
        ...app,
        jobTitle: job.title,
        jobDepartment: job.department
      }))
    );
  }, [jobs]);

  // Filter applications
  const filteredApplications = useMemo(() => {
    return allApplications.filter(app => {
      const matchesSearch = app.candidateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           app.candidateEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStage = stageFilter === 'all' || app.status === stageFilter;
      const matchesJob = jobFilter === 'all' || app.jobId === jobFilter;
      return matchesSearch && matchesStage && matchesJob;
    });
  }, [allApplications, searchTerm, stageFilter, jobFilter]);

  // Group applications by stage for board view
  const applicationsByStage = useMemo(() => {
    const grouped: Record<string, typeof filteredApplications> = {};
    selectionStages.forEach(stage => {
      grouped[stage.id] = filteredApplications.filter(app => {
        // Map status to stage IDs
        let mappedStatus = app.status;
        if (app.status === 'pending') mappedStatus = 'application';
        if (app.status === 'interviewing') mappedStatus = 'phone_interview';

        return mappedStatus === stage.id;
      });
    });
    return grouped;
  }, [filteredApplications, selectionStages]);

  // Statistics
  const stats = useMemo(() => {
    const total = allApplications.length;
    const inProcess = allApplications.filter(app => !['approved', 'rejected'].includes(app.status)).length;
    const approved = allApplications.filter(app => app.status === 'approved').length;
    const rejected = allApplications.filter(app => app.status === 'rejected').length;
    const openJobs = jobs.filter(job => job.applications.length === 0).length;
    const avgTimeInProcess = 5; // Simplified calculation

    return { total, inProcess, approved, rejected, openJobs, avgTimeInProcess };
  }, [allApplications, jobs]);

  const getStageInfo = (stageId: string) => {
    return selectionStages.find(stage => stage.id === stageId) || selectionStages[0];
  };

  const getStatusColor = (status: string) => {
    const stage = getStageInfo(status);
    return stage.color;
  };

  const handleMoveToStage = (application: JobApplication, targetStage: string, notes?: string, rating?: number) => {
    // Update application status
    const updatedJobs = jobs.map(job => ({
      ...job,
      applications: job.applications.map(app => {
        if (app.id === application.id) {
          const newStageHistory = [...(app.stageHistory || [])];
          newStageHistory.push({
            stage: getStageInfo(targetStage).name,
            date: new Date().toISOString(),
            notes: notes || '',
            evaluator: user?.name || 'Sistema'
          });

          return {
            ...app,
            status: targetStage as JobApplication['status'],
            currentStage: getStageInfo(targetStage).order,
            stageHistory: newStageHistory,
            notes: notes ? `${app.notes || ''}\n${notes}` : app.notes
          };
        }
        return app;
      })
    }));

    setJobs(updatedJobs);
    
    // Save to mock data store
    updatedJobs.forEach(job => {
      IntegratedDataStore.updateJob(job.id, job);
    });

    setIsActionDialogOpen(false);
    setActionNotes('');
    setActionRating(0);
  };

  const handleAdvanceStage = (application: JobApplication) => {
    const currentStage = getStageInfo(application.status);
    const nextStage = selectionStages.find(stage => stage.order === currentStage.order + 1);
    
    if (nextStage && nextStage.id !== 'rejected') {
      setSelectedApplication(application);
      setActionType('advance');
      setIsActionDialogOpen(true);
    }
  };

  const handleRejectApplication = (application: JobApplication) => {
    setSelectedApplication(application);
    setActionType('reject');
    setIsActionDialogOpen(true);
  };

  const handleApproveApplication = (application: JobApplication) => {
    setSelectedApplication(application);
    setActionType('approve');
    setIsActionDialogOpen(true);
  };

  const executeAction = () => {
    if (!selectedApplication) return;

    let targetStage = '';
    switch (actionType) {
      case 'advance':
        const currentStage = getStageInfo(selectedApplication.status);
        const nextStage = selectionStages.find(stage => stage.order === currentStage.order + 1);
        targetStage = nextStage?.id || 'approved';
        break;
      case 'approve':
        targetStage = 'approved';
        break;
      case 'reject':
        targetStage = 'rejected';
        break;
    }

    handleMoveToStage(selectedApplication, targetStage, actionNotes, actionRating);
  };

  // Drag and Drop handlers
  const handleDragStart = (e: React.DragEvent, application: any) => {
    e.dataTransfer.setData('application', JSON.stringify(application));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetStageId: string) => {
    e.preventDefault();
    const applicationData = e.dataTransfer.getData('application');
    if (applicationData) {
      const application = JSON.parse(applicationData);
      if (application.status !== targetStageId) {
        handleMoveToStage(application, targetStageId, `Movido via drag-and-drop para ${getStageInfo(targetStageId).name}`);
      }
    }
  };

  const getActionTitle = () => {
    switch (actionType) {
      case 'advance': return 'Avançar para Próxima Etapa';
      case 'approve': return 'Aprovar Candidato';
      case 'reject': return 'Rejeitar Candidato';
      default: return 'Ação';
    }
  };

  if (!canManage) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <UserCheck className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Acesso Restrito
          </h3>
          <p className="text-gray-600">
            Você não tem permissão para acessar o processo seletivo
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <GitBranch className="w-8 h-8 mr-3 text-purple-600" />
            Processo Seletivo
          </h1>
          <p className="text-gray-600 mt-1">
            Gerencie e acompanhe candidatos através das fases de seleção
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Select value={view} onValueChange={setView}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="board">Kanban</SelectItem>
              <SelectItem value="list">Lista</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Candidatos</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Users className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vagas Abertas</p>
                <p className="text-3xl font-bold text-gray-900">{stats.openJobs}</p>
              </div>
              <Briefcase className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Em Processo</p>
                <p className="text-3xl font-bold text-gray-900">{stats.inProcess}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Aprovados</p>
                <p className="text-3xl font-bold text-gray-900">{stats.approved}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Rejeitados</p>
                <p className="text-3xl font-bold text-gray-900">{stats.rejected}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search">Buscar Candidatos</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  id="search"
                  placeholder="Nome, email ou vaga..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="stage-filter">Filtrar por Etapa</Label>
              <Select value={stageFilter} onValueChange={setStageFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as etapas</SelectItem>
                  {selectionStages.map(stage => (
                    <SelectItem key={stage.id} value={stage.id}>{stage.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="job-filter">Filtrar por Vaga</Label>
              <Select value={jobFilter} onValueChange={setJobFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as vagas</SelectItem>
                  {jobs.map(job => (
                    <SelectItem key={job.id} value={job.id}>{job.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button variant="outline" onClick={() => {
                setSearchTerm('');
                setStageFilter('all');
                setJobFilter('all');
              }}>
                <Filter className="w-4 h-4 mr-2" />
                Limpar Filtros
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vagas em Aberto sem Candidatos */}
      {jobs.filter(job => job.applications.length === 0).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Briefcase className="w-5 h-5 mr-2" />
              Vagas em Aberto Aguardando Candidatos
            </CardTitle>
            <CardDescription>
              {jobs.filter(job => job.applications.length === 0).length} vaga(s) publicada(s) aguardando candidaturas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {jobs
                .filter(job => job.applications.length === 0)
                .map(job => (
                <Card key={job.id} className="p-4 border-dashed border-2 border-blue-200 bg-blue-50">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-blue-900">{job.title}</h4>
                      <Badge variant="outline" className="border-blue-300 text-blue-700">
                        {job.department}
                      </Badge>
                    </div>
                    <p className="text-sm text-blue-700">
                      Publicada em {format(new Date(job.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                    </p>
                    <p className="text-xs text-blue-600">
                      Aguardando primeiras candidaturas para iniciar processo seletivo
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-2 border-blue-300 text-blue-700"
                      onClick={() => {
                        // Redirect to Enhanced Jobs with kanban for this job
                        window.location.href = `/enhanced-jobs?openKanban=${job.id}`;
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Ver Detalhes da Vaga
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Content */}
      {view === 'board' ? (
        /* Kanban Board View */
        <div className="grid grid-cols-1 lg:grid-cols-7 gap-4 overflow-x-auto">
          {selectionStages.map(stage => (
            <div key={stage.id} className="min-w-80">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className={`w-3 h-3 ${stage.color} rounded-full`}></div>
                    <Badge variant="outline">
                      {applicationsByStage[stage.id]?.length || 0}
                    </Badge>
                  </div>
                  <CardTitle className="text-sm">{stage.name}</CardTitle>
                </CardHeader>
                <CardContent
                  className="space-y-3 min-h-[200px]"
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, stage.id)}
                >
                  {applicationsByStage[stage.id]?.map(application => (
                    <Card
                      key={application.id}
                      className={`p-3 hover:shadow-md transition-shadow cursor-move border-l-4 ${getStageInfo(application.status).color}`}
                      draggable
                      onDragStart={(e) => handleDragStart(e, application)}
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-sm">{application.candidateName}</h4>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleAdvanceStage(application)}>
                                <ArrowRight className="w-4 h-4 mr-2" />
                                Avançar Etapa
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {
                                setSelectedApplication(application);
                                setIsNotesDialogOpen(true);
                              }}>
                                <MessageSquare className="w-4 h-4 mr-2" />
                                Ver Histórico
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handleApproveApplication(application)} className="text-green-600">
                                <CheckCircle className="w-4 h-4 mr-2" />
                                Aprovar
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleRejectApplication(application)} className="text-red-600">
                                <XCircle className="w-4 h-4 mr-2" />
                                Rejeitar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        <p className="text-xs text-gray-600">{application.jobTitle}</p>
                        <p className="text-xs text-gray-500">{application.candidateEmail}</p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{format(new Date(application.appliedDate), 'dd/MM', { locale: ptBR })}</span>
                          {application.stageHistory && application.stageHistory.length > 1 && (
                            <span>{application.stageHistory.length - 1} movimentos</span>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                  
                  {(!applicationsByStage[stage.id] || applicationsByStage[stage.id].length === 0) && (
                    <div className="text-center py-8 text-gray-400">
                      <Target className="w-8 h-8 mx-auto mb-2" />
                      <p className="text-sm">Nenhum candidato</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Candidato</TableHead>
                  <TableHead>Vaga</TableHead>
                  <TableHead>Etapa Atual</TableHead>
                  <TableHead>Data Aplicação</TableHead>
                  <TableHead>Progresso</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApplications.map(application => {
                  const currentStage = getStageInfo(application.status);
                  const progress = ((currentStage.order + 1) / selectionStages.length) * 100;
                  
                  return (
                    <TableRow key={application.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{application.candidateName}</p>
                          <p className="text-sm text-gray-600">{application.candidateEmail}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{application.jobTitle}</p>
                          <p className="text-sm text-gray-600">{application.jobDepartment}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${getStatusColor(application.status)} text-gray-800`}>
                          {currentStage.name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {format(new Date(application.appliedDate), 'dd/MM/yyyy', { locale: ptBR })}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <Progress value={progress} className="h-2" />
                          <p className="text-xs text-gray-600">{Math.round(progress)}% concluído</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleAdvanceStage(application)}>
                              <ArrowRight className="w-4 h-4 mr-2" />
                              Avançar Etapa
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => {
                              setSelectedApplication(application);
                              setIsNotesDialogOpen(true);
                            }}>
                              <MessageSquare className="w-4 h-4 mr-2" />
                              Ver Histórico
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleApproveApplication(application)} className="text-green-600">
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Aprovar
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleRejectApplication(application)} className="text-red-600">
                              <XCircle className="w-4 h-4 mr-2" />
                              Rejeitar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            
            {filteredApplications.length === 0 && (
              <div className="text-center py-12">
                <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Nenhum candidato encontrado
                </h3>
                <p className="text-gray-600">
                  Ajuste os filtros ou aguarde novas candidaturas
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Action Dialog */}
      <Dialog open={isActionDialogOpen} onOpenChange={setIsActionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{getActionTitle()}</DialogTitle>
            <DialogDescription>
              {selectedApplication && `Candidato: ${selectedApplication.candidateName}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="action-notes">Observações</Label>
              <Textarea
                id="action-notes"
                value={actionNotes}
                onChange={(e) => setActionNotes(e.target.value)}
                placeholder="Adicione observações sobre esta ação..."
                rows={3}
              />
            </div>

            {actionType === 'advance' && (
              <div>
                <Label htmlFor="rating">Avaliação (opcional)</Label>
                <Select value={actionRating.toString()} onValueChange={(value) => setActionRating(Number(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma avaliação" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Sem avaliação</SelectItem>
                    <SelectItem value="1">⭐ Insatisfatório</SelectItem>
                    <SelectItem value="2">⭐⭐ Regular</SelectItem>
                    <SelectItem value="3">⭐⭐⭐ Bom</SelectItem>
                    <SelectItem value="4">⭐⭐⭐⭐ Muito Bom</SelectItem>
                    <SelectItem value="5">⭐⭐⭐⭐⭐ Excelente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsActionDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={executeAction}>
                <Save className="w-4 h-4 mr-2" />
                Confirmar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Notes/History Dialog */}
      <Dialog open={isNotesDialogOpen} onOpenChange={setIsNotesDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Histórico do Candidato</DialogTitle>
            <DialogDescription>
              {selectedApplication && `${selectedApplication.candidateName} - ${selectedApplication.jobTitle}`}
            </DialogDescription>
          </DialogHeader>

          {selectedApplication && (
            <div className="space-y-4">
              {/* Current Status */}
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Status Atual</h4>
                    <Badge className={`${getStatusColor(selectedApplication.status)} text-gray-800 mt-1`}>
                      {getStageInfo(selectedApplication.status).name}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Aplicou em</p>
                    <p className="font-medium">
                      {format(new Date(selectedApplication.appliedDate), 'dd/MM/yyyy', { locale: ptBR })}
                    </p>
                  </div>
                </div>
              </Card>

              {/* Stage History */}
              <div className="space-y-3">
                <h4 className="font-medium">Histórico de Etapas</h4>
                {selectedApplication.stageHistory && selectedApplication.stageHistory.length > 0 ? (
                  <div className="space-y-3">
                    {selectedApplication.stageHistory.map((entry, index) => (
                      <Card key={index} className="p-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <h5 className="font-medium">{entry.stage}</h5>
                              <Badge variant="outline" className="text-xs">
                                {format(new Date(entry.date), 'dd/MM HH:mm', { locale: ptBR })}
                              </Badge>
                            </div>
                            {entry.evaluator && (
                              <p className="text-sm text-gray-600">Por: {entry.evaluator}</p>
                            )}
                            {entry.notes && (
                              <p className="text-sm text-gray-700 mt-2">{entry.notes}</p>
                            )}
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600">Nenhum histórico disponível</p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
