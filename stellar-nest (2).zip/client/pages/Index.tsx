import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Users, ChevronRight, Heart, Building2, User, UserPlus,
  Briefcase, UserCheck, Star, Award, TrendingUp, BarChart3,
  Check, Crown, Zap, Shield, MessageSquare, FileText,
  GraduationCap, Calendar, Target, Megaphone, Clock
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div className="ml-4">
                  <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
                    Integre RH
                  </span>
                  <p className="text-xs text-gray-500 -mt-1">Conectando gestão e performance</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="ghost" size="sm" className="hover:bg-purple-50">
                  <User className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 bg-clip-text text-transparent">
              Integre RH
            </span>
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-8 leading-relaxed">
            <span className="font-semibold text-purple-600">
              "Conectando gestão, desenvolvimento e performance com inteligência e humanização."
            </span>
            <br className="mb-2" />
            Digitalize e centralize todos os processos de Recursos Humanos em uma única 
            plataforma moderna, intuitiva e funcional.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-8">
            <Link to="/login/rh">
              <Button size="lg" className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg">
                Acessar Plataforma
                <ChevronRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link to="/public-jobs">
              <Button
                variant="outline"
                size="lg"
                className="border-purple-200 text-purple-600 hover:bg-purple-50"
              >
                Área do Candidato
                <UserPlus className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
          
          {/* User Profile Types */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            <Link to="/login/rh">
              <Badge variant="secondary" className="bg-purple-100 text-purple-700 px-4 py-2 hover:bg-purple-200 cursor-pointer transition-colors">
                <Users className="w-4 h-4 mr-2" />
                RH Administrador
              </Badge>
            </Link>
            <Link to="/login/gestor">
              <Badge variant="secondary" className="bg-orange-100 text-orange-700 px-4 py-2 hover:bg-orange-200 cursor-pointer transition-colors">
                <Building2 className="w-4 h-4 mr-2" />
                Gestor
              </Badge>
            </Link>
            <Link to="/login/colaborador">
              <Badge variant="secondary" className="bg-green-100 text-green-700 px-4 py-2 hover:bg-green-200 cursor-pointer transition-colors">
                <User className="w-4 h-4 mr-2" />
                Colaborador
              </Badge>
            </Link>
            <Link to="/login/candidato">
              <Badge variant="secondary" className="bg-blue-100 text-blue-700 px-4 py-2 hover:bg-blue-200 cursor-pointer transition-colors">
                <UserPlus className="w-4 h-4 mr-2" />
                Candidato
              </Badge>
            </Link>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Colaboradores Ativos</p>
                  <p className="text-3xl font-bold">1,247</p>
                  <p className="text-purple-200 text-xs">+12% este mês</p>
                </div>
                <Users className="w-8 h-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Engajamento</p>
                  <p className="text-3xl font-bold">94.2%</p>
                  <p className="text-blue-200 text-xs">Acima da meta</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm">Turnover</p>
                  <p className="text-3xl font-bold">2.1%</p>
                  <p className="text-green-200 text-xs">Muito baixo</p>
                </div>
                <BarChart3 className="w-8 h-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm">Performance Média</p>
                  <p className="text-3xl font-bold">8.7/10</p>
                  <p className="text-orange-200 text-xs">Excelente</p>
                </div>
                <Award className="w-8 h-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pricing Plans Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-2">
            Planos e Preços
          </h2>
          <p className="text-gray-600 text-center mb-12">
            Escolha o plano ideal para sua empresa
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Plano Básico */}
            <Card className="relative hover:shadow-xl transition-all duration-300 border-gray-200">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Básico</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-gray-900">R$ 147</span>
                  <span className="text-gray-500">/mês</span>
                </div>
                <CardDescription className="mt-2">
                  Ideal para pequenas empresas até 50 colaboradores
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Gestão de colaboradores</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Controle de documentos</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Relatórios básicos</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Suporte por email</span>
                  </li>
                </ul>
                <Link to="/client-register?plan=basic">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Contratar Plano
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Plano Profissional */}
            <Card className="relative hover:shadow-xl transition-all duration-300 border-purple-300 scale-105">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-purple-600 text-white px-3 py-1">
                  <Star className="w-4 h-4 mr-1" />
                  Mais Popular
                </Badge>
              </div>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Crown className="w-8 h-8 text-purple-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Profissional</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-gray-900">R$ 447</span>
                  <span className="text-gray-500">/mês</span>
                </div>
                <CardDescription className="mt-2">
                  Para empresas em crescimento até 200 colaboradores
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Tudo do plano Básico</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Recrutamento e seleção</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Avaliações de performance</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Treinamentos online</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Suporte prioritário</span>
                  </li>
                </ul>
                <Link to="/client-register?plan=professional">
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">
                    Contratar Plano
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Plano Enterprise */}
            <Card className="relative hover:shadow-xl transition-all duration-300 border-green-200">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Enterprise</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-green-600">Consultar</span>
                  <span className="text-gray-500"></span>
                </div>
                <CardDescription className="mt-2">
                  Consulta personalizada via WhatsApp
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Consulta via WhatsApp</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Análise personalizada das necessidades</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Proposta customizada</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Suporte especializado</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-sm">Sem compromisso</span>
                  </li>
                </ul>
                <Link to="/client-register?plan=enterprise">
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    Consultar
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Main Features Preview */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-2">
            Funcionalidades Principais
          </h2>
          <p className="text-gray-600 text-center mb-8">
            Sistema completo para gestão de recursos humanos
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-xl transition-all duration-300 border-purple-100 hover:border-purple-300">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                  <Briefcase className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle className="text-purple-700">Gestão de Vagas</CardTitle>
                <CardDescription>
                  Sistema completo de recrutamento e seleção
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-blue-100 hover:border-blue-300">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle className="text-blue-700">Gestão de Colaboradores</CardTitle>
                <CardDescription>
                  Controle completo de funcionários e equipes
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-green-100 hover:border-green-300">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                  <UserCheck className="w-6 h-6 text-green-600" />
                </div>
                <CardTitle className="text-green-700">Avaliações 360°</CardTitle>
                <CardDescription>
                  Performance e competências dos colaboradores
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-yellow-100 hover:border-yellow-300">
              <CardHeader>
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mb-4">
                  <Star className="w-6 h-6 text-yellow-600" />
                </div>
                <CardTitle className="text-yellow-700">Banco de Talentos</CardTitle>
                <CardDescription>
                  Candidatos qualificados para futuras vagas
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-indigo-100 hover:border-indigo-300">
              <CardHeader>
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
                  <GraduationCap className="w-6 h-6 text-indigo-600" />
                </div>
                <CardTitle className="text-indigo-700">Treinamentos</CardTitle>
                <CardDescription>
                  Cursos e capacitações para desenvolvimento
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-red-100 hover:border-red-300">
              <CardHeader>
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-red-600" />
                </div>
                <CardTitle className="text-red-700">Relatórios e Analytics</CardTitle>
                <CardDescription>
                  Insights e métricas para tomada de decisão
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-teal-100 hover:border-teal-300">
              <CardHeader>
                <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-teal-600" />
                </div>
                <CardTitle className="text-teal-700">Gestão de Documentos</CardTitle>
                <CardDescription>
                  Contratos, certificados e arquivos importantes
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-pink-100 hover:border-pink-300">
              <CardHeader>
                <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center mb-4">
                  <MessageSquare className="w-6 h-6 text-pink-600" />
                </div>
                <CardTitle className="text-pink-700">Feedback e Comunicação</CardTitle>
                <CardDescription>
                  Sistema de feedback e comunicados internos
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-orange-100 hover:border-orange-300">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4">
                  <Calendar className="w-6 h-6 text-orange-600" />
                </div>
                <CardTitle className="text-orange-700">Controle de Afastamentos</CardTitle>
                <CardDescription>
                  Gestão de licenças e afastamentos temporários
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-gray-100 hover:border-gray-300">
              <CardHeader>
                <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mb-4">
                  <Target className="w-6 h-6 text-gray-600" />
                </div>
                <CardTitle className="text-gray-700">Metas e Objetivos</CardTitle>
                <CardDescription>
                  Acompanhamento de metas individuais e de equipe
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-cyan-100 hover:border-cyan-300">
              <CardHeader>
                <div className="w-12 h-12 bg-cyan-100 rounded-xl flex items-center justify-center mb-4">
                  <Clock className="w-6 h-6 text-cyan-600" />
                </div>
                <CardTitle className="text-cyan-700">Controle de Ponto</CardTitle>
                <CardDescription>
                  Registro de horários e controle de frequência
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-violet-100 hover:border-violet-300">
              <CardHeader>
                <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center mb-4">
                  <Megaphone className="w-6 h-6 text-violet-600" />
                </div>
                <CardTitle className="text-violet-700">Comunicações Internas</CardTitle>
                <CardDescription>
                  Avisos, comunicações e notícias da empresa
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 shadow-2xl">
          <CardContent className="p-12 text-center">
            <h3 className="text-3xl font-bold mb-4">
              Transforme sua Gestão de RH Hoje
            </h3>
            <p className="text-white/90 mb-8 max-w-3xl mx-auto text-lg leading-relaxed">
              Digitalize e centralize todos os processos de Recursos Humanos em uma única plataforma moderna,
              intuitiva e funcional.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/login">
                <Button
                  size="lg"
                  variant="secondary"
                  className="bg-white text-purple-600 hover:bg-gray-100 shadow-lg"
                >
                  Começar Agora
                  <ChevronRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
