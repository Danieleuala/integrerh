import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  Check, Crown, Zap, Building2, Users, ArrowLeft, 
  MessageSquare, Phone, Mail, Star, Shield, Headphones,
  CreditCard, QrCode, Smartphone
} from 'lucide-react';

interface PlanFeature {
  name: string;
  included: boolean;
}

interface Plan {
  id: string;
  name: string;
  description: string;
  monthlyPrice: number;
  yearlyPrice: number;
  popular?: boolean;
  enterprise?: boolean;
  features: PlanFeature[];
  maxEmployees: number | string;
  support: string;
}

const plans: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    description: 'Ideal para pequenas empresas',
    monthlyPrice: 97,
    yearlyPrice: 970,
    maxEmployees: 25,
    support: 'Email',
    features: [
      { name: 'Gestão de colaboradores', included: true },
      { name: 'Portal do funcionário', included: true },
      { name: 'Documentos digitais', included: true },
      { name: 'Comunicados básicos', included: true },
      { name: 'Relatórios básicos', included: true },
      { name: 'Processo seletivo simples', included: false },
      { name: 'Avaliações de desempenho', included: false },
      { name: 'Integração API', included: false },
      { name: 'Treinamentos corporativos', included: false },
      { name: 'Suporte 24/7', included: false }
    ]
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'Para empresas em crescimento',
    monthlyPrice: 197,
    yearlyPrice: 1970,
    popular: true,
    maxEmployees: 100,
    support: 'Email + Chat',
    features: [
      { name: 'Gestão de colaboradores', included: true },
      { name: 'Portal do funcionário', included: true },
      { name: 'Documentos digitais', included: true },
      { name: 'Comunicados básicos', included: true },
      { name: 'Relatórios básicos', included: true },
      { name: 'Processo seletivo completo', included: true },
      { name: 'Avaliações de desempenho', included: true },
      { name: 'Integração API básica', included: true },
      { name: 'Treinamentos corporativos', included: false },
      { name: 'Suporte 24/7', included: false }
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'Solução completa para grandes empresas',
    monthlyPrice: 397,
    yearlyPrice: 3970,
    enterprise: true,
    maxEmployees: 'Ilimitado',
    support: 'Dedicado 24/7',
    features: [
      { name: 'Gestão de colaboradores', included: true },
      { name: 'Portal do funcionário', included: true },
      { name: 'Documentos digitais', included: true },
      { name: 'Comunicados avançados', included: true },
      { name: 'Relatórios avançados', included: true },
      { name: 'Processo seletivo completo', included: true },
      { name: 'Avaliações de desempenho', included: true },
      { name: 'Integração API completa', included: true },
      { name: 'Treinamentos corporativos', included: true },
      { name: 'Suporte dedicado 24/7', included: true }
    ]
  }
];

export default function Planos() {
  const navigate = useNavigate();
  const [isYearly, setIsYearly] = useState(false);

  const handleSelectPlan = (plan: Plan) => {
    const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;
    const period = isYearly ? 'anual' : 'mensal';
    
    // Redirect to payment page with plan details
    navigate('/pagamento', { 
      state: { 
        plan: plan.name, 
        price, 
        period,
        planId: plan.id
      } 
    });
  };

  const calculateSavings = (plan: Plan) => {
    const monthlyCost = plan.monthlyPrice * 12;
    const savings = monthlyCost - plan.yearlyPrice;
    const percentage = Math.round((savings / monthlyCost) * 100);
    return { savings, percentage };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-purple-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao início
            </Button>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline"
                onClick={() => {
                  const message = encodeURIComponent("Olá! Gostaria de falar sobre os planos da Integre RH. Podem me ajudar?");
                  window.open(`https://wa.me/5587981389271?text=${message}`, '_blank');
                }}
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Falar com Consultor
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Escolha o Plano Ideal
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Transforme a gestão de RH da sua empresa com soluções modernas e eficientes. 
            Todos os planos incluem suporte e atualizações.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <Label htmlFor="billing-toggle" className={!isYearly ? 'font-medium' : 'text-gray-500'}>
              Mensal
            </Label>
            <Switch
              id="billing-toggle"
              checked={isYearly}
              onCheckedChange={setIsYearly}
            />
            <Label htmlFor="billing-toggle" className={isYearly ? 'font-medium' : 'text-gray-500'}>
              Anual
            </Label>
            {isYearly && (
              <Badge className="bg-green-100 text-green-800">
                Economize até 20%
              </Badge>
            )}
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => {
            const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;
            const savings = isYearly ? calculateSavings(plan) : null;
            
            return (
              <Card 
                key={plan.id} 
                className={`relative ${
                  plan.popular 
                    ? 'border-purple-300 shadow-xl scale-105' 
                    : plan.enterprise 
                    ? 'border-orange-300 shadow-lg'
                    : 'border-gray-200 shadow-md'
                } hover:shadow-xl transition-all duration-300`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-purple-600 text-white px-4 py-1">
                      <Star className="w-3 h-3 mr-1" />
                      Mais Popular
                    </Badge>
                  </div>
                )}
                
                {plan.enterprise && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-orange-600 text-white px-4 py-1">
                      <Crown className="w-3 h-3 mr-1" />
                      Enterprise
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription className="text-base">{plan.description}</CardDescription>
                  
                  <div className="mt-4">
                    <div className="flex items-baseline justify-center">
                      <span className="text-4xl font-bold text-gray-900">R$ {price}</span>
                      <span className="text-gray-500 ml-1">/{isYearly ? 'ano' : 'mês'}</span>
                    </div>
                    
                    {isYearly && savings && (
                      <div className="mt-2">
                        <span className="text-sm text-green-600 font-medium">
                          Economize R$ {savings.savings} ({savings.percentage}%)
                        </span>
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Plan Info */}
                  <div className="text-center space-y-2">
                    <div className="flex items-center justify-center space-x-2">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        Até {plan.maxEmployees} funcionários
                      </span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Headphones className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        Suporte: {plan.support}
                      </span>
                    </div>
                  </div>

                  <Separator />

                  {/* Features */}
                  <div className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <Check 
                          className={`w-4 h-4 ${
                            feature.included 
                              ? 'text-green-500' 
                              : 'text-gray-300'
                          }`} 
                        />
                        <span 
                          className={`text-sm ${
                            feature.included 
                              ? 'text-gray-900' 
                              : 'text-gray-400'
                          }`}
                        >
                          {feature.name}
                        </span>
                      </div>
                    ))}
                  </div>

                  <Button 
                    className={`w-full mt-6 ${
                      plan.popular 
                        ? 'bg-purple-600 hover:bg-purple-700' 
                        : plan.enterprise
                        ? 'bg-orange-600 hover:bg-orange-700'
                        : 'bg-gray-900 hover:bg-gray-800'
                    }`}
                    onClick={() => handleSelectPlan(plan)}
                  >
                    {plan.enterprise ? 'Contratar Enterprise' : 'Escolher Plano'}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Additional Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardContent className="p-6 text-center">
              <Shield className="w-8 h-8 text-green-500 mx-auto mb-3" />
              <h3 className="font-medium mb-2">Segurança Garantida</h3>
              <p className="text-sm text-gray-600">
                Criptografia de ponta e conformidade LGPD
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Zap className="w-8 h-8 text-blue-500 mx-auto mb-3" />
              <h3 className="font-medium mb-2">Implementação Rápida</h3>
              <p className="text-sm text-gray-600">
                Configure sua empresa em até 24 horas
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Phone className="w-8 h-8 text-purple-500 mx-auto mb-3" />
              <h3 className="font-medium mb-2">Suporte Especializado</h3>
              <p className="text-sm text-gray-600">
                Equipe dedicada para ajudar sua empresa
              </p>
            </CardContent>
          </Card>
        </div>

        {/* FAQ or Contact */}
        <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">
              Precisa de um plano personalizado?
            </h2>
            <p className="text-lg mb-6 opacity-90">
              Nossa equipe pode criar uma solução sob medida para sua empresa
            </p>
            <div className="space-x-4">
              <Button 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-purple-600"
                onClick={() => {
                  const message = encodeURIComponent("Olá! Gostaria de um plano personalizado para minha empresa. Podem me ajudar?");
                  window.open(`https://wa.me/5587981389271?text=${message}`, '_blank');
                }}
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Falar com Especialista
              </Button>
              <Button 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-purple-600"
                onClick={() => {
                  const message = encodeURIComponent("Olá! Gostaria de agendar uma demonstração da plataforma Integre RH.");
                  window.open(`https://wa.me/5587981389271?text=${message}`, '_blank');
                }}
              >
                <Phone className="w-4 h-4 mr-2" />
                Solicitar Demo
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
