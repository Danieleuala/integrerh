import React, { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Job, JobApplication } from "@/lib/mockData";
import { DataAdapter } from "@/lib/dataAdapter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Briefcase,
  Search,
  Eye,
  Clock,
  CheckCircle,
  XCircle,
  ArrowRight,
  User,
  Mail,
  Phone,
  Calendar,
  Building2,
  Target,
  AlertTriangle,
  Star,
  MapPin,
  Heart,
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface CandidateStatusProps {
  candidateEmail?: string;
}

export default function CandidateStatus({
  candidateEmail,
}: CandidateStatusProps) {
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState(
    candidateEmail || searchParams.get("email") || "",
  );
  const [applications, setApplications] = useState<
    (JobApplication & { job: Job })[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (email) {
      handleSearch();
    }
  }, []);

  const handleSearch = async () => {
    if (!email) {
      alert("Por favor, digite seu email para buscar suas candidaturas.");
      return;
    }

    setLoading(true);
    setSearched(true);
    setError(null);

    try {
      // Get all jobs using DataAdapter
      const jobs = await DataAdapter.getJobs();

      // Find applications for this email
      const userApplications: (JobApplication & { job: Job })[] = [];

      jobs.forEach((job) => {
        const userApps = job.applications.filter(
          (app) => app.candidateEmail.toLowerCase() === email.toLowerCase(),
        );

        userApps.forEach((app) => {
          userApplications.push({
            ...app,
            job,
          });
        });
      });

      setApplications(userApplications);
    } catch (error) {
      console.error("Erro ao buscar candidaturas:", error);
      setError("Erro ao buscar candidaturas. Tente novamente mais tarde.");
    } finally {
      setLoading(false);
    }
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case "applied":
        return {
          label: "Candidatura Enviada",
          color: "bg-blue-100 text-blue-700",
          icon: CheckCircle,
          description: "Sua candidatura foi recebida e está sendo analisada.",
        };
      case "screening":
        return {
          label: "Triagem",
          color: "bg-yellow-100 text-yellow-700",
          icon: Eye,
          description: "Seu perfil está passando por triagem inicial.",
        };
      case "interview":
        return {
          label: "Entrevista",
          color: "bg-purple-100 text-purple-700",
          icon: User,
          description: "Você foi selecionado para a fase de entrevistas.",
        };
      case "test":
        return {
          label: "Teste Técnico",
          color: "bg-orange-100 text-orange-700",
          icon: Target,
          description: "Fase de avalia��ão técnica ou prova.",
        };
      case "final":
        return {
          label: "Análise Final",
          color: "bg-indigo-100 text-indigo-700",
          icon: Star,
          description: "Você está na etapa final de avaliação.",
        };
      case "hired":
        return {
          label: "Contratado",
          color: "bg-green-100 text-green-700",
          icon: CheckCircle,
          description: "Parabéns! Você foi selecionado para a vaga.",
        };
      case "rejected":
        return {
          label: "Não Selecionado",
          color: "bg-red-100 text-red-700",
          icon: XCircle,
          description: "Infelizmente não foi selecionado nesta ocasião.",
        };
      default:
        return {
          label: "Em Análise",
          color: "bg-gray-100 text-gray-700",
          icon: Clock,
          description: "Sua candidatura está sendo processada.",
        };
    }
  };

  const getStageProgress = (currentStage: string, stages: any[]) => {
    const stageOrder = [
      "applied",
      "screening",
      "interview",
      "test",
      "final",
      "hired",
    ];
    const currentIndex = stageOrder.indexOf(currentStage);
    return ((currentIndex + 1) / stageOrder.length) * 100;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center">
                <Briefcase className="w-8 h-8 mr-3 text-purple-600" />
                Status das Candidaturas
              </h1>
              <p className="text-gray-600 mt-1">
                Acompanhe o andamento dos seus processos seletivos
              </p>
            </div>
            <Link to="/public-jobs">
              <Button variant="outline">
                <Search className="w-4 h-4 mr-2" />
                Ver Vagas
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Search Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="w-5 h-5 mr-2" />
              Buscar Candidaturas
            </CardTitle>
            <CardDescription>
              Digite seu email para verificar o status das suas candidaturas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4">
              <div className="flex-1">
                <Input
                  type="email"
                  placeholder="seu.email@exemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
              <Button onClick={handleSearch} disabled={loading}>
                {loading ? "Buscando..." : "Buscar"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {searched && (
          <>
            {applications.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Nenhuma candidatura encontrada
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Não encontramos candidaturas com este email. Verifique se o
                    email está correto ou candidate-se a uma vaga.
                  </p>
                  <Link to="/public-jobs">
                    <Button>
                      <Search className="w-4 h-4 mr-2" />
                      Ver Vagas Disponíveis
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900">
                    Suas Candidaturas ({applications.length})
                  </h2>
                  <p className="text-sm text-gray-600">Email: {email}</p>
                </div>

                {applications.map((application) => {
                  const statusInfo = getStatusInfo(application.status);
                  const progress = getStageProgress(
                    application.status,
                    application.job.stages,
                  );
                  const StatusIcon = statusInfo.icon;

                  return (
                    <Card key={application.id} className="overflow-hidden">
                      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="text-xl text-purple-700 mb-2">
                              {application.job.title}
                            </CardTitle>
                            <CardDescription className="space-y-1">
                              <div className="flex items-center space-x-4">
                                <div className="flex items-center">
                                  <Building2 className="w-4 h-4 mr-2" />
                                  {application.job.department}
                                </div>
                                {application.job.location && (
                                  <div className="flex items-center">
                                    <MapPin className="w-4 h-4 mr-2" />
                                    {application.job.location}
                                  </div>
                                )}
                              </div>
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 mr-2" />
                                Candidatura enviada em{" "}
                                {format(
                                  new Date(application.appliedDate),
                                  "dd/MM/yyyy 'às' HH:mm",
                                  { locale: ptBR },
                                )}
                              </div>
                            </CardDescription>
                          </div>
                          <Badge className={statusInfo.color}>
                            <StatusIcon className="w-4 h-4 mr-2" />
                            {statusInfo.label}
                          </Badge>
                        </div>
                      </CardHeader>

                      <CardContent className="p-6">
                        {/* Progress Bar */}
                        <div className="mb-6">
                          <div className="flex justify-between text-sm text-gray-600 mb-2">
                            <span>Progresso no Processo</span>
                            <span>{Math.round(progress)}%</span>
                          </div>
                          <Progress value={progress} className="h-2" />
                        </div>

                        {/* Status Description */}
                        <Alert className="mb-6">
                          <StatusIcon className="w-4 h-4" />
                          <AlertDescription>
                            <strong>Status Atual:</strong>{" "}
                            {statusInfo.description}
                          </AlertDescription>
                        </Alert>

                        {/* Application Details */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-medium text-gray-900 mb-3">
                              Dados da Candidatura
                            </h4>
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center">
                                <User className="w-4 h-4 mr-2 text-gray-400" />
                                <span>{application.candidateName}</span>
                              </div>
                              <div className="flex items-center">
                                <Mail className="w-4 h-4 mr-2 text-gray-400" />
                                <span>{application.candidateEmail}</span>
                              </div>
                              {application.candidatePhone && (
                                <div className="flex items-center">
                                  <Phone className="w-4 h-4 mr-2 text-gray-400" />
                                  <span>{application.candidatePhone}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          <div>
                            <h4 className="font-medium text-gray-900 mb-3">
                              Processo Seletivo
                            </h4>
                            <div className="space-y-2">
                              {application.job.stages
                                .slice(0, 3)
                                .map((stage, index) => (
                                  <div
                                    key={stage.id}
                                    className="flex items-center text-sm"
                                  >
                                    <div
                                      className={`w-3 h-3 rounded-full mr-3 ${
                                        index <=
                                        application.job.stages.findIndex(
                                          (s) =>
                                            s.id === application.currentStage,
                                        )
                                          ? "bg-green-500"
                                          : "bg-gray-300"
                                      }`}
                                    />
                                    <span className="text-gray-600">
                                      {stage.name}
                                    </span>
                                  </div>
                                ))}
                              {application.job.stages.length > 3 && (
                                <p className="text-xs text-gray-500 ml-6">
                                  +{application.job.stages.length - 3} etapas
                                  adicionais
                                </p>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Next Steps */}
                        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <h4 className="font-medium text-blue-900 mb-2">
                            Próximos Passos
                          </h4>
                          <p className="text-blue-800 text-sm">
                            {application.status === "hired"
                              ? "Aguarde contato da equipe de RH para os procedimentos de contratação."
                              : application.status === "rejected"
                                ? "Continue se candidatando a outras vagas. Agradecemos seu interesse!"
                                : "Mantenha-se atento ao seu email e telefone. Entraremos em contato em breve."}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Footer */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-4">
                <Heart className="w-6 h-6 text-purple-600 mr-2" />
                <h3 className="text-lg font-medium text-purple-900">
                  Integre RH
                </h3>
              </div>
              <p className="text-purple-700 text-sm mb-4">
                Conectando talentos às melhores oportunidades
              </p>
              <div className="flex justify-center space-x-4">
                <Link to="/public-jobs">
                  <Button variant="outline" size="sm">
                    Ver Todas as Vagas
                  </Button>
                </Link>
                <Link to="/">
                  <Button variant="outline" size="sm">
                    Página Inicial
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
