import { useState, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  Building2, Plus, Search, Eye, Edit, MoreHorizontal,
  Users, Globe, Mail, Phone, MapPin, Briefcase,
  CheckCircle, XCircle, AlertCircle, Settings,
  Calendar, DollarSign, Target, Star, Shield
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Company {
  id: string;
  name: string;
  trade_name?: string;
  email: string;
  phone?: string;
  cnpj?: string;
  address?: string;
  city?: string;
  state?: string;
  zip_code?: string;
  website?: string;
  logo_url?: string;
  description?: string;
  industry?: string;
  size: 'small' | 'medium' | 'large' | 'enterprise';
  status: 'active' | 'inactive' | 'trial' | 'suspended';
  plan: 'basic' | 'professional' | 'enterprise';
  max_employees: number;
  max_jobs: number;
  created_at: string;
  updated_at: string;
}

export default function CompanyManagement() {
  const { user } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [companyForm, setCompanyForm] = useState<Partial<Company>>({
    size: 'medium',
    status: 'active',
    plan: 'basic',
    max_employees: 50,
    max_jobs: 10
  });

  const canManage = hasPermission(user?.role || 'employee', ['admin']);

  useEffect(() => {
    loadCompanies();
  }, []);

  const loadCompanies = async () => {
    setLoading(true);
    try {
      // Mock data for demonstration
      const mockCompanies: Company[] = [
        {
          id: '1',
          name: 'TechCorp Solutions',
          trade_name: 'TechCorp',
          email: 'contato@techcorp.com',
          phone: '(11) 99999-1111',
          cnpj: '12.345.678/0001-90',
          address: 'Av. Paulista, 1000',
          city: 'São Paulo',
          state: 'SP',
          zip_code: '01310-100',
          website: 'https://techcorp.com',
          description: 'Empresa de soluções tecnológicas',
          industry: 'Tecnologia',
          size: 'large',
          status: 'active',
          plan: 'enterprise',
          max_employees: 200,
          max_jobs: 50,
          created_at: '2024-01-15T10:00:00Z',
          updated_at: '2024-01-15T10:00:00Z'
        },
        {
          id: '2',
          name: 'Marketing Plus',
          email: 'admin@marketingplus.com',
          phone: '(11) 88888-2222',
          cnpj: '98.765.432/0001-10',
          city: 'Rio de Janeiro',
          state: 'RJ',
          industry: 'Marketing',
          size: 'medium',
          status: 'trial',
          plan: 'professional',
          max_employees: 100,
          max_jobs: 25,
          created_at: '2024-01-20T14:30:00Z',
          updated_at: '2024-01-20T14:30:00Z'
        }
      ];
      setCompanies(mockCompanies);
    } catch (error) {
      console.error('Erro ao carregar empresas:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (company.cnpj && company.cnpj.includes(searchTerm));
    const matchesStatus = statusFilter === 'all' || company.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCreateCompany = async () => {
    try {
      // Aqui você faria a chamada para a API para criar a empresa
      console.log('Criando empresa:', companyForm);
      
      const newCompany: Company = {
        id: Math.random().toString(36).substr(2, 9),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...companyForm as Company
      };
      
      setCompanies([...companies, newCompany]);
      setIsCreateDialogOpen(false);
      setCompanyForm({
        size: 'medium',
        status: 'active',
        plan: 'basic',
        max_employees: 50,
        max_jobs: 10
      });
    } catch (error) {
      console.error('Erro ao criar empresa:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { color: 'bg-green-100 text-green-800', label: 'Ativo' },
      inactive: { color: 'bg-gray-100 text-gray-800', label: 'Inativo' },
      trial: { color: 'bg-blue-100 text-blue-800', label: 'Trial' },
      suspended: { color: 'bg-red-100 text-red-800', label: 'Suspenso' }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.inactive;
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  const getPlanBadge = (plan: string) => {
    const planConfig = {
      basic: { color: 'bg-gray-100 text-gray-800', label: 'Básico' },
      professional: { color: 'bg-blue-100 text-blue-800', label: 'Profissional' },
      enterprise: { color: 'bg-purple-100 text-purple-800', label: 'Enterprise' }
    };
    
    const config = planConfig[plan as keyof typeof planConfig] || planConfig.basic;
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  if (!canManage) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Acesso Negado</h3>
          <p className="mt-1 text-sm text-gray-500">Você não tem permissão para acessar esta área.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Empresas</h1>
          <p className="text-gray-600">Gerencie empresas clientes da plataforma</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nova Empresa
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar por nome, e-mail ou CNPJ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="active">Ativo</SelectItem>
            <SelectItem value="trial">Trial</SelectItem>
            <SelectItem value="inactive">Inativo</SelectItem>
            <SelectItem value="suspended">Suspenso</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Companies Table */}
      <Card>
        <CardHeader>
          <CardTitle>Empresas Cadastradas</CardTitle>
          <CardDescription>
            {filteredCompanies.length} empresa{filteredCompanies.length !== 1 ? 's' : ''} encontrada{filteredCompanies.length !== 1 ? 's' : ''}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <div className="text-gray-500">Carregando empresas...</div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Empresa</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Plano</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Usuários</TableHead>
                  <TableHead>Criado em</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCompanies.map((company) => (
                  <TableRow key={company.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Building2 className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium">{company.name}</div>
                          {company.trade_name && (
                            <div className="text-sm text-gray-500">{company.trade_name}</div>
                          )}
                          {company.industry && (
                            <Badge variant="outline" className="mt-1 text-xs">
                              {company.industry}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center text-sm">
                          <Mail className="w-4 h-4 mr-2 text-gray-400" />
                          {company.email}
                        </div>
                        {company.phone && (
                          <div className="flex items-center text-sm text-gray-500">
                            <Phone className="w-4 h-4 mr-2 text-gray-400" />
                            {company.phone}
                          </div>
                        )}
                        {company.city && company.state && (
                          <div className="flex items-center text-sm text-gray-500">
                            <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                            {company.city}, {company.state}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {getPlanBadge(company.plan)}
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(company.status)}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div className="font-medium">0/{company.max_employees}</div>
                        <div className="text-gray-500">usuários</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-gray-500">
                        {format(new Date(company.created_at), 'dd/MM/yyyy', { locale: ptBR })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => {
                            setSelectedCompany(company);
                            setIsViewDialogOpen(true);
                          }}>
                            <Eye className="w-4 h-4 mr-2" />
                            Visualizar
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => {
                            setSelectedCompany(company);
                            setCompanyForm(company);
                            setIsEditDialogOpen(true);
                          }}>
                            <Edit className="w-4 h-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Settings className="w-4 h-4 mr-2" />
                            Configurações
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create Company Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nova Empresa</DialogTitle>
            <DialogDescription>
              Cadastre uma nova empresa cliente na plataforma
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Razão Social *</Label>
              <Input
                id="name"
                value={companyForm.name || ''}
                onChange={(e) => setCompanyForm({...companyForm, name: e.target.value})}
                placeholder="Nome completo da empresa"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="trade_name">Nome Fantasia</Label>
              <Input
                id="trade_name"
                value={companyForm.trade_name || ''}
                onChange={(e) => setCompanyForm({...companyForm, trade_name: e.target.value})}
                placeholder="Nome comercial"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">E-mail *</Label>
              <Input
                id="email"
                type="email"
                value={companyForm.email || ''}
                onChange={(e) => setCompanyForm({...companyForm, email: e.target.value})}
                placeholder="contato@empresa.com"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={companyForm.phone || ''}
                onChange={(e) => setCompanyForm({...companyForm, phone: e.target.value})}
                placeholder="(11) 99999-9999"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="cnpj">CNPJ</Label>
              <Input
                id="cnpj"
                value={companyForm.cnpj || ''}
                onChange={(e) => setCompanyForm({...companyForm, cnpj: e.target.value})}
                placeholder="00.000.000/0000-00"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="industry">Setor</Label>
              <Input
                id="industry"
                value={companyForm.industry || ''}
                onChange={(e) => setCompanyForm({...companyForm, industry: e.target.value})}
                placeholder="Ex: Tecnologia, Saúde, Educação"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="size">Porte da Empresa</Label>
              <Select value={companyForm.size} onValueChange={(value) => setCompanyForm({...companyForm, size: value as any})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Pequena (até 50 funcionários)</SelectItem>
                  <SelectItem value="medium">Média (51-200 funcionários)</SelectItem>
                  <SelectItem value="large">Grande (201-1000 funcionários)</SelectItem>
                  <SelectItem value="enterprise">Enterprise (1000+ funcionários)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="plan">Plano</Label>
              <Select value={companyForm.plan} onValueChange={(value) => setCompanyForm({...companyForm, plan: value as any})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Básico</SelectItem>
                  <SelectItem value="professional">Profissional</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="max_employees">Máx. Funcionários</Label>
              <Input
                id="max_employees"
                type="number"
                value={companyForm.max_employees || ''}
                onChange={(e) => setCompanyForm({...companyForm, max_employees: parseInt(e.target.value)})}
                placeholder="50"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="max_jobs">Máx. Vagas</Label>
              <Input
                id="max_jobs"
                type="number"
                value={companyForm.max_jobs || ''}
                onChange={(e) => setCompanyForm({...companyForm, max_jobs: parseInt(e.target.value)})}
                placeholder="10"
              />
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={companyForm.address || ''}
                onChange={(e) => setCompanyForm({...companyForm, address: e.target.value})}
                placeholder="Endereço completo"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="city">Cidade</Label>
              <Input
                id="city"
                value={companyForm.city || ''}
                onChange={(e) => setCompanyForm({...companyForm, city: e.target.value})}
                placeholder="Cidade"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="state">Estado</Label>
              <Input
                id="state"
                value={companyForm.state || ''}
                onChange={(e) => setCompanyForm({...companyForm, state: e.target.value})}
                placeholder="SP"
              />
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={companyForm.website || ''}
                onChange={(e) => setCompanyForm({...companyForm, website: e.target.value})}
                placeholder="https://empresa.com"
              />
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={companyForm.description || ''}
                onChange={(e) => setCompanyForm({...companyForm, description: e.target.value})}
                placeholder="Descreva a empresa e suas atividades"
                rows={3}
              />
            </div>
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateCompany}>
              Criar Empresa
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
