import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Heart, Eye, EyeOff, CheckCircle, ArrowLeft, Loader2, AlertCircle, Lock } from 'lucide-react';
import { PasswordRecoveryService } from '@/lib/passwordRecoveryService';

export default function PasswordReset() {
  const [searchParams] = useSearchParams();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [tokenValid, setTokenValid] = useState<boolean | null>(null);
  const [userEmail, setUserEmail] = useState('');
  const navigate = useNavigate();

  const token = searchParams.get('token');

  useEffect(() => {
    if (!token) {
      setError('Link de recuperação inválido ou não encontrado');
      setTokenValid(false);
      return;
    }

    // Validate token
    const validation = PasswordRecoveryService.validateToken(token);
    
    if (!validation.valid) {
      setError(validation.error || 'Token inválido');
      setTokenValid(false);
    } else {
      setTokenValid(true);
      setUserEmail(validation.email || '');
    }
  }, [token]);

  const validatePassword = (pwd: string): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];

    if (pwd.length < 8) {
      errors.push('Deve ter pelo menos 8 caracteres');
    }
    if (!/[A-Z]/.test(pwd)) {
      errors.push('Deve conter pelo menos uma letra maiúscula');
    }
    if (!/[a-z]/.test(pwd)) {
      errors.push('Deve conter pelo menos uma letra minúscula');
    }
    if (!/\d/.test(pwd)) {
      errors.push('Deve conter pelo menos um número');
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(pwd)) {
      errors.push('Deve conter pelo menos um caractere especial');
    }

    return { valid: errors.length === 0, errors };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!password || !confirmPassword) {
      setError('Por favor, preencha todos os campos');
      return;
    }

    if (password !== confirmPassword) {
      setError('As senhas não coincidem');
      return;
    }

    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      setError(`Senha inválida:\n• ${passwordValidation.errors.join('\n• ')}`);
      return;
    }

    if (!token) {
      setError('Token inválido');
      return;
    }

    setIsLoading(true);

    try {
      // Simulate password reset (in production, call API)
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mark token as used
      const tokenMarked = PasswordRecoveryService.markTokenAsUsed(token);
      
      if (!tokenMarked) {
        setError('Erro ao processar redefinição. Tente novamente.');
        setIsLoading(false);
        return;
      }

      // In production, you would call your API to actually reset the password
      console.log('Password reset for:', userEmail);
      console.log('New password (hashed):', password); // Don't log in production!

      // Store success message for login page
      localStorage.setItem('passwordResetSuccess', 'true');

      setSuccess(true);
    } catch (error) {
      setError('Erro inesperado. Tente novamente em alguns minutos.');
      console.error('Password reset error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const passwordValidation = validatePassword(password);

  // Invalid token screen
  if (tokenValid === false) {
    return (
      <div className="min-h-screen bg-integre-gradient flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Heart className="w-10 h-10 text-purple-600" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Integre RH</h1>
            <p className="text-white/80">Conectando gestão e performance</p>
          </div>

          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Link Inválido
              </h2>
              
              <p className="text-gray-600 mb-6">
                {error}
              </p>

              <div className="space-y-3">
                <Link to="/recuperar-senha">
                  <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600">
                    Solicitar Novo Link
                  </Button>
                </Link>
                
                <Link to="/login">
                  <Button variant="ghost" className="w-full">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Voltar ao Login
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Success screen
  if (success) {
    return (
      <div className="min-h-screen bg-integre-gradient flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Heart className="w-10 h-10 text-purple-600" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Integre RH</h1>
            <p className="text-white/80">Conectando gestão e performance</p>
          </div>

          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Senha Redefinida!
              </h2>
              
              <p className="text-gray-600 mb-6">
                Sua senha foi redefinida com sucesso. Agora você pode fazer login com sua nova senha.
              </p>

              <Link to="/login">
                <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600">
                  Fazer Login
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Loading token validation
  if (tokenValid === null) {
    return (
      <div className="min-h-screen bg-integre-gradient flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card className="border-0 shadow-2xl">
            <CardContent className="p-8 text-center">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-600" />
              <p className="text-gray-600">Validando link de recuperação...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-integre-gradient flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Heart className="w-10 h-10 text-purple-600" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Integre RH</h1>
          <p className="text-white/80">Conectando gestão e performance</p>
        </div>

        {/* Reset Password Card */}
        <Card className="border-0 shadow-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-gray-900">Redefinir Senha</CardTitle>
            <CardDescription>
              Crie uma nova senha para sua conta
              {userEmail && (
                <div className="mt-2 text-sm text-purple-600 font-medium">
                  {userEmail}
                </div>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription className="whitespace-pre-line">{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium text-gray-700">
                  Nova Senha
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Digite sua nova senha"
                    className="h-11 pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-11 w-11 px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                
                {/* Password strength indicator */}
                {password && (
                  <div className="space-y-2">
                    <div className="text-xs text-gray-600">Força da senha:</div>
                    <div className="space-y-1">
                      {passwordValidation.errors.map((error, index) => (
                        <div key={index} className="flex items-center space-x-2 text-xs">
                          <div className="w-2 h-2 rounded-full bg-red-400"></div>
                          <span className="text-red-600">{error}</span>
                        </div>
                      ))}
                      {passwordValidation.valid && (
                        <div className="flex items-center space-x-2 text-xs">
                          <CheckCircle className="w-3 h-3 text-green-600" />
                          <span className="text-green-600">Senha forte</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">
                  Confirmar Nova Senha
                </label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirme sua nova senha"
                    className="h-11 pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-11 w-11 px-3"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-xs text-red-600">As senhas não coincidem</p>
                )}
                {confirmPassword && password === confirmPassword && (
                  <p className="text-xs text-green-600 flex items-center">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Senhas coincidem
                  </p>
                )}
              </div>

              <Button
                type="submit"
                disabled={isLoading || !passwordValidation.valid || password !== confirmPassword}
                className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Redefinindo...
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 mr-2" />
                    Redefinir Senha
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <Lock className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium mb-1">Requisitos da senha:</p>
                    <ul className="space-y-1">
                      <li>• Pelo menos 8 caracteres</li>
                      <li>• Letras maiúsculas e minúsculas</li>
                      <li>• Pelo menos um número</li>
                      <li>• Pelo menos um caractere especial</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 text-center">
              <Link 
                to="/login" 
                className="text-sm text-purple-600 hover:text-purple-500 font-medium inline-flex items-center"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Voltar ao Login
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <p className="text-white/60 text-sm">
            © 2024 Integre RH. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </div>
  );
}
