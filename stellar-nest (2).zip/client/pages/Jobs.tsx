import { useState, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore, Job, JobApplication } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  Briefcase, Plus, Search, Eye, Edit, MoreHorizontal,
  Users, Clock, Calendar, DollarSign, MapPin, Share2,
  CheckCircle, XCircle, AlertCircle, Send, Download,
  Building2, Globe, Target, Link, Copy, Phone, Video,
  FileText, UserPlus, ArrowRight, Filter, Star, MessageSquare
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Jobs() {
  const { user } = useAuth();
  const [jobs, setJobs] = useState(IntegratedDataStore.getJobs());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isApplicationsDialogOpen, setIsApplicationsDialogOpen] = useState(false);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [isPipelineDialogOpen, setIsPipelineDialogOpen] = useState(false);
  const [jobForm, setJobForm] = useState<Partial<Job>>({});
  const [selectedApplication, setSelectedApplication] = useState<JobApplication | null>(null);
  const [pipelineStage, setPipelineStage] = useState<string>('screening');
  const [createdJobId, setCreatedJobId] = useState<string>('');

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canApply = hasPermission(user?.role || 'employee', ['candidate']);

  // Generate shareable job link
  const generateJobLink = (jobId: string) => {
    return `${window.location.origin}/jobs/public/${jobId}`;
  };

  // Copy link to clipboard
  const copyJobLink = async (jobId: string) => {
    const link = generateJobLink(jobId);
    try {
      await navigator.clipboard.writeText(link);
      alert('Link copiado para a área de transferência!');
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = link;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      alert('Link copiado para a área de transferência!');
    }
  };

  // Share via social media
  const shareJobSocial = (jobId: string, platform: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;

    const link = generateJobLink(jobId);
    const text = `Confira esta oportunidade: ${job.title} - ${job.department}`;

    let shareUrl = '';
    switch (platform) {
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + link)}`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(link)}`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=${encodeURIComponent('Oportunidade de Emprego: ' + job.title)}&body=${encodeURIComponent(text + '\n\n' + link)}`;
        break;
    }

    if (shareUrl) {
      window.open(shareUrl, '_blank');
    }
  };

  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || job.status === statusFilter;
      const matchesDepartment = departmentFilter === 'all' || job.department === departmentFilter;
      
      return matchesSearch && matchesStatus && matchesDepartment;
    });
  }, [jobs, searchTerm, statusFilter, departmentFilter]);

  const departments = useMemo(() => {
    const depts = [...new Set(jobs.map(job => job.department))];
    return depts.sort();
  }, [jobs]);

  const getStatusBadge = (status: Job['status']) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-green-100 text-green-700">Aberta</Badge>;
      case 'closed':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-700">Fechada</Badge>;
      case 'draft':
        return <Badge variant="outline" className="border-orange-200 text-orange-700">Rascunho</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getApplicationStatusBadge = (status: JobApplication['status']) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="border-yellow-200 text-yellow-700">Pendente</Badge>;
      case 'screening':
        return <Badge className="bg-blue-100 text-blue-700">Triagem</Badge>;
      case 'phone_interview':
        return <Badge className="bg-yellow-100 text-yellow-700">Tel. Interview</Badge>;
      case 'technical_test':
        return <Badge className="bg-purple-100 text-purple-700">Teste Técnico</Badge>;
      case 'final_interview':
        return <Badge className="bg-orange-100 text-orange-700">Entrevista Final</Badge>;
      case 'interviewing':
        return <Badge className="bg-blue-100 text-blue-700">Em Entrevista</Badge>;
      case 'approved':
        return <Badge className="bg-green-100 text-green-700">Aprovado</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-700">Rejeitado</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
    setIsViewDialogOpen(true);
  };

  const handleViewApplications = (job: Job) => {
    setSelectedJob(job);
    setIsApplicationsDialogOpen(true);
  };

  const handleCreateJob = () => {
    setJobForm({
      title: '',
      department: '',
      description: '',
      requirements: [],
      benefits: [],
      salary: '',
      type: 'full_time',
      status: 'draft',
      createdDate: new Date().toISOString(),
      applications: []
    });
    setIsCreateDialogOpen(true);
  };

  const handleSaveJob = () => {
    if (jobForm.title && jobForm.department && jobForm.description) {
      const newJob = IntegratedDataStore.addJob(jobForm as Omit<Job, 'id'>);
      setJobs(IntegratedDataStore.getJobs());
      setIsCreateDialogOpen(false);
      setJobForm({});

      // Open share dialog for the newly created job
      setCreatedJobId(newJob.id);
      setIsShareDialogOpen(true);
    } else {
      alert('Por favor, preencha todos os campos obrigatórios: Título, Departamento e Descrição.');
    }
  };

  const handleEditJob = (job: Job) => {
    setSelectedJob(job);
    setJobForm(job);
    setIsCreateDialogOpen(true);
  };

  const handleUpdateJob = () => {
    if (selectedJob && jobForm.title && jobForm.department && jobForm.description) {
      const success = IntegratedDataStore.updateJob(selectedJob.id, jobForm);
      if (success) {
        setJobs(IntegratedDataStore.getJobs());
        setIsCreateDialogOpen(false);
        setJobForm({});
        setSelectedJob(null);
        alert('Vaga atualizada com sucesso!');
      }
    } else {
      alert('Por favor, preencha todos os campos obrigatórios.');
    }
  };

  const handleApplyToJob = (jobId: string) => {
    if (user) {
      // Check if user already applied
      const job = jobs.find(j => j.id === jobId);
      const hasApplied = job?.applications.some(app => app.candidateEmail === user.email);

      if (hasApplied) {
        alert('Você já se candidatou para esta vaga!');
        return;
      }

      // Add application using IntegratedDataStore
      const updatedJob = IntegratedDataStore.getJob(jobId);
      if (updatedJob) {
        const newApplication: JobApplication = {
          id: `app_${Date.now()}`,
          jobId: jobId,
          candidateName: user.name,
          candidateEmail: user.email,
          status: 'pending',
          appliedDate: new Date().toISOString()
        };

        updatedJob.applications.push(newApplication);
        IntegratedDataStore.updateJob(jobId, updatedJob);
        setJobs(IntegratedDataStore.getJobs());
        alert('Candidatura enviada com sucesso!');
      }
    } else {
      alert('Você precisa estar logado para se candidatar.');
    }
  };

  const handleExportJobs = () => {
    const dataStr = JSON.stringify(filteredJobs, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);

    const exportFileDefaultName = `vagas_${new Date().toISOString().split('T')[0]}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleShareJob = (job: Job) => {
    setSelectedJob(job);
    setIsShareDialogOpen(true);
  };

  const handleCopyJobLink = (jobId: string) => {
    const jobUrl = `${window.location.origin}/job/${jobId}`;
    navigator.clipboard.writeText(jobUrl).then(() => {
      alert('Link copiado para a área de transferência!');
    });
  };

  const handleUpdateApplicationStatus = (applicationId: string, newStatus: JobApplication['status'], notes?: string) => {
    if (!selectedJob) return;

    const updatedJob = { ...selectedJob };
    const applicationIndex = updatedJob.applications.findIndex(app => app.id === applicationId);

    if (applicationIndex !== -1) {
      updatedJob.applications[applicationIndex] = {
        ...updatedJob.applications[applicationIndex],
        status: newStatus,
        notes: notes || updatedJob.applications[applicationIndex].notes
      };

      IntegratedDataStore.updateJob(selectedJob.id, updatedJob);
      setJobs(IntegratedDataStore.getJobs());
      setSelectedJob(updatedJob);

      alert(`Status da candidatura atualizado para: ${getStatusDisplayName(newStatus)}`);
    }
  };

  const getStatusDisplayName = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'interviewing': return 'Em Entrevista';
      case 'approved': return 'Aprovado';
      case 'rejected': return 'Rejeitado';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'interviewing': return 'bg-blue-100 text-blue-700';
      case 'approved': return 'bg-green-100 text-green-700';
      case 'rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const scheduleInterview = (application: JobApplication) => {
    const interviewDate = prompt('Digite a data e hora da entrevista (ex: 25/01/2024 14:00):');
    if (interviewDate) {
      const notes = `${application.notes || ''}\n\nEntrevista agendada para: ${interviewDate}`;
      handleUpdateApplicationStatus(application.id, 'interviewing', notes);
    }
  };

  const stats = useMemo(() => {
    const totalApplications = jobs.reduce((acc, job) => acc + job.applications.length, 0);
    return {
      total: jobs.length,
      open: jobs.filter(job => job.status === 'open').length,
      closed: jobs.filter(job => job.status === 'closed').length,
      draft: jobs.filter(job => job.status === 'draft').length,
      totalApplications
    };
  }, [jobs]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Briefcase className="w-8 h-8 mr-3 text-purple-600" />
            Gestão de Vagas
          </h1>
          <p className="text-gray-600 mt-1">
            Sistema completo de recrutamento e seleção
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" onClick={handleExportJobs}>
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          {canCreate && (
            <Button onClick={handleCreateJob} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Nova Vaga
            </Button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Briefcase className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Abertas</p>
                <p className="text-3xl font-bold text-green-600">{stats.open}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Fechadas</p>
                <p className="text-3xl font-bold text-gray-600">{stats.closed}</p>
              </div>
              <XCircle className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Rascunhos</p>
                <p className="text-3xl font-bold text-orange-600">{stats.draft}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Candidaturas</p>
                <p className="text-3xl font-bold text-blue-600">{stats.totalApplications}</p>
              </div>
              <Users className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por título, departamento..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="open">Abertas</SelectItem>
                  <SelectItem value="closed">Fechadas</SelectItem>
                  <SelectItem value="draft">Rascunhos</SelectItem>
                </SelectContent>
              </Select>

              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Departamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os Departamentos</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredJobs.length} de {jobs.length} vaga(s)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredJobs.map((job) => (
          <Card key={job.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2">{job.title}</CardTitle>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center">
                      <Building2 className="w-4 h-4 mr-1" />
                      {job.department}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {job.type === 'full_time' ? 'Tempo Integral' : 
                       job.type === 'part_time' ? 'Meio Período' : 'Contrato'}
                    </div>
                    {job.salary && (
                      <div className="flex items-center">
                        <DollarSign className="w-4 h-4 mr-1" />
                        {job.salary}
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                    {job.description}
                  </p>
                </div>
                <div className="ml-4">
                  {getStatusBadge(job.status)}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    {format(new Date(job.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                  </div>
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-1" />
                    {job.applications.length} candidatura(s)
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {canApply && job.status === 'open' && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleApplyToJob(job.id)}
                    >
                      <Send className="w-4 h-4 mr-1" />
                      Candidatar
                    </Button>
                  )}
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleViewJob(job)}>
                        <Eye className="w-4 h-4 mr-2" />
                        Visualizar
                      </DropdownMenuItem>
                      {canEdit && (
                        <>
                          <DropdownMenuItem onClick={() => handleEditJob(job)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Share2 className="w-4 h-4 mr-2" />
                            Compartilhar
                          </DropdownMenuItem>
                        </>
                      )}
                      {job.applications.length > 0 && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleViewApplications(job)}>
                            <Users className="w-4 h-4 mr-2" />
                            Ver Candidaturas ({job.applications.length})
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredJobs.length === 0 && (
        <div className="text-center py-12">
          <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhuma vaga encontrada
          </h3>
          <p className="text-gray-600 mb-4">
            {searchTerm || statusFilter !== 'all' || departmentFilter !== 'all'
              ? 'Tente ajustar os filtros de busca'
              : 'Comece criando sua primeira oportunidade de emprego'
            }
          </p>
          {canCreate && (searchTerm === '' && statusFilter === 'all' && departmentFilter === 'all') && (
            <Button onClick={handleCreateJob}>
              <Plus className="w-4 h-4 mr-2" />
              Criar Primeira Vaga
            </Button>
          )}
        </div>
      )}

      {/* View Job Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedJob?.title}</DialogTitle>
            <DialogDescription>
              {selectedJob?.department} • {selectedJob?.type === 'full_time' ? 'Tempo Integral' : 
               selectedJob?.type === 'part_time' ? 'Meio Período' : 'Contrato'}
            </DialogDescription>
          </DialogHeader>
          
          {selectedJob && (
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                {getStatusBadge(selectedJob.status)}
                {selectedJob.salary && (
                  <Badge variant="outline">{selectedJob.salary}</Badge>
                )}
                <Badge variant="secondary">
                  {selectedJob.applications.length} candidatura(s)
                </Badge>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Descrição da Vaga</h4>
                <p className="text-gray-700 whitespace-pre-wrap">{selectedJob.description}</p>
              </div>

              {selectedJob.requirements.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Requisitos</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {selectedJob.requirements.map((req, index) => (
                      <li key={index} className="text-gray-700">{req}</li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedJob.benefits.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Benefícios</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {selectedJob.benefits.map((benefit, index) => (
                      <li key={index} className="text-gray-700">{benefit}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="pt-4 border-t">
                <p className="text-sm text-gray-600">
                  Criada em {format(new Date(selectedJob.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                </p>
              </div>

              {canApply && selectedJob.status === 'open' && (
                <div className="flex justify-end">
                  <Button 
                    onClick={() => handleApplyToJob(selectedJob.id)}
                    className="bg-gradient-to-r from-purple-600 to-blue-600"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Candidatar-se a esta Vaga
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Applications Dialog - Pipeline System */}
      <Dialog open={isApplicationsDialogOpen} onOpenChange={setIsApplicationsDialogOpen}>
        <DialogContent className="max-w-7xl">
          <DialogHeader>
            <DialogTitle>Pipeline de Candidatos - {selectedJob?.title}</DialogTitle>
            <DialogDescription>
              {selectedJob?.applications.length} candidatura(s) recebida(s) • Acompanhe o progresso de cada candidato
            </DialogDescription>
          </DialogHeader>

          {selectedJob && (
            <div className="space-y-6">
              {selectedJob.applications.length > 0 ? (
                <div className="space-y-6">
                  {/* Pipeline Stages */}
                  <div className="grid grid-cols-7 gap-2 text-center text-sm font-medium">
                    <div className="p-2 bg-gray-100 rounded">Aplicação</div>
                    <div className="p-2 bg-blue-100 rounded">Triagem</div>
                    <div className="p-2 bg-yellow-100 rounded">Tel. Interview</div>
                    <div className="p-2 bg-purple-100 rounded">Teste Técnico</div>
                    <div className="p-2 bg-orange-100 rounded">Entrevista Final</div>
                    <div className="p-2 bg-green-100 rounded">Aprovado</div>
                    <div className="p-2 bg-red-100 rounded">Rejeitado</div>
                  </div>

                  {/* Candidates */}
                  <div className="space-y-4">
                    {selectedJob.applications.map((application) => (
                      <Card key={application.id} className="p-4">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                              <span className="text-purple-600 font-semibold">
                                {application.candidateName.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div>
                              <h4 className="font-medium">{application.candidateName}</h4>
                              <p className="text-sm text-gray-600">{application.candidateEmail}</p>
                              {application.phone && (
                                <p className="text-sm text-gray-500">{application.phone}</p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge>{getApplicationStatusBadge(application.status)}</Badge>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <ArrowRight className="w-4 h-4 mr-2" />
                                  Avançar Etapa
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Eye className="w-4 h-4 mr-2" />
                                  Ver Detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Calendar className="w-4 h-4 mr-2" />
                                  Agendar Entrevista
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-green-600">
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                  Aprovar
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-red-600">
                                  <XCircle className="w-4 h-4 mr-2" />
                                  Rejeitar
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>

                        {/* Pipeline Progress */}
                        <div className="grid grid-cols-7 gap-2 mb-4">
                          {[0, 1, 2, 3, 4, 5, 6].map((stage) => (
                            <div
                              key={stage}
                              className={`h-2 rounded ${
                                stage <= (application.currentStage || 0)
                                  ? stage === 6 ? 'bg-red-400' : 'bg-blue-400'
                                  : 'bg-gray-200'
                              }`}
                            />
                          ))}
                        </div>

                        {/* Latest Stage History */}
                        {application.stageHistory && application.stageHistory.length > 0 && (
                          <div className="text-sm text-gray-600">
                            <span className="font-medium">Último movimento:</span>{' '}
                            {application.stageHistory[application.stageHistory.length - 1].stage} -{' '}
                            {format(
                              new Date(application.stageHistory[application.stageHistory.length - 1].date),
                              'dd/MM/yyyy',
                              { locale: ptBR }
                            )}
                            {application.stageHistory[application.stageHistory.length - 1].notes && (
                              <div className="mt-1 text-xs bg-gray-50 p-2 rounded">
                                {application.stageHistory[application.stageHistory.length - 1].notes}
                              </div>
                            )}
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Nenhuma candidatura ainda
                  </h3>
                  <p className="text-gray-600">
                    As candidaturas aparecerão aqui quando os candidatos se inscreverem
                  </p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create/Edit Job Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{selectedJob ? 'Editar Vaga' : 'Nova Vaga'}</DialogTitle>
            <DialogDescription>
              {selectedJob ? 'Atualize as informações da vaga' : 'Crie uma nova oportunidade de emprego'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="job-title">Título da Vaga</Label>
                <Input
                  id="job-title"
                  value={jobForm.title || ''}
                  onChange={(e) => setJobForm({...jobForm, title: e.target.value})}
                  placeholder="Ex: Desenvolvedor Full Stack"
                />
              </div>
              <div>
                <Label htmlFor="job-department">Departamento</Label>
                <Input
                  id="job-department"
                  value={jobForm.department || ''}
                  onChange={(e) => setJobForm({...jobForm, department: e.target.value})}
                  placeholder="Ex: Tecnologia"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="job-type">Tipo de Contrato</Label>
                <Select 
                  value={jobForm.type || ''} 
                  onValueChange={(value) => setJobForm({...jobForm, type: value as Job['type']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full_time">Tempo Integral</SelectItem>
                    <SelectItem value="part_time">Meio Período</SelectItem>
                    <SelectItem value="contract">Contrato</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="job-salary">Faixa Salarial (opcional)</Label>
                <Input
                  id="job-salary"
                  value={jobForm.salary || ''}
                  onChange={(e) => setJobForm({...jobForm, salary: e.target.value})}
                  placeholder="Ex: R$ 5.000 - R$ 8.000"
                />
              </div>
              <div>
                <Label htmlFor="job-status">Status</Label>
                <Select 
                  value={jobForm.status || ''} 
                  onValueChange={(value) => setJobForm({...jobForm, status: value as Job['status']})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Rascunho</SelectItem>
                    <SelectItem value="open">Aberta</SelectItem>
                    <SelectItem value="closed">Fechada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="job-description">Descrição da Vaga</Label>
              <Textarea
                id="job-description"
                value={jobForm.description || ''}
                onChange={(e) => setJobForm({...jobForm, description: e.target.value})}
                placeholder="Descreva as responsabilidades, objetivos e detalhes da posição..."
                rows={6}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="job-requirements">Requisitos (um por linha)</Label>
                <Textarea
                  id="job-requirements"
                  value={jobForm.requirements?.join('\n') || ''}
                  onChange={(e) => setJobForm({
                    ...jobForm, 
                    requirements: e.target.value.split('\n').filter(r => r.trim())
                  })}
                  placeholder="React&#10;Node.js&#10;3+ anos de experiência"
                  rows={4}
                />
              </div>
              <div>
                <Label htmlFor="job-benefits">Benefícios (um por linha)</Label>
                <Textarea
                  id="job-benefits"
                  value={jobForm.benefits?.join('\n') || ''}
                  onChange={(e) => setJobForm({
                    ...jobForm, 
                    benefits: e.target.value.split('\n').filter(b => b.trim())
                  })}
                  placeholder="Vale refeição&#10;Plano de saúde&#10;Home office flexível"
                  rows={4}
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <Button variant="outline" onClick={() => {
                setIsCreateDialogOpen(false);
                setSelectedJob(null);
                setJobForm({});
              }}>
                Cancelar
              </Button>
              <Button onClick={selectedJob ? handleUpdateJob : handleSaveJob}>
                {selectedJob ? 'Atualizar Vaga' : 'Criar Vaga'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Job Dialog */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Share2 className="w-5 h-5 mr-2" />
              Compartilhar Vaga
            </DialogTitle>
            <DialogDescription>
              Sua vaga foi criada com sucesso! Compartilhe para atrair candidatos.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Public Link */}
            <div className="space-y-2">
              <Label>Link Público da Vaga</Label>
              <div className="flex space-x-2">
                <Input
                  value={generateJobLink(createdJobId)}
                  readOnly
                  className="flex-1 text-sm"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyJobLink(createdJobId)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Social Sharing */}
            <div className="space-y-2">
              <Label>Compartilhar em Redes Sociais</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => shareJobSocial(createdJobId, 'whatsapp')}
                  className="flex items-center justify-center"
                >
                  <Phone className="w-4 h-4 mr-1" />
                  WhatsApp
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => shareJobSocial(createdJobId, 'linkedin')}
                  className="flex items-center justify-center"
                >
                  <Link className="w-4 h-4 mr-1" />
                  LinkedIn
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => shareJobSocial(createdJobId, 'email')}
                  className="flex items-center justify-center"
                >
                  <MessageSquare className="w-4 h-4 mr-1" />
                  Email
                </Button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setIsShareDialogOpen(false)}>
                Fechar
              </Button>
              <Button onClick={() => {
                setIsShareDialogOpen(false);
                // Navigate to process selection to see the job
                window.location.href = '/selection-process';
              }}>
                Ver no Processo Seletivo
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
