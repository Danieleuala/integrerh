import { useState, useMemo, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import {
  Users, Plus, Search, Filter, MoreHorizontal, Eye, Edit,
  Star, MapPin, Calendar, Briefcase, GraduationCap, 
  Phone, Mail, Download, UserPlus, Target, Award
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface TalentProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  currentPosition?: string;
  expectedSalary?: string;
  availability: 'immediate' | 'two_weeks' | 'one_month' | 'negotiable';
  experience: string; // Junior, Pleno, Senior
  skills: string[];
  education: string;
  summary: string;
  rating: number; // 1-5 stars
  status: 'available' | 'contacted' | 'interviewing' | 'hired' | 'unavailable';
  addedDate: string;
  lastContact?: string;
  documents: {
    cv?: string;
    portfolio?: string;
    certificates?: string[];
  };
  preferredAreas: string[];
  remoteWork: boolean;
  avatar?: string;
}

export default function TalentBank() {
  const { user } = useAuth();
  
  // Mock data for talent bank
  const [talents, setTalents] = useState<TalentProfile[]>([
    {
      id: '1',
      name: 'Ana Silva Santos',
      email: 'ana.silva@email.com',
      phone: '(11) 99999-9999',
      location: 'São Paulo, SP',
      currentPosition: 'Desenvolvedora Frontend',
      expectedSalary: 'R$ 8.000 - R$ 12.000',
      availability: 'two_weeks',
      experience: 'Pleno',
      skills: ['React', 'TypeScript', 'Node.js', 'Git', 'Figma'],
      education: 'Tecnólogo em Sistemas para Internet',
      summary: 'Desenvolvedora com 4 anos de experiência em React e TypeScript. Especialista em interfaces responsivas e performance web.',
      rating: 5,
      status: 'available',
      addedDate: '2024-01-15',
      documents: {
        cv: 'curriculo_ana_silva.pdf',
        portfolio: 'https://anasilva.dev'
      },
      preferredAreas: ['Tecnologia', 'Startups', 'Desenvolvimento'],
      remoteWork: true
    },
    {
      id: '2',
      name: 'Carlos Mendes Oliveira',
      email: 'carlos.mendes@email.com',
      phone: '(11) 88888-8888',
      location: 'Rio de Janeiro, RJ',
      currentPosition: 'Analista de Marketing',
      expectedSalary: 'R$ 5.000 - R$ 7.000',
      availability: 'immediate',
      experience: 'Senior',
      skills: ['Marketing Digital', 'Google Ads', 'Analytics', 'SEO', 'Social Media'],
      education: 'Bacharel em Marketing',
      summary: 'Profissional com 8 anos de experiência em marketing digital. Especialista em campanhas de performance e growth hacking.',
      rating: 4,
      status: 'contacted',
      addedDate: '2024-01-10',
      lastContact: '2024-01-20',
      documents: {
        cv: 'curriculo_carlos_mendes.pdf'
      },
      preferredAreas: ['Marketing', 'E-commerce', 'Tecnologia'],
      remoteWork: false
    },
    {
      id: '3',
      name: 'Mariana Costa Lima',
      email: 'mariana.costa@email.com',
      phone: '(11) 77777-7777',
      location: 'Belo Horizonte, MG',
      expectedSalary: 'R$ 6.000 - R$ 9.000',
      availability: 'one_month',
      experience: 'Pleno',
      skills: ['UX/UI Design', 'Figma', 'Adobe XD', 'Prototyping', 'User Research'],
      education: 'Bacharel em Design Gráfico',
      summary: 'Designer UX/UI com 5 anos de experiência. Focada em design centrado no usuário e interfaces intuitivas.',
      rating: 5,
      status: 'interviewing',
      addedDate: '2024-01-08',
      lastContact: '2024-01-18',
      documents: {
        cv: 'curriculo_mariana_costa.pdf',
        portfolio: 'https://marianadesign.com'
      },
      preferredAreas: ['Design', 'Produto', 'Tecnologia'],
      remoteWork: true
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [experienceFilter, setExperienceFilter] = useState<string>('all');
  const [locationFilter, setLocationFilter] = useState<string>('all');
  const [selectedTalent, setSelectedTalent] = useState<TalentProfile | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newTalent, setNewTalent] = useState<Partial<TalentProfile>>({});
  const [isContactDialogOpen, setIsContactDialogOpen] = useState(false);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [contactMessage, setContactMessage] = useState('');
  const [selectedJob, setSelectedJob] = useState('');

  // Load additional talents from localStorage (from job applications)
  useEffect(() => {
    const storedTalents = JSON.parse(localStorage.getItem('talentBank') || '[]');
    if (storedTalents.length > 0) {
      // Merge with existing mock data, avoiding duplicates
      const existingEmails = talents.map(t => t.email);
      const newTalents = storedTalents.filter((t: TalentProfile) => !existingEmails.includes(t.email));
      if (newTalents.length > 0) {
        setTalents(prev => [...prev, ...newTalents]);
      }
    }
  }, []);

  // Check permissions
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']) || true;
  const canAdd = hasPermission(user?.role || 'employee', ['rh_admin']) || true;

  // Filter talents
  const filteredTalents = useMemo(() => {
    return talents.filter(talent => {
      const matchesSearch = talent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           talent.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           talent.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
                           talent.preferredAreas.some(area => area.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesStatus = statusFilter === 'all' || talent.status === statusFilter;
      const matchesExperience = experienceFilter === 'all' || talent.experience === experienceFilter;
      const matchesLocation = locationFilter === 'all' || talent.location.includes(locationFilter);
      
      return matchesSearch && matchesStatus && matchesExperience && matchesLocation;
    });
  }, [talents, searchTerm, statusFilter, experienceFilter, locationFilter]);

  // Get unique locations
  const locations = useMemo(() => {
    const locs = [...new Set(talents.map(talent => talent.location.split(',')[1]?.trim()).filter(Boolean))];
    return locs.sort();
  }, [talents]);

  const getStatusBadge = (status: TalentProfile['status']) => {
    switch (status) {
      case 'available':
        return <Badge variant="default" className="bg-green-100 text-green-700">Disponível</Badge>;
      case 'contacted':
        return <Badge variant="outline" className="border-blue-200 text-blue-700">Contatado</Badge>;
      case 'interviewing':
        return <Badge variant="outline" className="border-yellow-200 text-yellow-700">Em Processo</Badge>;
      case 'hired':
        return <Badge variant="default" className="bg-purple-100 text-purple-700">Contratado</Badge>;
      case 'unavailable':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-700">Indisponível</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getAvailabilityBadge = (availability: TalentProfile['availability']) => {
    switch (availability) {
      case 'immediate':
        return <Badge variant="default" className="bg-green-100 text-green-700">Imediato</Badge>;
      case 'two_weeks':
        return <Badge variant="outline" className="border-yellow-200 text-yellow-700">2 Semanas</Badge>;
      case 'one_month':
        return <Badge variant="outline" className="border-orange-200 text-orange-700">1 Mês</Badge>;
      case 'negotiable':
        return <Badge variant="secondary">A Negociar</Badge>;
      default:
        return <Badge variant="secondary">Não Informado</Badge>;
    }
  };

  const getExperienceBadge = (experience: string) => {
    switch (experience) {
      case 'Junior':
        return <Badge variant="outline" className="border-blue-200 text-blue-700">Junior</Badge>;
      case 'Pleno':
        return <Badge variant="outline" className="border-purple-200 text-purple-700">Pleno</Badge>;
      case 'Senior':
        return <Badge variant="outline" className="border-red-200 text-red-700">Senior</Badge>;
      default:
        return <Badge variant="secondary">{experience}</Badge>;
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${star <= rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
          />
        ))}
      </div>
    );
  };

  const handleViewTalent = (talent: TalentProfile) => {
    setSelectedTalent(talent);
    setIsViewDialogOpen(true);
  };

  const handleAddTalent = () => {
    if (newTalent.name && newTalent.email && newTalent.skills && newTalent.experience) {
      const talent: TalentProfile = {
        id: `talent_${Date.now()}`,
        name: newTalent.name,
        email: newTalent.email,
        phone: newTalent.phone || '',
        location: newTalent.location || '',
        currentPosition: newTalent.currentPosition,
        expectedSalary: newTalent.expectedSalary,
        availability: newTalent.availability || 'negotiable',
        experience: newTalent.experience,
        skills: typeof newTalent.skills === 'string' ? newTalent.skills.split(',').map(s => s.trim()) : [],
        education: newTalent.education || '',
        summary: newTalent.summary || '',
        rating: 3,
        status: 'available',
        addedDate: new Date().toISOString().split('T')[0],
        documents: {},
        preferredAreas: typeof newTalent.preferredAreas === 'string' ? newTalent.preferredAreas.split(',').map(s => s.trim()) : [],
        remoteWork: newTalent.remoteWork || false
      };

      setTalents([...talents, talent]);
      setIsAddDialogOpen(false);
      setNewTalent({});
    } else {
      alert('Preencha todos os campos obrigatórios: Nome, Email, Habilidades e Experiência');
    }
  };

  const handleContactTalent = (talent: TalentProfile) => {
    setSelectedTalent(talent);
    setContactMessage(`Olá ${talent.name},\n\nEntramos em contato através do nosso banco de talentos. Gostaríamos de conversar sobre oportunidades que podem ser interessantes para o seu perfil.\n\nFicamos à disposição para agendar uma conversa.\n\nAtenciosamente,\nEquipe de RH`);
    setIsContactDialogOpen(true);
  };

  const handleInviteToJob = (talent: TalentProfile) => {
    setSelectedTalent(talent);
    setIsInviteDialogOpen(true);
  };

  const sendContact = () => {
    if (!selectedTalent) return;

    // Update talent status to contacted
    const updatedTalents = talents.map(t =>
      t.id === selectedTalent.id
        ? { ...t, status: 'contacted' as const, lastContact: new Date().toISOString() }
        : t
    );
    setTalents(updatedTalents);

    // Save to localStorage
    const storedTalents = JSON.parse(localStorage.getItem('talentBank') || '[]');
    const updatedStored = storedTalents.map((t: TalentProfile) =>
      t.id === selectedTalent.id
        ? { ...t, status: 'contacted' as const, lastContact: new Date().toISOString() }
        : t
    );
    localStorage.setItem('talentBank', JSON.stringify(updatedStored));

    // Simulate email sending (would integrate with actual email service)
    alert(`Mensagem enviada para ${selectedTalent.name} (${selectedTalent.email})`);

    setIsContactDialogOpen(false);
    setContactMessage('');
    setSelectedTalent(null);
  };

  const sendJobInvite = () => {
    if (!selectedTalent || !selectedJob) return;

    // Update talent status
    const updatedTalents = talents.map(t =>
      t.id === selectedTalent.id
        ? { ...t, status: 'contacted' as const, lastContact: new Date().toISOString() }
        : t
    );
    setTalents(updatedTalents);

    // Simulate job invitation email
    alert(`Convite para vaga enviado para ${selectedTalent.name} (${selectedTalent.email})`);

    setIsInviteDialogOpen(false);
    setSelectedJob('');
    setSelectedTalent(null);
  };

  const stats = useMemo(() => {
    return {
      total: talents.length,
      available: talents.filter(t => t.status === 'available').length,
      contacted: talents.filter(t => t.status === 'contacted').length,
      interviewing: talents.filter(t => t.status === 'interviewing').length,
      hired: talents.filter(t => t.status === 'hired').length
    };
  }, [talents]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Users className="w-8 h-8 mr-3 text-purple-600" />
            Banco de Talentos
          </h1>
          <p className="text-gray-600 mt-1">
            Gerencie e acompanhe candidatos qualificados para futuras oportunidades
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          {canAdd && (
            <Button onClick={() => setIsAddDialogOpen(true)} className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Talento
            </Button>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Users className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Disponíveis</p>
                <p className="text-3xl font-bold text-green-600">{stats.available}</p>
              </div>
              <Target className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Contatados</p>
                <p className="text-3xl font-bold text-blue-600">{stats.contacted}</p>
              </div>
              <Mail className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Em Processo</p>
                <p className="text-3xl font-bold text-yellow-600">{stats.interviewing}</p>
              </div>
              <Briefcase className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Contratados</p>
                <p className="text-3xl font-bold text-purple-600">{stats.hired}</p>
              </div>
              <Award className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por nome, email, habilidades..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="available">Disponíveis</SelectItem>
                  <SelectItem value="contacted">Contatados</SelectItem>
                  <SelectItem value="interviewing">Em Processo</SelectItem>
                  <SelectItem value="hired">Contratados</SelectItem>
                  <SelectItem value="unavailable">Indisponíveis</SelectItem>
                </SelectContent>
              </Select>

              <Select value={experienceFilter} onValueChange={setExperienceFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Experiência" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="Junior">Junior</SelectItem>
                  <SelectItem value="Pleno">Pleno</SelectItem>
                  <SelectItem value="Senior">Senior</SelectItem>
                </SelectContent>
              </Select>

              <Select value={locationFilter} onValueChange={setLocationFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Local" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {locations.map(location => (
                    <SelectItem key={location} value={location}>{location}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredTalents.length} de {talents.length} talentos
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Talents Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Talentos</CardTitle>
          <CardDescription>
            Candidatos qualificados disponíveis para futuras oportunidades
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Talento</TableHead>
                <TableHead>Experiência</TableHead>
                <TableHead>Habilidades</TableHead>
                <TableHead>Disponibilidade</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Avaliação</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTalents.map((talent) => (
                <TableRow key={talent.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={talent.avatar} alt={talent.name} />
                        <AvatarFallback className="bg-purple-100 text-purple-600">
                          {talent.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-gray-900">{talent.name}</p>
                        <p className="text-sm text-gray-500">{talent.email}</p>
                        <div className="flex items-center text-xs text-gray-400 mt-1">
                          <MapPin className="w-3 h-3 mr-1" />
                          {talent.location}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      {getExperienceBadge(talent.experience)}
                      {talent.currentPosition && (
                        <p className="text-xs text-gray-500 mt-1">{talent.currentPosition}</p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {talent.skills.slice(0, 3).map((skill, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {talent.skills.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{talent.skills.length - 3}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    {getAvailabilityBadge(talent.availability)}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(talent.status)}
                  </TableCell>
                  <TableCell>
                    {renderStars(talent.rating)}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleViewTalent(talent)}>
                          <Eye className="w-4 h-4 mr-2" />
                          Visualizar Perfil
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleContactTalent(talent)}>
                          <Mail className="w-4 h-4 mr-2" />
                          Entrar em Contato
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleInviteToJob(talent)}>
                          <UserPlus className="w-4 h-4 mr-2" />
                          Convidar para Vaga
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredTalents.length === 0 && (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum talento encontrado
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== 'all' || experienceFilter !== 'all' || locationFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Comece adicionando talentos qualificados ao banco'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Talent Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-3">
              <Avatar className="w-12 h-12">
                <AvatarImage src={selectedTalent?.avatar} alt={selectedTalent?.name} />
                <AvatarFallback className="bg-purple-100 text-purple-600">
                  {selectedTalent?.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-xl font-bold">{selectedTalent?.name}</h3>
                <p className="text-gray-600">{selectedTalent?.currentPosition || 'Talento Disponível'}</p>
              </div>
            </DialogTitle>
          </DialogHeader>
          
          {selectedTalent && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 border-b pb-2">Informações de Contato</h4>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email</Label>
                    <div className="flex items-center mt-1">
                      <Mail className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedTalent.email}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Telefone</Label>
                    <div className="flex items-center mt-1">
                      <Phone className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedTalent.phone}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Localização</Label>
                    <div className="flex items-center mt-1">
                      <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                      <span>{selectedTalent.location}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Trabalho Remoto</Label>
                    <div className="mt-1">
                      <Badge variant={selectedTalent.remoteWork ? 'default' : 'secondary'}>
                        {selectedTalent.remoteWork ? 'Aceita Remoto' : 'Presencial'}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 border-b pb-2">Informações Profissionais</h4>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Nível de Experiência</Label>
                    <div className="mt-1">
                      {getExperienceBadge(selectedTalent.experience)}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Disponibilidade</Label>
                    <div className="mt-1">
                      {getAvailabilityBadge(selectedTalent.availability)}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Pretensão Salarial</Label>
                    <div className="mt-1">
                      <span>{selectedTalent.expectedSalary || 'A negociar'}</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Status Atual</Label>
                    <div className="mt-1">
                      {getStatusBadge(selectedTalent.status)}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-500">Avaliação</Label>
                    <div className="mt-1">
                      {renderStars(selectedTalent.rating)}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-500">Resumo Profissional</Label>
                <p className="mt-2 text-sm text-gray-700">{selectedTalent.summary}</p>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-500">Habilidades</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedTalent.skills.map((skill, index) => (
                    <Badge key={index} variant="outline">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-500">Áreas de Interesse</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedTalent.preferredAreas.map((area, index) => (
                    <Badge key={index} variant="secondary">
                      {area}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-500">Formação</Label>
                <div className="flex items-center mt-1">
                  <GraduationCap className="w-4 h-4 mr-2 text-gray-400" />
                  <span>{selectedTalent.education}</span>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-gray-500">Adicionado em</Label>
                <div className="flex items-center mt-1">
                  <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                  <span>{format(new Date(selectedTalent.addedDate), 'dd/MM/yyyy', { locale: ptBR })}</span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Talent Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Novo Talento</DialogTitle>
            <DialogDescription>
              Cadastre um novo candidato qualificado ao banco de talentos
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 max-h-96 overflow-y-auto">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  value={newTalent.name || ''}
                  onChange={(e) => setNewTalent({...newTalent, name: e.target.value})}
                  placeholder="Nome do candidato"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={newTalent.email || ''}
                  onChange={(e) => setNewTalent({...newTalent, email: e.target.value})}
                  placeholder="email@exemplo.com"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={newTalent.phone || ''}
                  onChange={(e) => setNewTalent({...newTalent, phone: e.target.value})}
                  placeholder="(11) 99999-9999"
                />
              </div>
              <div>
                <Label htmlFor="location">Localização</Label>
                <Input
                  id="location"
                  value={newTalent.location || ''}
                  onChange={(e) => setNewTalent({...newTalent, location: e.target.value})}
                  placeholder="Cidade, Estado"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="experience">Experiência *</Label>
                <Select onValueChange={(value) => setNewTalent({...newTalent, experience: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o nível" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Junior">Junior</SelectItem>
                    <SelectItem value="Pleno">Pleno</SelectItem>
                    <SelectItem value="Senior">Senior</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="availability">Disponibilidade</Label>
                <Select onValueChange={(value) => setNewTalent({...newTalent, availability: value as TalentProfile['availability']})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Quando pode começar" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediate">Imediato</SelectItem>
                    <SelectItem value="two_weeks">2 Semanas</SelectItem>
                    <SelectItem value="one_month">1 Mês</SelectItem>
                    <SelectItem value="negotiable">A Negociar</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="skills">Habilidades * (separadas por vírgula)</Label>
              <Input
                id="skills"
                value={newTalent.skills || ''}
                onChange={(e) => setNewTalent({...newTalent, skills: e.target.value})}
                placeholder="React, TypeScript, Node.js, etc."
              />
            </div>

            <div>
              <Label htmlFor="preferredAreas">Áreas de Interesse (separadas por vírgula)</Label>
              <Input
                id="preferredAreas"
                value={newTalent.preferredAreas || ''}
                onChange={(e) => setNewTalent({...newTalent, preferredAreas: e.target.value})}
                placeholder="Tecnologia, Marketing, Design, etc."
              />
            </div>

            <div>
              <Label htmlFor="summary">Resumo Profissional</Label>
              <Textarea
                id="summary"
                value={newTalent.summary || ''}
                onChange={(e) => setNewTalent({...newTalent, summary: e.target.value})}
                placeholder="Breve descrição da experiência e objetivos profissionais..."
                rows={3}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddTalent}>
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Talento
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Contact Dialog */}
      <Dialog open={isContactDialogOpen} onOpenChange={setIsContactDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Mail className="w-5 h-5 text-blue-600" />
              <span>Entrar em Contato</span>
            </DialogTitle>
            <DialogDescription>
              {selectedTalent && `Enviar mensagem para ${selectedTalent.name}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {selectedTalent && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-blue-100 text-blue-600">
                      {selectedTalent.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{selectedTalent.name}</p>
                    <p className="text-sm text-gray-600">{selectedTalent.email}</p>
                  </div>
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="contact-message">Mensagem</Label>
              <Textarea
                id="contact-message"
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                rows={6}
                placeholder="Digite sua mensagem..."
                className="mt-2"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsContactDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={sendContact}
              disabled={!contactMessage.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Mail className="w-4 h-4 mr-2" />
              Enviar Contato
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invite to Job Dialog */}
      <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <UserPlus className="w-5 h-5 text-green-600" />
              <span>Convidar para Vaga</span>
            </DialogTitle>
            <DialogDescription>
              {selectedTalent && `Convide ${selectedTalent.name} para uma vaga`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {selectedTalent && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-green-100 text-green-600">
                      {selectedTalent.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{selectedTalent.name}</p>
                    <p className="text-sm text-gray-600">{selectedTalent.email}</p>
                  </div>
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="job-select">Selecionar Vaga</Label>
              <Select value={selectedJob} onValueChange={setSelectedJob}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Escolha uma vaga disponível" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="job1">Desenvolvedor Frontend - React</SelectItem>
                  <SelectItem value="job2">Analista de Marketing Digital</SelectItem>
                  <SelectItem value="job3">Designer UX/UI</SelectItem>
                  <SelectItem value="job4">Gerente de Projetos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsInviteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={sendJobInvite}
              disabled={!selectedJob}
              className="bg-green-600 hover:bg-green-700"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Enviar Convite
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
