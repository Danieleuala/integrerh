import { useState, useMemo } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { IntegratedDataStore } from '@/lib/mockData';
import { ReportGenerator, DEFAULT_REPORT_MODULES } from '@/components/ReportGenerator';
import {
  generatePDFReport,
  generateExcelReport,
  sortReportData,
  filterReportData,
  type ReportConfig,
  type ReportData
} from '@/lib/reportUtils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  BarChart3, Download, Calendar, Users, TrendingUp, TrendingDown,
  Target, Clock, Award, MessageSquare, Briefcase, BookOpen,
  FileText, PieChart, LineChart, Activity, Zap, AlertTriangle
} from 'lucide-react';
import { format, subDays, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Reports() {
  const { user } = useAuth();
  const [dateRange, setDateRange] = useState('last30days');
  const [reportType, setReportType] = useState('overview');

  const employees = IntegratedDataStore.getEmployees();
  const jobs = IntegratedDataStore.getJobs();
  const trainings = IntegratedDataStore.getTrainings();
  const evaluations = IntegratedDataStore.getEvaluations();
  const feedbacks = IntegratedDataStore.getFeedbacks();

  const canViewAll = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);

  const dashboardData = useMemo(() => {
    const today = new Date();
    const last30Days = subDays(today, 30);
    const last90Days = subDays(today, 90);
    const lastYear = subDays(today, 365);

    // Employee metrics
    const activeEmployees = employees.filter(emp => emp.status === 'active');
    const inactiveEmployees = employees.filter(emp => emp.status === 'inactive');
    const onLeaveEmployees = employees.filter(emp => emp.status === 'on_leave');

    // Department distribution
    const departmentCounts = employees.reduce((acc, emp) => {
      acc[emp.department] = (acc[emp.department] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Jobs metrics
    const openJobs = jobs.filter(job => job.status === 'open');
    const totalApplications = jobs.reduce((acc, job) => acc + job.applications.length, 0);
    const avgApplicationsPerJob = openJobs.length > 0 ? totalApplications / openJobs.length : 0;

    // Training metrics
    const activeTrainings = trainings.filter(training => training.status === 'in_progress');
    const completedTrainings = trainings.filter(training => training.status === 'completed');
    const trainingParticipants = trainings.reduce((acc, training) => acc + training.participants.length, 0);

    // Performance metrics
    const avgPerformance = evaluations.length > 0
      ? evaluations.reduce((acc, evaluation) => acc + evaluation.overallScore, 0) / evaluations.length
      : 0;

    // Recent feedback activity
    const recentFeedbacks = feedbacks.filter(feedback => {
      const feedbackDate = new Date(feedback.date);
      return feedbackDate >= last30Days;
    });

    // Turnover calculation (simplified)
    const turnoverRate = employees.length > 0 
      ? (inactiveEmployees.length / employees.length) * 100 
      : 0;

    return {
      employees: {
        total: employees.length,
        active: activeEmployees.length,
        inactive: inactiveEmployees.length,
        onLeave: onLeaveEmployees.length,
        turnoverRate: turnoverRate.toFixed(1),
        departmentDistribution: departmentCounts
      },
      jobs: {
        total: jobs.length,
        open: openJobs.length,
        applications: totalApplications,
        avgApplications: avgApplicationsPerJob.toFixed(1)
      },
      trainings: {
        total: trainings.length,
        active: activeTrainings.length,
        completed: completedTrainings.length,
        participants: trainingParticipants
      },
      performance: {
        average: avgPerformance.toFixed(1),
        evaluations: evaluations.length,
        recentFeedbacks: recentFeedbacks.length
      }
    };
  }, [employees, jobs, trainings, evaluations, feedbacks]);

  // Prepare data for each report module
  const prepareReportData = (moduleId: string): any[] => {
    switch (moduleId) {
      case 'employees':
        return employees.map(emp => ({
          name: emp.name,
          email: emp.email,
          phone: emp.phone,
          position: emp.position,
          department: emp.department,
          joinDate: emp.joinDate,
          status: emp.status,
          salary: emp.salary || 'Não informado',
          terminationDate: emp.terminationDate || null,
          terminationReason: emp.terminationReason || null
        }));

      case 'jobs':
        return jobs.map(job => ({
          title: job.title,
          department: job.department,
          status: job.status,
          applications: job.applications.length,
          createdDate: job.createdDate,
          responsible: job.responsible || 'Não definido',
          salary: job.salary || 'A combinar',
          type: job.type === 'full_time' ? 'Tempo Integral' : job.type === 'part_time' ? 'Meio Período' : 'Contrato'
        }));

      case 'trainings':
        return trainings.map(training => ({
          title: training.title,
          target: training.target || 'Todos os colaboradores',
          status: training.status,
          participants: training.participants.length,
          startDate: training.startDate,
          endDate: training.endDate,
          duration: training.duration || 0,
          instructor: training.instructor || 'Interno'
        }));

      case 'evaluations':
        return evaluations.map(evaluation => ({
          employeeName: evaluation.employeeName,
          position: evaluation.position || 'Não informado',
          evaluationType: evaluation.type || 'Performance',
          overallScore: evaluation.overallScore,
          evaluationDate: evaluation.date,
          status: evaluation.status || 'completed',
          evaluator: evaluation.evaluatorName || 'Sistema',
          period: evaluation.period || 'Anual'
        }));


      case 'terminations':
        return employees.filter(emp => emp.status === 'inactive' || emp.terminationDate).map(emp => ({
          name: emp.name,
          position: emp.position,
          terminationDate: emp.terminationDate || format(new Date(), 'yyyy-MM-dd'),
          terminationReason: emp.terminationReason || 'Não informado',
          responsible: 'RH',
          type: emp.terminationReason?.includes('pedido') ? 'Pedido' :
                emp.terminationReason?.includes('justa') ? 'Justa Causa' : 'Demissão',
          department: emp.department,
          timeInCompany: emp.joinDate ? `${Math.floor((new Date().getTime() - new Date(emp.joinDate).getTime()) / (1000 * 60 * 60 * 24 * 365))} anos` : 'Não calculado'
        }));

      default:
        return [];
    }
  };

  // Generate report by type ID
  const generateReport = async (reportId: string) => {
    try {
      const config: ReportConfig = {
        moduleId: reportId,
        format: 'pdf',
        title: `Relatório ${reportId}`,
        description: `Relatório gerado automaticamente para ${reportId}`,
        dateRange: {
          start: format(addDays(new Date(), -30), 'yyyy-MM-dd'),
          end: format(new Date(), 'yyyy-MM-dd')
        },
        filters: {},
        selectedFields: [],
        sortBy: 'date',
        sortOrder: 'desc'
      };

      await handleReportGeneration(config);
    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
      alert('Erro ao gerar relatório. Tente novamente.');
    }
  };

  // Enhanced report generation with the new system
  const handleReportGeneration = async (config: ReportConfig) => {
    try {
      // Get raw data for the selected module
      let rawData = prepareReportData(config.moduleId);

      // Apply date filtering
      const filteredData = filterReportData(rawData, config);

      // Apply sorting
      const sortedData = sortReportData(filteredData, config);

      // Prepare report data
      const reportData: ReportData = {
        config,
        data: sortedData,
        metadata: {
          generatedAt: new Date().toISOString(),
          generatedBy: user?.name || 'Sistema',
          totalRecords: rawData.length,
          filteredRecords: sortedData.length
        }
      };

      // Generate report based on format
      if (config.format === 'pdf') {
        await generatePDFReport(reportData);
      } else {
        await generateExcelReport(reportData);
      }

    } catch (error) {
      console.error('Report generation error:', error);
      throw error;
    }
  };

  const exportToPDF = () => {
    const reportData = {
      title: 'Relatório Integre RH',
      generatedAt: format(new Date(), 'dd/MM/yyyy HH:mm', { locale: ptBR }),
      dateRange,
      data: dashboardData
    };

    // Simulate PDF generation (in real app, would use library like jsPDF)
    const content = `
RELATÓRIO INTEGRE RH
====================
Gerado em: ${reportData.generatedAt}
Período: ${dateRange}

COLABORADORES
-------------
Total: ${dashboardData.employees.total}
Ativos: ${dashboardData.employees.active}
Inativos: ${dashboardData.employees.inactive}
Turnover: ${dashboardData.employees.turnoverRate}%

PERFORMANCE
-----------
Média Geral: ${dashboardData.performance.average}/10
Avaliações: ${dashboardData.performance.evaluations}
Feedbacks Recentes: ${dashboardData.performance.recentFeedbacks}

VAGAS
-----
Total: ${dashboardData.jobs.total}
Abertas: ${dashboardData.jobs.open}
Candidaturas: ${dashboardData.jobs.applications}

TREINAMENTOS
------------
Total: ${dashboardData.trainings.total}
Ativos: ${dashboardData.trainings.active}
Concluídos: ${dashboardData.trainings.completed}
    `;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `relatorio_integre_rh_${format(new Date(), 'yyyy-MM-dd')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportToExcel = () => {
    // Generate CSV data for Excel compatibility
    const csvData = [
      ['RELATÓRIO INTEGRE RH'],
      [`Gerado em: ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: ptBR })}`],
      [`Período: ${dateRange}`],
      [''],
      ['MÉTRICAS DE COLABORADORES'],
      ['Categoria', 'Valor'],
      ['Total de Colaboradores', dashboardData.employees.total],
      ['Colaboradores Ativos', dashboardData.employees.active],
      ['Colaboradores Inativos', dashboardData.employees.inactive],
      ['Taxa de Turnover (%)', dashboardData.employees.turnoverRate],
      [''],
      ['MÉTRICAS DE PERFORMANCE'],
      ['Categoria', 'Valor'],
      ['Performance Média', dashboardData.performance.average],
      ['Total de Avaliações', dashboardData.performance.evaluations],
      ['Feedbacks Recentes', dashboardData.performance.recentFeedbacks],
      [''],
      ['MÉTRICAS DE VAGAS'],
      ['Categoria', 'Valor'],
      ['Total de Vagas', dashboardData.jobs.total],
      ['Vagas Abertas', dashboardData.jobs.open],
      ['Total de Candidaturas', dashboardData.jobs.applications],
      [''],
      ['MÉTRICAS DE TREINAMENTOS'],
      ['Categoria', 'Valor'],
      ['Total de Treinamentos', dashboardData.trainings.total],
      ['Treinamentos Ativos', dashboardData.trainings.active],
      ['Treinamentos Concluídos', dashboardData.trainings.completed],
      [''],
      ['DISTRIBUIÇÃO POR DEPARTAMENTO'],
      ['Departamento', 'Quantidade', 'Percentual'],
      ...Object.entries(dashboardData.employees.departmentDistribution).map(([dept, count]) => [
        dept,
        count,
        `${((count / dashboardData.employees.total) * 100).toFixed(1)}%`
      ])
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `relatorio_integre_rh_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const reportTypes = [
    {
      id: 'overview',
      title: 'Visão Geral',
      description: 'Dashboard executivo com principais métricas',
      icon: BarChart3,
      color: 'bg-blue-500'
    },
    {
      id: 'employees',
      title: 'Colaboradores',
      description: 'Relatório detalhado da força de trabalho',
      icon: Users,
      color: 'bg-green-500'
    },
    {
      id: 'performance',
      title: 'Performance',
      description: 'Análise de desempenho e avaliações',
      icon: Award,
      color: 'bg-purple-500'
    },
    {
      id: 'recruitment',
      title: 'Recrutamento',
      description: 'Métricas de vagas e candidaturas',
      icon: Briefcase,
      color: 'bg-orange-500'
    },
    {
      id: 'training',
      title: 'Treinamentos',
      description: 'Acompanhamento de capacitação',
      icon: BookOpen,
      color: 'bg-indigo-500'
    },
    {
      id: 'feedback',
      title: 'Feedback',
      description: 'Análise de comunicação interna',
      icon: MessageSquare,
      color: 'bg-pink-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <BarChart3 className="w-8 h-8 mr-3 text-purple-600" />
            Relatórios e Analytics
          </h1>
          <p className="text-gray-600 mt-1">
            Business Intelligence e métricas de RH
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last7days">Últimos 7 dias</SelectItem>
              <SelectItem value="last30days">Últimos 30 dias</SelectItem>
              <SelectItem value="last90days">Últimos 90 dias</SelectItem>
              <SelectItem value="lastyear">Último ano</SelectItem>
            </SelectContent>
          </Select>

          {/* Enhanced Report Generator */}
          <ReportGenerator
            modules={DEFAULT_REPORT_MODULES.map(module => ({
              ...module,
              getData: () => prepareReportData(module.id)
            }))}
            onGenerate={handleReportGeneration}
          />

          {/* Legacy export buttons for backwards compatibility */}
          <Button variant="outline" size="sm" onClick={exportToPDF}>
            <FileText className="w-4 h-4 mr-2" />
            PDF Resumo
          </Button>
          <Button variant="outline" size="sm" onClick={exportToExcel}>
            <Download className="w-4 h-4 mr-2" />
            Excel Resumo
          </Button>
        </div>
      </div>

      {/* Key Metrics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Colaboradores Ativos</p>
                <p className="text-3xl font-bold text-gray-900">{dashboardData.employees.active}</p>
                <p className="text-xs text-green-600 flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {((dashboardData.employees.active / dashboardData.employees.total) * 100).toFixed(1)}%
                </p>
              </div>
              <Users className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Performance Média</p>
                <p className="text-3xl font-bold text-gray-900">{dashboardData.performance.average}</p>
                <p className="text-xs text-purple-600 flex items-center">
                  <Award className="w-3 h-3 mr-1" />
                  de 10.0 pontos
                </p>
              </div>
              <Award className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Turnover</p>
                <p className="text-3xl font-bold text-gray-900">{dashboardData.employees.turnoverRate}%</p>
                <p className="text-xs text-green-600 flex items-center">
                  <TrendingDown className="w-3 h-3 mr-1" />
                  Abaixo da média
                </p>
              </div>
              <Target className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vagas Abertas</p>
                <p className="text-3xl font-bold text-gray-900">{dashboardData.jobs.open}</p>
                <p className="text-xs text-orange-600 flex items-center">
                  <Briefcase className="w-3 h-3 mr-1" />
                  {dashboardData.jobs.applications} candidaturas
                </p>
              </div>
              <Briefcase className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Types */}
      <Card>
        <CardHeader>
          <CardTitle>Tipos de Relatórios</CardTitle>
          <CardDescription>
            Escolha o tipo de relatório para análise detalhada
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {reportTypes.map((report) => (
              <Card key={report.id} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-3">
                        <div className={`w-10 h-10 ${report.color} rounded-lg flex items-center justify-center mr-3`}>
                          <report.icon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{report.title}</h3>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-4">{report.description}</p>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => generateReport(report.id)}
                        className="w-full"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Gerar Relatório
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="w-5 h-5 mr-2" />
              Distribuição por Departamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(dashboardData.employees.departmentDistribution).map(([dept, count]) => {
                const percentage = (count / dashboardData.employees.total) * 100;
                return (
                  <div key={dept} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">{dept}</span>
                      <span className="text-sm text-gray-600">{count} ({percentage.toFixed(1)}%)</span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Training Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BookOpen className="w-5 h-5 mr-2" />
              Progresso de Treinamentos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {dashboardData.trainings.participants}
                </div>
                <p className="text-sm text-gray-600">Participantes Ativos</p>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Concluídos</span>
                  <span className="text-sm text-gray-600">{dashboardData.trainings.completed}</span>
                </div>
                <Progress 
                  value={(dashboardData.trainings.completed / dashboardData.trainings.total) * 100} 
                  className="h-2" 
                />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Em Andamento</span>
                  <span className="text-sm text-gray-600">{dashboardData.trainings.active}</span>
                </div>
                <Progress 
                  value={(dashboardData.trainings.active / dashboardData.trainings.total) * 100} 
                  className="h-2" 
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="w-5 h-5 mr-2" />
            Insights de Performance
          </CardTitle>
          <CardDescription>
            Análise automática dos principais indicadores
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex items-center mb-2">
                <Zap className="w-5 h-5 text-green-600 mr-2" />
                <span className="font-medium text-green-700">Performance Alta</span>
              </div>
              <p className="text-sm text-green-600">
                A média de performance está {dashboardData.performance.average} pontos, 
                {Number(dashboardData.performance.average) > 7 ? ' acima' : ' dentro'} do esperado.
              </p>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center mb-2">
                <Target className="w-5 h-5 text-blue-600 mr-2" />
                <span className="font-medium text-blue-700">Engajamento</span>
              </div>
              <p className="text-sm text-blue-600">
                {dashboardData.performance.recentFeedbacks} feedbacks nos últimos 30 dias 
                indicam boa comunicação interna.
              </p>
            </div>

            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="flex items-center mb-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mr-2" />
                <span className="font-medium text-orange-700">Atenção</span>
              </div>
              <p className="text-sm text-orange-600">
                {dashboardData.employees.onLeave} colaborador(es) afastado(s). 
                Monitorar impacto na produtividade.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
          <CardDescription>
            Gere relatórios específicos ou exporte dados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={() => generateReport('employees')}>
              <Users className="w-4 h-4 mr-2" />
              Relatório de Colaboradores
            </Button>
            <Button variant="outline" onClick={() => generateReport('performance')}>
              <Award className="w-4 h-4 mr-2" />
              Análise de Performance
            </Button>
            <Button variant="outline" onClick={() => generateReport('recruitment')}>
              <Briefcase className="w-4 h-4 mr-2" />
              Métricas de Recrutamento
            </Button>
            <Button variant="outline" onClick={() => generateReport('training')}>
              <BookOpen className="w-4 h-4 mr-2" />
              Progresso de Treinamentos
            </Button>
            <Button variant="outline" onClick={exportToPDF}>
              <FileText className="w-4 h-4 mr-2" />
              Dashboard Completo (PDF)
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
