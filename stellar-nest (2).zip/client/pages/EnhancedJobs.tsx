import { useState, useMemo, useEffect } from 'react';
import { useAuth, hasPermission } from '@/hooks/useAuth';
import { useSearchParams } from 'react-router-dom';
import { EnhancedDataStore, EnhancedJob, EnhancedJobApplication, Candidate, SelectionStage, Test } from '@/lib/enhancedData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, 
  DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuTrigger, DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { 
  Briefcase, Plus, Search, Eye, Edit, MoreHorizontal,
  Users, Clock, Calendar, DollarSign, MapPin, Share2,
  CheckCircle, XCircle, AlertCircle, Send, Download,
  Building2, Globe, Target, Link, Copy, Phone, Video,
  FileText, UserPlus, ArrowRight, Filter, Star,
  Workflow, TestTube, Database, BarChart3, GitBranch,
  MoveRight, Settings, ExternalLink, Mail, LinkIcon,
  Trash2, ChevronRight, DragHandleHorizontal, GripVertical
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import JobPipeline from '@/components/JobPipeline';
import TestManager from '@/components/TestManager';
import CandidateDatabase from '@/components/CandidateDatabase';
import JobKanban from '@/components/JobKanban';
import { ReportGenerator, DEFAULT_REPORT_MODULES } from '@/components/ReportGenerator';
import {
  generatePDFReport,
  generateExcelReport,
  sortReportData,
  filterReportData,
  type ReportConfig,
  type ReportData
} from '@/lib/reportUtils';

// Default selection stages
const DEFAULT_STAGES: Omit<SelectionStage, 'id'>[] = [
  {
    name: 'Análise Curricular',
    description: 'Avaliação inicial do currículo e qualificações',
    order: 1,
    isRequired: true,
    hasTest: false
  },
  {
    name: 'Entrevista Inicial',
    description: 'Primeira entrevista com o candidato',
    order: 2,
    isRequired: true,
    hasTest: false
  },
  {
    name: 'Prova Técnica',
    description: 'Avaliação das competências técnicas',
    order: 3,
    isRequired: false,
    hasTest: true
  },
  {
    name: 'Entrevista Final',
    description: 'Entrevista final com gestores',
    order: 4,
    isRequired: true,
    hasTest: false
  },
  {
    name: 'Selecionado',
    description: 'Candidato aprovado no processo',
    order: 5,
    isRequired: true,
    hasTest: false
  }
];

export default function EnhancedJobs() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  
  // State management
  const [jobs, setJobs] = useState<EnhancedJob[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [tests, setTests] = useState<Test[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  
  // Dialog states
  const [selectedJob, setSelectedJob] = useState<EnhancedJob | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPipelineDialogOpen, setIsPipelineDialogOpen] = useState(false);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [isTestDialogOpen, setIsTestDialogOpen] = useState(false);
  const [isCandidateDialogOpen, setIsCandidateDialogOpen] = useState(false);
  const [isKanbanOpen, setIsKanbanOpen] = useState(false);
  
  // Form states
  const [jobForm, setJobForm] = useState<Partial<EnhancedJob>>({
    title: '',
    department: '',
    description: '',
    requirements: [],
    benefits: [],
    salary: '',
    type: 'full_time',
    status: 'draft',
    stages: DEFAULT_STAGES.map((stage, index) => ({
      ...stage,
      id: `stage_${index + 1}`
    }))
  });
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [newRequirement, setNewRequirement] = useState('');
  const [newBenefit, setNewBenefit] = useState('');

  const canCreate = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);
  const canEdit = hasPermission(user?.role || 'employee', ['rh_admin', 'manager']);

  // Load data on component mount
  useEffect(() => {
    loadJobs();

    // Load candidates from localStorage
    const savedCandidates = localStorage.getItem('enhancedCandidates');
    const candidatesData = savedCandidates ? JSON.parse(savedCandidates) : EnhancedDataStore.getCandidates();
    setCandidates(candidatesData);

    setTests(EnhancedDataStore.getTests());
  }, []);

  // Check for openKanban query parameter
  useEffect(() => {
    const openKanbanJobId = searchParams.get('openKanban');
    if (openKanbanJobId && jobs.length > 0) {
      const job = jobs.find(j => j.id === openKanbanJobId);
      if (job) {
        setSelectedJob(job);
        setIsKanbanOpen(true);
      }
    }
  }, [searchParams, jobs]);

  const loadJobs = () => {
    // Load from localStorage or use default data
    const savedJobs = localStorage.getItem('enhancedJobs');
    if (savedJobs) {
      const jobs = JSON.parse(savedJobs);
      // Ensure all jobs have shareableLink
      const jobsWithLinks = jobs.map((job: EnhancedJob) => ({
        ...job,
        shareableLink: job.shareableLink || `${window.location.origin}/candidate-apply/${job.id}`
      }));
      setJobs(jobsWithLinks);
      localStorage.setItem('enhancedJobs', JSON.stringify(jobsWithLinks));
    } else {
      // Initialize with sample job
      const sampleJob: EnhancedJob = {
        id: 'job_1',
        title: 'Desenvolvedor React',
        department: 'Tecnologia',
        description: 'Desenvolvedor React Sênior para projetos inovadores',
        requirements: ['React', 'TypeScript', '3+ anos experiência'],
        benefits: ['Vale refeição', 'Plano de saúde', 'Home office'],
        salary: 'R$ 8.000 - 12.000',
        type: 'full_time',
        status: 'open',
        createdDate: new Date().toISOString(),
        applications: [],
        stages: DEFAULT_STAGES.map((stage, index) => ({
          ...stage,
          id: `stage_${index + 1}`
        })),
        shareCount: 0,
        viewCount: 0,
        shareableLink: `${window.location.origin}/candidate-apply/job_1`
      };
      setJobs([sampleJob]);
      localStorage.setItem('enhancedJobs', JSON.stringify([sampleJob]));
    }
  };

  const saveJobs = (updatedJobs: EnhancedJob[]) => {
    setJobs(updatedJobs);
    localStorage.setItem('enhancedJobs', JSON.stringify(updatedJobs));
  };

  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || job.status === statusFilter;
      const matchesDepartment = departmentFilter === 'all' || job.department === departmentFilter;
      
      return matchesSearch && matchesStatus && matchesDepartment;
    });
  }, [jobs, searchTerm, statusFilter, departmentFilter]);

  const departments = useMemo(() => {
    const depts = [...new Set(jobs.map(job => job.department))];
    return depts.sort();
  }, [jobs]);

  const getStatusBadge = (status: EnhancedJob['status']) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-green-100 text-green-700">Aberta</Badge>;
      case 'closed':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-700">Fechada</Badge>;
      case 'draft':
        return <Badge variant="outline" className="border-orange-200 text-orange-700">Rascunho</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const getApplicationStatusBadge = (status: EnhancedJobApplication['status']) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-blue-100 text-blue-700">Ativo</Badge>;
      case 'approved':
        return <Badge className="bg-green-100 text-green-700">Aprovado</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-700">Rejeitado</Badge>;
      case 'withdrawn':
        return <Badge variant="outline">Desistiu</Badge>;
      default:
        return <Badge variant="secondary">Desconhecido</Badge>;
    }
  };

  const handleCreateJob = () => {
    if (!jobForm.title || !jobForm.department || !jobForm.description) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    const jobId = `job_${Date.now()}`;
    const newJob: EnhancedJob = {
      ...jobForm as EnhancedJob,
      id: jobId,
      createdDate: new Date().toISOString(),
      applications: [],
      shareCount: 0,
      viewCount: 0,
      shareableLink: `${window.location.origin}/candidate-apply/${jobId}`
    };

    const updatedJobs = [...jobs, newJob];
    saveJobs(updatedJobs);
    
    setIsCreateDialogOpen(false);
    setJobForm({
      title: '',
      department: '',
      description: '',
      requirements: [],
      benefits: [],
      salary: '',
      type: 'full_time',
      status: 'draft',
      stages: DEFAULT_STAGES.map((stage, index) => ({
        ...stage,
        id: `stage_${index + 1}`
      }))
    });

    toast({
      title: "Sucesso",
      description: "Vaga criada com sucesso!",
    });
  };

  const handleShareJob = (job: EnhancedJob) => {
    setSelectedJob(job);
    setIsShareDialogOpen(true);
  };

  const copyJobLink = async () => {
    if (!selectedJob) {
      toast({
        title: "Erro",
        description: "Nenhuma vaga selecionada.",
        variant: "destructive"
      });
      return;
    }

    const link = selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`;

    try {
      // Try modern clipboard API first
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(link);
      } else {
        // Enhanced fallback method
        const textArea = document.createElement('textarea');
        textArea.value = link;
        textArea.style.position = 'absolute';
        textArea.style.left = '-9999px';
        textArea.style.top = '0';
        textArea.setAttribute('readonly', '');
        document.body.appendChild(textArea);
        textArea.select();
        textArea.setSelectionRange(0, 99999);
        const successful = document.execCommand('copy');
        document.body.removeChild(textArea);

        if (!successful) {
          throw new Error('Fallback copy failed');
        }
      }

      toast({
        title: "✅ Link copiado!",
        description: `Link da vaga copiado com sucesso!`,
      });

      // Update share count and ensure shareableLink exists
      const updatedJobs = jobs.map(job =>
        job.id === selectedJob.id
          ? {
              ...job,
              shareCount: job.shareCount + 1,
              shareableLink: job.shareableLink || `${window.location.origin}/candidate-apply/${job.id}`
            }
          : job
      );
      saveJobs(updatedJobs);

    } catch (err) {
      console.error('Failed to copy link:', err);

      // Show manual copy option
      const fallbackMessage = `Link da vaga: ${link}`;
      toast({
        title: "⚠️ Erro ao copiar automaticamente",
        description: fallbackMessage,
        variant: "destructive"
      });

      // Try one more time with prompt
      if (window.prompt) {
        window.prompt('Copie o link da vaga:', link);
      }
    }
  };

  const handleViewPipeline = (job: EnhancedJob) => {
    setSelectedJob(job);
    setIsPipelineDialogOpen(true);
  };

  const handleViewKanban = (job: EnhancedJob) => {
    setSelectedJob(job);
    setIsKanbanOpen(true);
  };

  const addRequirement = () => {
    if (newRequirement.trim()) {
      setJobForm(prev => ({
        ...prev,
        requirements: [...(prev.requirements || []), newRequirement.trim()]
      }));
      setNewRequirement('');
    }
  };

  const removeRequirement = (index: number) => {
    setJobForm(prev => ({
      ...prev,
      requirements: prev.requirements?.filter((_, i) => i !== index) || []
    }));
  };

  const addBenefit = () => {
    if (newBenefit.trim()) {
      setJobForm(prev => ({
        ...prev,
        benefits: [...(prev.benefits || []), newBenefit.trim()]
      }));
      setNewBenefit('');
    }
  };

  const removeBenefit = (index: number) => {
    setJobForm(prev => ({
      ...prev,
      benefits: prev.benefits?.filter((_, i) => i !== index) || []
    }));
  };

  const addStage = () => {
    const newStage: SelectionStage = {
      id: `stage_${Date.now()}`,
      name: 'Nova Etapa',
      description: '',
      order: (jobForm.stages?.length || 0) + 1,
      isRequired: false,
      hasTest: false
    };
    setJobForm(prev => ({
      ...prev,
      stages: [...(prev.stages || []), newStage]
    }));
  };

  const updateStage = (stageId: string, updates: Partial<SelectionStage>) => {
    setJobForm(prev => ({
      ...prev,
      stages: prev.stages?.map(stage => 
        stage.id === stageId ? { ...stage, ...updates } : stage
      ) || []
    }));
  };

  const removeStage = (stageId: string) => {
    setJobForm(prev => ({
      ...prev,
      stages: prev.stages?.filter(stage => stage.id !== stageId) || []
    }));
  };

  const handleEditJob = (job: EnhancedJob) => {
    setSelectedJob(job);
    setJobForm({
      title: job.title,
      department: job.department,
      description: job.description,
      requirements: job.requirements || [],
      benefits: job.benefits || [],
      salary: job.salary || '',
      type: job.type,
      status: job.status,
      location: job.location || '',
      urgency: job.urgency || 'medium',
      stages: job.stages || []
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdateJob = () => {
    if (!selectedJob || !jobForm.title || !jobForm.department || !jobForm.description) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    const updatedJob: EnhancedJob = {
      ...selectedJob,
      ...jobForm as EnhancedJob,
      shareableLink: selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`
    };

    const updatedJobs = jobs.map(job =>
      job.id === selectedJob.id ? updatedJob : job
    );

    saveJobs(updatedJobs);
    setIsEditDialogOpen(false);
    setSelectedJob(null);
    setJobForm({
      title: '',
      department: '',
      description: '',
      requirements: [],
      benefits: [],
      salary: '',
      type: 'full_time',
      status: 'draft',
      stages: DEFAULT_STAGES.map((stage, index) => ({
        ...stage,
        id: `stage_${index + 1}`
      }))
    });

    toast({
      title: "Sucesso",
      description: "Vaga atualizada com sucesso!",
    });
  };

  const handleDeleteJob = (job: EnhancedJob) => {
    if (window.confirm(`Tem certeza que deseja excluir a vaga "${job.title}"? Esta ação não pode ser desfeita.`)) {
      const updatedJobs = jobs.filter(j => j.id !== job.id);
      saveJobs(updatedJobs);

      toast({
        title: "Vaga excluída",
        description: "A vaga foi removida com sucesso.",
      });
    }
  };

  // Report generation functionality for jobs
  const handleJobsReportGeneration = async (config: ReportConfig) => {
    try {
      // Prepare jobs data for reporting
      const reportData = jobs.map(job => ({
        title: job.title,
        department: job.department,
        status: job.status,
        applications: job.applications.length,
        createdDate: job.createdDate,
        responsible: 'RH', // Default responsible
        salary: job.salary || 'A combinar',
        type: job.type === 'full_time' ? 'Tempo Integral' : job.type === 'part_time' ? 'Meio Período' : 'Contrato'
      }));

      // Apply date filtering
      const filteredData = filterReportData(reportData, config);

      // Apply sorting
      const sortedData = sortReportData(filteredData, config);

      // Prepare report data structure
      const finalReportData: ReportData = {
        config,
        data: sortedData,
        metadata: {
          generatedAt: new Date().toISOString(),
          generatedBy: user?.name || 'Sistema',
          totalRecords: reportData.length,
          filteredRecords: sortedData.length
        }
      };

      // Generate report based on format
      if (config.format === 'pdf') {
        await generatePDFReport(finalReportData);
      } else {
        await generateExcelReport(finalReportData);
      }

    } catch (error) {
      console.error('Jobs report generation error:', error);
      throw error;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Briefcase className="w-8 h-8 mr-3 text-purple-600" />
            Gestão de Vagas Avançada
          </h1>
          <p className="text-gray-600 mt-1">
            Sistema completo de recrutamento com pipeline personalizado
          </p>
        </div>
        <div className="flex items-center space-x-3 mt-4 lg:mt-0">
          {/* Enhanced Report Generator */}
          <ReportGenerator
            modules={[{
              ...DEFAULT_REPORT_MODULES.find(m => m.id === 'jobs')!,
              getData: () => jobs.map(job => ({
                title: job.title,
                department: job.department,
                status: job.status,
                applications: job.applications.length,
                createdDate: job.createdDate,
                responsible: 'RH',
                salary: job.salary || 'A combinar',
                type: job.type === 'full_time' ? 'Tempo Integral' : job.type === 'part_time' ? 'Meio Período' : 'Contrato'
              }))
            }]}
            onGenerate={handleJobsReportGeneration}
          />

          <Button variant="outline" size="sm" onClick={() => setIsCandidateDialogOpen(true)}>
            <Database className="w-4 h-4 mr-2" />
            Banco de Candidatos
          </Button>
          <Button variant="outline" size="sm" onClick={() => setIsTestDialogOpen(true)}>
            <TestTube className="w-4 h-4 mr-2" />
            Gerenciar Provas
          </Button>
          {canCreate && (
            <Button
              className="bg-gradient-to-r from-purple-600 to-blue-600"
              onClick={() => setIsCreateDialogOpen(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Vaga
            </Button>
          )}
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Vagas Abertas</p>
                <p className="text-3xl font-bold text-green-600">
                  {jobs.filter(j => j.status === 'open').length}
                </p>
              </div>
              <Briefcase className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Candidatos</p>
                <p className="text-3xl font-bold text-blue-600">{candidates.length}</p>
              </div>
              <Users className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Candidaturas Ativas</p>
                <p className="text-3xl font-bold text-purple-600">
                  {jobs.reduce((acc, job) => acc + job.applications.filter(a => a.status === 'active').length, 0)}
                </p>
              </div>
              <Target className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Provas Aplicadas</p>
                <p className="text-3xl font-bold text-orange-600">
                  {candidates.reduce((acc, candidate) => acc + candidate.testResults.length, 0)}
                </p>
              </div>
              <TestTube className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
            <div className="flex flex-1 items-center space-x-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar vagas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="open">Abertas</SelectItem>
                  <SelectItem value="closed">Fechadas</SelectItem>
                  <SelectItem value="draft">Rascunho</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Departamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="text-sm text-gray-600">
              {filteredJobs.length} de {jobs.length} vaga(s)
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Jobs List */}
      <div className="grid grid-cols-1 gap-6">
        {filteredJobs.map((job) => (
          <Card
            key={job.id}
            className="hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => handleViewKanban(job)}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                    {getStatusBadge(job.status)}
                    <Badge variant="outline">{job.type.replace('_', ' ')}</Badge>
                  </div>
                  
                  <div className="flex items-center space-x-6 text-sm text-gray-600 mb-3">
                    <div className="flex items-center">
                      <Building2 className="w-4 h-4 mr-2" />
                      {job.department}
                    </div>
                    {job.salary && (
                      <div className="flex items-center">
                        <DollarSign className="w-4 h-4 mr-2" />
                        {job.salary}
                      </div>
                    )}
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      {format(new Date(job.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 line-clamp-2">{job.description}</p>
                  
                  <div className="flex items-center space-x-6 text-sm">
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-blue-500" />
                      <span>{job.applications.length} candidatura(s)</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <GitBranch className="w-4 h-4 text-purple-500" />
                      <span>{job.stages.length} etapa(s)</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Share2 className="w-4 h-4 text-green-500" />
                      <span>{job.shareCount} compartilhamento(s)</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4 text-orange-500" />
                      <span>{job.viewCount} visualização(ões)</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleViewPipeline(job);
                    }}
                  >
                    <Workflow className="w-4 h-4 mr-2" />
                    Pipeline
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleShareJob(job);
                    }}
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartilhar
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => {
                        setSelectedJob(job);
                        setIsViewDialogOpen(true);
                      }}>
                        <Eye className="w-4 h-4 mr-2" />
                        Ver Detalhes da Vaga
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleShareJob(job)}>
                        <Share2 className="w-4 h-4 mr-2" />
                        Compartilhar Link
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleViewPipeline(job)}>
                        <Workflow className="w-4 h-4 mr-2" />
                        Ver Pipeline
                      </DropdownMenuItem>
                      {canEdit && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleEditJob(job)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Editar Vaga
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => handleDeleteJob(job)}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Excluir Vaga
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredJobs.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma vaga encontrada
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== 'all' || departmentFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Crie sua primeira vaga para começar'
                }
              </p>
              {canCreate && (
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeira Vaga
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* View Job Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedJob?.title}</DialogTitle>
            <DialogDescription>
              {selectedJob?.department} • {selectedJob?.type === 'full_time' ? 'Tempo Integral' :
               selectedJob?.type === 'part_time' ? 'Meio Período' : 'Contrato'}
            </DialogDescription>
          </DialogHeader>

          {selectedJob && (
            <div className="space-y-6">
              {/* Status and Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-lg font-bold text-blue-600">{selectedJob.applications.length}</div>
                    <div className="text-sm text-gray-600">Candidaturas</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-lg font-bold text-green-600">{selectedJob.shareCount}</div>
                    <div className="text-sm text-gray-600">Compartilhamentos</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-lg font-bold text-purple-600">{selectedJob.stages.length}</div>
                    <div className="text-sm text-gray-600">Etapas</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-lg font-bold text-orange-600">
                      {selectedJob.applications.filter(a => a.status === 'active').length}
                    </div>
                    <div className="text-sm text-gray-600">Em Processo</div>
                  </CardContent>
                </Card>
              </div>

              <div className="flex items-center space-x-4">
                {getStatusBadge(selectedJob.status)}
                {selectedJob.salary && (
                  <Badge variant="outline">{selectedJob.salary}</Badge>
                )}
                <Badge variant="secondary">
                  Criada em {format(new Date(selectedJob.createdDate), 'dd/MM/yyyy', { locale: ptBR })}
                </Badge>
              </div>

              {/* Description */}
              <div>
                <h4 className="font-semibold mb-2">Descri��ão da Vaga</h4>
                <p className="text-gray-700 whitespace-pre-wrap">{selectedJob.description}</p>
              </div>

              {/* Requirements and Benefits */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {selectedJob.requirements.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3">Requisitos</h4>
                    <ul className="space-y-2">
                      {selectedJob.requirements.map((req, index) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedJob.benefits.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3">Benefícios</h4>
                    <ul className="space-y-2">
                      {selectedJob.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-start">
                          <Star className="w-4 h-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Process Stages */}
              <div>
                <h4 className="font-semibold mb-3">Etapas do Processo Seletivo</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedJob.stages.map((stage, index) => {
                    const stageApplications = selectedJob.applications.filter(app => app.currentStage === stage.id);
                    return (
                      <div key={stage.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center text-sm font-medium">
                              {index + 1}
                            </div>
                            <h5 className="font-medium">{stage.name}</h5>
                          </div>
                          <div className="flex items-center space-x-1">
                            {stage.hasTest && <TestTube className="w-4 h-4 text-blue-500" />}
                            {stage.isRequired && <Star className="w-4 h-4 text-orange-500" />}
                            <Badge variant="outline" className="text-xs">
                              {stageApplications.length} candidato(s)
                            </Badge>
                          </div>
                        </div>
                        {stage.description && (
                          <p className="text-sm text-gray-600">{stage.description}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Public Link */}
              <div>
                <h4 className="font-semibold mb-2">Link Público para Candidaturas</h4>
                <div className="flex">
                  <Input
                    value={selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`}
                    readOnly
                    className="rounded-r-none font-mono text-sm"
                  />
                  <Button
                    onClick={() => {
                      const link = selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`;
                      navigator.clipboard.writeText(link);
                      toast({
                        title: "Link copiado!",
                        description: "Link da vaga copiado para a área de transferência.",
                      });
                    }}
                    className="rounded-l-none"
                    variant="outline"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-between pt-6 border-t">
                <div className="space-x-3">
                  <Button variant="outline" onClick={() => handleShareJob(selectedJob)}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartilhar
                  </Button>
                  <Button variant="outline" onClick={() => handleViewKanban(selectedJob)}>
                    <Workflow className="w-4 h-4 mr-2" />
                    Abrir Kanban
                  </Button>
                </div>
                <Button onClick={() => setIsViewDialogOpen(false)}>
                  Fechar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Job Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Criar Nova Vaga</DialogTitle>
            <DialogDescription>
              Configure todos os detalhes da vaga incluindo as etapas do processo seletivo
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="basic" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
              <TabsTrigger value="requirements">Requisitos & Benefícios</TabsTrigger>
              <TabsTrigger value="stages">Etapas do Processo</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Título da Vaga *</Label>
                  <Input
                    id="title"
                    value={jobForm.title || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Ex: Desenvolvedor React Sênior"
                  />
                </div>
                <div>
                  <Label htmlFor="department">Departamento *</Label>
                  <Input
                    id="department"
                    value={jobForm.department || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, department: e.target.value }))}
                    placeholder="Ex: Tecnologia"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Descrição da Vaga *</Label>
                <Textarea
                  id="description"
                  value={jobForm.description || ''}
                  onChange={(e) => setJobForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Descreva as responsabilidades e expectativas da vaga..."
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="salary">Faixa Salarial</Label>
                  <Input
                    id="salary"
                    value={jobForm.salary || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, salary: e.target.value }))}
                    placeholder="Ex: R$ 8.000 - 12.000"
                  />
                </div>
                <div>
                  <Label htmlFor="type">Tipo de Contrato</Label>
                  <Select
                    value={jobForm.type || 'full_time'}
                    onValueChange={(value) => setJobForm(prev => ({ 
                      ...prev, 
                      type: value as 'full_time' | 'part_time' | 'contract' 
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full_time">Tempo Integral</SelectItem>
                      <SelectItem value="part_time">Meio Período</SelectItem>
                      <SelectItem value="contract">Contrato</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="status">Status da Vaga</Label>
                <Select
                  value={jobForm.status || 'draft'}
                  onValueChange={(value) => setJobForm(prev => ({ 
                    ...prev, 
                    status: value as 'open' | 'closed' | 'draft' 
                  }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Rascunho</SelectItem>
                    <SelectItem value="open">Aberta</SelectItem>
                    <SelectItem value="closed">Fechada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            {/* Requirements & Benefits Tab */}
            <TabsContent value="requirements" className="space-y-6">
              {/* Requirements */}
              <div>
                <Label>Requisitos</Label>
                <div className="flex space-x-2 mt-2">
                  <Input
                    value={newRequirement}
                    onChange={(e) => setNewRequirement(e.target.value)}
                    placeholder="Digite um requisito..."
                    onKeyPress={(e) => e.key === 'Enter' && addRequirement()}
                  />
                  <Button type="button" onClick={addRequirement}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {jobForm.requirements?.map((req, index) => (
                    <Badge key={index} variant="secondary" className="flex items-center gap-2">
                      {req}
                      <button
                        type="button"
                        onClick={() => removeRequirement(index)}
                        className="text-gray-500 hover:text-red-500"
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Benefits */}
              <div>
                <Label>Benefícios</Label>
                <div className="flex space-x-2 mt-2">
                  <Input
                    value={newBenefit}
                    onChange={(e) => setNewBenefit(e.target.value)}
                    placeholder="Digite um benefício..."
                    onKeyPress={(e) => e.key === 'Enter' && addBenefit()}
                  />
                  <Button type="button" onClick={addBenefit}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {jobForm.benefits?.map((benefit, index) => (
                    <Badge key={index} variant="outline" className="flex items-center gap-2">
                      {benefit}
                      <button
                        type="button"
                        onClick={() => removeBenefit(index)}
                        className="text-gray-500 hover:text-red-500"
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Stages Tab */}
            <TabsContent value="stages" className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Etapas do Processo Seletivo</h3>
                  <p className="text-sm text-gray-600">Configure as etapas que os candidatos passarão</p>
                </div>
                <Button type="button" onClick={addStage} variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Etapa
                </Button>
              </div>

              <div className="space-y-4">
                {jobForm.stages?.map((stage, index) => (
                  <Card key={stage.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <div className="flex items-center justify-center w-8 h-8 bg-purple-100 text-purple-600 rounded-full text-sm font-medium">
                          {index + 1}
                        </div>
                        <div className="flex-1 space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <Label>Nome da Etapa</Label>
                              <Input
                                value={stage.name}
                                onChange={(e) => updateStage(stage.id, { name: e.target.value })}
                                placeholder="Nome da etapa..."
                              />
                            </div>
                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-2">
                                <Switch
                                  checked={stage.isRequired}
                                  onCheckedChange={(checked) => updateStage(stage.id, { isRequired: checked })}
                                />
                                <Label className="text-sm">Obrigatória</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Switch
                                  checked={stage.hasTest}
                                  onCheckedChange={(checked) => updateStage(stage.id, { hasTest: checked })}
                                />
                                <Label className="text-sm">Tem Prova</Label>
                              </div>
                            </div>
                          </div>
                          <div>
                            <Label>Descrição</Label>
                            <Textarea
                              value={stage.description || ''}
                              onChange={(e) => updateStage(stage.id, { description: e.target.value })}
                              placeholder="Descreva o que acontece nesta etapa..."
                              rows={2}
                            />
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeStage(stage.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreateJob}>
              Criar Vaga
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Job Dialog */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Share2 className="w-5 h-5 mr-2" />
              Compartilhar Vaga para Receber Currículos
            </DialogTitle>
            <DialogDescription>
              Compartilhe esta vaga através de diferentes canais para atrair candidatos
            </DialogDescription>
          </DialogHeader>

          {selectedJob && (
            <div className="space-y-6">
              {/* Job Summary */}
              <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Briefcase className="w-6 h-6 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{selectedJob.title}</h3>
                      <p className="text-sm text-gray-600">{selectedJob.department}</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                        <span>{selectedJob.stages.length} etapas no processo</span>
                        <span>•</span>
                        <span>{selectedJob.applications.length} candidaturas</span>
                        {selectedJob.salary && (
                          <>
                            <span>•</span>
                            <span>{selectedJob.salary}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Public Link */}
              <div>
                <Label className="text-base font-medium">Link Público para Receber Currículos</Label>
                <p className="text-sm text-gray-600 mb-3">
                  Este link direciona candidatos diretamente para a vaga onde podem enviar seus currículos
                </p>
                <div className="flex mt-2">
                  <Input
                    value={selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`}
                    readOnly
                    className="rounded-r-none font-mono text-sm"
                  />
                  <Button
                    onClick={copyJobLink}
                    className="rounded-l-none px-3"
                    variant="outline"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <Separator />

              {/* Social Sharing */}
              <div>
                <Label className="text-base font-medium">Compartilhar em Redes Sociais</Label>
                <p className="text-sm text-gray-600 mb-3">
                  Divulgue a vaga em diferentes plataformas para alcançar mais candidatos
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => {
                      const link = selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`;
                      const text = `🚀 Nova Oportunidade: ${selectedJob.title}\n\n📍 ${selectedJob.department}\n💰 ${selectedJob.salary || 'Salário a combinar'}\n\n📋 ${selectedJob.stages.length} etapas no processo seletivo\n\n👥 Candidate-se: ${link}`;
                      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
                      // Update share count
                      const updatedJobs = jobs.map(job =>
                        job.id === selectedJob.id
                          ? { ...job, shareCount: job.shareCount + 1 }
                          : job
                      );
                      saveJobs(updatedJobs);
                    }}
                  >
                    <Phone className="w-5 h-5 mr-3 text-green-600" />
                    <div className="text-left">
                      <div className="font-medium">WhatsApp</div>
                      <div className="text-xs text-gray-500">Mensagem direta</div>
                    </div>
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => {
                      const link = selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`;
                      const text = `Nova oportunidade: ${selectedJob.title} em ${selectedJob.department}. ${selectedJob.stages.length} etapas no processo seletivo. Candidate-se: ${link}`;
                      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(link)}&summary=${encodeURIComponent(text)}`, '_blank');
                      // Update share count
                      const updatedJobs = jobs.map(job =>
                        job.id === selectedJob.id
                          ? { ...job, shareCount: job.shareCount + 1 }
                          : job
                      );
                      saveJobs(updatedJobs);
                    }}
                  >
                    <LinkIcon className="w-5 h-5 mr-3 text-blue-600" />
                    <div className="text-left">
                      <div className="font-medium">LinkedIn</div>
                      <div className="text-xs text-gray-500">Rede profissional</div>
                    </div>
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => {
                      const subject = `Oportunidade de Trabalho: ${selectedJob.title}`;
                      const body = `Olá!

Gostaríamos de compartilhar uma excelente oportunidade de trabalho:

🚀 Vaga: ${selectedJob.title}
🏢 Departamento: ${selectedJob.department}
💰 Salário: ${selectedJob.salary || 'A combinar'}

📋 Processo Seletivo:
${selectedJob.stages.map((stage, index) => `${index + 1}. ${stage.name}${stage.description ? ` - ${stage.description}` : ''}`).join('\n')}

📝 Descrição:
${selectedJob.description}

Para se candidatar, acesse: ${selectedJob.shareableLink || `${window.location.origin}/candidate-apply/${selectedJob.id}`}

Atenciosamente,
Equipe Integre RH`;
                      window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
                      // Update share count
                      const updatedJobs = jobs.map(job =>
                        job.id === selectedJob.id
                          ? { ...job, shareCount: job.shareCount + 1 }
                          : job
                      );
                      saveJobs(updatedJobs);
                    }}
                  >
                    <Mail className="w-5 h-5 mr-3 text-red-600" />
                    <div className="text-left">
                      <div className="font-medium">E-mail</div>
                      <div className="text-xs text-gray-500">Mensagem completa</div>
                    </div>
                  </Button>
                </div>
              </div>

              {/* Process Overview */}
              <div>
                <Label className="text-base font-medium">Fases do Processo Seletivo</Label>
                <p className="text-sm text-gray-600 mb-3">
                  Etapas que os candidatos passarão após se candidatarem
                </p>
                <div className="space-y-2">
                  {selectedJob.stages.map((stage, index) => (
                    <div key={stage.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-center w-8 h-8 bg-purple-100 text-purple-600 rounded-full text-sm font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium">{stage.name}</span>
                          {stage.isRequired && <Star className="w-4 h-4 text-orange-500" />}
                          {stage.hasTest && <TestTube className="w-4 h-4 text-blue-500" />}
                        </div>
                        {stage.description && (
                          <p className="text-sm text-gray-600 mt-1">{stage.description}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Statistics */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">{selectedJob.shareCount}</div>
                    <div className="text-sm text-gray-600">Compartilhamentos</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">{selectedJob.applications.length}</div>
                    <div className="text-sm text-gray-600">Candidaturas Recebidas</div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-between pt-4 border-t">
                <Button variant="outline" onClick={() => setIsShareDialogOpen(false)}>
                  Fechar
                </Button>
                <Button onClick={() => {
                  setIsShareDialogOpen(false);
                  handleViewPipeline(selectedJob);
                }}>
                  <Workflow className="w-4 h-4 mr-2" />
                  Ver Processo Seletivo
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Pipeline Dialog */}
      <Dialog open={isPipelineDialogOpen} onOpenChange={setIsPipelineDialogOpen}>
        <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Pipeline de Candidatos</DialogTitle>
            <DialogDescription>
              Gerencie candidatos através das etapas do processo seletivo
            </DialogDescription>
          </DialogHeader>

          {selectedJob && (
            <JobPipeline
              job={selectedJob}
              candidates={candidates}
              onUpdateApplication={(applicationId, updates) => {
                const updatedJobs = jobs.map(job => {
                  if (job.id === selectedJob.id) {
                    return {
                      ...job,
                      applications: job.applications.map(app =>
                        app.id === applicationId ? { ...app, ...updates } : app
                      )
                    };
                  }
                  return job;
                });
                saveJobs(updatedJobs);
                setSelectedJob(updatedJobs.find(j => j.id === selectedJob.id) || null);
              }}
              onClose={() => setIsPipelineDialogOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Test Manager Dialog */}
      <Dialog open={isTestDialogOpen} onOpenChange={setIsTestDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gerenciamento de Provas</DialogTitle>
            <DialogDescription>
              Crie e gerencie provas para o processo seletivo
            </DialogDescription>
          </DialogHeader>

          <TestManager onClose={() => setIsTestDialogOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Candidate Database Dialog */}
      <Dialog open={isCandidateDialogOpen} onOpenChange={setIsCandidateDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Banco de Candidatos</DialogTitle>
            <DialogDescription>
              Base permanente de todos os candidatos
            </DialogDescription>
          </DialogHeader>

          <CandidateDatabase onClose={() => setIsCandidateDialogOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Edit Job Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Vaga</DialogTitle>
            <DialogDescription>
              Atualize as informações da vaga e suas etapas do processo seletivo
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="basic" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
              <TabsTrigger value="requirements">Requisitos & Benefícios</TabsTrigger>
              <TabsTrigger value="stages">Etapas do Processo</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-title">Título da Vaga *</Label>
                  <Input
                    id="edit-title"
                    value={jobForm.title || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Ex: Desenvolvedor React Sênior"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-department">Departamento *</Label>
                  <Input
                    id="edit-department"
                    value={jobForm.department || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, department: e.target.value }))}
                    placeholder="Ex: Tecnologia"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="edit-description">Descrição da Vaga *</Label>
                <Textarea
                  id="edit-description"
                  value={jobForm.description || ''}
                  onChange={(e) => setJobForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Descreva as responsabilidades e expectativas da vaga..."
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-salary">Faixa Salarial</Label>
                  <Input
                    id="edit-salary"
                    value={jobForm.salary || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, salary: e.target.value }))}
                    placeholder="Ex: R$ 8.000 - 12.000"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-type">Tipo de Contrato</Label>
                  <Select
                    value={jobForm.type || 'full_time'}
                    onValueChange={(value) => setJobForm(prev => ({
                      ...prev,
                      type: value as EnhancedJob['type']
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full_time">Tempo Integral</SelectItem>
                      <SelectItem value="part_time">Meio Período</SelectItem>
                      <SelectItem value="contract">Contrato</SelectItem>
                      <SelectItem value="internship">Estágio</SelectItem>
                      <SelectItem value="freelance">Freelance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-location">Localização</Label>
                  <Input
                    id="edit-location"
                    value={jobForm.location || ''}
                    onChange={(e) => setJobForm(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="Ex: São Paulo, SP"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-status">Status da Vaga</Label>
                  <Select
                    value={jobForm.status || 'draft'}
                    onValueChange={(value) => setJobForm(prev => ({
                      ...prev,
                      status: value as EnhancedJob['status']
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Rascunho</SelectItem>
                      <SelectItem value="open">Aberta</SelectItem>
                      <SelectItem value="closed">Fechada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            {/* Requirements and Benefits Tab */}
            <TabsContent value="requirements" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Requirements */}
                <div>
                  <Label className="text-base font-medium">Requisitos</Label>
                  <div className="space-y-3 mt-2">
                    <div className="flex space-x-2">
                      <Input
                        value={newRequirement}
                        onChange={(e) => setNewRequirement(e.target.value)}
                        placeholder="Digite um requisito..."
                        onKeyPress={(e) => e.key === 'Enter' && addRequirement()}
                      />
                      <Button type="button" onClick={addRequirement} size="sm">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {jobForm.requirements?.map((req, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="text-sm">{req}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeRequirement(index)}
                          >
                            <XCircle className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Benefits */}
                <div>
                  <Label className="text-base font-medium">Benefícios</Label>
                  <div className="space-y-3 mt-2">
                    <div className="flex space-x-2">
                      <Input
                        value={newBenefit}
                        onChange={(e) => setNewBenefit(e.target.value)}
                        placeholder="Digite um benefício..."
                        onKeyPress={(e) => e.key === 'Enter' && addBenefit()}
                      />
                      <Button type="button" onClick={addBenefit} size="sm">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {jobForm.benefits?.map((benefit, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="text-sm">{benefit}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeBenefit(index)}
                          >
                            <XCircle className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Stages Tab */}
            <TabsContent value="stages" className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-base font-medium">Etapas do Processo Seletivo</Label>
                  <Button type="button" onClick={addStage} size="sm" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Etapa
                  </Button>
                </div>

                <div className="space-y-3">
                  {jobForm.stages?.map((stage, index) => (
                    <Card key={stage.id} className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center text-sm font-medium">
                              {index + 1}
                            </div>
                            <Input
                              value={stage.name}
                              onChange={(e) => updateStage(stage.id, { name: e.target.value })}
                              placeholder="Nome da etapa"
                            />
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeStage(stage.id)}
                            className="text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>

                        <Input
                          value={stage.description || ''}
                          onChange={(e) => updateStage(stage.id, { description: e.target.value })}
                          placeholder="Descrição da etapa"
                        />

                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <Switch
                              checked={stage.isRequired}
                              onCheckedChange={(checked) => updateStage(stage.id, { isRequired: checked })}
                            />
                            <Label className="text-sm">Obrigatória</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch
                              checked={stage.hasTest}
                              onCheckedChange={(checked) => updateStage(stage.id, { hasTest: checked })}
                            />
                            <Label className="text-sm">Tem Teste</Label>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-3 pt-6 border-t">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleUpdateJob}>
              Salvar Alterações
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Kanban Dialog */}
      <Dialog open={isKanbanOpen} onOpenChange={setIsKanbanOpen}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] overflow-hidden">
          <DialogHeader className="sr-only">
            <DialogTitle>Kanban do Processo Seletivo</DialogTitle>
          </DialogHeader>

          {selectedJob && (
            <JobKanban
              job={selectedJob}
              candidates={candidates}
              onUpdateApplication={(applicationId, updates) => {
                const updatedJobs = jobs.map(job => {
                  if (job.id === selectedJob.id) {
                    return {
                      ...job,
                      applications: job.applications.map(app =>
                        app.id === applicationId ? { ...app, ...updates } : app
                      )
                    };
                  }
                  return job;
                });
                saveJobs(updatedJobs);
                setSelectedJob(updatedJobs.find(j => j.id === selectedJob.id) || null);
              }}
              onBack={() => setIsKanbanOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
