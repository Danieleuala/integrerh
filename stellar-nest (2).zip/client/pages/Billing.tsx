import React, { useState, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { 
  DollarSign, Download, Eye, Send, Calendar, Search, 
  CheckCircle, Clock, XCircle, AlertTriangle, FileText,
  CreditCard, TrendingUp, PlusCircle, Edit, Building2, Users
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import InvoiceViewer from '@/components/InvoiceViewer';
import EmployeeLimitManager from '@/components/EmployeeLimitManager';

interface Invoice {
  id: string;
  companyId: string;
  companyName: string;
  plan: 'basic' | 'professional' | 'enterprise';
  month: string;
  year: number;
  dueDate: string;
  issueDate: string;
  amount: number;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  paymentDate?: string;
  paymentMethod?: string;
  barcode?: string;
  notes?: string;
}

interface Company {
  id: string;
  name: string;
  plan: 'basic' | 'professional' | 'enterprise';
  cnpj?: string;
  email?: string;
  phone?: string;
  address?: string;
  currentEmployees: number;
  employeeLimit: number;
  status: 'active' | 'inactive' | 'suspended';
}

// Mock companies data
const mockCompanies: Company[] = [
  { 
    id: '1', 
    name: 'Tech Solutions Ltda', 
    plan: 'professional', 
    cnpj: '12.345.678/0001-90', 
    email: 'contato@techsolutions.com',
    phone: '(11) 9999-8888',
    address: 'Rua das Tecnologias, 123 - São Paulo/SP',
    currentEmployees: 89,
    employeeLimit: 200,
    status: 'active'
  },
  { 
    id: '2', 
    name: 'Inovação Digital S.A.', 
    plan: 'enterprise', 
    cnpj: '98.765.432/0001-10', 
    email: 'admin@inovacaodigital.com',
    phone: '(21) 8888-7777',
    address: 'Av. Inovação, 456 - Rio de Janeiro/RJ',
    currentEmployees: 750,
    employeeLimit: 1000,
    status: 'active'
  },
  { 
    id: '3', 
    name: 'StartUp Criativa', 
    plan: 'basic', 
    cnpj: '11.222.333/0001-44', 
    email: 'info@startupcriativa.com',
    phone: '(85) 7777-6666',
    address: 'Rua da Criatividade, 789 - Fortaleza/CE',
    currentEmployees: 42,
    employeeLimit: 50,
    status: 'active'
  },
  { 
    id: '4', 
    name: 'Consultoria Avançada', 
    plan: 'professional', 
    cnpj: '44.555.666/0001-77', 
    email: 'contato@consultoriaavancada.com',
    phone: '(31) 6666-5555',
    address: 'Praça dos Consultores, 321 - Belo Horizonte/MG',
    currentEmployees: 156,
    employeeLimit: 200,
    status: 'active'
  },
  { 
    id: '5', 
    name: 'Empresa Global Ltda', 
    plan: 'enterprise', 
    cnpj: '77.888.999/0001-00', 
    email: 'global@empresaglobal.com',
    phone: '(51) 5555-4444',
    address: 'Centro Empresarial Global, 654 - Porto Alegre/RS',
    currentEmployees: 920,
    employeeLimit: 1000,
    status: 'active'
  }
];

// Plan values mapping
const planValues = {
  basic: 147.00,
  professional: 447.00,
  enterprise: 0 // Consultation plan
};

const planLabels = {
  basic: 'Básico',
  professional: 'Profissional', 
  enterprise: 'Enterprise'
};

// Mock data
const mockInvoices: Invoice[] = [
  {
    id: 'INV-2024-001',
    companyId: '1',
    companyName: 'Tech Solutions Ltda',
    plan: 'professional',
    month: 'Janeiro',
    year: 2024,
    dueDate: '2024-01-15',
    issueDate: '2024-01-01',
    amount: 447.00,
    status: 'paid',
    paymentDate: '2024-01-12',
    paymentMethod: 'Boleto Bancário'
  },
  {
    id: 'INV-2024-002',
    companyId: '2',
    companyName: 'Inovação Digital S.A.',
    plan: 'enterprise',
    month: 'Janeiro',
    year: 2024,
    dueDate: '2024-01-10',
    issueDate: '2024-01-01',
    amount: 0,
    status: 'paid',
    paymentDate: '2024-01-08',
    paymentMethod: 'Consulta Gratuita'
  },
  {
    id: 'INV-2024-003',
    companyId: '3',
    companyName: 'StartUp Criativa',
    plan: 'basic',
    month: 'Dezembro',
    year: 2023,
    dueDate: '2023-12-15',
    issueDate: '2023-12-01',
    amount: 147.00,
    status: 'overdue',
    notes: 'Cliente solicitou renegociação'
  },
  {
    id: 'INV-2024-004',
    companyId: '1',
    companyName: 'Tech Solutions Ltda',
    plan: 'professional',
    month: 'Fevereiro',
    year: 2024,
    dueDate: '2024-02-15',
    issueDate: '2024-02-01',
    amount: 447.00,
    status: 'pending'
  },
  {
    id: 'INV-2024-005',
    companyId: '2',
    companyName: 'Inovação Digital S.A.',
    plan: 'enterprise',
    month: 'Fevereiro',
    year: 2024,
    dueDate: '2024-02-10',
    issueDate: '2024-02-01',
    amount: 0,
    status: 'pending'
  }
];

export default function Billing() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices);
  const [companies, setCompanies] = useState<Company[]>(mockCompanies);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [isGenerateInvoiceDialogOpen, setIsGenerateInvoiceDialogOpen] = useState(false);
  const [isEditInvoiceDialogOpen, setIsEditInvoiceDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'invoices' | 'employees'>('invoices');

  // Form states for invoice generation/editing
  const [selectedCompany, setSelectedCompany] = useState<string>('');
  const [invoiceMonth, setInvoiceMonth] = useState<string>('');
  const [invoiceYear, setInvoiceYear] = useState<number>(new Date().getFullYear());
  const [invoiceDueDate, setInvoiceDueDate] = useState<string>('');
  const [invoiceAmount, setInvoiceAmount] = useState<number>(0);

  // Filtros
  const filteredInvoices = useMemo(() => {
    return invoices.filter(invoice => {
      const matchesSearch = invoice.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           invoice.id.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = selectedStatus === 'all' || invoice.status === selectedStatus;
      
      const matchesMonth = selectedMonth === 'all' || invoice.month === selectedMonth;
      
      return matchesSearch && matchesStatus && matchesMonth;
    });
  }, [invoices, searchTerm, selectedStatus, selectedMonth]);

  // Estatísticas
  const stats = useMemo(() => {
    const total = invoices.length;
    const paid = invoices.filter(i => i.status === 'paid').length;
    const pending = invoices.filter(i => i.status === 'pending').length;
    const overdue = invoices.filter(i => i.status === 'overdue').length;
    
    const totalRevenue = invoices
      .filter(i => i.status === 'paid')
      .reduce((sum, i) => sum + i.amount, 0);
    
    const pendingRevenue = invoices
      .filter(i => i.status === 'pending')
      .reduce((sum, i) => sum + i.amount, 0);
    
    const overdueRevenue = invoices
      .filter(i => i.status === 'overdue')
      .reduce((sum, i) => sum + i.amount, 0);
    
    return { 
      total, paid, pending, overdue, 
      totalRevenue, pendingRevenue, overdueRevenue 
    };
  }, [invoices]);

  const months = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i);

  const handleCompanyChange = (companyId: string) => {
    setSelectedCompany(companyId);
    const company = companies.find(c => c.id === companyId);
    if (company) {
      setInvoiceAmount(planValues[company.plan]);
    }
  };

  const openEditDialog = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setSelectedCompany(invoice.companyId);
    setInvoiceMonth(invoice.month);
    setInvoiceYear(invoice.year);
    setInvoiceDueDate(invoice.dueDate);
    setInvoiceAmount(invoice.amount);
    setIsEditInvoiceDialogOpen(true);
  };

  const resetForm = () => {
    setSelectedCompany('');
    setInvoiceMonth('');
    setInvoiceYear(new Date().getFullYear());
    setInvoiceDueDate('');
    setInvoiceAmount(0);
  };

  const handleViewInvoice = (invoice: Invoice) => {
    setViewingInvoice(invoice);
    setIsViewerOpen(true);
  };

  const handleDownloadInvoice = (invoice: Invoice) => {
    // Generate PDF or document download
    const invoiceData = {
      id: invoice.id,
      company: companies.find(c => c.id === invoice.companyId)?.name,
      amount: invoice.amount,
      dueDate: invoice.dueDate,
      month: invoice.month,
      year: invoice.year
    };

    // Create a simple text file for demonstration
    const content = `
BOLETO DE PAGAMENTO
==================

Número: ${invoiceData.id}
Empresa: ${invoiceData.company}
Competência: ${invoiceData.month}/${invoiceData.year}
Valor: R$ ${invoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
Vencimento: ${new Date(invoiceData.dueDate).toLocaleDateString('pt-BR')}

Este é um arquivo de demonstração.
Para um sistema real, aqui seria gerado um PDF com o boleto completo.
    `;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `boleto_${invoice.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Download iniciado",
      description: `Boleto ${invoice.id} foi baixado com sucesso.`,
    });
  };

  const handleSendInvoice = (invoice: Invoice) => {
    const company = companies.find(c => c.id === invoice.companyId);
    if (!company?.email) {
      toast({
        title: "Erro no envio",
        description: "Empresa não possui email cadastrado.",
        variant: "destructive",
      });
      return;
    }

    // Simulate email sending
    setTimeout(() => {
      toast({
        title: "Email enviado",
        description: `Boleto ${invoice.id} foi enviado para ${company.email}`,
      });
    }, 1000);

    toast({
      title: "Enviando email...",
      description: `Enviando boleto para ${company.email}`,
    });
  };

  const handleUpdateCompany = (companyId: string, updates: Partial<Company>) => {
    setCompanies(companies.map(company => 
      company.id === companyId ? { ...company, ...updates } : company
    ));
  };

  const generateInvoice = () => {
    const company = companies.find(c => c.id === selectedCompany);
    if (!company) return;

    const newInvoice: Invoice = {
      id: `INV-${invoiceYear}-${String(invoices.length + 1).padStart(3, '0')}`,
      companyId: company.id,
      companyName: company.name,
      plan: company.plan,
      month: invoiceMonth,
      year: invoiceYear,
      dueDate: invoiceDueDate,
      issueDate: new Date().toISOString().split('T')[0],
      amount: invoiceAmount,
      status: 'pending'
    };

    setInvoices([...invoices, newInvoice]);
    setIsGenerateInvoiceDialogOpen(false);
    resetForm();
  };

  const updateInvoice = () => {
    if (!selectedInvoice) return;

    const company = companies.find(c => c.id === selectedCompany);
    if (!company) return;

    const updatedInvoices = invoices.map(inv => 
      inv.id === selectedInvoice.id ? {
        ...inv,
        companyId: selectedCompany,
        companyName: company.name,
        plan: company.plan,
        month: invoiceMonth,
        year: invoiceYear,
        dueDate: invoiceDueDate,
        amount: invoiceAmount
      } : inv
    );

    setInvoices(updatedInvoices);
    setIsEditInvoiceDialogOpen(false);
    setSelectedInvoice(null);
    resetForm();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'overdue':
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4 text-gray-600" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Pago</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pendente</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800">Vencido</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-100 text-gray-800">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case 'basic':
        return <Badge variant="outline" className="text-blue-600 border-blue-300">Básico</Badge>;
      case 'professional':
        return <Badge variant="outline" className="text-purple-600 border-purple-300">Profissional</Badge>;
      case 'enterprise':
        return <Badge variant="outline" className="text-green-600 border-green-300">Enterprise</Badge>;
      default:
        return <Badge variant="outline">{plan}</Badge>;
    }
  };

  if (user?.role !== 'admin') {
    return (
      <div className="text-center py-8">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Acesso Restrito</h2>
        <p className="text-gray-600">Esta área é exclusiva para administradores do sistema.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Faturamento</h1>
          <p className="text-gray-600 mt-1">Gestão de boletos, pagamentos e limites de funcionários</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Tab Navigation */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <Button
              variant={activeTab === 'invoices' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('invoices')}
              className="rounded-md"
            >
              <FileText className="w-4 h-4 mr-2" />
              Boletos
            </Button>
            <Button
              variant={activeTab === 'employees' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('employees')}
              className="rounded-md"
            >
              <Users className="w-4 h-4 mr-2" />
              Funcionários
            </Button>
          </div>

          {activeTab === 'invoices' && (
            <Dialog open={isGenerateInvoiceDialogOpen} onOpenChange={setIsGenerateInvoiceDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-purple-600 hover:bg-purple-700">
                  <PlusCircle className="w-4 h-4 mr-2" />
                  Gerar Boleto
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Gerar Novo Boleto</DialogTitle>
                  <DialogDescription>
                    Crie um boleto personalizado para uma empresa específica
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="company">Empresa</Label>
                    <Select value={selectedCompany} onValueChange={handleCompanyChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a empresa" />
                      </SelectTrigger>
                      <SelectContent>
                        {companies.map(company => (
                          <SelectItem key={company.id} value={company.id}>
                            <div className="flex items-center justify-between w-full">
                              <span>{company.name}</span>
                              <div className="ml-2">
                                {getPlanBadge(company.plan)}
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {selectedCompany && (
                      <div className="text-sm text-gray-600 mt-1">
                        {(() => {
                          const company = companies.find(c => c.id === selectedCompany);
                          return company ? (
                            <div className="flex items-center space-x-4">
                              <span>CNPJ: {company.cnpj}</span>
                              <span>Plano: {planLabels[company.plan]}</span>
                              <span>Email: {company.email}</span>
                            </div>
                          ) : null;
                        })()}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="month">Mês de Competência</Label>
                    <Select value={invoiceMonth} onValueChange={setInvoiceMonth}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o mês" />
                      </SelectTrigger>
                      <SelectContent>
                        {months.map(month => (
                          <SelectItem key={month} value={month}>{month}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="year">Ano de Competência</Label>
                    <Select value={String(invoiceYear)} onValueChange={(value) => setInvoiceYear(Number(value))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map(year => (
                          <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="due-date">Data de Vencimento</Label>
                    <Input 
                      type="date" 
                      value={invoiceDueDate}
                      onChange={(e) => setInvoiceDueDate(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Valor (R$)</Label>
                    <Input 
                      type="number" 
                      step="0.01"
                      value={invoiceAmount}
                      onChange={(e) => setInvoiceAmount(Number(e.target.value))}
                      placeholder="0,00"
                    />
                    {selectedCompany && (
                      <div className="text-sm text-blue-600">
                        Valor padrão do plano: R$ {planValues[companies.find(c => c.id === selectedCompany)?.plan || 'basic'].toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </div>
                    )}
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => {
                    setIsGenerateInvoiceDialogOpen(false);
                    resetForm();
                  }}>
                    Cancelar
                  </Button>
                  <Button 
                    onClick={generateInvoice} 
                    className="bg-purple-600 hover:bg-purple-700"
                    disabled={!selectedCompany || !invoiceMonth || !invoiceDueDate}
                  >
                    Gerar Boleto
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {/* Content based on active tab */}
      {activeTab === 'invoices' ? (
        <>
          {/* Edit Invoice Dialog */}
          <Dialog open={isEditInvoiceDialogOpen} onOpenChange={setIsEditInvoiceDialogOpen}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Editar Boleto</DialogTitle>
                <DialogDescription>
                  Edite as informações do boleto {selectedInvoice?.id}
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="edit-company">Empresa</Label>
                  <Select value={selectedCompany} onValueChange={handleCompanyChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a empresa" />
                    </SelectTrigger>
                    <SelectContent>
                      {companies.map(company => (
                        <SelectItem key={company.id} value={company.id}>
                          <div className="flex items-center justify-between w-full">
                            <span>{company.name}</span>
                            <div className="ml-2">
                              {getPlanBadge(company.plan)}
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-month">Mês de Competência</Label>
                  <Select value={invoiceMonth} onValueChange={setInvoiceMonth}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o mês" />
                    </SelectTrigger>
                    <SelectContent>
                      {months.map(month => (
                        <SelectItem key={month} value={month}>{month}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-year">Ano de Competência</Label>
                  <Select value={String(invoiceYear)} onValueChange={(value) => setInvoiceYear(Number(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map(year => (
                        <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-due-date">Data de Vencimento</Label>
                  <Input 
                    type="date" 
                    value={invoiceDueDate}
                    onChange={(e) => setInvoiceDueDate(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-amount">Valor (R$)</Label>
                  <Input 
                    type="number" 
                    step="0.01"
                    value={invoiceAmount}
                    onChange={(e) => setInvoiceAmount(Number(e.target.value))}
                    placeholder="0,00"
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setIsEditInvoiceDialogOpen(false);
                  setSelectedInvoice(null);
                  resetForm();
                }}>
                  Cancelar
                </Button>
                <Button 
                  onClick={updateInvoice} 
                  className="bg-purple-600 hover:bg-purple-700"
                  disabled={!selectedCompany || !invoiceMonth || !invoiceDueDate}
                >
                  Salvar Alterações
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Invoice Viewer */}
          <InvoiceViewer
            invoice={viewingInvoice}
            company={viewingInvoice ? companies.find(c => c.id === viewingInvoice.companyId) || null : null}
            isOpen={isViewerOpen}
            onClose={() => {
              setIsViewerOpen(false);
              setViewingInvoice(null);
            }}
          />

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Recebida</CardTitle>
                <CheckCircle className="w-4 h-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  R$ {stats.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground">{stats.paid} boletos pagos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Pendente</CardTitle>
                <Clock className="w-4 h-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  R$ {stats.pendingRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground">{stats.pending} boletos pendentes</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Vencida</CardTitle>
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">
                  R$ {stats.overdueRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground">{stats.overdue} boletos vencidos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Boletos</CardTitle>
                <FileText className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
                <p className="text-xs text-muted-foreground">Emitidos no período</p>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Buscar por empresa ou número do boleto..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="w-full md:w-48">
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Status</SelectItem>
                      <SelectItem value="paid">Pago</SelectItem>
                      <SelectItem value="pending">Pendente</SelectItem>
                      <SelectItem value="overdue">Vencido</SelectItem>
                      <SelectItem value="cancelled">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full md:w-48">
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Meses</SelectItem>
                      {months.map(month => (
                        <SelectItem key={month} value={month}>{month}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Invoices Table */}
          <Card>
            <CardHeader>
              <CardTitle>Lista de Boletos</CardTitle>
              <CardDescription>
                {filteredInvoices.length} boleto(s) encontrado(s)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Número</TableHead>
                    <TableHead>Empresa</TableHead>
                    <TableHead>Plano</TableHead>
                    <TableHead>Período</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Vencimento</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell>
                        <div className="font-medium">{invoice.id}</div>
                        {invoice.paymentDate && (
                          <div className="text-sm text-gray-500">
                            Pago em: {new Date(invoice.paymentDate).toLocaleDateString('pt-BR')}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{invoice.companyName}</div>
                        <div className="text-sm text-gray-500">
                          {companies.find(c => c.id === invoice.companyId)?.cnpj}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getPlanBadge(invoice.plan)}
                      </TableCell>
                      <TableCell>
                        <div>{invoice.month}/{invoice.year}</div>
                      </TableCell>
                      <TableCell className="font-medium">
                        {invoice.amount > 0 ? (
                          `R$ ${invoice.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
                        ) : (
                          <Badge variant="outline" className="text-green-600">Consulta</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{new Date(invoice.dueDate).toLocaleDateString('pt-BR')}</span>
                          {invoice.status === 'overdue' && (
                            <span className="text-xs text-red-600">
                              {Math.floor((Date.now() - new Date(invoice.dueDate).getTime()) / (1000 * 60 * 60 * 24))} dias
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(invoice.status)}
                          {getStatusBadge(invoice.status)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            title="Editar"
                            onClick={() => openEditDialog(invoice)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            title="Visualizar"
                            onClick={() => handleViewInvoice(invoice)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            title="Download"
                            onClick={() => handleDownloadInvoice(invoice)}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            title="Enviar por Email"
                            onClick={() => handleSendInvoice(invoice)}
                          >
                            <Send className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      ) : (
        <EmployeeLimitManager 
          companies={companies}
          onUpdateCompany={handleUpdateCompany}
        />
      )}
    </div>
  );
}
