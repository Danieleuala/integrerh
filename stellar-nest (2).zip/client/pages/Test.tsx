import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, AlertCircle, Info } from "lucide-react";
import { Link } from "react-router-dom";

export default function Test() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">
          🔧 Teste de Navegação - Integre RH
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Rotas Públicas */}
          <Card>
            <CardHeader>
              <CardTitle className="text-green-600 flex items-center">
                <CheckCircle className="w-5 h-5 mr-2" />
                Rotas Públicas (Funcionando)
              </CardTitle>
              <CardDescription>
                Estas rotas devem funcionar para todos os usuários
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link to="/">
                <Button variant="outline" className="w-full justify-start">
                  / - Página Inicial
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" className="w-full justify-start">
                  /login - Login
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="outline" className="w-full justify-start">
                  /register - Cadastro
                </Button>
              </Link>
              <Link to="/recuperar-senha">
                <Button variant="outline" className="w-full justify-start">
                  /recuperar-senha - Recuperar Senha
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Rotas Protegidas */}
          <Card>
            <CardHeader>
              <CardTitle className="text-orange-600 flex items-center">
                <AlertCircle className="w-5 h-5 mr-2" />
                Rotas Protegidas (Requer Login)
              </CardTitle>
              <CardDescription>
                Estas rotas redirecionam para login se não autenticado
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link to="/dashboard">
                <Button variant="outline" className="w-full justify-start">
                  /dashboard - Dashboard
                </Button>
              </Link>
              <Link to="/employees">
                <Button variant="outline" className="w-full justify-start">
                  /employees - Colaboradores
                </Button>
              </Link>
              <Link to="/jobs">
                <Button variant="outline" className="w-full justify-start">
                  /jobs - Vagas
                </Button>
              </Link>
              <Link to="/reports">
                <Button variant="outline" className="w-full justify-start">
                  /reports - Relatórios
                </Button>
              </Link>
              <Link to="/settings">
                <Button variant="outline" className="w-full justify-start">
                  /settings - Configurações
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Status das Integrações */}
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="text-blue-600 flex items-center">
                <Info className="w-5 h-5 mr-2" />
                Status das Integrações
              </CardTitle>
              <CardDescription>
                Configurações atuais da plataforma
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                  <h4 className="font-medium text-green-800">Banco de Dados</h4>
                  <p className="text-sm text-green-600">
                    {import.meta.env.VITE_USE_REAL_DATABASE === 'true' ? 'Supabase (Real)' : 'Mock (Demo)'}
                  </p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 className="font-medium text-blue-800">Email</h4>
                  <p className="text-sm text-blue-600">
                    {import.meta.env.VITE_RESEND_API_KEY ? 'Resend (Real)' : 'Mock (Demo)'}
                  </p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                  <h4 className="font-medium text-purple-800">WhatsApp</h4>
                  <p className="text-sm text-purple-600">
                    {import.meta.env.VITE_WHATSAPP_ACCESS_TOKEN ? 'Meta Business (Real)' : 'Mock (Demo)'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 text-center">
          <Link to="/">
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
              Voltar à Página Inicial
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
