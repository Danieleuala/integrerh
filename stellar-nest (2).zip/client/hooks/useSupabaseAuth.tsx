import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { User as SupabaseUser, Session } from '@supabase/supabase-js';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'rh_admin' | 'manager' | 'employee' | 'candidate';
  avatar?: string;
  department?: string;
  position?: string;
  joinDate?: string;
  phone?: string;
  employeeId?: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string, userData: Partial<User>) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<boolean>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function SupabaseAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) {
        loadUserProfile(session.user);
      } else {
        setIsLoading(false);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        
        if (session?.user) {
          await loadUserProfile(session.user);
        } else {
          setUser(null);
          setIsLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const loadUserProfile = async (supabaseUser: SupabaseUser) => {
    try {
      // Get user profile data
      const { data: profile, error: profileError } = await supabase
        .from('user_profiles')
        .select(`
          role,
          employee_id,
          employees (
            name,
            phone,
            position,
            department,
            join_date,
            avatar
          )
        `)
        .eq('id', supabaseUser.id)
        .single();

      if (profileError) {
        console.error('Error loading user profile:', profileError);
        // Create a basic user profile if none exists
        const newUser: User = {
          id: supabaseUser.id,
          email: supabaseUser.email || '',
          name: supabaseUser.user_metadata?.name || supabaseUser.email?.split('@')[0] || 'Usuário',
          role: 'employee'
        };
        setUser(newUser);
      } else {
        const employee = profile.employees as any;
        const userProfile: User = {
          id: supabaseUser.id,
          email: supabaseUser.email || '',
          name: employee?.name || supabaseUser.user_metadata?.name || 'Usuário',
          role: profile.role || 'employee',
          employeeId: profile.employee_id,
          phone: employee?.phone,
          position: employee?.position,
          department: employee?.department,
          joinDate: employee?.join_date,
          avatar: employee?.avatar || supabaseUser.user_metadata?.avatar_url
        };
        setUser(userProfile);
      }
    } catch (error) {
      console.error('Error in loadUserProfile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        setIsLoading(false);
        return { success: false, error: error.message };
      }

      // loadUserProfile will be called automatically via onAuthStateChange
      return { success: true };
    } catch (error) {
      setIsLoading(false);
      return { success: false, error: 'Erro inesperado durante o login' };
    }
  };

  const signup = async (
    email: string, 
    password: string, 
    userData: Partial<User>
  ): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: userData.name
          }
        }
      });

      if (error) {
        setIsLoading(false);
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Create user profile
        const { error: profileError } = await supabase
          .from('user_profiles')
          .insert({
            id: data.user.id,
            role: userData.role || 'employee'
          });

        if (profileError) {
          console.error('Error creating user profile:', profileError);
        }

        // If employee data is provided, create employee record
        if (userData.name && userData.department && userData.position) {
          const { data: employee, error: employeeError } = await supabase
            .from('employees')
            .insert({
              name: userData.name,
              email,
              phone: userData.phone || '',
              position: userData.position,
              department: userData.department,
              join_date: userData.joinDate || new Date().toISOString().split('T')[0],
              status: 'active',
              avatar: userData.avatar
            })
            .select()
            .single();

          if (!employeeError && employee) {
            // Update user profile with employee_id
            await supabase
              .from('user_profiles')
              .update({ employee_id: employee.id })
              .eq('id', data.user.id);
          }
        }
      }

      setIsLoading(false);
      return { success: true };
    } catch (error) {
      setIsLoading(false);
      return { success: false, error: 'Erro inesperado durante o cadastro' };
    }
  };

  const logout = async (): Promise<void> => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
  };

  const updateProfile = async (data: Partial<User>): Promise<boolean> => {
    if (!user) return false;

    try {
      // Update auth user metadata if needed
      if (data.name || data.avatar) {
        const { error: authError } = await supabase.auth.updateUser({
          data: {
            ...(data.name && { name: data.name }),
            ...(data.avatar && { avatar_url: data.avatar })
          }
        });

        if (authError) {
          console.error('Error updating auth user:', authError);
          return false;
        }
      }

      // Update employee record if exists
      if (user.employeeId) {
        const { error: employeeError } = await supabase
          .from('employees')
          .update({
            ...(data.name && { name: data.name }),
            ...(data.phone && { phone: data.phone }),
            ...(data.position && { position: data.position }),
            ...(data.department && { department: data.department }),
            ...(data.avatar && { avatar: data.avatar })
          })
          .eq('id', user.employeeId);

        if (employeeError) {
          console.error('Error updating employee:', employeeError);
          return false;
        }
      }

      // Update user profile role if needed
      if (data.role) {
        const { error: profileError } = await supabase
          .from('user_profiles')
          .update({ role: data.role })
          .eq('id', user.id);

        if (profileError) {
          console.error('Error updating user profile:', profileError);
          return false;
        }
      }

      // Update local user state
      setUser({ ...user, ...data });
      return true;
    } catch (error) {
      console.error('Error updating profile:', error);
      return false;
    }
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`
      });

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Erro inesperado ao enviar email de recuperação' };
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      login,
      signup,
      logout,
      updateProfile,
      resetPassword,
      isLoading
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useSupabaseAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useSupabaseAuth must be used within a SupabaseAuthProvider');
  }
  return context;
}

// Helper function to get role display name
export function getRoleDisplayName(role: User['role']): string {
  switch (role) {
    case 'rh_admin':
      return 'RH Administrador';
    case 'manager':
      return 'Gestor';
    case 'employee':
      return 'Colaborador';
    case 'candidate':
      return 'Candidato';
    default:
      return 'Usuário';
  }
}

// Helper function to check permissions
export function hasPermission(userRole: User['role'], requiredRoles: User['role'][]): boolean {
  return requiredRoles.includes(userRole);
}

// Password validation
export function validatePassword(password: string): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('A senha deve ter pelo menos 8 caracteres');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('A senha deve conter pelo menos uma letra maiúscula');
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push('A senha deve conter pelo menos uma letra minúscula');
  }
  
  if (!/\d/.test(password)) {
    errors.push('A senha deve conter pelo menos um número');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}
