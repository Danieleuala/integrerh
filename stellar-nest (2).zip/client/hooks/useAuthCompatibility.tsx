import { useRealAuth } from './useRealAuth';

// Compatibility layer to bridge old useAuth with new useRealAuth
export function useAuth() {
  const realAuth = useRealAuth();

  // Map new user structure to old interface
  const user = realAuth.user ? {
    id: realAuth.user.id,
    name: realAuth.user.name,
    email: realAuth.user.email,
    role: (realAuth.user.role === 'hr' ? 'rh_admin' : realAuth.user.role) as 'rh_admin' | 'manager' | 'employee' | 'candidate',
    avatar: realAuth.user.avatar,
    department: realAuth.user.department,
    position: realAuth.user.department, // Map department to position for compatibility
    joinDate: new Date().toISOString(), // Default for compatibility
    phone: '' // Default for compatibility
  } : null;

  // Compatibility login function that returns boolean
  const login = async (email: string, password?: string, role?: string): Promise<boolean> => {
    // If password is not provided, assume it's the old direct access format
    if (!password) {
      // For backward compatibility with direct access
      const defaultPasswords: { [key: string]: string } = {
        'admin@integrerh.com': 'admin123',
        'rh@integrerh.com': 'rh123',
        'gestor@integrerh.com': 'gestor123',
        'funcionario@integrerh.com': 'func123',
        'candidato@integrerh.com': 'cand123'
      };
      password = defaultPasswords[email] || 'default123';
    }

    const result = await realAuth.login(email, password, role);
    return result.success;
  };

  return {
    user,
    login,
    logout: realAuth.logout,
    updateProfile: (data: any) => {
      // For now, just log the update - implement later if needed
      console.log('Profile update requested:', data);
    },
    isLoading: realAuth.isLoading
  };
}

// Helper functions for role management
export function getRoleDisplayName(role: string): string {
  const roleNames: Record<string, string> = {
    'admin': 'Administrador',
    'rh_admin': 'RH Administrador',
    'hr': 'Recursos Humanos',
    'manager': 'Gestor',
    'employee': 'Funcionário',
    'candidate': 'Candidato'
  };
  return roleNames[role] || role;
}

// Helper function for permission checking - supports both old and new formats
export function hasPermission(userRoleOrUser: any, permissionOrRoles: string | string[]): boolean {
  // Handle new format: hasPermission(userRole, requiredRoles)
  if (typeof userRoleOrUser === 'string' && Array.isArray(permissionOrRoles)) {
    const userRole = userRoleOrUser;
    const requiredRoles = permissionOrRoles;

    if (!userRole) return false;

    // Map 'hr' to 'rh_admin' for compatibility
    const mappedRole = userRole === 'hr' ? 'rh_admin' : userRole;

    // Admin and rh_admin have all permissions
    if (mappedRole === 'admin' || mappedRole === 'rh_admin') return true;

    // Check if user role is in required roles list
    return requiredRoles.includes(mappedRole) || requiredRoles.includes(userRole);
  }

  // Handle old format: hasPermission(user, permission)
  if (typeof userRoleOrUser === 'object' && typeof permissionOrRoles === 'string') {
    const user = userRoleOrUser;
    const permission = permissionOrRoles;

    if (!user) return false;

    // Map 'hr' to 'rh_admin' for compatibility
    const mappedRole = user.role === 'hr' ? 'rh_admin' : user.role;

    // Admin and rh_admin have all permissions
    if (mappedRole === 'admin' || mappedRole === 'rh_admin') return true;

    // Simple permission mapping for compatibility
    const rolePermissions: Record<string, string[]> = {
      'rh_admin': ['users.read', 'users.write', 'jobs.read', 'jobs.write', 'evaluations.read', 'evaluations.write'],
      'manager': ['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write'],
      'employee': ['profile.read', 'profile.write', 'evaluations.read'],
      'candidate': ['jobs.read', 'applications.read', 'applications.write']
    };

    const userPermissions = rolePermissions[mappedRole] || [];
    return userPermissions.includes(permission);
  }

  return false;
}

// Export the real auth provider for the App component
export { AuthProvider } from './useRealAuth';
