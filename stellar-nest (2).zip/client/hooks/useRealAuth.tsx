import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'hr' | 'manager' | 'employee' | 'candidate';
  department?: string;
  avatar?: string;
  permissions: string[];
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string, role?: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  register: (userData: RegisterData) => Promise<{ success: boolean; message: string }>;
  forgotPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  resetPassword: (token: string, newPassword: string) => Promise<{ success: boolean; message: string }>;
  isLoading: boolean;
  isAuthenticated: boolean;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'hr' | 'manager' | 'employee' | 'candidate';
  department?: string;
  phone?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// API local apenas
const API_BASE_URL = 'http://localhost:3001/api';


export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedToken = localStorage.getItem('integrerh_token');
    const savedUser = localStorage.getItem('integrerh_user');
    
    if (savedToken && savedUser) {
      try {
        setToken(savedToken);
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Error parsing saved user data:', error);
        localStorage.removeItem('integrerh_token');
        localStorage.removeItem('integrerh_user');
      }
    }
    setIsLoading(false);
  }, []);

  // Verify token validity on app start
  useEffect(() => {
    if (token && (token.startsWith('auto-token-') || token.startsWith('auth-token-'))) {
      console.log('✅ Token verified');
    } else if (token) {
      console.warn('⚠️ Token inválido, fazendo logout');
      logout();
    }
  }, [token]);


  const login = async (email: string, password: string, role?: string): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true);

    try {
      console.log('🔐 Login attempt:', email, role);

      // Usuários válidos do sistema
      const validUsers = {
        'admin@integrerh.com': {
          id: 1, name: 'Administrador Sistema', email: 'admin@integrerh.com',
          role: 'admin', department: 'Administração Central', permissions: ['*'],
          password: 'admin123'
        },
        'rh@integrerh.com': {
          id: 2, name: 'Gestor de RH', email: 'rh@integrerh.com',
          role: 'hr', department: 'Recursos Humanos', permissions: ['*'],
          password: 'rh123'
        },
        'gestor@integrerh.com': {
          id: 3, name: 'Gestor de Equipe', email: 'gestor@integrerh.com',
          role: 'manager', department: 'Gestão', permissions: ['team_management', 'evaluations', 'reports'],
          password: 'gestor123'
        },
        'funcionario@integrerh.com': {
          id: 4, name: 'Funcionário', email: 'funcionario@integrerh.com',
          role: 'employee', department: 'Operacional', permissions: ['profile', 'trainings', 'evaluations'],
          password: 'func123'
        },
        'candidato@integrerh.com': {
          id: 5, name: 'Candidato', email: 'candidato@integrerh.com',
          role: 'candidate', department: 'Externo', permissions: ['jobs', 'applications'],
          password: 'cand123'
        }
      };

      const user = validUsers[email as keyof typeof validUsers];

      if (!user) {
        return { success: false, message: 'Email não encontrado no sistema' };
      }

      if (user.password !== password) {
        return { success: false, message: 'Senha incorreta' };
      }

      // Verificar se o papel corresponde (se especificado)
      if (role && user.role !== role) {
        return { success: false, message: 'Tipo de acesso não corresponde ao usuário' };
      }

      // Login bem-sucedido
      const token = `auth-token-${Date.now()}-${user.role}`;

      setToken(token);
      setUser(user);

      // Save to localStorage
      localStorage.setItem('integrerh_token', token);
      localStorage.setItem('integrerh_user', JSON.stringify(user));

      console.log('✅ Login success:', user);
      return { success: true, message: `Bem-vindo(a), ${user.name}!` };

    } catch (error: any) {
      console.error('❌ Login error:', error);
      return { success: false, message: 'Erro interno. Tente novamente.' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: RegisterData): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      if (response.ok) {
        return { success: true, message: 'Cadastro realizado com sucesso!' };
      } else {
        return { success: false, message: data.message || 'Erro ao cadastrar usuário' };
      }
    } catch (error) {
      console.error('Register error:', error);
      return { success: false, message: 'Erro de conexão. Tente novamente.' };
    } finally {
      setIsLoading(false);
    }
  };

  const forgotPassword = async (email: string): Promise<{ success: boolean; message: string }> => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok) {
        return { success: true, message: 'Email de recuperação enviado!' };
      } else {
        return { success: false, message: data.message || 'Erro ao enviar email' };
      }
    } catch (error) {
      console.error('Forgot password error:', error);
      return { success: false, message: 'Erro de conexão. Tente novamente.' };
    }
  };

  const resetPassword = async (token: string, newPassword: string): Promise<{ success: boolean; message: string }> => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token, newPassword }),
      });

      const data = await response.json();

      if (response.ok) {
        return { success: true, message: 'Senha redefinida com sucesso!' };
      } else {
        return { success: false, message: data.message || 'Erro ao redefinir senha' };
      }
    } catch (error) {
      console.error('Reset password error:', error);
      return { success: false, message: 'Erro de conexão. Tente novamente.' };
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('integrerh_token');
    localStorage.removeItem('integrerh_user');
  };

  const value: AuthContextType = {
    user,
    token,
    login,
    logout,
    register,
    forgotPassword,
    resetPassword,
    isLoading,
    isAuthenticated: !!user && !!token,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useRealAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useRealAuth must be used within an AuthProvider');
  }
  return context;
}

// Route protection HOC
export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  requiredRole?: string[]
) {
  return function AuthenticatedComponent(props: P) {
    const { user, isLoading } = useRealAuth();

    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-600"></div>
        </div>
      );
    }

    if (!user) {
      window.location.href = '/login';
      return null;
    }

    if (requiredRole && !requiredRole.includes(user.role)) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Acesso Negado</h1>
            <p className="text-gray-600">Você não tem permissão para acessar esta página.</p>
          </div>
        </div>
      );
    }

    return <Component {...props} />;
  };
}
