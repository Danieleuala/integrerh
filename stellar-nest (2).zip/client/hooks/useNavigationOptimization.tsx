import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

interface NavigationOptions {
  prefetch?: boolean;
  smooth?: boolean;
  showLoading?: boolean;
  loadingText?: string;
}

export const useNavigationOptimization = (options: NavigationOptions = {}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isNavigating, setIsNavigating] = useState(false);
  const navigationTimeout = useRef<NodeJS.Timeout>();
  const prefetchedRoutes = useRef<Set<string>>(new Set());

  const {
    prefetch = true,
    smooth = true,
    showLoading = true,
    loadingText = 'Carregando...'
  } = options;

  // Enhanced navigation with loading states
  const enhancedNavigate = useCallback((to: string, options?: any) => {
    if (showLoading) {
      setIsNavigating(true);
    }

    // Add smooth transition delay
    if (smooth) {
      navigationTimeout.current = setTimeout(() => {
        navigate(to, options);
        setIsNavigating(false);
      }, 150);
    } else {
      navigate(to, options);
      setIsNavigating(false);
    }
  }, [navigate, smooth, showLoading]);

  // Prefetch route data
  const prefetchRoute = useCallback((route: string) => {
    if (!prefetch || prefetchedRoutes.current.has(route)) return;

    // Simulate prefetching by warming up the route
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.href = route;
    document.head.appendChild(link);
    
    prefetchedRoutes.current.add(route);

    // Clean up after 30 seconds
    setTimeout(() => {
      if (document.head.contains(link)) {
        document.head.removeChild(link);
      }
    }, 30000);
  }, [prefetch]);

  // Handle navigation interruption
  useEffect(() => {
    return () => {
      if (navigationTimeout.current) {
        clearTimeout(navigationTimeout.current);
      }
    };
  }, []);

  // Reset navigation state when location changes
  useEffect(() => {
    setIsNavigating(false);
  }, [location.pathname]);

  return {
    enhancedNavigate,
    prefetchRoute,
    isNavigating,
    loadingText
  };
};

// Performance monitoring hook
export const usePerformanceMonitoring = () => {
  const [metrics, setMetrics] = useState({
    loadTime: 0,
    renderTime: 0,
    navigationCount: 0
  });

  const startTime = useRef(performance.now());
  const location = useLocation();

  useEffect(() => {
    const endTime = performance.now();
    const loadTime = endTime - startTime.current;
    
    setMetrics(prev => ({
      ...prev,
      loadTime,
      navigationCount: prev.navigationCount + 1
    }));

    startTime.current = endTime;
  }, [location.pathname]);

  useEffect(() => {
    // Monitor long tasks that could cause jank
    if ('PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'longtask') {
            console.warn('Long task detected:', entry);
          }
        }
      });

      try {
        observer.observe({ entryTypes: ['longtask'] });
      } catch (e) {
        // Long task API not supported
      }

      return () => observer.disconnect();
    }
  }, []);

  return metrics;
};

// Memory management hook
export const useMemoryOptimization = () => {
  const intervalRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    // Cleanup interval for garbage collection
    intervalRef.current = setInterval(() => {
      // Force garbage collection if available (development only)
      if (process.env.NODE_ENV === 'development' && 'gc' in window) {
        (window as any).gc();
      }

      // Clean up old localStorage entries
      try {
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000; // 24 hours
        
        Object.keys(localStorage).forEach(key => {
          if (key.startsWith('temp_') || key.startsWith('cache_')) {
            const item = localStorage.getItem(key);
            if (item) {
              try {
                const data = JSON.parse(item);
                if (data.timestamp && (now - data.timestamp) > maxAge) {
                  localStorage.removeItem(key);
                }
              } catch (e) {
                // Invalid JSON, remove it
                localStorage.removeItem(key);
              }
            }
          }
        });
      } catch (e) {
        console.warn('Error cleaning localStorage:', e);
      }
    }, 60000); // Run every minute

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const clearCache = useCallback(() => {
    try {
      // Clear temporary data
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith('temp_') || key.startsWith('cache_')) {
          localStorage.removeItem(key);
        }
      });

      // Clear session storage
      sessionStorage.clear();

      return true;
    } catch (e) {
      console.error('Error clearing cache:', e);
      return false;
    }
  }, []);

  return { clearCache };
};

// Smooth scroll hook for better UX
export const useSmoothScroll = () => {
  const scrollToTop = useCallback(() => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }, []);

  const scrollToElement = useCallback((elementId: string) => {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  }, []);

  const scrollToSection = useCallback((selector: string) => {
    const element = document.querySelector(selector);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  }, []);

  return {
    scrollToTop,
    scrollToElement,
    scrollToSection
  };
};
