// Re-export everything from the compatibility layer
export * from './useAuthCompatibility';
