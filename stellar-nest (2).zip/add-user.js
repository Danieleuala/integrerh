// Add your specific user to the database
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const bcrypt = require('bcryptjs');

async function addUser() {
  try {
    console.log('🔑 Adicionando usuário específico...');
    
    const db = await open({
      filename: './integrerh.db',
      driver: sqlite3.Database
    });

    // Your specific email and a test password
    const email = 'admdanielecruz@gmail.com';
    const password = 'daniele123';
    const hashedPassword = await bcrypt.hash(password, 12);

    // Check if user already exists
    const existingUser = await db.get('SELECT id FROM users WHERE email = ?', [email]);
    
    if (existingUser) {
      console.log('👤 Usuário já existe, atualizando senha...');
      await db.run('UPDATE users SET password = ? WHERE email = ?', [hashedPassword, email]);
    } else {
      console.log('👤 Criando novo usuário...');
      await db.run(`
        INSERT INTO users (name, email, password, role, department, permissions, email_verified, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        'Daniele Cruz',
        email,
        hashedPassword,
        'admin',
        'Administração',
        JSON.stringify(['*']),
        true,
        true
      ]);
    }

    console.log('✅ Usuário configurado com sucesso!');
    console.log('📧 Email:', email);
    console.log('🔑 Senha:', password);
    console.log('🎭 Role: admin');

    await db.close();
    
  } catch (error) {
    console.error('💥 Erro:', error.message);
  }
}

addUser();
