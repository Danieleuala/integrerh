const testLogins = [
  { email: 'admin@integrerh.com', password: 'admin123', role: 'admin' },
  { email: 'rh@integrerh.com', password: 'rh123', role: 'hr' },
  { email: 'gestor@integrerh.com', password: 'manager123', role: 'manager' },
  { email: 'funcionario@integrerh.com', password: 'employee123', role: 'employee' },
  { email: 'candidato@integrerh.com', password: 'candidate123', role: 'candidate' }
];

async function testLogin(credentials) {
  try {
    const response = await fetch('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ ${credentials.role.toUpperCase()} - Login OK:`, data.user.name);
      return true;
    } else {
      console.log(`❌ ${credentials.role.toUpperCase()} - Falhou:`, data.message);
      return false;
    }
  } catch (error) {
    console.log(`❌ ${credentials.role.toUpperCase()} - Erro:`, error.message);
    return false;
  }
}

async function testAllLogins() {
  console.log('🔍 Testando todos os logins...\n');
  
  let successCount = 0;
  for (const credentials of testLogins) {
    const success = await testLogin(credentials);
    if (success) successCount++;
    await new Promise(resolve => setTimeout(resolve, 100)); // pequena pausa
  }
  
  console.log(`\n📊 Resultado: ${successCount}/${testLogins.length} logins funcionando`);
  
  if (successCount === testLogins.length) {
    console.log('🎉 Todos os logins estão funcionando perfeitamente!');
  }
}

testAllLogins();
