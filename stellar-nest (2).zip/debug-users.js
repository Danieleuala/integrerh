const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const bcrypt = require('bcryptjs');
const path = require('path');

async function debugUsers() {
  try {
    console.log('🔍 Abrindo banco SQLite...');
    
    const db = await open({
      filename: path.join(process.cwd(), 'integrerh.db'),
      driver: sqlite3.Database
    });

    console.log('📋 Listando todos os usuários:');
    const users = await db.all('SELECT id, name, email, role, is_active, email_verified FROM users');
    
    console.table(users);

    // Testar senha do gestor
    console.log('\n🔐 Testando senha do gestor...');
    const gestorUser = await db.get('SELECT * FROM users WHERE email = ?', ['gestor@integrerh.com']);
    
    if (gestorUser) {
      console.log('✅ Usuário gestor encontrado:', {
        id: gestorUser.id,
        name: gestorUser.name,
        email: gestorUser.email,
        role: gestorUser.role,
        is_active: gestorUser.is_active
      });
      
      const isValidPassword = await bcrypt.compare('gestor123', gestorUser.password);
      console.log('🔑 Senha válida:', isValidPassword);
      
      if (!isValidPassword) {
        console.log('❌ Senha inválida! Recriando usuário...');
        
        // Deletar usuário existente
        await db.run('DELETE FROM users WHERE email = ?', ['gestor@integrerh.com']);
        
        // Recriar com nova senha
        const hashedPassword = await bcrypt.hash('gestor123', 12);
        await db.run(`
          INSERT INTO users (name, email, password, role, department, permissions, email_verified, is_active)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          'Gestor Equipe',
          'gestor@integrerh.com',
          hashedPassword,
          'manager',
          'Tecnologia',
          JSON.stringify(['users.read', 'jobs.read', 'evaluations.read', 'evaluations.write', 'trainings.read']),
          true,
          true
        ]);
        
        console.log('✅ Usuário gestor recriado com sucesso!');
      }
    } else {
      console.log('❌ Usuário gestor não encontrado!');
    }

    await db.close();
    console.log('\n✅ Verificação concluída!');
    
  } catch (error) {
    console.error('❌ Erro:', error);
  }
}

debugUsers();
