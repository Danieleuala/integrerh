# Configuração de Domínio Personalizado - integrerh.com.br

## ✅ Atualizações Realizadas

Foram atualizadas todas as referências do link do Fly.dev para usar o domínio personalizado `integrerh.com.br`:

### 🔧 Arquivos Atualizados:

1. **debug-login.js** - URL da API de produção
2. **test-all-logins.js** - URL da API de teste
3. **test-login-simple.html** - URLs de teste e produção
4. **server/app-sqlite.ts** - Configurações CORS
5. **nginx/nginx.conf** - Configuração do servidor web
6. **nginx/production.conf** - Configuração de produção
7. **package.json** - Homepage do projeto
8. **server/app-mysql.ts** - Configurações de domínio
9. **INTEGRACOES_IMPLEMENTADAS.md** - Email de integração
10. **server/routes/integrations.ts** - Configuração de email

### 🌐 Domínios Configurados:

- **Principal**: `https://integrerh.com.br`
- **WWW**: `https://www.integrerh.com.br`
- **API**: `https://api.integrerh.com.br`
- **Admin**: `https://admin.integrerh.com.br`

## 🚀 Próximos Passos

Para completar a configuração do domínio personalizado, você precisa:

### 1. Configuração DNS
Configure os seguintes registros DNS no seu provedor de domínio:

```
Tipo    Nome                Valor/Destino
A       integrerh.com.br    [IP do seu servidor]
CNAME   www                 integrerh.com.br
CNAME   api                 integrerh.com.br
CNAME   admin               integrerh.com.br
```

### 2. Certificados SSL
Configure certificados SSL para:
- `integrerh.com.br`
- `www.integrerh.com.br`
- `api.integrerh.com.br`
- `admin.integrerh.com.br`

### 3. Configuração do Servidor
Se estiver usando Fly.dev, adicione no `fly.toml`:

```toml
[[services.ports]]
port = 80
handlers = ["http"]
force_https = true

[[services.ports]]
port = 443
handlers = ["tls", "http"]

[http_service]
internal_port = 8080
force_https = true
auto_stop_machines = true
auto_start_machines = true

[[http_service.checks]]
grace_period = "10s"
interval = "30s"
method = "GET"
path = "/api/health"
port = 8080
timeout = "5s"
```

### 4. Variáveis de Ambiente
Configure as seguintes variáveis de ambiente:

```bash
FRONTEND_URL=https://integrerh.com.br
BACKEND_URL=https://api.integrerh.com.br
VITE_FROM_EMAIL=noreply@integrerh.com.br
VITE_FROM_NAME=Integre RH
```

### 5. Teste da Configuração
Após configurar o DNS e SSL, teste:

1. **Frontend**: `https://integrerh.com.br`
2. **API Health**: `https://api.integrerh.com.br/api/health`
3. **Login**: `https://integrerh.com.br/login`

## 📋 Checklist de Verificação

- [ ] DNS configurado e propagado
- [ ] Certificados SSL instalados
- [ ] Servidor configurado para o novo domínio
- [ ] Variáveis de ambiente atualizadas
- [ ] Testes de conectividade realizados
- [ ] Login funcionando corretamente
- [ ] API respondendo adequadamente

## 🔍 Troubleshooting

### Problemas Comuns:

1. **DNS não propagado**: Aguarde até 48h para propagação completa
2. **Erro de SSL**: Verifique se os certificados estão corretamente instalados
3. **CORS Error**: Confirme se as URLs estão corretas nos arquivos de configuração
4. **API não responde**: Verifique se o servidor está rodando na porta correta

### Comandos de Teste:

```bash
# Teste DNS
nslookup integrerh.com.br

# Teste SSL
curl -I https://integrerh.com.br

# Teste API
curl https://api.integrerh.com.br/api/health
```

## 📞 Suporte

Se precisar de ajuda adicional com a configuração, verifique:
- Logs do servidor
- Configurações do provedor de hospedagem
- Status do DNS
- Validade dos certificados SSL

---
*Todas as referências ao link do Fly.dev foram substituídas por integrerh.com.br conforme solicitado.*
